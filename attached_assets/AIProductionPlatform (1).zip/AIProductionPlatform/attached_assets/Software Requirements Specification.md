# Software Requirements Specification

## MLOps System for Classification and Regression Models

**Version 1.0**  
**May 16, 2025**

## 1. Introduction

### 1.1 Purpose

This Software Requirements Specification (SRS) document describes the requirements for an MLOps system that integrates with Azure ML, Azure Kubernetes Service (AKS), and AWS SageMaker, with SQL Server for persistence. The system is designed to support the full lifecycle of classification and regression machine learning models, from development to deployment and monitoring.

### 1.2 Scope

The MLOps system will provide comprehensive capabilities for model training, versioning, deployment, and monitoring across Azure and AWS environments. It will use SQL Server for persistent storage of model metadata, training metrics, and operational data. The system will support classification and regression models only, excluding NLP and computer vision models.

### 1.3 Definitions, Acronyms, and Abbreviations

- **MLOps**: Machine Learning Operations
- **AKS**: Azure Kubernetes Service
- **CI/CD**: Continuous Integration/Continuous Deployment
- **API**: Application Programming Interface
- **SDK**: Software Development Kit
- **RBAC**: Role-Based Access Control
- **TDE**: Transparent Data Encryption

### 1.4 References

1. Azure Machine Learning Documentation
2. AWS SageMaker Documentation
3. SQL Server 2025 Documentation
4. MLflow Documentation

### 1.5 Overview

The remainder of this document provides a detailed description of the MLOps system requirements. Section 2 gives an overall description of the system. Section 3 details the specific requirements, both functional and non-functional. Section 4 describes the data model and persistence strategy. Section 5 outlines external interfaces and integration points.

## 2. Overall Description

### 2.1 Product Perspective

The MLOps system is designed to bridge the gap between data science and operations teams, transforming machine learning from a series of one-off experiments into reliable, repeatable processes. It integrates with existing cloud platforms (Azure and AWS) and uses SQL Server for persistence, enabling organizations to operate with agility and confidence while meeting governance requirements.

### 2.2 Product Functions

The major functions of the MLOps system include:

1. Model registration and versioning
2. Automated training pipelines
3. Model deployment with blue-green strategies
4. Comprehensive monitoring and alerting
5. Data and dataset management
6. SQL Server persistence for all metadata and metrics

### 2.3 User Classes and Characteristics

The system is designed for the following user classes:

1. **Data Scientists**: Users who develop and train machine learning models
2. **MLOps Engineers**: Users who build and maintain the infrastructure for model deployment
3. **App Builders**: Users who integrate machine learning models into applications
4. **Operations Teams**: Users who monitor and maintain deployed models
5. **Compliance Officers**: Users who ensure models meet regulatory requirements

### 2.4 Operating Environment

The system will operate in a hybrid cloud environment spanning:

1. Azure Cloud (Azure ML and AKS)
2. AWS Cloud (SageMaker)
3. On-premises SQL Server (DESKTOP-I3D98TM)

### 2.5 Design and Implementation Constraints

1. The system must use SQL Server on DESKTOP-I3D98TM with Windows Authentication
2. The system must support classification and regression models only
3. The system must integrate with Azure ML and AWS SageMaker as the primary ML platforms
4. The system must use Python as the primary programming language for ML components

### 2.6 Assumptions and Dependencies

1. SQL Server is properly configured on DESKTOP-I3D98TM with appropriate permissions
2. Azure and AWS accounts are properly configured with necessary permissions
3. Network connectivity exists between on-premises SQL Server and cloud environments
4. Python 3.8+ is available in all environments

## 3. Specific Requirements

### 3.1 External Interface Requirements

#### 3.1.1 User Interfaces

The system shall provide:

1. Web-based dashboard for model management and monitoring
2. Command-line interfaces for automation and scripting
3. Python SDK for programmatic access to all system functions

#### 3.1.2 Hardware Interfaces

The system shall interface with:

1. Azure ML compute clusters
2. AKS clusters
3. AWS SageMaker instances
4. SQL Server hardware

#### 3.1.3 Software Interfaces

The system shall interface with:

1. Azure ML SDK
2. Azure Kubernetes Service
3. AWS SageMaker SDK
4. SQL Server via ODBC
5. Git repositories for version control
6. CI/CD systems (Azure DevOps, GitHub Actions)

#### 3.1.4 Communications Interfaces

The system shall support:

1. HTTPS for all web communications
2. TLS 1.2+ for all data transfers
3. SQL Server protocols for database access

### 3.2 Functional Requirements

#### 3.2.1 Model Management

1. The system shall provide model registration capabilities for both Azure ML and AWS SageMaker.
   - Priority: High
   - Input: Model artifacts, metadata
   - Processing: Register model in respective platform and SQL Server
   - Output: Model ID, registration confirmation

2. The system shall support versioning of machine learning models.
   - Priority: High
   - Input: Model version, previous model ID
   - Processing: Create new version in model registry
   - Output: New model version ID

3. The system shall track model metadata including algorithm, framework, and model type.
   - Priority: Medium
   - Input: Model metadata
   - Processing: Store in SQL Server
   - Output: Confirmation of metadata storage

4. The system shall maintain model lifecycle states (Development, Production, Archived).
   - Priority: Medium
   - Input: Model ID, desired state
   - Processing: Update model state in SQL Server
   - Output: Updated model state

5. The system shall support storage of model artifacts in both Azure Blob Storage and AWS S3.
   - Priority: High
   - Input: Model artifacts
   - Processing: Upload to appropriate storage
   - Output: Storage path

#### 3.2.2 Training Pipeline Management

1. The system shall support automated training pipelines in Azure ML.
   - Priority: High
   - Input: Training code, data, configuration
   - Processing: Execute training pipeline
   - Output: Trained model, metrics

2. The system shall support automated training pipelines in AWS SageMaker.
   - Priority: High
   - Input: Training code, data, configuration
   - Processing: Execute training job
   - Output: Trained model, metrics

3. The system shall track training run metadata including start time, end time, and status.
   - Priority: Medium
   - Input: Training run events
   - Processing: Update SQL Server records
   - Output: Updated training run status

4. The system shall record hyperparameters used in each training run.
   - Priority: High
   - Input: Hyperparameter values
   - Processing: Store in SQL Server
   - Output: Confirmation of storage

5. The system shall capture performance metrics for each training run.
   - Priority: High
   - Input: Training metrics
   - Processing: Store in SQL Server
   - Output: Confirmation of storage

6. The system shall support experiment tracking with tools like MLflow.
   - Priority: Medium
   - Input: Experiment data
   - Processing: Log to experiment tracking system
   - Output: Experiment ID

7. The system shall maintain training dataset lineage.
   - Priority: Medium
   - Input: Dataset information
   - Processing: Store relationships in SQL Server
   - Output: Lineage information

#### 3.2.3 Deployment Management

1. The system shall support model deployment to Azure ML endpoints.
   - Priority: High
   - Input: Model ID, deployment configuration
   - Processing: Deploy model to Azure ML
   - Output: Endpoint URL

2. The system shall support model deployment to AKS clusters.
   - Priority: High
   - Input: Model ID, AKS configuration
   - Processing: Deploy model to AKS
   - Output: Service URL

3. The system shall support model deployment to AWS SageMaker endpoints.
   - Priority: High
   - Input: Model ID, deployment configuration
   - Processing: Deploy model to SageMaker
   - Output: Endpoint URL

4. The system shall implement blue-green deployment strategies for zero-downtime updates.
   - Priority: Medium
   - Input: New model version, traffic shift configuration
   - Processing: Gradual traffic shifting
   - Output: Deployment status updates

5. The system shall track deployment metadata including environment, platform, and status.
   - Priority: Medium
   - Input: Deployment events
   - Processing: Update SQL Server records
   - Output: Updated deployment status

6. The system shall support auto-scaling configurations for deployed models.
   - Priority: Medium
   - Input: Scaling parameters
   - Processing: Configure auto-scaling
   - Output: Scaling configuration confirmation

#### 3.2.4 Monitoring and Observability

1. The system shall monitor deployed models for data drift.
   - Priority: High
   - Input: Production data samples
   - Processing: Compare with baseline distribution
   - Output: Drift metrics, alerts

2. The system shall monitor deployed models for performance degradation.
   - Priority: High
   - Input: Model predictions, ground truth
   - Processing: Calculate performance metrics
   - Output: Performance metrics, alerts

3. The system shall track operational metrics including latency and throughput.
   - Priority: Medium
   - Input: Request/response data
   - Processing: Calculate operational metrics
   - Output: Metrics, dashboards

4. The system shall implement alerting for model performance issues.
   - Priority: High
   - Input: Threshold configurations
   - Processing: Compare metrics to thresholds
   - Output: Alerts when thresholds are exceeded

5. The system shall log prediction requests and responses for auditing.
   - Priority: Medium
   - Input: Prediction traffic
   - Processing: Sample and store in SQL Server
   - Output: Queryable logs

#### 3.2.5 Data Management

1. The system shall track dataset metadata including version, format, and schema.
   - Priority: Medium
   - Input: Dataset information
   - Processing: Store in SQL Server
   - Output: Dataset ID

2. The system shall support dataset versioning.
   - Priority: Medium
   - Input: Dataset version information
   - Processing: Create new version in registry
   - Output: New dataset version ID

3. The system shall maintain dataset storage locations in both Azure and AWS.
   - Priority: Medium
   - Input: Dataset storage paths
   - Processing: Store in SQL Server
   - Output: Confirmation of storage

4. The system shall track dataset lineage for training, validation, and testing.
   - Priority: Medium
   - Input: Dataset usage information
   - Processing: Store relationships in SQL Server
   - Output: Lineage information

#### 3.2.6 SQL Server Persistence

1. The system shall store all model metadata in SQL Server.
   - Priority: High
   - Input: Model metadata
   - Processing: Insert/update SQL records
   - Output: Confirmation of storage

2. The system shall store all training run information in SQL Server.
   - Priority: High
   - Input: Training run data
   - Processing: Insert/update SQL records
   - Output: Confirmation of storage

3. The system shall store all deployment information in SQL Server.
   - Priority: High
   - Input: Deployment data
   - Processing: Insert/update SQL records
   - Output: Confirmation of storage

4. The system shall store all monitoring data in SQL Server.
   - Priority: Medium
   - Input: Monitoring metrics
   - Processing: Insert/update SQL records
   - Output: Confirmation of storage

5. The system shall provide stored procedures for common MLOps operations.
   - Priority: Medium
   - Input: Operation parameters
   - Processing: Execute stored procedures
   - Output: Operation results

6. The system shall integrate with both Azure ML and AWS SageMaker for data persistence.
   - Priority: High
   - Input: Platform-specific data
   - Processing: Transform and store in SQL Server
   - Output: Confirmation of storage

### 3.3 Non-Functional Requirements

#### 3.3.1 Performance Requirements

1. The system shall support high-throughput model inference with response times under 100ms.
2. The database shall handle high-volume logging of prediction requests.
3. The system shall implement appropriate indexing strategies for SQL Server tables.
4. The system shall support partitioning for large tables like PredictionLogs.

#### 3.3.2 Safety Requirements

1. The system shall implement validation checks before model deployment.
2. The system shall support rollback of failed deployments.
3. The system shall implement circuit breakers for failing model endpoints.

#### 3.3.3 Security Requirements

1. The system shall implement authentication for all API endpoints.
2. The system shall use Windows Authentication for SQL Server access.
3. The system shall implement role-based access control for model operations.
4. The system shall enable Transparent Data Encryption for data at rest.
5. The system shall protect sensitive data using column-level encryption.
6. The system shall implement audit logging for database access.

#### 3.3.4 Software Quality Attributes

1. **Reliability**: The system shall maintain 99.9% uptime for production model endpoints.
2. **Availability**: The system shall implement high availability for critical components.
3. **Maintainability**: The system shall follow consistent coding standards and provide comprehensive documentation.
4. **Portability**: The system shall support deployment across multiple cloud environments.
5. **Scalability**: The system shall handle increasing load through auto-scaling.
6. **Interoperability**: The system shall integrate with both Azure and AWS services.
7. **Testability**: The system shall support automated testing of all components.
8. **Usability**: The system shall provide intuitive interfaces for all user classes.

## 4. Data Model

### 4.1 Database Schema

The system shall implement the following database schema in SQL Server:

#### 4.1.1 Models Table

```sql
CREATE TABLE Models (
    ModelID INT IDENTITY(1,1) PRIMARY KEY,
    ModelName NVARCHAR(100) NOT NULL,
    ModelVersion NVARCHAR(20) NOT NULL,
    Description NVARCHAR(500) NULL,
    Algorithm NVARCHAR(100) NOT NULL,
    Framework NVARCHAR(50) NOT NULL,
    CreatedBy NVARCHAR(100) NOT NULL,
    CreatedDate DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UpdatedDate DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    Status NVARCHAR(20) NOT NULL DEFAULT 'Development',
    S3Path NVARCHAR(500) NULL,
    AzureBlobPath NVARCHAR(500) NULL,
    RegistryPath NVARCHAR(500) NULL,
    ModelType NVARCHAR(50) NOT NULL,
    IsProduction BIT NOT NULL DEFAULT 0,
    IsArchived BIT NOT NULL DEFAULT 0,
    CONSTRAINT UQ_ModelNameVersion UNIQUE(ModelName, ModelVersion)
);
```

#### 4.1.2 TrainingRuns Table

```sql
CREATE TABLE TrainingRuns (
    RunID INT IDENTITY(1,1) PRIMARY KEY,
    ModelID INT NOT NULL,
    RunName NVARCHAR(100) NOT NULL,
    StartTime DATETIME2 NOT NULL,
    EndTime DATETIME2 NULL,
    Status NVARCHAR(20) NOT NULL DEFAULT 'Running',
    Platform NVARCHAR(50) NOT NULL,
    ComputeTarget NVARCHAR(100) NOT NULL,
    TrainingDatasetID INT NOT NULL,
    ValidationDatasetID INT NULL,
    TestDatasetID INT NULL,
    ExperimentID NVARCHAR(100) NULL,
    RunBy NVARCHAR(100) NOT NULL,
    GitCommitHash NVARCHAR(50) NULL,
    GitRepository NVARCHAR(200) NULL,
    RunTags NVARCHAR(MAX) NULL,
    FOREIGN KEY (ModelID) REFERENCES Models(ModelID),
    FOREIGN KEY (TrainingDatasetID) REFERENCES Datasets(DatasetID),
    FOREIGN KEY (ValidationDatasetID) REFERENCES Datasets(DatasetID),
    FOREIGN KEY (TestDatasetID) REFERENCES Datasets(DatasetID)
);
```

#### 4.1.3 Hyperparameters Table

```sql
CREATE TABLE Hyperparameters (
    HyperparameterID INT IDENTITY(1,1) PRIMARY KEY,
    RunID INT NOT NULL,
    ParameterName NVARCHAR(100) NOT NULL,
    ParameterValue NVARCHAR(MAX) NOT NULL,
    ParameterType NVARCHAR(50) NOT NULL,
    FOREIGN KEY (RunID) REFERENCES TrainingRuns(RunID),
    CONSTRAINT UQ_RunParameter UNIQUE(RunID, ParameterName)
);
```

#### 4.1.4 Metrics Table

```sql
CREATE TABLE Metrics (
    MetricID INT IDENTITY(1,1) PRIMARY KEY,
    RunID INT NOT NULL,
    MetricName NVARCHAR(100) NOT NULL,
    MetricValue FLOAT NOT NULL,
    Timestamp DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    Step INT NULL,
    FOREIGN KEY (RunID) REFERENCES TrainingRuns(RunID),
    CONSTRAINT UQ_RunMetricStep UNIQUE(RunID, MetricName, Step)
);
```

#### 4.1.5 Datasets Table

```sql
CREATE TABLE Datasets (
    DatasetID INT IDENTITY(1,1) PRIMARY KEY,
    DatasetName NVARCHAR(100) NOT NULL,
    DatasetVersion NVARCHAR(20) NOT NULL,
    Description NVARCHAR(500) NULL,
    CreatedDate DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    CreatedBy NVARCHAR(100) NOT NULL,
    S3Path NVARCHAR(500) NULL,
    AzureBlobPath NVARCHAR(500) NULL,
    DataFormat NVARCHAR(50) NOT NULL,
    RowCount BIGINT NULL,
    FeatureCount INT NULL,
    SchemaDefinition NVARCHAR(MAX) NULL,
    DatasetTags NVARCHAR(MAX) NULL,
    CONSTRAINT UQ_DatasetNameVersion UNIQUE(DatasetName, DatasetVersion)
);
```

#### 4.1.6 Deployments Table

```sql
CREATE TABLE Deployments (
    DeploymentID INT IDENTITY(1,1) PRIMARY KEY,
    ModelID INT NOT NULL,
    DeploymentName NVARCHAR(100) NOT NULL,
    Environment NVARCHAR(50) NOT NULL,
    Platform NVARCHAR(50) NOT NULL,
    EndpointURL NVARCHAR(500) NULL,
    DeployedBy NVARCHAR(100) NOT NULL,
    DeployedDate DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    Status NVARCHAR(20) NOT NULL DEFAULT 'Deploying',
    ComputeConfiguration NVARCHAR(MAX) NULL,
    ScalingConfiguration NVARCHAR(MAX) NULL,
    LastUpdatedDate DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    DeploymentTags NVARCHAR(MAX) NULL,
    FOREIGN KEY (ModelID) REFERENCES Models(ModelID)
);
```

#### 4.1.7 ModelMonitoring Table

```sql
CREATE TABLE ModelMonitoring (
    MonitoringID INT IDENTITY(1,1) PRIMARY KEY,
    DeploymentID INT NOT NULL,
    MonitoringType NVARCHAR(50) NOT NULL,
    MonitoringTime DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    AlertStatus NVARCHAR(20) NOT NULL DEFAULT 'Normal',
    MetricName NVARCHAR(100) NOT NULL,
    MetricValue FLOAT NOT NULL,
    ThresholdValue FLOAT NULL,
    Details NVARCHAR(MAX) NULL,
    FOREIGN KEY (DeploymentID) REFERENCES Deployments(DeploymentID)
);
```

#### 4.1.8 PredictionLogs Table

```sql
CREATE TABLE PredictionLogs (
    LogID INT IDENTITY(1,1) PRIMARY KEY,
    DeploymentID INT NOT NULL,
    RequestTime DATETIME2 NOT NULL,
    ResponseTime DATETIME2 NOT NULL,
    LatencyMs INT NOT NULL,
    RequestPayload NVARCHAR(MAX) NOT NULL,
    ResponsePayload NVARCHAR(MAX) NOT NULL,
    StatusCode INT NOT NULL,
    ClientIP NVARCHAR(50) NULL,
    UserAgent NVARCHAR(500) NULL,
    FOREIGN KEY (DeploymentID) REFERENCES Deployments(DeploymentID)
);
```

### 4.2 Data Dictionary

| Entity | Attribute | Description | Data Type | Constraints |
|--------|-----------|-------------|-----------|-------------|
| Models | ModelID | Unique identifier for the model | INT | Primary Key, Auto-increment |
| Models | ModelName | Name of the model | NVARCHAR(100) | Not Null |
| Models | ModelVersion | Version of the model | NVARCHAR(20) | Not Null |
| Models | Algorithm | Algorithm used in the model | NVARCHAR(100) | Not Null |
| Models | Framework | Framework used to build the model | NVARCHAR(50) | Not Null |
| Models | ModelType | Type of model (Classification, Regression) | NVARCHAR(50) | Not Null |
| TrainingRuns | RunID | Unique identifier for the training run | INT | Primary Key, Auto-increment |
| TrainingRuns | ModelID | Reference to the model | INT | Foreign Key |
| TrainingRuns | Platform | Platform used for training | NVARCHAR(50) | Not Null |
| Hyperparameters | HyperparameterID | Unique identifier for the hyperparameter | INT | Primary Key, Auto-increment |
| Hyperparameters | RunID | Reference to the training run | INT | Foreign Key |
| Hyperparameters | ParameterName | Name of the hyperparameter | NVARCHAR(100) | Not Null |
| Metrics | MetricID | Unique identifier for the metric | INT | Primary Key, Auto-increment |
| Metrics | RunID | Reference to the training run | INT | Foreign Key |
| Metrics | MetricName | Name of the metric | NVARCHAR(100) | Not Null |
| Metrics | MetricValue | Value of the metric | FLOAT | Not Null |
| Datasets | DatasetID | Unique identifier for the dataset | INT | Primary Key, Auto-increment |
| Datasets | DatasetName | Name of the dataset | NVARCHAR(100) | Not Null |
| Datasets | DatasetVersion | Version of the dataset | NVARCHAR(20) | Not Null |
| Deployments | DeploymentID | Unique identifier for the deployment | INT | Primary Key, Auto-increment |
| Deployments | ModelID | Reference to the model | INT | Foreign Key |
| Deployments | Environment | Deployment environment | NVARCHAR(50) | Not Null |
| Deployments | Platform | Deployment platform | NVARCHAR(50) | Not Null |
| ModelMonitoring | MonitoringID | Unique identifier for the monitoring record | INT | Primary Key, Auto-increment |
| ModelMonitoring | DeploymentID | Reference to the deployment | INT | Foreign Key |
| ModelMonitoring | MonitoringType | Type of monitoring | NVARCHAR(50) | Not Null |
| PredictionLogs | LogID | Unique identifier for the log | INT | Primary Key, Auto-increment |
| PredictionLogs | DeploymentID | Reference to the deployment | INT | Foreign Key |
| PredictionLogs | LatencyMs | Request-response latency in milliseconds | INT | Not Null |

## 5. External Interfaces

### 5.1 Azure ML Integration

The system shall integrate with Azure ML using the Azure ML SDK:

```python
from azure.ai.ml import MLClient
from azure.ai.ml.entities import Model
from azure.identity import DefaultAzureCredential
import pyodbc
import json
import datetime

# SQL Server connection
conn_str = 'DRIVER={ODBC Driver 18 for SQL Server};SERVER=DESKTOP-I3D98TM;DATABASE=MLOps;Trusted_Connection=yes;'
conn = pyodbc.connect(conn_str)
cursor = conn.cursor()

# Azure ML client
ml_client = MLClient(
    DefaultAzureCredential(),
    subscription_id="<subscription_id>",
    resource_group_name="<resource_group>",
    workspace_name="<workspace_name>"
)

def register_model_in_sql(model_name, model_version, description, algorithm, framework, 
                         azure_path, model_type):
    """Register a model in SQL Server after registering in Azure ML"""
    cursor.execute("""
        INSERT INTO Models (ModelName, ModelVersion, Description, Algorithm, Framework, 
                           CreatedBy, AzureBlobPath, ModelType)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, model_name, model_version, description, algorithm, framework, 
         "current_user", azure_path, model_type)
    conn.commit()
    
    # Get the ModelID of the inserted record
    cursor.execute("SELECT @@IDENTITY")
    model_id = cursor.fetchone()[0]
    return model_id
```

### 5.2 AWS SageMaker Integration

The system shall integrate with AWS SageMaker using the SageMaker Python SDK:

```python
import boto3
import sagemaker
from sagemaker.session import Session
import pyodbc
import json
import datetime

# SQL Server connection
conn_str = 'DRIVER={ODBC Driver 18 for SQL Server};SERVER=DESKTOP-I3D98TM;DATABASE=MLOps;Trusted_Connection=yes;'
conn = pyodbc.connect(conn_str)
cursor = conn.cursor()

# SageMaker session
sagemaker_session = Session()
sm_client = boto3.client('sagemaker')

def register_model_in_sql(model_name, model_version, description, algorithm, framework, 
                         s3_path, model_type):
    """Register a model in SQL Server after registering in SageMaker"""
    cursor.execute("""
        INSERT INTO Models (ModelName, ModelVersion, Description, Algorithm, Framework, 
                           CreatedBy, S3Path, ModelType)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, model_name, model_version, description, algorithm, framework, 
         "current_user", s3_path, model_type)
    conn.commit()
    
    # Get the ModelID of the inserted record
    cursor.execute("SELECT @@IDENTITY")
    model_id = cursor.fetchone()[0]
    return model_id
```

### 5.3 SQL Server Stored Procedures

The system shall implement the following stored procedures:

```sql
-- Get Latest Model Version
CREATE PROCEDURE GetLatestModelVersion
    @ModelName NVARCHAR(100)
AS
BEGIN
    SELECT TOP 1 ModelID, ModelName, ModelVersion, Description, Algorithm, Framework, 
                 CreatedDate, Status, ModelType
    FROM Models
    WHERE ModelName = @ModelName
    ORDER BY CAST(REPLACE(ModelVersion, 'v', '') AS FLOAT) DESC;
END;

-- Get Model Performance History
CREATE PROCEDURE GetModelPerformanceHistory
    @ModelName NVARCHAR(100),
    @MetricName NVARCHAR(100) = 'accuracy'
AS
BEGIN
    SELECT m.ModelName, m.ModelVersion, tr.RunName, tr.StartTime, 
           met.MetricName, met.MetricValue
    FROM Models m
    JOIN TrainingRuns tr ON m.ModelID = tr.ModelID
    JOIN Metrics met ON tr.RunID = met.RunID
    WHERE m.ModelName = @ModelName
      AND met.MetricName = @MetricName
    ORDER BY tr.StartTime DESC;
END;

-- Compare Model Versions
CREATE PROCEDURE CompareModelVersions
    @ModelName NVARCHAR(100),
    @Version1 NVARCHAR(20),
    @Version2 NVARCHAR(20)
AS
BEGIN
    -- Get model IDs
    DECLARE @ModelID1 INT, @ModelID2 INT;
    
    SELECT @ModelID1 = ModelID FROM Models 
    WHERE ModelName = @ModelName AND ModelVersion = @Version1;
    
    SELECT @ModelID2 = ModelID FROM Models 
    WHERE ModelName = @ModelName AND ModelVersion = @Version2;
    
    -- Get latest run IDs for each model
    DECLARE @RunID1 INT, @RunID2 INT;
    
    SELECT TOP 1 @RunID1 = RunID FROM TrainingRuns 
    WHERE ModelID = @ModelID1 ORDER BY StartTime DESC;
    
    SELECT TOP 1 @RunID2 = RunID FROM TrainingRuns 
    WHERE ModelID = @ModelID2 ORDER BY StartTime DESC;
    
    -- Compare hyperparameters
    SELECT 'Hyperparameters' AS ComparisonType, 
           h1.ParameterName, 
           h1.ParameterValue AS Version1Value, 
           h2.ParameterValue AS Version2Value
    FROM Hyperparameters h1
    FULL OUTER JOIN Hyperparameters h2 
        ON h1.ParameterName = h2.ParameterName AND h2.RunID = @RunID2
    WHERE h1.RunID = @RunID1
    
    UNION ALL
    
    -- Compare metrics
    SELECT 'Metrics' AS ComparisonType, 
           m1.MetricName, 
           CAST(m1.MetricValue AS NVARCHAR(100)) AS Version1Value, 
           CAST(m2.MetricValue AS NVARCHAR(100)) AS Version2Value
    FROM Metrics m1
    FULL OUTER JOIN Metrics m2 
        ON m1.MetricName = m2.MetricName AND m2.RunID = @RunID2
    WHERE m1.RunID = @RunID1;
END;
```

## 6. Appendices

### 6.1 Assumptions and Dependencies

1. SQL Server is properly configured on DESKTOP-I3D98TM with appropriate permissions
2. Azure and AWS accounts are properly configured with necessary permissions
3. Network connectivity exists between on-premises SQL Server and cloud environments
4. Python 3.8+ is available in all environments

### 6.2 Acronyms and Abbreviations

- **MLOps**: Machine Learning Operations
- **AKS**: Azure Kubernetes Service
- **CI/CD**: Continuous Integration/Continuous Deployment
- **API**: Application Programming Interface
- **SDK**: Software Development Kit
- **RBAC**: Role-Based Access Control
- **TDE**: Transparent Data Encryption

### 6.3 References

1. Azure Machine Learning Documentation
2. AWS SageMaker Documentation
3. SQL Server 2025 Documentation
4. MLflow Documentation
