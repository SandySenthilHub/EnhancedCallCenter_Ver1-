#!/usr/bin/env tsx
/**
 * Script to migrate the application from PostgreSQL to Azure SQL Server
 * This will:
 * 1. Update environment variables with SQL Server connection details
 * 2. Create the SQL Server schema
 * 3. Restart the application to use SQL Server
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import readline from 'readline';

// Connection details for Azure SQL Server
const sqlServerConfig = {
  server: process.env.AZURE_SQL_SERVER || 'callcenter1.database.windows.net',
  database: process.env.AZURE_SQL_DATABASE || 'AImodel',
  user: process.env.AZURE_SQL_USER || 'shahul',
  password: process.env.AZURE_SQL_PASSWORD || 'apple123!@#',
};

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Function to prompt the user
function prompt(question: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
}

// Main migration function
async function migrateToAzureSql() {
  try {
    console.log('\n=== Migrating to Azure SQL Server ===\n');
    
    // Confirm migration
    console.log('Current SQL Server configuration:');
    console.log(`Server: ${sqlServerConfig.server}`);
    console.log(`Database: ${sqlServerConfig.database}`);
    console.log(`User: ${sqlServerConfig.user}`);
    console.log('\nThis migration will:');
    console.log('1. Update environment variables for SQL Server connection');
    console.log('2. Create the SQL Server database schema');
    console.log('3. Update application code to use SQL Server');
    
    const confirm = await prompt('\nDo you want to proceed with the migration? (yes/no): ');
    if (confirm.toLowerCase() !== 'yes') {
      console.log('Migration cancelled');
      rl.close();
      return;
    }
    
    // Step 1: Update environment variables
    console.log('\n--- Step 1: Updating environment variables ---');
    process.env.AZURE_SQL_SERVER = sqlServerConfig.server;
    process.env.AZURE_SQL_DATABASE = sqlServerConfig.database;
    process.env.AZURE_SQL_USER = sqlServerConfig.user;
    process.env.AZURE_SQL_PASSWORD = sqlServerConfig.password;
    
    console.log('Environment variables set successfully');
    
    // Step 2: Execute SQL Server schema script
    console.log('\n--- Step 2: Creating SQL Server schema ---');
    try {
      execSync('npx tsx server/execute-sqlserver-schema.ts', { stdio: 'inherit' });
      console.log('SQL Server schema created successfully');
    } catch (error) {
      console.error('Error creating SQL Server schema:', error);
      console.log('Migration will continue, but you may need to run the schema script manually');
    }
    
    // Step 3: Copy the SQL Server database files over the PostgreSQL ones
    console.log('\n--- Step 3: Updating application code ---');
    
    const filesToCopy = [
      { src: 'server/db.ts.new', dest: 'server/db.ts' },
      { src: 'server/storage.ts.new', dest: 'server/storage.ts' },
      { src: 'server/auth.ts.new', dest: 'server/auth.ts' },
      { src: 'shared/schema.ts.new', dest: 'shared/schema.ts' }
    ];
    
    // Make backups first
    for (const file of filesToCopy) {
      if (fs.existsSync(file.dest)) {
        fs.copyFileSync(file.dest, `${file.dest}.bak`);
        console.log(`Backed up ${file.dest} to ${file.dest}.bak`);
      }
    }
    
    // Copy new files
    for (const file of filesToCopy) {
      if (fs.existsSync(file.src)) {
        fs.copyFileSync(file.src, file.dest);
        console.log(`Copied ${file.src} to ${file.dest}`);
      } else {
        console.warn(`Warning: ${file.src} does not exist and was not copied`);
      }
    }
    
    console.log('\n=== Migration to Azure SQL Server completed ===');
    console.log('\nTo complete the migration:');
    console.log('1. Restart the application');
    console.log('2. Test login functionality to ensure sessions are persisted');
    
    rl.close();
  } catch (error) {
    console.error('Error during migration:', error);
    rl.close();
    process.exit(1);
  }
}

// Run the migration
migrateToAzureSql();