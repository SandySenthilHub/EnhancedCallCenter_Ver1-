#!/bin/bash
# Script to migrate from PostgreSQL to Azure SQL Server

echo "Running migration to Azure SQL Server..."
npx tsx migrate-to-azure-sql.ts