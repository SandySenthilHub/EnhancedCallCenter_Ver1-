-- Import CSV data directly to the algorithm_dependencies table

-- boto3
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('boto3', '1.35.24', 'AWS SDK', 'pip', 'boto3 - AWS SDK library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- numpy
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('numpy', '2.1.1', 'Scientific Computing', 'pip', 'numpy - Scientific Computing library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- pandas
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('pandas', '2.2.3', 'Data Analysis', 'pip', 'pandas - Data Analysis library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- requests
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('requests', '2.32.3', 'HTTP Requests', 'pip', 'requests - HTTP Requests library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- tensorflow
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('tensorflow', '2.17.0', 'Machine Learning', 'pip', 'tensorflow - Machine Learning library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- torch
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('torch', '2.4.1', 'Machine Learning', 'pip', 'torch - Machine Learning library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- scikit-learn
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('scikit-learn', '1.5.2', 'Machine Learning', 'pip', 'scikit-learn - Machine Learning library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- matplotlib
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('matplotlib', '3.9.2', 'Data Visualization', 'pip', 'matplotlib - Data Visualization library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- seaborn
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('seaborn', '0.13.2', 'Data Visualization', 'pip', 'seaborn - Data Visualization library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- flask
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('flask', '3.0.3', 'Web Framework', 'pip', 'flask - Web Framework library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- django
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('django', '5.1.1', 'Web Framework', 'pip', 'django - Web Framework library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- sqlalchemy
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('sqlalchemy', '2.0.35', 'ORM', 'pip', 'sqlalchemy - ORM library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- pytest
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('pytest', '8.3.3', 'Testing', 'pip', 'pytest - Testing library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- beautifulsoup4
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('beautifulsoup4', '4.12.3', 'Web Scraping', 'pip', 'beautifulsoup4 - Web Scraping library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- opencv-python
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('opencv-python', '4.10.0', 'Computer Vision', 'pip', 'opencv-python - Computer Vision library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- pillow
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('pillow', '10.4.0', 'Image Processing', 'pip', 'pillow - Image Processing library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- scipy
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('scipy', '1.14.1', 'Scientific Computing', 'pip', 'scipy - Scientific Computing library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- jupyter
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('jupyter', '1.1.1', 'Interactive Computing', 'pip', 'jupyter - Interactive Computing library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- fastapi
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('fastapi', '0.115.0', 'Web Framework', 'pip', 'fastapi - Web Framework library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- httpx
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('httpx', '0.27.2', 'HTTP Client', 'pip', 'httpx - HTTP Client library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- Add more libraries as needed
-- To use this script, run:
-- psql -f import-libraries.sql

-- For larger imports, consider creating a CSV file and using COPY command

-- Example of adding 10 more libraries:

-- aiohttp
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('aiohttp', '3.10.5', 'Asynchronous HTTP', 'pip', 'aiohttp - Asynchronous HTTP library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- asyncpg
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('asyncpg', '0.29.0', 'Database', 'pip', 'asyncpg - Database library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- black
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('black', '24.8.0', 'Code Formatting', 'pip', 'black - Code Formatting library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- celery
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('celery', '5.4.0', 'Task Queue', 'pip', 'celery - Task Queue library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- click
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('click', '8.1.7', 'Command Line Interface', 'pip', 'click - Command Line Interface library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- dask
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('dask', '2024.9.0', 'Parallel Computing', 'pip', 'dask - Parallel Computing library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- faker
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('faker', '28.4.1', 'Data Generation', 'pip', 'faker - Data Generation library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- gensim
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('gensim', '4.3.3', 'Natural Language Processing', 'pip', 'gensim - Natural Language Processing library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- gradio
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('gradio', '4.44.0', 'Web Interface', 'pip', 'gradio - Web Interface library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;

-- h5py
INSERT INTO algorithm_dependencies (name, version, category, package_manager, description)
VALUES ('h5py', '3.11.0', 'Data Storage', 'pip', 'h5py - Data Storage library')
ON CONFLICT (name) 
DO UPDATE SET version = EXCLUDED.version, category = EXCLUDED.category;