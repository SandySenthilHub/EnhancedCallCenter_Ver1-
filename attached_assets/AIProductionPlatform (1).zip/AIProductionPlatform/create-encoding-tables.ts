import { getPool } from './server/db';

async function createEncodingTables() {
  try {
    console.log('Creating data encoding tables...');
    const pool = await getPool();
    
    // SQL Server specific syntax for table creation
    const createTablesQuery = `
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'data_encoding_configs')
      BEGIN
        CREATE TABLE data_encoding_configs (
          id INT IDENTITY(1,1) PRIMARY KEY,
          name NVARCHAR(255) NOT NULL,
          status NVARCHAR(50) DEFAULT 'draft',
          config NVARCHAR(MAX),
          user_id INT,
          created_at DATETIME DEFAULT GETDATE(),
          updated_at DATETIME DEFAULT GETDATE(),
          data_source_id INT,
          description NVARCHAR(500),
          encoding_type NVARCHAR(50) NOT NULL,
          source_column NVARCHAR(255) NOT NULL,
          output_columns NVARCHAR(MAX),
          file_id INT
        );
        PRINT 'Created data_encoding_configs table';
      END

      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'data_encoding_history')
      BEGIN
        CREATE TABLE data_encoding_history (
          id INT IDENTITY(1,1) PRIMARY KEY,
          status NVARCHAR(50) DEFAULT 'completed',
          user_id INT,
          metrics NVARCHAR(MAX),
          config_id INT NOT NULL,
          applied_at DATETIME DEFAULT GETDATE(),
          results NVARCHAR(MAX)
        );
        PRINT 'Created data_encoding_history table';
      END
    `;
    
    await pool.request().query(createTablesQuery);
    console.log('Data encoding tables creation completed');
  } catch (error) {
    console.error('Error creating data encoding tables:', error);
    throw error;
  }
}

createEncodingTables()
  .then(() => {
    console.log('Successfully created data encoding tables');
    process.exit(0);
  })
  .catch(err => {
    console.error('Failed to create data encoding tables:', err);
    process.exit(1);
  });
