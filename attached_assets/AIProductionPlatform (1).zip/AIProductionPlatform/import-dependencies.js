// Import dependencies script
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { Pool } = require('@neondatabase/serverless');

// CSV content from user's file
const csvContent = `name,version,category
boto3,1.35.24,AWS SDK
numpy,2.1.1,Scientific Computing
pandas,2.2.3,Data Analysis
requests,2.32.3,HTTP Requests
tensorflow,2.17.0,Machine Learning
torch,2.4.1,Machine Learning
scikit-learn,1.5.2,Machine Learning
matplotlib,3.9.2,Data Visualization
seaborn,0.13.2,Data Visualization
flask,3.0.3,Web Framework
django,5.1.1,Web Framework
sqlalchemy,2.0.35,ORM
pytest,8.3.3,Testing
beautifulsoup4,4.12.3,Web Scraping
opencv-python,4.10.0,Computer Vision
pillow,10.4.0,Image Processing
scipy,1.14.1,Scientific Computing
jupyter,1.1.1,Interactive Computing
fastapi,0.115.0,Web Framework
httpx,0.27.2,HTTP Client
aiohttp,3.10.5,Asynchronous HTTP
asyncpg,0.29.0,Database
black,24.8.0,Code Formatting
celery,5.4.0,Task Queue
click,8.1.7,Command Line Interface
dask,2024.9.0,Parallel Computing
faker,28.4.1,Data Generation
gensim,4.3.3,Natural Language Processing
gradio,4.44.0,Web Interface
h5py,3.11.0,Data Storage
httplib2,0.22.0,HTTP Client
isort,5.13.2,Code Formatting
jinja2,3.1.4,Templating
keras,3.5.0,Machine Learning
langchain,0.3.1,Natural Language Processing
lxml,5.3.0,XML Processing
mypy,1.11.2,Static Typing
networkx,3.3,Graph Analysis
nltk,3.9.1,Natural Language Processing
numba,0.60.0,Performance Optimization
openpyxl,3.1.5,Excel Processing
orjson,3.10.7,JSON Processing
plotly,5.24.1,Data Visualization
psycopg2-binary,2.9.9,Database
pydantic,2.9.2,Data Validation
pyarrow,17.0.0,Data Processing
pycryptodome,3.20.0,Cryptography
pymongo,4.8.0,Database
pyodbc,5.1.0,Database
pytest-cov,5.0.0,Testing
python-dotenv,1.0.1,Environment Management
pytz,2024.2,Time Zone Handling
pywavelets,1.7.0,Signal Processing
redis,5.0.8,Database
regex,2024.9.11,Regular Expressions
s3fs,2024.9.0,File System
spacy,3.7.6,Natural Language Processing
statsmodels,0.14.2,Statistical Modeling
sympy,1.13.2,Symbolic Mathematics
tabulate,0.9.0,Data Formatting
uvicorn,0.30.6,Web Server
xgboost,2.1.1,Machine Learning
yfinance,0.2.44,Financial Data
alabaster,0.7.16,Documentation
anaconda-client,1.12.3,Package Management
argon2-cffi,23.1.0,Security
astropy,6.1.3,Astronomy
attrs,24.2.0,Utilities
backoff,2.2.1,Retry Logic
bleach,6.1.0,Text Sanitization
bokeh,3.6.0,Data Visualization
bottleneck,1.4.0,Performance Optimization
cachetools,5.5.0,Caching
cffi,1.17.1,Foreign Function Interface
charset-normalizer,3.3.2,Text Encoding
cloudpickle,3.0.0,Serialization
coverage,7.6.1,Testing
cryptography,43.0.1,Security
cycler,0.12.1,Data Visualization
cython,3.0.11,Performance Optimization
djangorestframework,3.15.2,Web Framework
docopt,0.6.2,Command Line Interface
et-xmlfile,1.1.0,Excel Processing
filelock,3.16.1,File Locking
fire,0.7.0,Command Line Interface
fsspec,2024.9.0,File System
future,1.0.0,Compatibility
gunicorn,23.0.0,Web Server
hypothesis,6.111.1,Testing
imageio,2.35.1,Image Processing
imbalanced-learn,0.12.3,Machine Learning
inflection,0.5.1,Text Processing
joblib,1.4.2,Parallel Computing
jsonschema,4.23.0,Data Validation
kiwisolver,1.4.7,Data Visualization
loguru,0.7.2,Logging
markdown,3.7,Text Formatting
markupsafe,2.1.5,Templating
more-itertools,10.5.0,Utilities
msgpack,1.0.8,Serialization
nest-asyncio,1.6.0,Asynchronous
oauthlib,3.2.2,Authentication
packaging,24.1,Packaging
paramiko,3.5.0,SSH
patsy,0.5.6,Statistical Modeling
pendulum,3.0.0,DateTime Handling
platformdirs,4.3.2,Platform Utilities
prometheus-client,0.20.0,Monitoring
py4j,0.10.9.7,Java Integration
pydot,3.0.1,Graph Visualization
pyparsing,3.1.4,Parsing
pysocks,1.7.1,Networking
python-dateutil,2.9.0,DateTime Handling
pyyaml,6.0.2,Configuration
retrying,1.3.4,Retry Logic
six,1.16.0,Compatibility
snowballstemmer,2.2.0,Text Processing
sortedcontainers,2.4.0,Data Structures
soupsieve,2.6,Web Scraping
termcolor,2.4.0,Text Formatting
textblob,0.18.0,Natural Language Processing
threadpoolctl,3.5.0,Parallel Computing
toml,0.10.2,Configuration
tornado,6.4.1,Web Framework
tqdm,4.66.5,Progress Bar
typing-extensions,4.12.2,Static Typing
urllib3,2.2.3,HTTP Client
virtualenv,20.26.3,Environment Management
websocket-client,1.8.0,WebSocket
werkzeug,3.0.4,Web Framework
wrapt,1.16.0,Utilities
zipp,3.20.2,Packaging`;

// Save CSV content to a file
const csvFilePath = path.join(__dirname, 'library-dependencies.csv');
fs.writeFileSync(csvFilePath, csvContent);
console.log(`CSV file saved to ${csvFilePath}`);

// Function to parse CSV data
function parseCSV(csv) {
  const lines = csv.split('\n');
  const headers = lines[0].split(',').map(h => h.trim());
  
  const dependencies = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const values = line.split(',').map(v => v.trim());
    if (values.length < 3) continue;
    
    dependencies.push({
      name: values[0],
      version: values[1],
      category: values[2],
      packageManager: 'pip',
      description: `${values[0]} - ${values[2]} library`
    });
  }
  
  return dependencies;
}

async function importDependencies() {
  try {
    // Get database connection from environment
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable not set');
    }
    
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    
    // Parse CSV data
    const dependencies = parseCSV(csvContent);
    console.log(`Parsed ${dependencies.length} dependencies from CSV`);
    
    // Insert dependencies into database
    let successCount = 0;
    
    for (const dep of dependencies) {
      try {
        // Check if dependency already exists
        const checkResult = await pool.query(
          'SELECT id FROM "algorithm_dependency" WHERE name = $1',
          [dep.name]
        );
        
        if (checkResult.rows.length > 0) {
          // Update existing dependency
          const id = checkResult.rows[0].id;
          await pool.query(
            'UPDATE "algorithm_dependency" SET version = $1, category = $2, "packageManager" = $3, description = $4 WHERE id = $5',
            [dep.version, dep.category, dep.packageManager, dep.description, id]
          );
          console.log(`Updated dependency: ${dep.name}`);
        } else {
          // Insert new dependency
          await pool.query(
            'INSERT INTO "algorithm_dependency" (name, version, category, "packageManager", description) VALUES ($1, $2, $3, $4, $5)',
            [dep.name, dep.version, dep.category, dep.packageManager, dep.description]
          );
          console.log(`Inserted dependency: ${dep.name}`);
        }
        
        successCount++;
      } catch (err) {
        console.error(`Error processing dependency ${dep.name}:`, err);
      }
    }
    
    console.log(`Successfully processed ${successCount} out of ${dependencies.length} dependencies`);
    
    // Close pool
    await pool.end();
    
    return successCount;
  } catch (error) {
    console.error('Error importing dependencies:', error);
    throw error;
  }
}

// Run the import
importDependencies()
  .then(count => {
    console.log(`Import complete! Successfully imported ${count} dependencies.`);
    process.exit(0);
  })
  .catch(err => {
    console.error('Import failed:', err);
    process.exit(1);
  });