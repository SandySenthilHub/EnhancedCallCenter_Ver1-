// Data Source types
export interface DataSource {
  id: number;
  name: string;
  type: string;
  connection: string;
  status: 'connected' | 'disconnected';
}

// Model types
export interface Model {
  id: number;
  name: string;
  type: 'regression' | 'classification' | 'clustering';
  algorithm: string;
  version: string;
  status: 'draft' | 'training' | 'trained' | 'production' | 'archived';
  metrics: Record<string, number>;
}

// Pipeline types
export interface Pipeline {
  id: number;
  name: string;
  type: 'regression' | 'classification' | 'clustering';
  schedule: string;
  status: 'draft' | 'running' | 'success' | 'failed';
  lastRun: string | null;
  createdAt: string;
}

// Activity types
export interface Activity {
  id: number;
  activity: string;
  pipeline: string;
  status: 'success' | 'running' | 'failed';
  timestamp: string;
}

// Feature Engineering types
export interface FeatureEngineeringStep {
  type: 'missing_values' | 'scaling' | 'encoding';
  config: {
    method: string;
    columns?: string[];
  };
}

// Algorithm options
export interface AlgorithmOption {
  id: string;
  name: string;
  description: string;
  features: string[];
}

export interface ModelType {
  id: 'regression' | 'classification' | 'clustering';
  name: string;
  description: string;
  examples: string[];
  algorithms: AlgorithmOption[];
}

// Dashboard types
export interface StatCard {
  title: string;
  value: number;
  change: string;
  description: string;
  icon: string;
}

export interface UseCase {
  id: string;
  title: string;
  description: string;
  status: 'active' | 'in-development';
  icon: string;
  color: string;
}

// App config types
export interface User {
  id: number;
  username: string;
  email: string;
  role: 'data_scientist' | 'ml_engineer' | 'business_analyst';
}
