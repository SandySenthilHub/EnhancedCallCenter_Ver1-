import { createContext, ReactNode, useContext } from 'react';
import { useRealTimeMonitoring, MonitoringEvent } from '@/hooks/use-real-time-monitoring';

type MonitoringContextType = ReturnType<typeof useRealTimeMonitoring>;

export const MonitoringContext = createContext<MonitoringContextType | null>(null);

export function MonitoringProvider({ children }: { children: ReactNode }) {
  const monitoringData = useRealTimeMonitoring();
  
  return (
    <MonitoringContext.Provider value={monitoringData}>
      {children}
    </MonitoringContext.Provider>
  );
}

export function useMonitoring() {
  const context = useContext(MonitoringContext);
  
  if (!context) {
    throw new Error('useMonitoring must be used within a MonitoringProvider');
  }
  
  return context;
}

// Helper hooks to make monitoring more accessible

export function useModelStatusUpdates() {
  const { getEntityStatusUpdates } = useMonitoring();
  return getEntityStatusUpdates('model');
}

export function usePipelineStatusUpdates() {
  const { getEntityStatusUpdates } = useMonitoring();
  return getEntityStatusUpdates('pipeline');
}

export function useDataSourceStatusUpdates() {
  const { getEntityStatusUpdates } = useMonitoring();
  return getEntityStatusUpdates('data_source');
}

export function useSystemAlerts() {
  const { getAlerts } = useMonitoring();
  return getAlerts();
}