import { useState, useEffect, useCallback } from 'react';

export type MonitoringEventType = 'status' | 'alert' | 'status_update' | 'subscribed';

export interface MonitoringEvent {
  type: MonitoringEventType;
  timestamp?: string;
  message?: string;
  severity?: 'info' | 'warning' | 'critical';
  source?: string;
  details?: any;
  channel?: string;
  entityType?: 'model' | 'pipeline' | 'data_source';
  id?: number;
  name?: string;
  status?: string;
}

export function useRealTimeMonitoring() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [events, setEvents] = useState<MonitoringEvent[]>([]);

  // Initialize WebSocket connection
  useEffect(() => {
    // Create WebSocket connection using secure protocol if needed
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('Connected to monitoring WebSocket');
      setConnected(true);
    };
    
    ws.onclose = () => {
      console.log('Disconnected from monitoring WebSocket');
      setConnected(false);
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data) as MonitoringEvent;
        setEvents((prev) => [data, ...prev].slice(0, 100)); // Keep last 100 events
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    setSocket(ws);
    
    // Cleanup on unmount
    return () => {
      ws.close();
    };
  }, []);
  
  // Function to subscribe to specific monitoring channels
  const subscribe = useCallback((channel: string) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'subscribe',
        channel
      }));
    }
  }, [socket]);
  
  // Filter events by type
  const getAlerts = useCallback(() => {
    return events.filter(event => event.type === 'alert');
  }, [events]);
  
  const getStatusUpdates = useCallback(() => {
    return events.filter(event => event.type === 'status_update');
  }, [events]);
  
  // Get status updates for a specific entity type
  const getEntityStatusUpdates = useCallback((entityType: 'model' | 'pipeline' | 'data_source') => {
    return events.filter(
      event => event.type === 'status_update' && event.entityType === entityType
    );
  }, [events]);
  
  return {
    connected,
    events,
    subscribe,
    getAlerts,
    getStatusUpdates,
    getEntityStatusUpdates
  };
}