import { useMutation, UseMutationResult } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

// Types for feature name suggestions
export interface FeatureNameSuggestion {
  name: string;
  reason: string;
  confidence: number;
}

export interface FeatureNameSuggestionsResponse {
  suggestions: FeatureNameSuggestion[];
}

export interface FeatureNameSuggestionParams {
  columnData?: any[];
  datasetDescription?: string;
  currentName?: string;
  dataType?: string;
  statistics?: any;
  domain?: string;
}

// Types for batch feature name suggestions
export interface BatchFeatureNameSuggestion {
  originalName: string;
  suggestedName: string;
  reason: string;
  confidence: number;
}

export interface BatchFeatureNameSuggestionsResponse {
  suggestions: BatchFeatureNameSuggestion[];
}

export interface BatchFeatureParams {
  name?: string;
  dataType?: string;
  description?: string;
  statistics?: any;
  sampleValues?: any[];
  suggestedName?: string;
  reason?: string;
  confidence?: number;
}

export interface BatchFeatureNameSuggestionParams {
  features: BatchFeatureParams[];
  datasetDescription?: string;
  domain?: string;
}

// Types for feature description suggestions
export interface FeatureDescriptionSuggestionsResponse {
  description: string;
  shortDescription: string;
  possibleUses: string[];
  cautions: string[];
}

export interface FeatureDescriptionSuggestionParams {
  featureName: string;
  dataType?: string;
  sampleValues?: any[];
  statistics?: any;
  domain?: string;
  currentDescription?: string;
}

export function useAISuggestions() {
  // Mutation for getting feature name suggestions
  const getFeatureNameSuggestions: UseMutationResult<
    FeatureNameSuggestionsResponse,
    Error,
    FeatureNameSuggestionParams
  > = useMutation({
    mutationFn: async (params: FeatureNameSuggestionParams) => {
      const response = await apiRequest('POST', '/api/ai/feature-name-suggestions', params);
      return response.json();
    },
  });

  // Mutation for getting batch feature name suggestions
  const getBatchFeatureNameSuggestions: UseMutationResult<
    BatchFeatureNameSuggestionsResponse,
    Error,
    BatchFeatureNameSuggestionParams
  > = useMutation({
    mutationFn: async (params: BatchFeatureNameSuggestionParams) => {
      const response = await apiRequest('POST', '/api/ai/batch-feature-name-suggestions', params);
      return response.json();
    },
  });

  // Mutation for getting feature description suggestions
  const getFeatureDescriptionSuggestions: UseMutationResult<
    FeatureDescriptionSuggestionsResponse,
    Error,
    FeatureDescriptionSuggestionParams
  > = useMutation({
    mutationFn: async (params: FeatureDescriptionSuggestionParams) => {
      const response = await apiRequest('POST', '/api/ai/feature-description-suggestions', params);
      return response.json();
    },
  });

  return {
    getFeatureNameSuggestions,
    getBatchFeatureNameSuggestions,
    getFeatureDescriptionSuggestions,
  };
}