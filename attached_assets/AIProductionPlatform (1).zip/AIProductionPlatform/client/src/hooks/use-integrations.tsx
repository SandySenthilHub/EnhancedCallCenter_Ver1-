import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Integration } from '@shared/schema';

export function useIntegrations() {
  const { toast } = useToast();
  const [selectedIntegrationType, setSelectedIntegrationType] = useState<string | null>(null);

  // Fetch all integrations
  const {
    data: integrations = [],
    isLoading: isLoadingIntegrations,
    error: integrationsError,
    refetch: refetchIntegrations
  } = useQuery<Integration[]>({
    queryKey: ['/api/integrations'],
    enabled: true
  });

  // Fetch integrations by type if a type is selected
  const {
    data: filteredIntegrations = [],
    isLoading: isLoadingFilteredIntegrations,
    error: filteredIntegrationsError
  } = useQuery<Integration[]>({
    queryKey: ['/api/integrations/type', selectedIntegrationType],
    enabled: !!selectedIntegrationType
  });

  // Create a new integration
  const createIntegrationMutation = useMutation({
    mutationFn: async (integration: Omit<Integration, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) => {
      const res = await apiRequest('POST', '/api/integrations', integration);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
      if (selectedIntegrationType) {
        queryClient.invalidateQueries({ queryKey: ['/api/integrations/type', selectedIntegrationType] });
      }
      toast({
        title: 'Integration created',
        description: 'The integration was created successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error creating integration',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Update an existing integration
  const updateIntegrationMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<Integration> }) => {
      const res = await apiRequest('PATCH', `/api/integrations/${id}`, data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/integrations', variables.id] });
      if (selectedIntegrationType) {
        queryClient.invalidateQueries({ queryKey: ['/api/integrations/type', selectedIntegrationType] });
      }
      toast({
        title: 'Integration updated',
        description: 'The integration was updated successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error updating integration',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Delete an integration
  const deleteIntegrationMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/integrations/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
      if (selectedIntegrationType) {
        queryClient.invalidateQueries({ queryKey: ['/api/integrations/type', selectedIntegrationType] });
      }
      toast({
        title: 'Integration deleted',
        description: 'The integration was deleted successfully',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error deleting integration',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  // Test integration connection
  const testIntegrationMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('POST', `/api/integrations/${id}/test`);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/integrations'] });
      if (selectedIntegrationType) {
        queryClient.invalidateQueries({ queryKey: ['/api/integrations/type', selectedIntegrationType] });
      }
      
      toast({
        title: data.status === 'connected' ? 'Connection successful' : 'Connection failed',
        description: data.message,
        variant: data.status === 'connected' ? 'default' : 'destructive',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error testing integration',
        description: error.message,
        variant: 'destructive',
      });
    }
  });

  return {
    integrations,
    filteredIntegrations,
    isLoadingIntegrations,
    isLoadingFilteredIntegrations,
    integrationsError,
    filteredIntegrationsError,
    selectedIntegrationType,
    setSelectedIntegrationType,
    createIntegration: createIntegrationMutation.mutate,
    updateIntegration: updateIntegrationMutation.mutate,
    deleteIntegration: deleteIntegrationMutation.mutate,
    testIntegration: testIntegrationMutation.mutate,
    isCreating: createIntegrationMutation.isPending,
    isUpdating: updateIntegrationMutation.isPending,
    isDeleting: deleteIntegrationMutation.isPending,
    isTesting: testIntegrationMutation.isPending,
    refetchIntegrations
  };
}