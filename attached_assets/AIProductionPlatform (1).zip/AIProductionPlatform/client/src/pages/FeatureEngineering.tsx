import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Area, AreaChart,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  ScatterChart, Scatter, Cell
} from 'recharts';
import { Download, Search, Plus, Settings, FileCode, ArrowRight, CheckCircle2, Code, Database, BarChart2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

// Sample data for visualizations
const missingDataSample = [
  { name: 'Column A', complete: 95, missing: 5 },
  { name: 'Column B', complete: 82, missing: 18 },
  { name: 'Column C', complete: 100, missing: 0 },
  { name: 'Column D', complete: 70, missing: 30 },
  { name: 'Column E', complete: 88, missing: 12 },
];

const featureImportanceData = [
  { name: 'Feature 1', importance: 0.32 },
  { name: 'Feature 2', importance: 0.18 },
  { name: 'Feature 3', importance: 0.15 },
  { name: 'Feature 4', importance: 0.12 },
  { name: 'Feature 5', importance: 0.09 },
  { name: 'Feature 6', importance: 0.08 },
  { name: 'Feature 7', importance: 0.06 },
];

const pcaExplainedVarianceData = [
  { name: 'PC1', variance: 0.38 },
  { name: 'PC2', variance: 0.21 },
  { name: 'PC3', variance: 0.15 },
  { name: 'PC4', variance: 0.09 },
  { name: 'PC5', variance: 0.07 },
  { name: 'PC6', variance: 0.06 },
  { name: 'PC7', variance: 0.04 },
];

const pcaScatterData = Array.from({ length: 50 }, (_, i) => ({
  x: Math.random() * 100 - 50 + (i % 3) * 30,
  y: Math.random() * 100 - 50 + Math.floor(i / 3) * 30,
  cluster: Math.floor(i / 17)
}));

const COLORS = ['#0088FE', '#00C49F', '#FFBB28'];

// Sample code snippets
const missingDataCode = `import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

# Identify missing values
missing_values = df.isnull().sum()
print(missing_values[missing_values > 0])

# Impute missing values with mean
imputer = SimpleImputer(strategy='mean')
df[['age', 'income']] = imputer.fit_transform(df[['age', 'income']])

# Impute categorical variables with most frequent value
cat_imputer = SimpleImputer(strategy='most_frequent')
df[['category', 'region']] = cat_imputer.fit_transform(df[['category', 'region']])`;

const normalizeCode = `from sklearn.preprocessing import StandardScaler, MinMaxScaler

# Standardization (z-score normalization)
scaler = StandardScaler()
df[['feature1', 'feature2']] = scaler.fit_transform(df[['feature1', 'feature2']])

# Min-Max scaling (to [0,1] range)
min_max_scaler = MinMaxScaler()
df[['feature3', 'feature4']] = min_max_scaler.fit_transform(df[['feature3', 'feature4']])`;

const categoricalCode = `import pandas as pd
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder

# One-hot encoding for nominal categories
encoder = OneHotEncoder(sparse=False)
encoded_data = encoder.fit_transform(df[['color', 'model']])
encoded_df = pd.DataFrame(
    encoded_data, 
    columns=encoder.get_feature_names_out(['color', 'model'])
)

# Ordinal encoding for ordered categories
ordinal_encoder = OrdinalEncoder(categories=[['low', 'medium', 'high']])
df['quality_encoded'] = ordinal_encoder.fit_transform(df[['quality']])`;

const pipelineCode = `from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier

# Define preprocessing for numerical columns
numeric_features = ['age', 'income', 'score']
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

# Define preprocessing for categorical columns
categorical_features = ['gender', 'category', 'region']
categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

# Combine preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)
    ])

# Create and configure the pipeline
pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier())
])

# Train the model
pipeline.fit(X_train, y_train)`;

const dimensionalityCode = `from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import umap

# PCA for linear dimensionality reduction
pca = PCA(n_components=2)
pca_result = pca.fit_transform(scaled_features)
print(f"Explained variance ratio: {pca.explained_variance_ratio_}")

# t-SNE for non-linear dimensionality reduction (visualization)
tsne = TSNE(n_components=2, random_state=42)
tsne_result = tsne.fit_transform(scaled_features)

# UMAP for faster non-linear reduction
reducer = umap.UMAP(n_components=2)
umap_result = reducer.fit_transform(scaled_features)`;

const FeatureEngineering: React.FC = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [dimReductionTechnique, setDimReductionTechnique] = useState('pca');
  const [selectedTab, setSelectedTab] = useState('introduction');

  const handleDownloadClick = () => {
    toast({
      title: "Checklist Downloaded",
      description: "Feature Engineering Checklist has been downloaded successfully",
    });
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality here
    toast({
      title: "Search Results",
      description: `Found results for: ${searchQuery}`,
    });
  };

  return (
    <>
      <Helmet>
        <title>Feature Engineering | AI/ML Playbook</title>
        <meta 
          name="description" 
          content="Transform raw data into meaningful features to optimize AI model performance with feature engineering techniques."
        />
      </Helmet>

      <div className="flex flex-col md:flex-row gap-6 h-full">
        {/* Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <Card className="sticky top-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Feature Engineering</CardTitle>
              <CardDescription>
                Section Navigation
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <form onSubmit={handleSearch} className="mb-4">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </form>
              <div className="space-y-1">
                <Button 
                  variant={selectedTab === 'introduction' ? 'secondary' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setSelectedTab('introduction')}
                >
                  Introduction
                </Button>
                <Button 
                  variant={selectedTab === 'missing-data' ? 'secondary' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setSelectedTab('missing-data')}
                >
                  Missing Data
                </Button>
                <Button 
                  variant={selectedTab === 'preprocessing' ? 'secondary' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setSelectedTab('preprocessing')}
                >
                  Preprocessing
                </Button>
                <Button 
                  variant={selectedTab === 'pipeline' ? 'secondary' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setSelectedTab('pipeline')}
                >
                  Data Pipeline
                </Button>
                <Button 
                  variant={selectedTab === 'dimensionality' ? 'secondary' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setSelectedTab('dimensionality')}
                >
                  Dimensionality Reduction
                </Button>
                <Button 
                  variant={selectedTab === 'best-practices' ? 'secondary' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setSelectedTab('best-practices')}
                >
                  Best Practices
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full" 
                onClick={handleDownloadClick}
                variant="outline"
              >
                <Download className="mr-2 h-4 w-4" />
                Download Checklist
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Main content */}
        <div className="flex-1">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">Feature Engineering for AI Model Development</h1>
            <p className="text-muted-foreground mt-2">Transform raw data into powerful features for your AI models</p>
          </div>

          <Card className={`mb-6 ${selectedTab === 'introduction' ? 'block' : 'hidden'}`}>
            <CardHeader>
              <CardTitle>Introduction to Feature Engineering</CardTitle>
              <CardDescription>
                Learn how to extract meaningful information from your data
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <p>
                  Feature engineering is the process of using domain knowledge to extract features from raw data that make 
                  machine learning algorithms work. It's a crucial step because the right features can simplify models and 
                  improve their performance dramatically.
                </p>
                
                <div className="my-6 p-4 bg-muted rounded-md">
                  <h3 className="text-lg font-medium mb-2 flex items-center">
                    <CheckCircle2 className="mr-2 h-5 w-5 text-green-500" />
                    Why Feature Engineering Matters
                  </h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Good features allow models to learn with less data</li>
                    <li>Well-crafted features can increase model interpretability</li>
                    <li>Features tuned to the problem can improve accuracy more than algorithm tuning</li>
                    <li>Domain-specific features encode human expertise into the modeling process</li>
                  </ul>
                </div>
                
                <h3 className="text-lg font-medium mt-4">Common Feature Engineering Techniques</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium">Feature Creation</h4>
                    <p className="text-sm text-muted-foreground">Creating new features from existing ones, like ratios or aggregations</p>
                  </div>
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium">Feature Transformation</h4>
                    <p className="text-sm text-muted-foreground">Scaling, normalization, or applying mathematical functions</p>
                  </div>
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium">Feature Extraction</h4>
                    <p className="text-sm text-muted-foreground">Deriving features from complex data types (text, images, etc.)</p>
                  </div>
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium">Feature Selection</h4>
                    <p className="text-sm text-muted-foreground">Choosing the most relevant features to avoid overfitting</p>
                  </div>
                </div>
                
                <h3 className="text-lg font-medium mt-6">Example: Time Feature Engineering</h3>
                <p>
                  Consider a dataset with timestamps. Instead of using raw timestamps, you can extract:
                </p>
                <ul className="list-disc pl-6">
                  <li>Hour of day (captures daily patterns)</li>
                  <li>Day of week (captures weekly patterns)</li>
                  <li>Month (captures seasonal patterns)</li>
                  <li>Is weekend/holiday (captures special days)</li>
                </ul>
                
                <div className="mt-6">
                  <div className="font-medium mb-2">Feature Importance from an Example Model</div>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart
                      data={featureImportanceData}
                      layout="vertical"
                      margin={{ top: 20, right: 30, left: 90, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="name" width={80} />
                      <Tooltip />
                      <Bar dataKey="importance" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                  <p className="text-sm text-muted-foreground text-center mt-2">
                    Feature importance from a random forest model showing which engineered features contributed most
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={`mb-6 ${selectedTab === 'missing-data' ? 'block' : 'hidden'}`}>
            <CardHeader>
              <CardTitle>Handling Missing and Inconsistent Data</CardTitle>
              <CardDescription>
                Learn how to identify and address data quality issues
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="missing-data">
                  <AccordionTrigger>
                    <div className="flex items-center">
                      <Database className="mr-2 h-5 w-5" />
                      Identifying and Handling Missing Data
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="prose max-w-none">
                      <p>
                        Missing data can significantly impact model performance. It's crucial to identify patterns of missingness
                        and apply appropriate strategies.
                      </p>
                      
                      <div className="my-4">
                        <div className="font-medium mb-2">Missing Data by Column</div>
                        <ResponsiveContainer width="100%" height={300}>
                          <BarChart
                            data={missingDataSample}
                            stackOffset="expand"
                            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis tickFormatter={(tick) => `${Math.round(tick * 100)}%`} />
                            <Tooltip formatter={(value) => `${Math.round(Number(value))}%`} />
                            <Legend />
                            <Bar dataKey="complete" stackId="a" fill="#82ca9d" name="Complete" />
                            <Bar dataKey="missing" stackId="a" fill="#ff8042" name="Missing" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                      
                      <h3 className="text-lg font-medium mt-4">Imputation Strategies</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li><strong>Statistical Imputation:</strong> Replace with mean, median, or mode</li>
                        <li><strong>Predictive Modeling:</strong> Use other features to predict missing values</li>
                        <li><strong>KNN Imputation:</strong> Use values from similar data points</li>
                        <li><strong>Multiple Imputation:</strong> Create multiple dataset versions with different imputations</li>
                      </ul>
                      
                      <div className="mt-4 bg-muted p-4 rounded-md overflow-auto">
                        <div className="font-medium mb-2 flex items-center">
                          <Code className="mr-2 h-4 w-4" />
                          Python Code for Handling Missing Data
                        </div>
                        <pre className="text-xs">{missingDataCode}</pre>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="inconsistent-data">
                  <AccordionTrigger>
                    <div className="flex items-center">
                      <Settings className="mr-2 h-5 w-5" />
                      Dealing with Inconsistent Data
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="prose max-w-none">
                      <p>
                        Inconsistent data includes values in different formats, incorrect entries, or values 
                        that don't adhere to business rules.
                      </p>
                      
                      <h3 className="text-lg font-medium mt-4">Common Inconsistencies</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                        <div className="border rounded-md p-4">
                          <h4 className="font-medium">Text Variations</h4>
                          <p className="text-sm text-muted-foreground">Different spellings, capitalizations, or abbreviations</p>
                          <div className="mt-2 text-sm">
                            <Badge variant="outline" className="mr-1">New York</Badge>
                            <Badge variant="outline" className="mr-1">NY</Badge>
                            <Badge variant="outline" className="mr-1">N.Y.</Badge>
                            <Badge variant="outline">new york</Badge>
                          </div>
                        </div>
                        <div className="border rounded-md p-4">
                          <h4 className="font-medium">Date/Time Formats</h4>
                          <p className="text-sm text-muted-foreground">Inconsistent date representations</p>
                          <div className="mt-2 text-sm">
                            <Badge variant="outline" className="mr-1">01/02/2023</Badge>
                            <Badge variant="outline" className="mr-1">2023-01-02</Badge>
                            <Badge variant="outline">Feb 1, 2023</Badge>
                          </div>
                        </div>
                        <div className="border rounded-md p-4">
                          <h4 className="font-medium">Units of Measurement</h4>
                          <p className="text-sm text-muted-foreground">Mixed units in the same column</p>
                          <div className="mt-2 text-sm">
                            <Badge variant="outline" className="mr-1">72 inches</Badge>
                            <Badge variant="outline" className="mr-1">183 cm</Badge>
                            <Badge variant="outline">6 ft</Badge>
                          </div>
                        </div>
                        <div className="border rounded-md p-4">
                          <h4 className="font-medium">Outliers</h4>
                          <p className="text-sm text-muted-foreground">Values that fall far outside the expected range</p>
                          <div className="mt-2 text-sm">
                            <Badge variant="outline" className="mr-1">Age: -5</Badge>
                            <Badge variant="outline" className="mr-1">Age: 200</Badge>
                            <Badge variant="outline">Price: $999,999</Badge>
                          </div>
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-medium mt-4">Standardization Techniques</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>Text normalization (lowercase, remove punctuation)</li>
                        <li>Converting dates to ISO format (YYYY-MM-DD)</li>
                        <li>Using regular expressions for pattern matching and correction</li>
                        <li>Creating lookup tables for standard values</li>
                        <li>Statistical methods for outlier detection and handling (z-score, IQR)</li>
                      </ul>
                      
                      <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800">
                        <h4 className="font-medium text-blue-700 dark:text-blue-300">Best Practice</h4>
                        <p className="text-sm">
                          Always create data quality reports to track improvements in missing data rates 
                          and inconsistencies before and after preprocessing.
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card className={`mb-6 ${selectedTab === 'preprocessing' ? 'block' : 'hidden'}`}>
            <CardHeader>
              <CardTitle>Preprocessing Steps for Data Preparation</CardTitle>
              <CardDescription>
                Essential techniques to clean and normalize your data
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="scaling" className="w-full">
                <TabsList className="grid grid-cols-4 mb-6">
                  <TabsTrigger value="scaling">Scaling</TabsTrigger>
                  <TabsTrigger value="categorical">Categorical Encoding</TabsTrigger>
                  <TabsTrigger value="text">Text Processing</TabsTrigger>
                  <TabsTrigger value="time">Time Features</TabsTrigger>
                </TabsList>
                <TabsContent value="scaling">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-medium">Normalizing Numerical Features</h3>
                    <p>
                      Scaling ensures that numerical features are on a similar scale, which is crucial for many 
                      machine learning algorithms that are sensitive to the magnitude of features.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Standardization (Z-score)</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Transforms features to have zero mean and unit variance
                        </p>
                        <div className="text-sm font-mono bg-muted p-2 rounded-md">
                          X' = (X - μ) / σ
                        </div>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> When features follow a normal distribution and for algorithms 
                          sensitive to outliers (like SVM, neural networks)
                        </div>
                      </div>
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Min-Max Scaling</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Transforms features to a specific range, usually [0,1]
                        </p>
                        <div className="text-sm font-mono bg-muted p-2 rounded-md">
                          X' = (X - Xmin) / (Xmax - Xmin)
                        </div>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> When you need bounded values, like for neural networks 
                          with sigmoid activation functions
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Robust Scaling</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Uses median and IQR instead of mean and standard deviation
                        </p>
                        <div className="text-sm font-mono bg-muted p-2 rounded-md">
                          X' = (X - median) / IQR
                        </div>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> When your data contains outliers that you don't want to remove
                        </div>
                      </div>
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Log Transformation</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Takes the logarithm of features to handle skewed distributions
                        </p>
                        <div className="text-sm font-mono bg-muted p-2 rounded-md">
                          X' = log(X + c) 
                        </div>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> When feature distribution is right-skewed (e.g., income, prices)
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6 bg-muted p-4 rounded-md overflow-auto">
                      <div className="font-medium mb-2 flex items-center">
                        <Code className="mr-2 h-4 w-4" />
                        Python Code for Feature Scaling
                      </div>
                      <pre className="text-xs">{normalizeCode}</pre>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="categorical">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-medium">Encoding Categorical Variables</h3>
                    <p>
                      Machine learning algorithms typically require numerical input, so categorical variables 
                      need to be converted to a numerical representation.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">One-Hot Encoding</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Creates binary columns for each category
                        </p>
                        <div className="mt-2 text-sm">
                          <div className="flex mb-1">
                            <div className="w-24">Original:</div>
                            <div>['red', 'blue', 'green']</div>
                          </div>
                          <div className="flex">
                            <div className="w-24">Encoded:</div>
                            <div>
                              [1,0,0], [0,1,0], [0,0,1]
                            </div>
                          </div>
                        </div>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> For nominal categories with no inherent order
                        </div>
                      </div>
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Ordinal Encoding</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Assigns integers to categories based on their order
                        </p>
                        <div className="mt-2 text-sm">
                          <div className="flex mb-1">
                            <div className="w-24">Original:</div>
                            <div>['low', 'medium', 'high']</div>
                          </div>
                          <div className="flex">
                            <div className="w-24">Encoded:</div>
                            <div>
                              [0, 1, 2]
                            </div>
                          </div>
                        </div>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> For ordinal categories with a clear ranking
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Target Encoding</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Replaces categories with the mean of the target for that category
                        </p>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> For high-cardinality features (many unique values)
                        </div>
                      </div>
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Frequency Encoding</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Replaces categories with their frequency in the dataset
                        </p>
                        <div className="mt-3 text-sm">
                          <strong>When to use:</strong> When category frequency is informative
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6 bg-muted p-4 rounded-md overflow-auto">
                      <div className="font-medium mb-2 flex items-center">
                        <Code className="mr-2 h-4 w-4" />
                        Python Code for Categorical Encoding
                      </div>
                      <pre className="text-xs">{categoricalCode}</pre>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="text">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-medium">Text Feature Processing</h3>
                    <p>
                      Text data requires specialized preprocessing to convert unstructured text into structured features.
                    </p>
                    
                    <div className="my-4 p-4 border rounded-md">
                      <h4 className="font-medium mb-2">Text Preprocessing Pipeline</h4>
                      <div className="relative">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center text-sm">
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-md mb-2 md:mb-0">
                            Raw Text
                          </div>
                          <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-md mb-2 md:mb-0">
                            Tokenization
                          </div>
                          <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-md mb-2 md:mb-0">
                            Stop Word Removal
                          </div>
                          <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-md mb-2 md:mb-0">
                            Stemming/Lemmatization
                          </div>
                          <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                          <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-md">
                            Vectorization
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-4 mt-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Text Vectorization Techniques</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                          <div>
                            <h5 className="font-medium text-sm">Count Vectorization (Bag of Words)</h5>
                            <p className="text-sm text-muted-foreground">
                              Counts word occurrences in documents
                            </p>
                            <div className="mt-2 text-xs font-mono bg-muted p-2 rounded-md">
                              from sklearn.feature_extraction.text import CountVectorizer
                            </div>
                          </div>
                          <div>
                            <h5 className="font-medium text-sm">TF-IDF Vectorization</h5>
                            <p className="text-sm text-muted-foreground">
                              Weights words by their importance across documents
                            </p>
                            <div className="mt-2 text-xs font-mono bg-muted p-2 rounded-md">
                              from sklearn.feature_extraction.text import TfidfVectorizer
                            </div>
                          </div>
                          <div>
                            <h5 className="font-medium text-sm">Word Embeddings</h5>
                            <p className="text-sm text-muted-foreground">
                              Maps words to dense vectors (Word2Vec, GloVe)
                            </p>
                            <div className="mt-2 text-xs font-mono bg-muted p-2 rounded-md">
                              from gensim.models import Word2Vec
                            </div>
                          </div>
                          <div>
                            <h5 className="font-medium text-sm">Transformer Embeddings</h5>
                            <p className="text-sm text-muted-foreground">
                              Contextual embeddings from transformer models
                            </p>
                            <div className="mt-2 text-xs font-mono bg-muted p-2 rounded-md">
                              from transformers import BertTokenizer, BertModel
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800">
                      <h4 className="font-medium text-blue-700 dark:text-blue-300">Best Practice</h4>
                      <p className="text-sm">
                        For most modern NLP tasks, consider using pre-trained transformer models (BERT, RoBERTa) as 
                        they capture context and semantic meaning better than traditional methods.
                      </p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="time">
                  <div className="prose max-w-none">
                    <h3 className="text-lg font-medium">Time-Based Feature Engineering</h3>
                    <p>
                      Time series data and timestamps contain valuable information that can be extracted 
                      through feature engineering.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Calendar Features</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Extracting components from dates
                        </p>
                        <ul className="text-sm list-disc pl-5 space-y-1">
                          <li>Day of week (1-7)</li>
                          <li>Month (1-12)</li>
                          <li>Quarter (1-4)</li>
                          <li>Year</li>
                          <li>Is weekend (binary)</li>
                          <li>Is holiday (binary)</li>
                        </ul>
                      </div>
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Time Features</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Extracting components from timestamps
                        </p>
                        <ul className="text-sm list-disc pl-5 space-y-1">
                          <li>Hour of day (0-23)</li>
                          <li>AM/PM (binary)</li>
                          <li>Hour sin/cos (for cyclical representation)</li>
                          <li>Business hours (binary)</li>
                          <li>Meal times (binary flags)</li>
                        </ul>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Lag Features</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Including past values as features
                        </p>
                        <ul className="text-sm list-disc pl-5 space-y-1">
                          <li>Previous day's value</li>
                          <li>Previous week's value</li>
                          <li>Same day last year's value</li>
                          <li>Multiple lags for autoregression</li>
                        </ul>
                      </div>
                      <div className="border rounded-md p-4">
                        <h4 className="font-medium">Window Features</h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          Aggregating values over time windows
                        </p>
                        <ul className="text-sm list-disc pl-5 space-y-1">
                          <li>Rolling mean (7-day, 30-day)</li>
                          <li>Rolling standard deviation</li>
                          <li>Rolling max/min</li>
                          <li>Expanding mean (all history)</li>
                        </ul>
                      </div>
                    </div>
                    
                    <div className="mt-4 p-4 bg-muted rounded-md">
                      <h4 className="font-medium mb-2">Python Example for Time Features</h4>
                      <pre className="text-xs">
{`import pandas as pd

# Convert to datetime if needed
df['date'] = pd.to_datetime(df['date'])

# Extract calendar features
df['day_of_week'] = df['date'].dt.dayofweek
df['month'] = df['date'].dt.month
df['is_weekend'] = df['date'].dt.dayofweek >= 5

# Extract time features from timestamp
df['hour'] = df['timestamp'].dt.hour
df['is_business_hours'] = (df['hour'] >= 9) & (df['hour'] <= 17)

# Create cyclical features for hour (to represent its cyclical nature)
df['hour_sin'] = np.sin(2 * np.pi * df['hour']/24)
df['hour_cos'] = np.cos(2 * np.pi * df['hour']/24)

# Create lag features
df['value_lag1'] = df['value'].shift(1)
df['value_lag7'] = df['value'].shift(7)

# Create rolling window features
df['rolling_mean_7d'] = df['value'].rolling(window=7).mean()
df['rolling_std_7d'] = df['value'].rolling(window=7).std()`}
                      </pre>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className={`mb-6 ${selectedTab === 'pipeline' ? 'block' : 'hidden'}`}>
            <CardHeader>
              <CardTitle>Data Pipeline Structure</CardTitle>
              <CardDescription>
                Design modular and efficient data processing pipelines
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <p>
                  A well-structured data pipeline ensures reproducibility, maintainability, and efficiency in your 
                  feature engineering process. It provides a consistent way to transform raw data into model-ready features.
                </p>
                
                <div className="my-6 p-4 bg-muted rounded-md">
                  <h3 className="text-lg font-medium mb-2">Pipeline Architecture Principles</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium text-sm">Modularity</h4>
                      <p className="text-sm text-muted-foreground">
                        Break the pipeline into small, reusable components that can be combined in different ways.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Idempotency</h4>
                      <p className="text-sm text-muted-foreground">
                        Running the pipeline multiple times with the same input should produce the same output.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Reproducibility</h4>
                      <p className="text-sm text-muted-foreground">
                        The pipeline should be versioned and trackable so results can be reproduced later.
                      </p>
                    </div>
                    <div>
                      <h4 className="font-medium text-sm">Testability</h4>
                      <p className="text-sm text-muted-foreground">
                        Each component should be testable in isolation to ensure it behaves as expected.
                      </p>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-lg font-medium">Pipeline Components</h3>
                <div className="my-4 relative">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center p-4 border rounded-md bg-gray-50 dark:bg-gray-900">
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-md mb-2 md:mb-0 text-center">
                      <div className="font-medium">Data Ingestion</div>
                      <div className="text-xs text-muted-foreground">Load raw data</div>
                    </div>
                    <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-md mb-2 md:mb-0 text-center">
                      <div className="font-medium">Data Validation</div>
                      <div className="text-xs text-muted-foreground">Check quality</div>
                    </div>
                    <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-md mb-2 md:mb-0 text-center">
                      <div className="font-medium">Data Cleaning</div>
                      <div className="text-xs text-muted-foreground">Fix issues</div>
                    </div>
                    <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-md mb-2 md:mb-0 text-center">
                      <div className="font-medium">Feature Creation</div>
                      <div className="text-xs text-muted-foreground">Build features</div>
                    </div>
                    <ArrowRight className="hidden md:block h-4 w-4 mx-2" />
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-md text-center">
                      <div className="font-medium">Feature Selection</div>
                      <div className="text-xs text-muted-foreground">Choose best</div>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-lg font-medium mt-6">Implementation with Scikit-learn Pipelines</h3>
                <p>
                  Scikit-learn's Pipeline and ColumnTransformer classes provide a clean, standardized way to implement 
                  data processing pipelines in Python.
                </p>
                
                <div className="mt-4 bg-muted p-4 rounded-md overflow-auto">
                  <div className="font-medium mb-2 flex items-center">
                    <Code className="mr-2 h-4 w-4" />
                    Python Code for Pipeline Implementation
                  </div>
                  <pre className="text-xs">{pipelineCode}</pre>
                </div>
                
                <h3 className="text-lg font-medium mt-6">Pipeline Best Practices</h3>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Fit transformers using only the training data to avoid data leakage</li>
                  <li>Keep feature engineering code separate from model training code</li>
                  <li>Create a configuration file to store parameter values for the pipeline</li>
                  <li>Log intermediate outputs for debugging</li>
                  <li>Use tools like MLflow or DVC to version your pipelines and track experiments</li>
                  <li>Implement data validation checks at the beginning of the pipeline</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card className={`mb-6 ${selectedTab === 'dimensionality' ? 'block' : 'hidden'}`}>
            <CardHeader>
              <CardTitle>Dimensionality Reduction Techniques</CardTitle>
              <CardDescription>
                Strategies for reducing feature space while preserving information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <p>
                  Dimensionality reduction helps simplify datasets by reducing the number of features while retaining 
                  most of the important information. This improves model performance, reduces computation time, and 
                  helps with visualization.
                </p>
                
                <Tabs defaultValue="pca" onValueChange={setDimReductionTechnique} className="mt-6">
                  <TabsList className="grid grid-cols-3 w-full max-w-md mx-auto">
                    <TabsTrigger value="pca">PCA</TabsTrigger>
                    <TabsTrigger value="tsne">t-SNE</TabsTrigger>
                    <TabsTrigger value="umap">UMAP</TabsTrigger>
                  </TabsList>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                    <div>
                      {dimReductionTechnique === 'pca' && (
                        <>
                          <h3 className="text-lg font-medium mb-2">Principal Component Analysis (PCA)</h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            PCA is a linear dimensionality reduction technique that transforms the data into a new 
                            coordinate system where the greatest variance lies on the first coordinate (principal component), 
                            the second greatest variance on the second coordinate, and so on.
                          </p>
                          <div className="space-y-2 text-sm">
                            <p><strong>Strengths:</strong></p>
                            <ul className="list-disc pl-6 space-y-1">
                              <li>Simple and efficient implementation</li>
                              <li>Preserves global structure of the data</li>
                              <li>Helpful for removing multicollinearity</li>
                              <li>Works well when linear relationships exist</li>
                            </ul>
                            <p><strong>Limitations:</strong></p>
                            <ul className="list-disc pl-6 space-y-1">
                              <li>Assumes linear relationships between features</li>
                              <li>Sensitive to feature scaling</li>
                              <li>May not preserve local structure of data</li>
                            </ul>
                          </div>
                        </>
                      )}
                      {dimReductionTechnique === 'tsne' && (
                        <>
                          <h3 className="text-lg font-medium mb-2">t-Distributed Stochastic Neighbor Embedding (t-SNE)</h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            t-SNE is a non-linear technique that models similar data points as nearby points and dissimilar 
                            data points as distant points, focusing on preserving local structure and creating meaningful clusters.
                          </p>
                          <div className="space-y-2 text-sm">
                            <p><strong>Strengths:</strong></p>
                            <ul className="list-disc pl-6 space-y-1">
                              <li>Excellent for visualization in 2D/3D</li>
                              <li>Preserves local structure well</li>
                              <li>Good at revealing clusters</li>
                              <li>Works with non-linear relationships</li>
                            </ul>
                            <p><strong>Limitations:</strong></p>
                            <ul className="list-disc pl-6 space-y-1">
                              <li>Computationally expensive for large datasets</li>
                              <li>Non-deterministic (different runs give different results)</li>
                              <li>Sensitive to hyperparameters (perplexity)</li>
                              <li>Not suitable for dimensionality reduction for modeling</li>
                            </ul>
                          </div>
                        </>
                      )}
                      {dimReductionTechnique === 'umap' && (
                        <>
                          <h3 className="text-lg font-medium mb-2">Uniform Manifold Approximation and Projection (UMAP)</h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            UMAP is a non-linear dimensionality reduction technique that preserves both local and global 
                            structure of the data, often providing better visualizations than t-SNE with faster computation.
                          </p>
                          <div className="space-y-2 text-sm">
                            <p><strong>Strengths:</strong></p>
                            <ul className="list-disc pl-6 space-y-1">
                              <li>Faster than t-SNE</li>
                              <li>Preserves both local and global structure</li>
                              <li>Scales well to large datasets</li>
                              <li>Can be used for visualization and general dimensionality reduction</li>
                            </ul>
                            <p><strong>Limitations:</strong></p>
                            <ul className="list-disc pl-6 space-y-1">
                              <li>Relatively new algorithm with fewer tools</li>
                              <li>Complex mathematics behind the algorithm</li>
                              <li>Results can vary based on hyperparameter selection</li>
                            </ul>
                          </div>
                        </>
                      )}
                    </div>
                    <div>
                      {dimReductionTechnique === 'pca' && (
                        <div className="space-y-4">
                          <h4 className="font-medium">PCA Explained Variance</h4>
                          <ResponsiveContainer width="100%" height={250}>
                            <BarChart
                              data={pcaExplainedVarianceData}
                              margin={{ top: 20, right: 20, left: 20, bottom: 20 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis tickFormatter={(value) => `${Math.round(value * 100)}%`} />
                              <Tooltip formatter={(value) => `${Math.round(Number(value) * 100)}%`} />
                              <Bar dataKey="variance" fill="#8884d8" />
                            </BarChart>
                          </ResponsiveContainer>
                          <p className="text-sm text-muted-foreground">
                            The first few principal components capture most of the variance in the data
                          </p>
                          
                          <h4 className="font-medium mt-4">PCA in 2D</h4>
                          <ResponsiveContainer width="100%" height={250}>
                            <ScatterChart
                              margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis type="number" dataKey="x" name="PC1" />
                              <YAxis type="number" dataKey="y" name="PC2" />
                              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                              <Scatter name="Data points" data={pcaScatterData} fill="#8884d8">
                                {pcaScatterData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[entry.cluster % COLORS.length]} />
                                ))}
                              </Scatter>
                            </ScatterChart>
                          </ResponsiveContainer>
                          <p className="text-sm text-muted-foreground">
                            2D PCA projection showing clusters in reduced feature space
                          </p>
                        </div>
                      )}
                      {dimReductionTechnique === 'tsne' && (
                        <div className="space-y-4">
                          <h4 className="font-medium">t-SNE Visualization</h4>
                          <ResponsiveContainer width="100%" height={300}>
                            <ScatterChart
                              margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis type="number" dataKey="x" name="t-SNE 1" />
                              <YAxis type="number" dataKey="y" name="t-SNE 2" />
                              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                              <Scatter name="Data points" data={pcaScatterData} fill="#8884d8">
                                {pcaScatterData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[entry.cluster % COLORS.length]} />
                                ))}
                              </Scatter>
                            </ScatterChart>
                          </ResponsiveContainer>
                          <p className="text-sm text-muted-foreground">
                            t-SNE typically shows clearer cluster separation than PCA for complex data
                          </p>
                          
                          <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800">
                            <h4 className="font-medium text-blue-700 dark:text-blue-300">t-SNE Tips</h4>
                            <ul className="text-sm list-disc pl-5 space-y-1 mt-2">
                              <li>Use PCA first to reduce to ~50 dimensions for very high-dimensional data</li>
                              <li>Experiment with perplexity (usually between 5-50)</li>
                              <li>Run for at least 1000 iterations for convergence</li>
                              <li>Don't interpret distances between clusters</li>
                            </ul>
                          </div>
                        </div>
                      )}
                      {dimReductionTechnique === 'umap' && (
                        <div className="space-y-4">
                          <h4 className="font-medium">UMAP Visualization</h4>
                          <ResponsiveContainer width="100%" height={300}>
                            <ScatterChart
                              margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis type="number" dataKey="x" name="UMAP 1" />
                              <YAxis type="number" dataKey="y" name="UMAP 2" />
                              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                              <Scatter name="Data points" data={pcaScatterData} fill="#8884d8">
                                {pcaScatterData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[entry.cluster % COLORS.length]} />
                                ))}
                              </Scatter>
                            </ScatterChart>
                          </ResponsiveContainer>
                          <p className="text-sm text-muted-foreground">
                            UMAP preserves both local and global structure, often giving more interpretable visualizations
                          </p>
                          
                          <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950 rounded-md border border-blue-200 dark:border-blue-800">
                            <h4 className="font-medium text-blue-700 dark:text-blue-300">UMAP Parameters</h4>
                            <ul className="text-sm list-disc pl-5 space-y-1 mt-2">
                              <li><strong>n_neighbors</strong>: Controls focus on local vs. global structure (small: local, large: global)</li>
                              <li><strong>min_dist</strong>: Controls compactness of clusters (smaller: tighter clusters)</li>
                              <li><strong>metric</strong>: Distance metric (euclidean, cosine, etc.)</li>
                            </ul>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-6 bg-muted p-4 rounded-md overflow-auto">
                    <div className="font-medium mb-2 flex items-center">
                      <Code className="mr-2 h-4 w-4" />
                      Python Code for Dimensionality Reduction
                    </div>
                    <pre className="text-xs">{dimensionalityCode}</pre>
                  </div>
                </Tabs>
              </div>
            </CardContent>
          </Card>

          <Card className={`mb-6 ${selectedTab === 'best-practices' ? 'block' : 'hidden'}`}>
            <CardHeader>
              <CardTitle>Best Practices and Guidelines</CardTitle>
              <CardDescription>
                Expert tips for effective feature engineering
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="border rounded-md p-5">
                    <h3 className="text-lg font-medium flex items-center">
                      <CheckCircle2 className="mr-2 h-5 w-5 text-green-500" />
                      Design Process
                    </h3>
                    <ul className="mt-3 space-y-2">
                      <li className="flex items-start">
                        <span className="bg-green-100 dark:bg-green-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                        </span>
                        <span className="text-sm">Start with domain knowledge to identify important features</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-green-100 dark:bg-green-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                        </span>
                        <span className="text-sm">Perform exploratory data analysis (EDA) before feature engineering</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-green-100 dark:bg-green-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                        </span>
                        <span className="text-sm">Consult domain experts to validate your feature ideas</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-green-100 dark:bg-green-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                        </span>
                        <span className="text-sm">Document each feature's meaning and transformation logic</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="border rounded-md p-5">
                    <h3 className="text-lg font-medium flex items-center">
                      <BarChart2 className="mr-2 h-5 w-5 text-blue-500" />
                      Implementation Practices
                    </h3>
                    <ul className="mt-3 space-y-2">
                      <li className="flex items-start">
                        <span className="bg-blue-100 dark:bg-blue-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-blue-500" />
                        </span>
                        <span className="text-sm">Create atomic feature transformations that can be reused</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-blue-100 dark:bg-blue-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-blue-500" />
                        </span>
                        <span className="text-sm">Test transformations on small datasets before scaling up</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-blue-100 dark:bg-blue-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-blue-500" />
                        </span>
                        <span className="text-sm">Use version control for feature engineering code</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-blue-100 dark:bg-blue-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-blue-500" />
                        </span>
                        <span className="text-sm">Log feature statistics before and after transformations</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="border rounded-md p-5">
                    <h3 className="text-lg font-medium flex items-center">
                      <FileCode className="mr-2 h-5 w-5 text-purple-500" />
                      Data Leakage Prevention
                    </h3>
                    <ul className="mt-3 space-y-2">
                      <li className="flex items-start">
                        <span className="bg-purple-100 dark:bg-purple-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-purple-500" />
                        </span>
                        <span className="text-sm">Fit feature transformers only on training data</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-purple-100 dark:bg-purple-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-purple-500" />
                        </span>
                        <span className="text-sm">Be cautious with features that contain future information</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-purple-100 dark:bg-purple-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-purple-500" />
                        </span>
                        <span className="text-sm">Use cross-validation to assess feature engineering impact</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-purple-100 dark:bg-purple-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-purple-500" />
                        </span>
                        <span className="text-sm">Validate feature distribution shifts in test data</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="border rounded-md p-5">
                    <h3 className="text-lg font-medium flex items-center">
                      <Settings className="mr-2 h-5 w-5 text-amber-500" />
                      Optimization Tips
                    </h3>
                    <ul className="mt-3 space-y-2">
                      <li className="flex items-start">
                        <span className="bg-amber-100 dark:bg-amber-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-amber-500" />
                        </span>
                        <span className="text-sm">Start simple with baseline features, then add complexity</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-amber-100 dark:bg-amber-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-amber-500" />
                        </span>
                        <span className="text-sm">Use feature selection to remove redundant or irrelevant features</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-amber-100 dark:bg-amber-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-amber-500" />
                        </span>
                        <span className="text-sm">Consider feature cost in production (computation, memory)</span>
                      </li>
                      <li className="flex items-start">
                        <span className="bg-amber-100 dark:bg-amber-900 p-1 rounded-full mr-2 mt-0.5">
                          <CheckCircle2 className="h-3 w-3 text-amber-500" />
                        </span>
                        <span className="text-sm">Monitor feature drift over time in production models</span>
                      </li>
                    </ul>
                  </div>
                </div>
                
                <div className="mt-8">
                  <h3 className="text-lg font-medium mb-4">Feature Engineering Checklist</h3>
                  <div className="border rounded-md">
                    <div className="p-4 bg-muted border-b">
                      <h4 className="font-medium">Before Feature Engineering</h4>
                    </div>
                    <div className="p-4">
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <input type="checkbox" id="check1" className="mr-2" />
                          <label htmlFor="check1" className="text-sm">Understand the business problem and data domain</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check2" className="mr-2" />
                          <label htmlFor="check2" className="text-sm">Perform exploratory data analysis (EDA)</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check3" className="mr-2" />
                          <label htmlFor="check3" className="text-sm">Assess data quality and identify issues</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check4" className="mr-2" />
                          <label htmlFor="check4" className="text-sm">Define feature engineering goals and success metrics</label>
                        </li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-muted border-b border-t">
                      <h4 className="font-medium">During Feature Engineering</h4>
                    </div>
                    <div className="p-4">
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <input type="checkbox" id="check5" className="mr-2" />
                          <label htmlFor="check5" className="text-sm">Handle missing data appropriately</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check6" className="mr-2" />
                          <label htmlFor="check6" className="text-sm">Clean and standardize inconsistent data</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check7" className="mr-2" />
                          <label htmlFor="check7" className="text-sm">Scale numerical features if needed</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check8" className="mr-2" />
                          <label htmlFor="check8" className="text-sm">Encode categorical variables appropriately</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check9" className="mr-2" />
                          <label htmlFor="check9" className="text-sm">Create domain-specific features</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check10" className="mr-2" />
                          <label htmlFor="check10" className="text-sm">Apply dimensionality reduction if needed</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check11" className="mr-2" />
                          <label htmlFor="check11" className="text-sm">Document all transformations and features</label>
                        </li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-muted border-b border-t">
                      <h4 className="font-medium">After Feature Engineering</h4>
                    </div>
                    <div className="p-4">
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <input type="checkbox" id="check12" className="mr-2" />
                          <label htmlFor="check12" className="text-sm">Validate feature distributions</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check13" className="mr-2" />
                          <label htmlFor="check13" className="text-sm">Assess feature importance and selection</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check14" className="mr-2" />
                          <label htmlFor="check14" className="text-sm">Implement pipeline for reproducibility</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check15" className="mr-2" />
                          <label htmlFor="check15" className="text-sm">Ensure no data leakage has occurred</label>
                        </li>
                        <li className="flex items-center">
                          <input type="checkbox" id="check16" className="mr-2" />
                          <label htmlFor="check16" className="text-sm">Create monitoring for feature drift</label>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
};

export default FeatureEngineering;