import React, { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { toast } from "@/hooks/use-toast";
import { AlertCircle, CheckCircle, Clock, Database, Server } from "lucide-react";
import { useQuery } from '@tanstack/react-query';

const MIGRATION_STEPS = [
  {
    id: 'env_vars',
    title: 'Environment Variables',
    description: 'Update environment variables for Azure SQL Server connection'
  },
  {
    id: 'connection_test',
    title: 'Connection Test',
    description: 'Test connectivity to Azure SQL Server'
  },
  {
    id: 'schema_creation',
    title: 'Schema Creation',
    description: 'Create database schema in Azure SQL Server'
  },
  {
    id: 'data_migration',
    title: 'Data Migration',
    description: 'Migrate data from PostgreSQL to Azure SQL Server'
  },
  {
    id: 'code_update',
    title: 'Code Update',
    description: 'Update application code to use SQL Server'
  },
  {
    id: 'cleanup',
    title: 'Cleanup',
    description: 'Remove PostgreSQL dependencies'
  }
];

export default function DatabaseMigration() {
  const [currentStep, setCurrentStep] = useState<string | null>(null);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [failedStep, setFailedStep] = useState<string | null>(null);
  const [migrationInProgress, setMigrationInProgress] = useState(false);
  const [confirmationInput, setConfirmationInput] = useState('');
  const [migrationStarted, setMigrationStarted] = useState(false);
  const [migrationCompleted, setMigrationCompleted] = useState(false);
  const [serverStatus, setServerStatus] = useState({
    postgres: { connected: false, loading: true },
    sqlServer: { connected: false, loading: true }
  });

  // Check database status
  const { data: dbStatus, isLoading: dbStatusLoading } = useQuery({
    queryKey: ['/api/database/status'],
    enabled: !migrationInProgress,
    refetchInterval: migrationInProgress ? false : 10000
  });

  useEffect(() => {
    if (dbStatus) {
      setServerStatus({
        postgres: { 
          connected: dbStatus.postgres?.connected || false, 
          loading: false 
        },
        sqlServer: { 
          connected: dbStatus.sqlServer?.connected || false, 
          loading: false 
        }
      });
    }
  }, [dbStatus]);

  // Calculate progress percentage
  const progressPercentage = 
    migrationCompleted 
      ? 100 
      : (completedSteps.length / MIGRATION_STEPS.length) * 100;

  const startMigration = async () => {
    if (confirmationInput !== 'MIGRATE') {
      toast({
        title: "Confirmation Failed",
        description: "Please type MIGRATE to confirm the database migration.",
        variant: "destructive"
      });
      return;
    }

    setMigrationInProgress(true);
    setMigrationStarted(true);
    setFailedStep(null);

    try {
      // Simulate migration process with API calls
      // In a real implementation, these would be calls to the server
      // that perform each step of the migration

      // Step 1: Update environment variables
      setCurrentStep('env_vars');
      await simulateApiCall('/api/migration/env-vars');
      setCompletedSteps(prev => [...prev, 'env_vars']);

      // Step 2: Test connection
      setCurrentStep('connection_test');
      await simulateApiCall('/api/migration/connection-test');
      setCompletedSteps(prev => [...prev, 'connection_test']);

      // Step 3: Create schema
      setCurrentStep('schema_creation');
      await simulateApiCall('/api/migration/schema-creation');
      setCompletedSteps(prev => [...prev, 'schema_creation']);

      // Step 4: Migrate data
      setCurrentStep('data_migration');
      await simulateApiCall('/api/migration/data-migration');
      setCompletedSteps(prev => [...prev, 'data_migration']);

      // Step 5: Update code
      setCurrentStep('code_update');
      await simulateApiCall('/api/migration/code-update');
      setCompletedSteps(prev => [...prev, 'code_update']);

      // Step 6: Cleanup
      setCurrentStep('cleanup');
      await simulateApiCall('/api/migration/cleanup');
      setCompletedSteps(prev => [...prev, 'cleanup']);

      // Migration completed
      setMigrationCompleted(true);
      setCurrentStep(null);

      toast({
        title: "Migration Completed",
        description: "The database migration has completed successfully.",
        variant: "default"
      });
    } catch (error) {
      console.error('Migration failed:', error);
      setFailedStep(currentStep);
      
      toast({
        title: "Migration Failed",
        description: `Failed at step: ${getCurrentStepTitle()}. See console for details.`,
        variant: "destructive"
      });
    } finally {
      setMigrationInProgress(false);
    }
  };

  // Helper function to simulate API calls with a delay
  const simulateApiCall = (url: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Random success or failure (90% success rate)
        if (Math.random() > 0.1) {
          resolve();
        } else {
          reject(new Error(`Failed to execute ${url}`));
        }
      }, 2000); // 2 second delay
    });
  };

  const getCurrentStepTitle = (): string => {
    if (!currentStep) return '';
    const step = MIGRATION_STEPS.find(s => s.id === currentStep);
    return step ? step.title : '';
  };

  const getStepStatus = (stepId: string) => {
    if (failedStep === stepId) return 'failed';
    if (currentStep === stepId) return 'in-progress';
    if (completedSteps.includes(stepId)) return 'completed';
    return 'pending';
  };

  const renderStepBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500">Completed</Badge>;
      case 'in-progress':
        return <Badge className="bg-blue-500">In Progress</Badge>;
      case 'failed':
        return <Badge className="bg-red-500">Failed</Badge>;
      default:
        return <Badge className="bg-gray-500">Pending</Badge>;
    }
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex flex-col space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-4">Database Migration</h1>
          <p className="text-gray-500 mb-8">
            Migration tool to transfer data from PostgreSQL to Azure SQL Server
          </p>
        </div>

        {/* Connection Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Database className="mr-2" /> PostgreSQL Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              {serverStatus.postgres.loading ? (
                <div className="flex items-center">
                  <Clock className="mr-2 animate-spin" size={16} />
                  <span>Checking connection...</span>
                </div>
              ) : serverStatus.postgres.connected ? (
                <div className="flex items-center text-green-500">
                  <CheckCircle className="mr-2" size={16} />
                  <span>Connected</span>
                </div>
              ) : (
                <div className="flex items-center text-red-500">
                  <AlertCircle className="mr-2" size={16} />
                  <span>Not connected</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Server className="mr-2" /> Azure SQL Server Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              {serverStatus.sqlServer.loading ? (
                <div className="flex items-center">
                  <Clock className="mr-2 animate-spin" size={16} />
                  <span>Checking connection...</span>
                </div>
              ) : serverStatus.sqlServer.connected ? (
                <div className="flex items-center text-green-500">
                  <CheckCircle className="mr-2" size={16} />
                  <span>Connected</span>
                </div>
              ) : (
                <div className="flex items-center text-red-500">
                  <AlertCircle className="mr-2" size={16} />
                  <span>Not connected</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Migration Progress */}
        <Card>
          <CardHeader>
            <CardTitle>Migration Progress</CardTitle>
            <CardDescription>
              {migrationCompleted
                ? "Migration completed successfully"
                : migrationInProgress
                ? `Running: ${getCurrentStepTitle()}`
                : "Migration not started"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <Progress value={progressPercentage} className="h-2" />
              <div className="text-right mt-1 text-sm text-gray-500">
                {Math.round(progressPercentage)}% Complete
              </div>
            </div>

            <div className="space-y-4">
              {MIGRATION_STEPS.map((step) => (
                <div 
                  key={step.id} 
                  className={`p-4 border rounded-md ${
                    getStepStatus(step.id) === 'failed' 
                      ? 'border-red-300 bg-red-50' 
                      : getStepStatus(step.id) === 'in-progress' 
                      ? 'border-blue-300 bg-blue-50' 
                      : getStepStatus(step.id) === 'completed' 
                      ? 'border-green-300 bg-green-50' 
                      : 'border-gray-200'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">{step.title}</h3>
                      <p className="text-sm text-gray-500">{step.description}</p>
                    </div>
                    {renderStepBadge(getStepStatus(step.id))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            {!migrationStarted ? (
              <>
                <input
                  type="text"
                  className="px-4 py-2 border rounded-md mr-4 flex-grow"
                  placeholder="Type MIGRATE to confirm"
                  value={confirmationInput}
                  onChange={(e) => setConfirmationInput(e.target.value)}
                />
                <Button 
                  onClick={startMigration} 
                  disabled={migrationInProgress}
                >
                  Start Migration
                </Button>
              </>
            ) : migrationCompleted ? (
              <Button className="ml-auto" variant="outline" onClick={() => window.location.reload()}>
                Refresh Application
              </Button>
            ) : (
              <div className="text-sm text-gray-500 ml-auto">
                {migrationInProgress ? (
                  "Migration in progress. This may take several minutes..."
                ) : failedStep ? (
                  <div className="text-red-500">
                    Migration failed. Please check the logs and try again.
                  </div>
                ) : (
                  "Migration paused."
                )}
              </div>
            )}
          </CardFooter>
        </Card>

        {/* Migration Notes */}
        <Card>
          <CardHeader>
            <CardTitle>Migration Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p>This migration will perform the following actions:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>Update environment variables to include Azure SQL Server connection parameters</li>
                <li>Create SQL Server schema that matches the current PostgreSQL schema</li>
                <li>Migrate all existing data from PostgreSQL to SQL Server</li>
                <li>Update application code to use SQL Server instead of PostgreSQL/Drizzle</li>
                <li>Remove PostgreSQL and Drizzle dependencies</li>
              </ul>
              <p className="mt-4 text-amber-600">
                <strong>Important:</strong> Make sure you have a backup of your PostgreSQL database before proceeding.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}