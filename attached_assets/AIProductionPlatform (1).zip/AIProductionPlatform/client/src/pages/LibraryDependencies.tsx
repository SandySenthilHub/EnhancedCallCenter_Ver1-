import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { Badge } from '@/components/ui/badge';
import { Search, Database, Package } from 'lucide-react';

interface AlgorithmDependency {
  id: number;
  name: string;
  version: string | null;
  packageManager: string;
  category: string | null;
  description: string | null;
  createdAt?: string;
  updatedAt?: string;
}

const LibraryDependencies: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);

  // Fetch dependencies
  const {
    data: dependencies = [],
    isLoading,
    error
  } = useQuery<AlgorithmDependency[]>({
    queryKey: ['/api/algorithm-dependencies'],
    queryFn: () => apiRequest('GET', '/api/algorithm-dependencies')
      .then(res => res.json())
      .catch(error => {
        console.error("Error fetching dependencies:", error);
        toast({
          title: "Error fetching dependencies",
          description: "Please try again later.",
          variant: "destructive"
        });
        return [];
      }),
  });

  // Get unique categories for filter dropdown
  const uniqueCategories = React.useMemo(() => {
    const categories = dependencies
      .map(dep => dep.category)
      .filter((category, index, self) => 
        category !== null && 
        category !== undefined && 
        self.indexOf(category) === index
      );
    return categories as string[];
  }, [dependencies]);

  // Filter dependencies based on search query and category
  const filteredDependencies = React.useMemo(() => {
    return dependencies.filter(dep => {
      const matchesSearch = searchQuery === '' || 
        dep.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (dep.description && dep.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (dep.category && dep.category.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = !categoryFilter || 
        (dep.category && dep.category === categoryFilter);
      
      return matchesSearch && matchesCategory;
    });
  }, [dependencies, searchQuery, categoryFilter]);

  // Handle error and loading states
  if (error) {
    return (
      <div className="container mx-auto p-6">
        <div className="bg-red-50 border border-red-200 p-4 rounded-md">
          <h2 className="text-lg font-medium text-red-800">Error loading dependencies</h2>
          <p className="text-red-600">Please try again later.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <Helmet>
        <title>Library Dependencies | AI/ML Playbook</title>
      </Helmet>

      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Library Dependencies</h1>
            <p className="text-muted-foreground">
              View and search the imported libraries and packages
            </p>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-medium flex items-center">
              <Package className="h-5 w-5 mr-2" />
              Imported Libraries ({dependencies.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              {/* Search and filter controls */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="Search libraries..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <Select
                    value={categoryFilter || "all"}
                    onValueChange={(value) => setCategoryFilter(value === "all" ? null : value)}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="All categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All categories</SelectItem>
                      {uniqueCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Libraries table */}
              {isLoading ? (
                <div className="h-[400px] flex items-center justify-center">
                  <div className="animate-pulse flex flex-col items-center">
                    <Database className="h-8 w-8 text-muted-foreground mb-2" />
                    <p className="text-muted-foreground">Loading libraries...</p>
                  </div>
                </div>
              ) : filteredDependencies.length === 0 ? (
                <div className="h-[200px] flex items-center justify-center border rounded-md">
                  <div className="text-center">
                    <Package className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No libraries found</p>
                  </div>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Version</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Package Manager</TableHead>
                        <TableHead>Description</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDependencies.map((dep) => (
                        <TableRow key={dep.id}>
                          <TableCell className="font-medium">{dep.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{dep.version || 'N/A'}</Badge>
                          </TableCell>
                          <TableCell>{dep.category || 'Uncategorized'}</TableCell>
                          <TableCell>{dep.packageManager}</TableCell>
                          <TableCell className="max-w-xs truncate">
                            {dep.description || 'No description'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
              
              <div className="text-sm text-muted-foreground mt-2">
                Showing {filteredDependencies.length} of {dependencies.length} libraries
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LibraryDependencies;