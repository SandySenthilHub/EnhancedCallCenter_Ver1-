import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { AlertCircle, Check, ChevronRight, Clock, Code, Edit, Loader2, Plus, Trash2, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/hooks/use-auth';

// Type definitions
type CicdPipeline = {
  id: number;
  name: string;
  description: string;
  triggerType: string;
  status: string;
  steps: any[];
  modelId: number;
  thresholds: Record<string, any>;
  notifications: any[];
  userId: number;
  createdAt: string;
  updatedAt: string;
};

type ApprovalWorkflow = {
  id: number;
  name: string;
  description: string;
  modelId: number;
  stages: any[];
  currentStage: number;
  status: string;
  comments: any[];
  userId: number;
  createdAt: string;
  updatedAt: string;
};

type Model = {
  id: number;
  name: string;
};

// Helper components
const StatusBadge = ({ status }: { status: string }) => {
  const color = 
    status === 'active' ? 'bg-green-100 text-green-800' : 
    status === 'inactive' ? 'bg-yellow-100 text-yellow-800' : 
    status === 'failed' ? 'bg-red-100 text-red-800' : 
    status === 'pending' ? 'bg-blue-100 text-blue-800' : 
    status === 'approved' ? 'bg-green-100 text-green-800' : 
    status === 'rejected' ? 'bg-red-100 text-red-800' : 
    'bg-gray-100 text-gray-800';

  return (
    <Badge variant="outline" className={`${color} border-0`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
};

// Main Component
const MLOpsAutomation: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('cicd');
  
  const [isCreateCicdDialogOpen, setIsCreateCicdDialogOpen] = useState(false);
  const [isCreateApprovalDialogOpen, setIsCreateApprovalDialogOpen] = useState(false);
  
  // Queries
  const {
    data: cicdPipelines = [],
    isLoading: isCicdLoading,
    error: cicdError
  } = useQuery<CicdPipeline[]>({
    queryKey: ['/api/cicd-pipelines'],
    queryFn: () => apiRequest('GET', '/api/cicd-pipelines').then(res => res.json()),
  });

  const {
    data: approvalWorkflows = [],
    isLoading: isApprovalLoading,
    error: approvalError
  } = useQuery<ApprovalWorkflow[]>({
    queryKey: ['/api/approval-workflows'],
    queryFn: () => apiRequest('GET', '/api/approval-workflows').then(res => res.json()),
  });

  const {
    data: models = [],
    isLoading: isModelsLoading,
  } = useQuery<Model[]>({
    queryKey: ['/api/models'],
    queryFn: () => apiRequest('GET', '/api/models').then(res => res.json()),
  });

  // Mutations
  const createCicdMutation = useMutation({
    mutationFn: async (pipeline: any) => {
      const res = await apiRequest('POST', '/api/cicd-pipelines', pipeline);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cicd-pipelines'] });
      setIsCreateCicdDialogOpen(false);
      toast({
        title: "Pipeline created",
        description: "CI/CD pipeline was created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create pipeline",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const createApprovalMutation = useMutation({
    mutationFn: async (workflow: any) => {
      const res = await apiRequest('POST', '/api/approval-workflows', workflow);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/approval-workflows'] });
      setIsCreateApprovalDialogOpen(false);
      toast({
        title: "Workflow created",
        description: "Approval workflow was created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create workflow",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Create CI/CD Pipeline form
  const CicdPipelineForm = () => {
    const [formData, setFormData] = useState({
      name: '',
      description: '',
      triggerType: 'scheduled',
      modelId: '',
      steps: [
        { name: 'Build', script: '# Build step code\npython -m pytest tests/' },
        { name: 'Test', script: '# Test step code\npython -m pytest tests/' },
        { name: 'Deploy', script: '# Deploy step code\naws s3 cp model.pkl s3://models/' },
      ]
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.name) {
        toast({
          title: "Missing fields",
          description: "Please provide a pipeline name",
          variant: "destructive",
        });
        return;
      }

      createCicdMutation.mutate({
        ...formData,
        userId: user?.id,
        status: 'inactive',
        thresholds: { accuracy: 0.8, f1: 0.75 },
        notifications: [{ type: 'email', recipients: [user?.email] }]
      });
    };

    return (
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 py-2 pb-4">
          <div className="space-y-2">
            <Label htmlFor="name">Pipeline Name</Label>
            <Input 
              id="name" 
              placeholder="Enter pipeline name"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea 
              id="description" 
              placeholder="Enter description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="triggerType">Trigger Type</Label>
            <Select 
              value={formData.triggerType}
              onValueChange={(value) => setFormData({...formData, triggerType: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select trigger type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="performance-based">Performance Based</SelectItem>
                <SelectItem value="manual">Manual</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="modelId">Select Model</Label>
            <Select 
              value={formData.modelId}
              onValueChange={(value) => setFormData({...formData, modelId: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a model" />
              </SelectTrigger>
              <SelectContent>
                {models.map(model => (
                  <SelectItem key={model.id} value={model.id.toString()}>
                    {model.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Pipeline Steps</Label>
            <Accordion type="single" collapsible className="w-full">
              {formData.steps.map((step, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-sm font-medium">
                    {step.name}
                  </AccordionTrigger>
                  <AccordionContent>
                    <Textarea 
                      value={step.script}
                      onChange={(e) => {
                        const newSteps = [...formData.steps];
                        newSteps[index].script = e.target.value;
                        setFormData({...formData, steps: newSteps});
                      }}
                      className="font-mono text-xs h-32"
                    />
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={createCicdMutation.isPending}>
            {createCicdMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Pipeline
          </Button>
        </DialogFooter>
      </form>
    );
  };

  // Create Approval Workflow form
  const ApprovalWorkflowForm = () => {
    const [formData, setFormData] = useState({
      name: '',
      description: '',
      modelId: '',
      stages: [
        { name: 'Data Scientist Review', approvers: [1] },
        { name: 'ML Engineer Review', approvers: [1] },
        { name: 'Business Stakeholder Review', approvers: [1] },
      ]
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.name) {
        toast({
          title: "Missing fields",
          description: "Please provide a workflow name",
          variant: "destructive",
        });
        return;
      }

      createApprovalMutation.mutate({
        ...formData,
        userId: user?.id,
        status: 'pending',
        currentStage: 0,
        comments: []
      });
    };

    return (
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 py-2 pb-4">
          <div className="space-y-2">
            <Label htmlFor="name">Workflow Name</Label>
            <Input 
              id="name" 
              placeholder="Enter workflow name"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea 
              id="description" 
              placeholder="Enter description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="modelId">Select Model</Label>
            <Select 
              value={formData.modelId}
              onValueChange={(value) => setFormData({...formData, modelId: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a model" />
              </SelectTrigger>
              <SelectContent>
                {models.map(model => (
                  <SelectItem key={model.id} value={model.id.toString()}>
                    {model.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Approval Stages</Label>
            <Card>
              <CardContent className="pt-6">
                {formData.stages.map((stage, index) => (
                  <div key={index} className="flex items-center mb-4 last:mb-0">
                    <div className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs mr-3">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{stage.name}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={createApprovalMutation.isPending}>
            {createApprovalMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Workflow
          </Button>
        </DialogFooter>
      </form>
    );
  };

  return (
    <div className="container mx-auto py-6">
      <Helmet>
        <title>MLOps Automation - AI/ML Playbook</title>
        <meta name="description" content="Automate your machine learning workflows with CI/CD pipelines and approval processes." />
      </Helmet>
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">MLOps Automation</h1>
          <p className="text-muted-foreground">Automate your machine learning workflows with CI/CD pipelines and approval processes.</p>
        </div>
        <div className="flex space-x-2">
          {activeTab === 'cicd' ? (
            <Dialog open={isCreateCicdDialogOpen} onOpenChange={setIsCreateCicdDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New CI/CD Pipeline
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Create CI/CD Pipeline</DialogTitle>
                  <DialogDescription>
                    Configure a new CI/CD pipeline for model building, testing, and deployment.
                  </DialogDescription>
                </DialogHeader>
                <CicdPipelineForm />
              </DialogContent>
            </Dialog>
          ) : (
            <Dialog open={isCreateApprovalDialogOpen} onOpenChange={setIsCreateApprovalDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Approval Workflow
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Create Approval Workflow</DialogTitle>
                  <DialogDescription>
                    Set up a new approval workflow with multi-stage review processes.
                  </DialogDescription>
                </DialogHeader>
                <ApprovalWorkflowForm />
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <Tabs defaultValue="cicd" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="cicd">CI/CD Pipelines</TabsTrigger>
          <TabsTrigger value="approval">Approval Workflows</TabsTrigger>
        </TabsList>
        
        <TabsContent value="cicd">
          {isCicdLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : cicdError ? (
            <div className="flex justify-center items-center py-12 text-destructive">
              <AlertCircle className="h-6 w-6 mr-2" />
              <p>Failed to load CI/CD pipelines</p>
            </div>
          ) : cicdPipelines.length === 0 ? (
            <div className="text-center py-12 border rounded-md border-dashed">
              <Code className="h-12 w-12 mx-auto text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">No CI/CD Pipelines</h3>
              <p className="text-muted-foreground mt-2">Get started by creating your first pipeline.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setIsCreateCicdDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Pipeline
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {cicdPipelines.map(pipeline => (
                <Card key={pipeline.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{pipeline.name}</CardTitle>
                      <StatusBadge status={pipeline.status} />
                    </div>
                    <CardDescription className="line-clamp-2">
                      {pipeline.description || "No description provided"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="text-sm">
                      <div className="flex items-center mb-2">
                        <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          Trigger: {pipeline.triggerType.replace('-', ' ')}
                        </span>
                      </div>
                      <div className="space-y-2">
                        {pipeline.steps.map((step, index) => (
                          <div key={index} className="flex items-center text-sm">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center mr-2 text-xs 
                              ${index < 2 ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                              {index < 2 ? <Check className="h-3 w-3" /> : (index + 1)}
                            </div>
                            <span>{step.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2">
                    <div className="flex justify-between items-center w-full">
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm">
                        Run
                        <ChevronRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="approval">
          {isApprovalLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : approvalError ? (
            <div className="flex justify-center items-center py-12 text-destructive">
              <AlertCircle className="h-6 w-6 mr-2" />
              <p>Failed to load approval workflows</p>
            </div>
          ) : approvalWorkflows.length === 0 ? (
            <div className="text-center py-12 border rounded-md border-dashed">
              <Clock className="h-12 w-12 mx-auto text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">No Approval Workflows</h3>
              <p className="text-muted-foreground mt-2">Start by creating your first approval workflow.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setIsCreateApprovalDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Workflow
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {approvalWorkflows.map(workflow => (
                <Card key={workflow.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{workflow.name}</CardTitle>
                      <StatusBadge status={workflow.status} />
                    </div>
                    <CardDescription className="line-clamp-2">
                      {workflow.description || "No description provided"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        {workflow.stages.map((stage, index) => (
                          <div key={index} className="flex items-center text-sm">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center mr-2 text-xs
                              ${index < workflow.currentStage ? 'bg-green-100 text-green-800' : 
                                index === workflow.currentStage ? 'bg-blue-100 text-blue-800' : 
                                'bg-gray-100 text-gray-800'}`}>
                              {index < workflow.currentStage ? 
                                <Check className="h-3 w-3" /> : 
                                (index + 1)
                              }
                            </div>
                            <span className={index === workflow.currentStage ? 'font-medium' : ''}>
                              {stage.name}
                            </span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="text-sm">
                        <span className="font-medium">Current stage: </span>
                        <span>{workflow.stages[workflow.currentStage]?.name || 'Not started'}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <div className="flex justify-between items-center w-full">
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      {workflow.status === 'pending' && (
                        <div className="flex space-x-1">
                          <Button variant="outline" size="sm" className="border-green-500 text-green-600 hover:bg-green-50">
                            <Check className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button variant="outline" size="sm" className="border-red-500 text-red-600 hover:bg-red-50">
                            <X className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MLOpsAutomation;