import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, ArrowRight, ChevronLeft, Sparkles, Settings, Target, Database, Search } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Types for wizard steps and recommendation
type WizardStep = 'business-case' | 'data-type' | 'objective' | 'requirements' | 'preferences' | 'results';

interface UserPreferences {
  preferredDataTypes: string[];
  preferredAlgorithms: string[];
  preferredMetrics: string[];
  domainExpertise: string[];
  skillLevel: 'beginner' | 'intermediate' | 'advanced';
}

interface BusinessCaseSelection {
  businessCase: string;
  description?: string;
}

interface DataTypeSelection {
  dataType: string;
  format?: string;
  size?: string;
  hasTimeComponent: boolean;
}

interface ObjectiveSelection {
  objective: string;
  description?: string;
  targetVariable?: string;
}

interface RequirementsSelection {
  explainability: boolean;
  realTimeInference: boolean;
  automatedRetraining: boolean;
  deploymentEnvironment: string;
  resourceConstraints?: string;
}

// Main wizard component
const WorkflowWizard: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState<WizardStep>('business-case');
  const [loadingResults, setLoadingResults] = useState(false);
  
  // State for each step's data
  const [businessCase, setBusinessCase] = useState<BusinessCaseSelection>({ businessCase: '', description: '' });
  const [dataType, setDataType] = useState<DataTypeSelection>({ dataType: '', hasTimeComponent: false });
  const [objective, setObjective] = useState<ObjectiveSelection>({ objective: '' });
  const [requirements, setRequirements] = useState<RequirementsSelection>({
    explainability: false,
    realTimeInference: false,
    automatedRetraining: false,
    deploymentEnvironment: 'cloud'
  });
  
  // Load user preferences if available
  const { data: preferences, isLoading: loadingPreferences } = useQuery<UserPreferences>({
    queryKey: ['/api/user-workflow-preferences'],
    enabled: !!user,
  });
  
  // Load business cases for selection
  const { data: businessCases, isLoading: loadingBusinessCases } = useQuery({
    queryKey: ['/api/business-case-settings'],
    enabled: currentStep === 'business-case',
  });
  
  // Load recommendation templates
  const { data: recommendationTemplates, isLoading: loadingTemplates } = useQuery({
    queryKey: ['/api/recommendation-templates'],
    enabled: currentStep === 'results',
  });
  
  // Create recommendation mutation
  const createRecommendationMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/workflow-recommendations', data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Recommendation created",
        description: "Your personalized ML workflow recommendation has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/workflow-recommendations'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating recommendation",
        description: error.message || "An error occurred while creating your recommendation.",
        variant: "destructive",
      });
    }
  });
  
  // Navigation functions
  const goToNextStep = () => {
    if (currentStep === 'business-case') setCurrentStep('data-type');
    else if (currentStep === 'data-type') setCurrentStep('objective');
    else if (currentStep === 'objective') setCurrentStep('requirements');
    else if (currentStep === 'requirements') setCurrentStep('preferences');
    else if (currentStep === 'preferences') {
      setLoadingResults(true);
      // Generate recommendation based on all selections
      generateRecommendation();
    }
  };
  
  const goToPreviousStep = () => {
    if (currentStep === 'data-type') setCurrentStep('business-case');
    else if (currentStep === 'objective') setCurrentStep('data-type');
    else if (currentStep === 'requirements') setCurrentStep('objective');
    else if (currentStep === 'preferences') setCurrentStep('requirements');
    else if (currentStep === 'results') setCurrentStep('preferences');
  };
  
  const generateRecommendation = async () => {
    // Aggregate all data from different steps
    const recommendationData = {
      name: `${businessCase.businessCase} - ${objective.objective} Workflow`,
      description: businessCase.description,
      businessCase: businessCase.businessCase,
      dataType: dataType.dataType,
      objective: objective.objective,
      // Placeholder structures to be populated with actual recommendations
      features: {
        engineeringSteps: [],
        selectionMethod: '',
        transformations: []
      },
      models: [
        // Will be populated based on selections
      ],
      pipeline: {
        steps: [],
        schedule: "manual",
        monitoring: {
          metrics: [],
          alerts: []
        }
      }
    };
    
    try {
      // This would normally call the API to get AI-generated recommendations
      // For now, we'll simulate a recommendation process with a timeout
      setTimeout(() => {
        setLoadingResults(false);
        setCurrentStep('results');
      }, 2000);
      
      // In a real implementation, we would save the recommendation:
      // await createRecommendationMutation.mutateAsync(recommendationData);
    } catch (error) {
      setLoadingResults(false);
      toast({
        title: "Error generating recommendation",
        description: "An error occurred while generating your workflow recommendation.",
        variant: "destructive",
      });
    }
  };
  
  // Check if current step is valid for proceeding
  const isCurrentStepValid = () => {
    if (currentStep === 'business-case') return !!businessCase.businessCase;
    if (currentStep === 'data-type') return !!dataType.dataType;
    if (currentStep === 'objective') return !!objective.objective;
    return true;
  };
  
  // Render wizard step content
  const renderStepContent = () => {
    switch (currentStep) {
      case 'business-case':
        return renderBusinessCaseStep();
      case 'data-type':
        return renderDataTypeStep();
      case 'objective':
        return renderObjectiveStep();
      case 'requirements':
        return renderRequirementsStep();
      case 'preferences':
        return renderPreferencesStep();
      case 'results':
        return renderResultsStep();
      default:
        return null;
    }
  };
  
  // Business Case Selection Step
  const renderBusinessCaseStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Select a Business Case</h3>
        <p className="text-sm text-neutral-500">Choose the business domain or use case for your ML workflow</p>
      </div>
      
      {loadingBusinessCases ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Business Case Selections */}
          <div 
            className={`p-4 border rounded-lg cursor-pointer hover:border-primary ${
              businessCase.businessCase === 'customer-churn' ? 'border-primary bg-primary/5' : ''
            }`}
            onClick={() => setBusinessCase({ 
              businessCase: 'customer-churn', 
              description: 'Predict which customers are likely to churn and take preventive actions'
            })}
          >
            <h4 className="font-medium">Customer Churn Prediction</h4>
            <p className="text-sm text-neutral-500">Identify customers at risk of leaving</p>
          </div>
          
          <div 
            className={`p-4 border rounded-lg cursor-pointer hover:border-primary ${
              businessCase.businessCase === 'fraud-detection' ? 'border-primary bg-primary/5' : ''
            }`}
            onClick={() => setBusinessCase({ 
              businessCase: 'fraud-detection', 
              description: 'Detect fraudulent transactions and suspicious activities in real-time'
            })}
          >
            <h4 className="font-medium">Fraud Detection</h4>
            <p className="text-sm text-neutral-500">Identify suspicious transactions and activities</p>
          </div>
          
          <div 
            className={`p-4 border rounded-lg cursor-pointer hover:border-primary ${
              businessCase.businessCase === 'demand-forecasting' ? 'border-primary bg-primary/5' : ''
            }`}
            onClick={() => setBusinessCase({ 
              businessCase: 'demand-forecasting', 
              description: 'Predict future demand for products or services to optimize inventory and resources'
            })}
          >
            <h4 className="font-medium">Demand Forecasting</h4>
            <p className="text-sm text-neutral-500">Predict future demand for products or services</p>
          </div>
          
          <div 
            className={`p-4 border rounded-lg cursor-pointer hover:border-primary ${
              businessCase.businessCase === 'recommendation-system' ? 'border-primary bg-primary/5' : ''
            }`}
            onClick={() => setBusinessCase({ 
              businessCase: 'recommendation-system', 
              description: 'Provide personalized product or content recommendations to users'
            })}
          >
            <h4 className="font-medium">Recommendation System</h4>
            <p className="text-sm text-neutral-500">Suggest products or content to users</p>
          </div>
          
          <div 
            className={`p-4 border rounded-lg cursor-pointer hover:border-primary ${
              businessCase.businessCase === 'predictive-maintenance' ? 'border-primary bg-primary/5' : ''
            }`}
            onClick={() => setBusinessCase({ 
              businessCase: 'predictive-maintenance', 
              description: 'Predict equipment failures before they occur to schedule maintenance efficiently'
            })}
          >
            <h4 className="font-medium">Predictive Maintenance</h4>
            <p className="text-sm text-neutral-500">Forecast equipment failures before they happen</p>
          </div>
          
          <div 
            className={`p-4 border rounded-lg cursor-pointer hover:border-primary ${
              businessCase.businessCase === 'custom' ? 'border-primary bg-primary/5' : ''
            }`}
            onClick={() => setBusinessCase({ 
              businessCase: 'custom', 
              description: ''
            })}
          >
            <h4 className="font-medium">Custom Use Case</h4>
            <p className="text-sm text-neutral-500">Define your own business case</p>
          </div>
        </div>
      )}
      
      {businessCase.businessCase === 'custom' && (
        <div className="space-y-4 mt-4">
          <div>
            <Label htmlFor="custom-case">Describe your business case</Label>
            <Textarea 
              id="custom-case" 
              placeholder="Describe your specific business problem and what you want to achieve with machine learning..." 
              value={businessCase.description || ''}
              onChange={(e) => setBusinessCase({ ...businessCase, description: e.target.value })}
              className="mt-1"
            />
          </div>
        </div>
      )}
    </div>
  );
  
  // Data Type Selection Step
  const renderDataTypeStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Data Type Information</h3>
        <p className="text-sm text-neutral-500">Tell us about the data you'll be working with</p>
      </div>
      
      <div className="space-y-4">
        <div>
          <Label>Primary Data Type</Label>
          <RadioGroup 
            value={dataType.dataType} 
            onValueChange={(value) => setDataType({ ...dataType, dataType: value })}
            className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-3"
          >
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="structured" id="structured" />
              <Label htmlFor="structured" className="flex flex-col cursor-pointer">
                <span className="font-medium">Structured Data</span>
                <span className="text-xs text-neutral-500">Tabular data, database records, CSV files</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="time-series" id="time-series" />
              <Label htmlFor="time-series" className="flex flex-col cursor-pointer">
                <span className="font-medium">Time Series Data</span>
                <span className="text-xs text-neutral-500">Sequential data with timestamps</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="text" id="text" />
              <Label htmlFor="text" className="flex flex-col cursor-pointer">
                <span className="font-medium">Text Data</span>
                <span className="text-xs text-neutral-500">Documents, reviews, social media posts</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="image" id="image" />
              <Label htmlFor="image" className="flex flex-col cursor-pointer">
                <span className="font-medium">Image Data</span>
                <span className="text-xs text-neutral-500">Photos, diagrams, scanned documents</span>
              </Label>
            </div>
          </RadioGroup>
        </div>
        
        {dataType.dataType && (
          <>
            <div>
              <Label htmlFor="data-format">Data Format</Label>
              <Select 
                value={dataType.format || ""} 
                onValueChange={(value) => setDataType({ ...dataType, format: value })}
              >
                <SelectTrigger id="data-format" className="mt-1">
                  <SelectValue placeholder="Select data format" />
                </SelectTrigger>
                <SelectContent>
                  {dataType.dataType === 'structured' && (
                    <>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                      <SelectItem value="database">Database</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                    </>
                  )}
                  {dataType.dataType === 'time-series' && (
                    <>
                      <SelectItem value="csv">CSV with timestamps</SelectItem>
                      <SelectItem value="database">Time-series database</SelectItem>
                      <SelectItem value="iot">IoT stream</SelectItem>
                    </>
                  )}
                  {dataType.dataType === 'text' && (
                    <>
                      <SelectItem value="txt">Text files</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="pdf">PDF</SelectItem>
                      <SelectItem value="html">HTML</SelectItem>
                    </>
                  )}
                  {dataType.dataType === 'image' && (
                    <>
                      <SelectItem value="jpg">JPG/JPEG</SelectItem>
                      <SelectItem value="png">PNG</SelectItem>
                      <SelectItem value="tiff">TIFF</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="data-size">Approximate Dataset Size</Label>
              <Select 
                value={dataType.size || ""} 
                onValueChange={(value) => setDataType({ ...dataType, size: value })}
              >
                <SelectTrigger id="data-size" className="mt-1">
                  <SelectValue placeholder="Select dataset size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="small">Small (&lt; 1GB)</SelectItem>
                  <SelectItem value="medium">Medium (1-50GB)</SelectItem>
                  <SelectItem value="large">Large (50-500GB)</SelectItem>
                  <SelectItem value="very-large">Very Large (&gt; 500GB)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {(dataType.dataType === 'structured') && (
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="time-component" 
                  checked={dataType.hasTimeComponent}
                  onCheckedChange={(checked) => 
                    setDataType({ ...dataType, hasTimeComponent: checked === true })
                  }
                />
                <Label htmlFor="time-component">Data has important time component</Label>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
  
  // Objective Selection Step
  const renderObjectiveStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Define Your Objective</h3>
        <p className="text-sm text-neutral-500">What do you want to achieve with your machine learning model?</p>
      </div>
      
      <div className="space-y-4">
        <div>
          <Label>Primary Objective</Label>
          <RadioGroup 
            value={objective.objective} 
            onValueChange={(value) => setObjective({ ...objective, objective: value })}
            className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-3"
          >
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="classification" id="classification" />
              <Label htmlFor="classification" className="flex flex-col cursor-pointer">
                <span className="font-medium">Classification</span>
                <span className="text-xs text-neutral-500">Categorize data into predefined classes</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="regression" id="regression" />
              <Label htmlFor="regression" className="flex flex-col cursor-pointer">
                <span className="font-medium">Regression</span>
                <span className="text-xs text-neutral-500">Predict continuous numerical values</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="clustering" id="clustering" />
              <Label htmlFor="clustering" className="flex flex-col cursor-pointer">
                <span className="font-medium">Clustering</span>
                <span className="text-xs text-neutral-500">Group similar data points together</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="anomaly-detection" id="anomaly-detection" />
              <Label htmlFor="anomaly-detection" className="flex flex-col cursor-pointer">
                <span className="font-medium">Anomaly Detection</span>
                <span className="text-xs text-neutral-500">Identify unusual patterns or outliers</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="forecasting" id="forecasting" />
              <Label htmlFor="forecasting" className="flex flex-col cursor-pointer">
                <span className="font-medium">Forecasting</span>
                <span className="text-xs text-neutral-500">Predict future values based on historical data</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="recommendation" id="recommendation" />
              <Label htmlFor="recommendation" className="flex flex-col cursor-pointer">
                <span className="font-medium">Recommendation</span>
                <span className="text-xs text-neutral-500">Suggest items or actions to users</span>
              </Label>
            </div>
          </RadioGroup>
        </div>
        
        {(objective.objective === 'classification' || objective.objective === 'regression') && (
          <div>
            <Label htmlFor="target-variable">Target Variable</Label>
            <Input 
              id="target-variable" 
              placeholder="What are you trying to predict?" 
              className="mt-1"
              value={objective.targetVariable || ''}
              onChange={(e) => setObjective({ ...objective, targetVariable: e.target.value })}
            />
          </div>
        )}
        
        <div>
          <Label htmlFor="objective-description">Additional Details (Optional)</Label>
          <Textarea 
            id="objective-description" 
            placeholder="Provide additional context about your objective..." 
            className="mt-1"
            value={objective.description || ''}
            onChange={(e) => setObjective({ ...objective, description: e.target.value })}
          />
        </div>
      </div>
    </div>
  );
  
  // Requirements Selection Step
  const renderRequirementsStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Project Requirements</h3>
        <p className="text-sm text-neutral-500">Define key requirements for your ML workflow</p>
      </div>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Model Requirements</Label>
          
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="explainability" 
              checked={requirements.explainability}
              onCheckedChange={(checked) => 
                setRequirements({ ...requirements, explainability: checked === true })
              }
            />
            <Label htmlFor="explainability" className="cursor-pointer">
              Model explainability is important
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="real-time" 
              checked={requirements.realTimeInference}
              onCheckedChange={(checked) => 
                setRequirements({ ...requirements, realTimeInference: checked === true })
              }
            />
            <Label htmlFor="real-time" className="cursor-pointer">
              Need real-time inference
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="auto-retrain" 
              checked={requirements.automatedRetraining}
              onCheckedChange={(checked) => 
                setRequirements({ ...requirements, automatedRetraining: checked === true })
              }
            />
            <Label htmlFor="auto-retrain" className="cursor-pointer">
              Require automated model retraining
            </Label>
          </div>
        </div>
        
        <div>
          <Label>Deployment Environment</Label>
          <RadioGroup 
            value={requirements.deploymentEnvironment} 
            onValueChange={(value) => setRequirements({ ...requirements, deploymentEnvironment: value })}
            className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-3"
          >
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="cloud" id="cloud" />
              <Label htmlFor="cloud" className="cursor-pointer">Cloud</Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="on-premise" id="on-premise" />
              <Label htmlFor="on-premise" className="cursor-pointer">On-premise</Label>
            </div>
            
            <div className="flex items-center space-x-2 rounded-md border p-3">
              <RadioGroupItem value="edge" id="edge" />
              <Label htmlFor="edge" className="cursor-pointer">Edge/IoT</Label>
            </div>
          </RadioGroup>
        </div>
        
        <div>
          <Label htmlFor="constraints">Resource Constraints (Optional)</Label>
          <Textarea 
            id="constraints" 
            placeholder="Describe any memory, compute, or latency constraints..." 
            className="mt-1"
            value={requirements.resourceConstraints || ''}
            onChange={(e) => setRequirements({ ...requirements, resourceConstraints: e.target.value })}
          />
        </div>
      </div>
    </div>
  );
  
  // User Preferences Step
  const renderPreferencesStep = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Your Preferences</h3>
        <p className="text-sm text-neutral-500">Help us personalize recommendations based on your experience</p>
      </div>
      
      {loadingPreferences ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="space-y-4">
          <div>
            <Label>Experience Level</Label>
            <RadioGroup 
              defaultValue={preferences?.skillLevel || "intermediate"} 
              className="mt-2 grid grid-cols-3 gap-3"
            >
              <div className="flex items-center space-x-2 rounded-md border p-3">
                <RadioGroupItem value="beginner" id="beginner" />
                <Label htmlFor="beginner" className="cursor-pointer">Beginner</Label>
              </div>
              
              <div className="flex items-center space-x-2 rounded-md border p-3">
                <RadioGroupItem value="intermediate" id="intermediate" />
                <Label htmlFor="intermediate" className="cursor-pointer">Intermediate</Label>
              </div>
              
              <div className="flex items-center space-x-2 rounded-md border p-3">
                <RadioGroupItem value="advanced" id="advanced" />
                <Label htmlFor="advanced" className="cursor-pointer">Advanced</Label>
              </div>
            </RadioGroup>
          </div>
          
          <div>
            <Label>Preferred Algorithms</Label>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="random-forest" defaultChecked={preferences?.preferredAlgorithms?.includes('random-forest')} />
                <Label htmlFor="random-forest" className="cursor-pointer">Random Forest</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="gradient-boosting" defaultChecked={preferences?.preferredAlgorithms?.includes('gradient-boosting')} />
                <Label htmlFor="gradient-boosting" className="cursor-pointer">Gradient Boosting</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="neural-networks" defaultChecked={preferences?.preferredAlgorithms?.includes('neural-networks')} />
                <Label htmlFor="neural-networks" className="cursor-pointer">Neural Networks</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="linear-models" defaultChecked={preferences?.preferredAlgorithms?.includes('linear-models')} />
                <Label htmlFor="linear-models" className="cursor-pointer">Linear Models</Label>
              </div>
            </div>
          </div>
          
          <div>
            <Label>Domain Expertise</Label>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <div className="flex items-center space-x-2">
                <Checkbox id="finance" defaultChecked={preferences?.domainExpertise?.includes('finance')} />
                <Label htmlFor="finance" className="cursor-pointer">Finance</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="healthcare" defaultChecked={preferences?.domainExpertise?.includes('healthcare')} />
                <Label htmlFor="healthcare" className="cursor-pointer">Healthcare</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="retail" defaultChecked={preferences?.domainExpertise?.includes('retail')} />
                <Label htmlFor="retail" className="cursor-pointer">Retail</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox id="manufacturing" defaultChecked={preferences?.domainExpertise?.includes('manufacturing')} />
                <Label htmlFor="manufacturing" className="cursor-pointer">Manufacturing</Label>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
  
  // Results Step
  const renderResultsStep = () => (
    <div className="space-y-6">
      <div>
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Your Personalized ML Workflow</h3>
          <Badge variant="outline" className="px-2 py-1">
            <Sparkles className="h-3 w-3 mr-1" />
            AI Generated
          </Badge>
        </div>
        <p className="text-sm text-neutral-500">Based on your selections, here's our recommendation</p>
      </div>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="data">Data Pipeline</TabsTrigger>
          <TabsTrigger value="model">Model Selection</TabsTrigger>
          <TabsTrigger value="deployment">Deployment</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Workflow Summary</CardTitle>
              <CardDescription>
                {businessCase.businessCase === 'customer-churn' 
                  ? 'Customer Churn Prediction Workflow'
                  : businessCase.businessCase === 'fraud-detection'
                  ? 'Fraud Detection Workflow'
                  : `${businessCase.businessCase} Workflow`}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-500">Business Case:</span>
                  <span className="font-medium">{businessCase.businessCase}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-500">Data Type:</span>
                  <span className="font-medium">{dataType.dataType}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-neutral-500">Objective:</span>
                  <span className="font-medium">{objective.objective}</span>
                </div>
                <Separator />
                <div className="pt-2">
                  <h4 className="text-sm font-medium mb-2">Recommended Workflow Steps</h4>
                  <ol className="space-y-2 text-sm">
                    <li className="flex items-center">
                      <div className="h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">1</div>
                      <span>Data preprocessing and cleaning</span>
                    </li>
                    <li className="flex items-center">
                      <div className="h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">2</div>
                      <span>Feature engineering specific to {businessCase.businessCase}</span>
                    </li>
                    <li className="flex items-center">
                      <div className="h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">3</div>
                      <span>{objective.objective === 'classification' ? 'Binary classification model training' : 'Model training'}</span>
                    </li>
                    <li className="flex items-center">
                      <div className="h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">4</div>
                      <span>Model evaluation and optimization</span>
                    </li>
                    <li className="flex items-center">
                      <div className="h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center mr-2">5</div>
                      <span>Deployment to {requirements.deploymentEnvironment} environment</span>
                    </li>
                  </ol>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Save This Recommendation
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="data" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Data Pipeline</CardTitle>
              <CardDescription>Recommended data processing steps</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium">Data Sources</h4>
                  <div className="mt-2 grid grid-cols-1 gap-2">
                    <div className="flex items-center space-x-2 p-2 rounded-md border">
                      <Database className="h-4 w-4 text-primary" />
                      <span className="text-sm">{dataType.format || 'CSV'} data files</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium">Preprocessing Steps</h4>
                  <div className="mt-2 space-y-2">
                    <div className="p-2 rounded-md border text-sm">
                      <div className="font-medium">Handle Missing Values</div>
                      <div className="text-neutral-500">Impute missing values using mean/median for numerical and mode for categorical</div>
                    </div>
                    
                    <div className="p-2 rounded-md border text-sm">
                      <div className="font-medium">Feature Scaling</div>
                      <div className="text-neutral-500">Standardize numerical features</div>
                    </div>
                    
                    <div className="p-2 rounded-md border text-sm">
                      <div className="font-medium">Encoding</div>
                      <div className="text-neutral-500">One-hot encode categorical variables</div>
                    </div>
                    
                    {dataType.hasTimeComponent && (
                      <div className="p-2 rounded-md border text-sm">
                        <div className="font-medium">Time Features</div>
                        <div className="text-neutral-500">Extract date/time components (day, month, year, etc.)</div>
                      </div>
                    )}
                  </div>
                </div>
                
                {objective.objective === 'classification' && (
                  <>
                    <Separator />
                    
                    <div>
                      <h4 className="text-sm font-medium">Class Imbalance Handling</h4>
                      <div className="mt-2">
                        <div className="p-2 rounded-md border text-sm">
                          <div className="font-medium">SMOTE</div>
                          <div className="text-neutral-500">Synthetic Minority Over-sampling Technique to address class imbalance</div>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Generate Data Pipeline Code
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="model" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Model Recommendations</CardTitle>
              <CardDescription>Algorithms suited for your use case</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-3 rounded-md border border-primary bg-primary/5">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">Primary Recommendation</div>
                    <Badge>Best Match</Badge>
                  </div>
                  
                  <div className="mt-2">
                    {objective.objective === 'classification' && (
                      <div className="text-sm">
                        <div className="font-medium">Gradient Boosting Classifier</div>
                        <div className="text-neutral-500 mt-1">XGBoost or LightGBM implementation</div>
                        <div className="mt-2 flex items-center text-sm">
                          <span className="text-neutral-500 mr-1">Strengths:</span>
                          <span>High accuracy, handles complex relationships, feature importance</span>
                        </div>
                      </div>
                    )}
                    
                    {objective.objective === 'regression' && (
                      <div className="text-sm">
                        <div className="font-medium">Gradient Boosting Regressor</div>
                        <div className="text-neutral-500 mt-1">XGBoost implementation</div>
                        <div className="mt-2 flex items-center text-sm">
                          <span className="text-neutral-500 mr-1">Strengths:</span>
                          <span>High accuracy, handles non-linear relationships, feature importance</span>
                        </div>
                      </div>
                    )}
                    
                    {objective.objective === 'clustering' && (
                      <div className="text-sm">
                        <div className="font-medium">K-Means Clustering</div>
                        <div className="text-neutral-500 mt-1">With automated k selection</div>
                        <div className="mt-2 flex items-center text-sm">
                          <span className="text-neutral-500 mr-1">Strengths:</span>
                          <span>Scalable, intuitive, widely used for segmentation tasks</span>
                        </div>
                      </div>
                    )}
                    
                    {objective.objective === 'forecasting' && (
                      <div className="text-sm">
                        <div className="font-medium">ARIMA + XGBoost Hybrid</div>
                        <div className="text-neutral-500 mt-1">Combines statistical and ML approaches</div>
                        <div className="mt-2 flex items-center text-sm">
                          <span className="text-neutral-500 mr-1">Strengths:</span>
                          <span>Captures trends, seasonality, and complex patterns</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-2">Alternative Models</h4>
                  <div className="space-y-2">
                    <div className="p-2 rounded-md border text-sm">
                      <div className="font-medium">Random Forest</div>
                      <div className="text-neutral-500">Good balance of performance and interpretability</div>
                    </div>
                    
                    {requirements.explainability && (
                      <div className="p-2 rounded-md border text-sm">
                        <div className="font-medium">Explainable Boosting Machine</div>
                        <div className="text-neutral-500">Prioritizes interpretability while maintaining high accuracy</div>
                      </div>
                    )}
                    
                    {requirements.realTimeInference && (
                      <div className="p-2 rounded-md border text-sm">
                        <div className="font-medium">Decision Tree</div>
                        <div className="text-neutral-500">Faster inference times, suitable for real-time applications</div>
                      </div>
                    )}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium">Evaluation Metrics</h4>
                  <div className="mt-2 space-y-2">
                    {objective.objective === 'classification' && (
                      <>
                        <div className="flex justify-between items-center text-sm">
                          <span>Accuracy</span>
                          <span className="text-neutral-500">Overall correctness</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span>F1 Score</span>
                          <span className="text-neutral-500">Balance between precision and recall</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span>AUC-ROC</span>
                          <span className="text-neutral-500">Discrimination ability</span>
                        </div>
                      </>
                    )}
                    
                    {objective.objective === 'regression' && (
                      <>
                        <div className="flex justify-between items-center text-sm">
                          <span>RMSE</span>
                          <span className="text-neutral-500">Root Mean Squared Error</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span>MAE</span>
                          <span className="text-neutral-500">Mean Absolute Error</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span>R²</span>
                          <span className="text-neutral-500">Coefficient of determination</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Generate Model Training Code
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="deployment" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Deployment Recommendations</CardTitle>
              <CardDescription>How to deploy and monitor your model</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium">Deployment Strategy</h4>
                  <div className="mt-2 p-3 rounded-md border">
                    {requirements.deploymentEnvironment === 'cloud' && (
                      <div className="text-sm">
                        <div className="font-medium">REST API with Docker</div>
                        <div className="text-neutral-500 mt-1">Deploy as containerized microservice on cloud platform</div>
                        <div className="mt-2">
                          <span className="text-neutral-500">Suggested Tools:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            <Badge variant="secondary">FastAPI</Badge>
                            <Badge variant="secondary">Docker</Badge>
                            <Badge variant="secondary">Kubernetes</Badge>
                            <Badge variant="secondary">AWS/Azure/GCP</Badge>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {requirements.deploymentEnvironment === 'on-premise' && (
                      <div className="text-sm">
                        <div className="font-medium">On-premise Deployment</div>
                        <div className="text-neutral-500 mt-1">Deploy within existing infrastructure</div>
                        <div className="mt-2">
                          <span className="text-neutral-500">Suggested Tools:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            <Badge variant="secondary">Flask/FastAPI</Badge>
                            <Badge variant="secondary">Docker</Badge>
                            <Badge variant="secondary">MLflow</Badge>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {requirements.deploymentEnvironment === 'edge' && (
                      <div className="text-sm">
                        <div className="font-medium">Edge Deployment</div>
                        <div className="text-neutral-500 mt-1">Optimize for edge devices with limited resources</div>
                        <div className="mt-2">
                          <span className="text-neutral-500">Suggested Tools:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            <Badge variant="secondary">ONNX</Badge>
                            <Badge variant="secondary">TensorFlow Lite</Badge>
                            <Badge variant="secondary">Edge TPU</Badge>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium">Monitoring & Maintenance</h4>
                  <div className="mt-2 space-y-2">
                    <div className="p-2 rounded-md border text-sm">
                      <div className="font-medium">Model Performance Monitoring</div>
                      <div className="text-neutral-500">Track inference quality metrics over time</div>
                    </div>
                    
                    <div className="p-2 rounded-md border text-sm">
                      <div className="font-medium">Data Drift Detection</div>
                      <div className="text-neutral-500">Monitor for changes in input data distributions</div>
                    </div>
                    
                    {requirements.automatedRetraining && (
                      <div className="p-2 rounded-md border text-sm">
                        <div className="font-medium">Automated Retraining Pipeline</div>
                        <div className="text-neutral-500">Schedule periodic retraining with performance validation</div>
                      </div>
                    )}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="text-sm font-medium">CI/CD Pipeline</h4>
                  <div className="mt-2 p-3 rounded-md border text-sm">
                    <ol className="space-y-2 list-decimal list-inside">
                      <li>Model training and evaluation in isolated environment</li>
                      <li>Automated testing against validation datasets</li>
                      <li>Performance comparison with previous model version</li>
                      <li>Containerization and deployment to target environment</li>
                      <li>Post-deployment verification and monitoring setup</li>
                    </ol>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Generate Deployment Code
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
  
  // Render wizard navigation
  const renderNavigation = () => (
    <div className="flex items-center justify-between mt-6">
      <Button
        variant="outline"
        onClick={goToPreviousStep}
        disabled={currentStep === 'business-case'}
      >
        <ChevronLeft className="h-4 w-4 mr-2" />
        Back
      </Button>
      
      {currentStep !== 'results' ? (
        <Button
          onClick={goToNextStep}
          disabled={!isCurrentStepValid() || loadingResults}
        >
          {loadingResults ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Generating Recommendation...
            </>
          ) : (
            <>
              {currentStep === 'preferences' ? 'Generate Recommendation' : 'Next'}
              <ArrowRight className="h-4 w-4 ml-2" />
            </>
          )}
        </Button>
      ) : (
        <Button onClick={() => {/* Save or export recommendation */}}>
          Save Workflow
        </Button>
      )}
    </div>
  );
  
  // Main render
  return (
    <div className="container py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">ML Workflow Recommendation Wizard</h1>
        <p className="text-neutral-500 mt-2">
          Let us help you design the optimal machine learning workflow for your business needs
        </p>
      </div>
      
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full border ${
              currentStep === 'business-case' ? 'border-primary bg-primary text-white' : 'text-neutral-500'
            }`}>
              <Search className="h-5 w-5" />
            </div>
            <div className={`h-px w-6 ${
              ['data-type', 'objective', 'requirements', 'preferences', 'results'].includes(currentStep) 
                ? 'bg-primary' : 'bg-neutral-200'
            }`} />
          </div>
          
          <div className="flex items-center">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full border ${
              currentStep === 'data-type' ? 'border-primary bg-primary text-white' : 
              ['objective', 'requirements', 'preferences', 'results'].includes(currentStep) ? 'border-primary text-primary' : 'text-neutral-500'
            }`}>
              <Database className="h-5 w-5" />
            </div>
            <div className={`h-px w-6 ${
              ['objective', 'requirements', 'preferences', 'results'].includes(currentStep) 
                ? 'bg-primary' : 'bg-neutral-200'
            }`} />
          </div>
          
          <div className="flex items-center">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full border ${
              currentStep === 'objective' ? 'border-primary bg-primary text-white' : 
              ['requirements', 'preferences', 'results'].includes(currentStep) ? 'border-primary text-primary' : 'text-neutral-500'
            }`}>
              <Target className="h-5 w-5" />
            </div>
            <div className={`h-px w-6 ${
              ['requirements', 'preferences', 'results'].includes(currentStep) 
                ? 'bg-primary' : 'bg-neutral-200'
            }`} />
          </div>
          
          <div className="flex items-center">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full border ${
              currentStep === 'requirements' ? 'border-primary bg-primary text-white' : 
              ['preferences', 'results'].includes(currentStep) ? 'border-primary text-primary' : 'text-neutral-500'
            }`}>
              <Settings className="h-5 w-5" />
            </div>
            <div className={`h-px w-6 ${
              ['preferences', 'results'].includes(currentStep) 
                ? 'bg-primary' : 'bg-neutral-200'
            }`} />
          </div>
          
          <div className="flex items-center">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full border ${
              currentStep === 'preferences' ? 'border-primary bg-primary text-white' : 
              currentStep === 'results' ? 'border-primary text-primary' : 'text-neutral-500'
            }`}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 16v-4" />
                <path d="M12 8h.01" />
              </svg>
            </div>
            <div className={`h-px w-6 ${
              currentStep === 'results' ? 'bg-primary' : 'bg-neutral-200'
            }`} />
          </div>
          
          <div className="flex items-center">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full border ${
              currentStep === 'results' ? 'border-primary bg-primary text-white' : 'text-neutral-500'
            }`}>
              <Sparkles className="h-5 w-5" />
            </div>
          </div>
        </div>
      </div>
      
      <Card>
        <CardContent className="p-6">
          {renderStepContent()}
          {renderNavigation()}
        </CardContent>
      </Card>
    </div>
  );
};

export default WorkflowWizard;