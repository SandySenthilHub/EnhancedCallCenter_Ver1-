import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { 
  Table, TableBody, TableCell, TableHead, 
  TableHeader, TableRow 
} from '@/components/ui/table';
import { 
  Dialog, DialogContent, DialogDescription, 
  DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog';
import { 
  AlertDialog, AlertDialogAction, AlertDialogCancel, 
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter, 
  AlertDialogHeader, AlertDialogTitle 
} from '@/components/ui/alert-dialog';
import { 
  Plus, Edit, Trash2, Save, Search, 
  SortAsc, SortDesc, X, Building, Check, Filter 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface BusinessCase {
  id: number;
  name: string;
  description: string;
  industry?: string;
  usage?: number;
}

const INDUSTRY_OPTIONS = [
  'All Industries',
  'Healthcare',
  'Finance',
  'Retail',
  'Manufacturing',
  'Technology',
  'Education',
  'Government',
  'Energy',
  'Transportation',
  'Insurance',
  'Telecommunications',
  'Real Estate'
];

const BusinessCaseSettings: React.FC = () => {
  // State management
  const [businessCases, setBusinessCases] = useState<BusinessCase[]>([
    { id: 1, name: 'Anomaly Detection', description: 'Identifying unusual patterns that do not conform to expected behavior', industry: 'All Industries', usage: 8 },
    { id: 2, name: 'Customer Churn', description: 'Predicting which customers are likely to cancel a subscription or service', industry: 'Telecommunications', usage: 12 },
    { id: 3, name: 'Fraud Detection', description: 'Identifying fraudulent transactions or activities', industry: 'Finance', usage: 15 },
    { id: 4, name: 'Price Optimization', description: 'Determining optimal pricing for products or services', industry: 'Retail', usage: 7 },
    { id: 5, name: 'Customer Segmentation', description: 'Dividing customers into groups based on similar characteristics', industry: 'All Industries', usage: 14 },
    { id: 6, name: 'Credit Scoring', description: 'Assessing creditworthiness of individuals or businesses', industry: 'Finance', usage: 11 },
    { id: 7, name: 'Demand Prediction', description: 'Forecasting future demand for products or services', industry: 'Manufacturing', usage: 9 },
    { id: 8, name: 'Medical Diagnosis', description: 'Assisting in diagnosis of medical conditions', industry: 'Healthcare', usage: 6 },
    { id: 9, name: 'Image Recognition', description: 'Identifying objects, people, or actions in images', industry: 'Technology', usage: 5 },
    { id: 10, name: 'Text Classification', description: 'Categorizing text documents', industry: 'All Industries', usage: 10 },
  ]);
  
  const [showAddDialog, setShowAddDialog] = useState<boolean>(false);
  const [showEditDialog, setShowEditDialog] = useState<boolean>(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState<boolean>(false);
  const [newBusinessCase, setNewBusinessCase] = useState<Omit<BusinessCase, 'id'>>({
    name: '',
    description: '',
    industry: 'All Industries',
    usage: 0
  });
  const [editingBusinessCase, setEditingBusinessCase] = useState<BusinessCase | null>(null);
  const [deletingBusinessCase, setDeletingBusinessCase] = useState<BusinessCase | null>(null);
  
  // Search and filter
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [industryFilter, setIndustryFilter] = useState<string>('All');
  const [sortField, setSortField] = useState<keyof BusinessCase>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  
  const { toast } = useToast();
  
  // Filter and sort business cases
  const filteredBusinessCases = businessCases
    .filter(bc => 
      bc.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      bc.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter(bc => industryFilter === 'All' || bc.industry === industryFilter)
    .sort((a, b) => {
      // Handle each field type specifically
      if (sortField === 'name' || sortField === 'description' || sortField === 'industry') {
        const aValue = a[sortField] || '';
        const bValue = b[sortField] || '';
        
        if (sortDirection === 'asc') {
          return aValue > bValue ? 1 : -1;
        } else {
          return aValue < bValue ? 1 : -1;
        }
      } else if (sortField === 'usage') {
        const aValue = a.usage || 0;
        const bValue = b.usage || 0;
        
        if (sortDirection === 'asc') {
          return aValue > bValue ? 1 : -1;
        } else {
          return aValue < bValue ? 1 : -1;
        }
      } else {
        // Default case, for id or other fields
        return sortDirection === 'asc' 
          ? a.id - b.id
          : b.id - a.id;
      }
    });
  
  // Handle sorting
  const handleSort = (field: keyof BusinessCase) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  // CRUD operations
  const handleAddBusinessCase = () => {
    if (!newBusinessCase.name.trim()) {
      toast({
        title: "Error",
        description: "Business case name is required",
        variant: "destructive"
      });
      return;
    }
    
    const newId = Math.max(0, ...businessCases.map(bc => bc.id)) + 1;
    
    setBusinessCases([
      ...businessCases,
      {
        id: newId,
        ...newBusinessCase
      }
    ]);
    
    setNewBusinessCase({
      name: '',
      description: '',
      industry: 'All Industries',
      usage: 0
    });
    
    setShowAddDialog(false);
    
    toast({
      title: "Success",
      description: "Business case added successfully",
    });
  };
  
  const handleEditBusinessCase = () => {
    if (!editingBusinessCase || !editingBusinessCase.name.trim()) {
      toast({
        title: "Error",
        description: "Business case name is required",
        variant: "destructive"
      });
      return;
    }
    
    setBusinessCases(
      businessCases.map(bc => 
        bc.id === editingBusinessCase.id ? editingBusinessCase : bc
      )
    );
    
    setShowEditDialog(false);
    setEditingBusinessCase(null);
    
    toast({
      title: "Success",
      description: "Business case updated successfully",
    });
  };
  
  const handleDeleteBusinessCase = () => {
    if (!deletingBusinessCase) return;
    
    setBusinessCases(
      businessCases.filter(bc => bc.id !== deletingBusinessCase.id)
    );
    
    setShowDeleteDialog(false);
    setDeletingBusinessCase(null);
    
    toast({
      title: "Success",
      description: "Business case deleted successfully",
    });
  };
  
  // Reset dialogs when closed
  useEffect(() => {
    if (!showAddDialog) {
      setNewBusinessCase({
        name: '',
        description: '',
        industry: 'All Industries',
        usage: 0
      });
    }
    
    if (!showEditDialog) {
      setEditingBusinessCase(null);
    }
    
    if (!showDeleteDialog) {
      setDeletingBusinessCase(null);
    }
  }, [showAddDialog, showEditDialog, showDeleteDialog]);
  
  return (
    <>
      <Helmet>
        <title>Business Case Settings | AI/ML Playbook</title>
        <meta 
          name="description" 
          content="Manage business use case categories for your machine learning algorithms"
        />
      </Helmet>
      
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Business Case Settings</h1>
            <p className="text-muted-foreground mt-2">
              Manage business use case categories for algorithms
            </p>
          </div>
          
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Business Case
          </Button>
        </div>
        
        <Separator className="my-6" />
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Business Cases</CardTitle>
            <CardDescription>
              These business cases will be available for selection when creating or editing algorithms
            </CardDescription>
            
            <div className="flex flex-col md:flex-row gap-4 mt-4">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or description..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="w-full md:w-1/4">
                <select
                  className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-2 text-sm"
                  value={industryFilter}
                  onChange={(e) => setIndustryFilter(e.target.value)}
                >
                  <option value="All">All Industries</option>
                  {INDUSTRY_OPTIONS.map(industry => (
                    <option key={industry} value={industry}>{industry}</option>
                  ))}
                </select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead 
                      className="w-[200px] cursor-pointer"
                      onClick={() => handleSort('name')}
                    >
                      <div className="flex items-center">
                        Name
                        {sortField === 'name' && (
                          sortDirection === 'asc' 
                            ? <SortAsc className="ml-2 h-4 w-4" /> 
                            : <SortDesc className="ml-2 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="min-w-[300px]">Description</TableHead>
                    <TableHead 
                      className="cursor-pointer"
                      onClick={() => handleSort('industry')}
                    >
                      <div className="flex items-center">
                        Industry
                        {sortField === 'industry' && (
                          sortDirection === 'asc' 
                            ? <SortAsc className="ml-2 h-4 w-4" /> 
                            : <SortDesc className="ml-2 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead 
                      className="cursor-pointer text-right"
                      onClick={() => handleSort('usage')}
                    >
                      <div className="flex items-center justify-end">
                        Usage
                        {sortField === 'usage' && (
                          sortDirection === 'asc' 
                            ? <SortAsc className="ml-2 h-4 w-4" /> 
                            : <SortDesc className="ml-2 h-4 w-4" />
                        )}
                      </div>
                    </TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBusinessCases.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="h-24 text-center">
                        No business cases found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredBusinessCases.map(businessCase => (
                      <TableRow key={businessCase.id}>
                        <TableCell className="font-medium">{businessCase.name}</TableCell>
                        <TableCell>{businessCase.description}</TableCell>
                        <TableCell>
                          {businessCase.industry && (
                            <div className="flex items-center">
                              <Building className="mr-2 h-4 w-4 text-muted-foreground" />
                              {businessCase.industry}
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {businessCase.usage !== undefined ? businessCase.usage : 0} algorithms
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => {
                                setEditingBusinessCase(businessCase);
                                setShowEditDialog(true);
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setDeletingBusinessCase(businessCase);
                                setShowDeleteDialog(true);
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
            
            <div className="text-xs text-muted-foreground mt-4">
              Showing {filteredBusinessCases.length} of {businessCases.length} business cases
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Add Business Case Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Business Case</DialogTitle>
            <DialogDescription>
              Create a new business case for algorithm categorization
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="name">Name</Label>
              <Input 
                id="name" 
                placeholder="Enter business case name"
                value={newBusinessCase.name}
                onChange={(e) => setNewBusinessCase({...newBusinessCase, name: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea 
                id="description" 
                placeholder="Enter business case description"
                rows={3}
                value={newBusinessCase.description}
                onChange={(e) => setNewBusinessCase({...newBusinessCase, description: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="industry">Industry</Label>
              <select
                id="industry"
                className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-2 text-sm"
                value={newBusinessCase.industry}
                onChange={(e) => setNewBusinessCase({...newBusinessCase, industry: e.target.value})}
              >
                {INDUSTRY_OPTIONS.map(industry => (
                  <option key={industry} value={industry}>{industry}</option>
                ))}
              </select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
            <Button onClick={handleAddBusinessCase}>Add Business Case</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Business Case Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Business Case</DialogTitle>
            <DialogDescription>
              Update business case details
            </DialogDescription>
          </DialogHeader>
          
          {editingBusinessCase && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="edit-name">Name</Label>
                <Input 
                  id="edit-name" 
                  value={editingBusinessCase.name}
                  onChange={(e) => setEditingBusinessCase({...editingBusinessCase, name: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="edit-description">Description</Label>
                <Textarea 
                  id="edit-description" 
                  rows={3}
                  value={editingBusinessCase.description}
                  onChange={(e) => setEditingBusinessCase({...editingBusinessCase, description: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="edit-industry">Industry</Label>
                <select
                  id="edit-industry"
                  className="w-full h-10 rounded-md border border-input bg-transparent px-3 py-2 text-sm"
                  value={editingBusinessCase.industry}
                  onChange={(e) => setEditingBusinessCase({...editingBusinessCase, industry: e.target.value})}
                >
                  {INDUSTRY_OPTIONS.map(industry => (
                    <option key={industry} value={industry}>{industry}</option>
                  ))}
                </select>
              </div>
              
              <div className="grid grid-cols-1 gap-2">
                <Label htmlFor="edit-usage">Usage Count (Read-only)</Label>
                <Input 
                  id="edit-usage" 
                  value={editingBusinessCase.usage}
                  disabled
                />
                <p className="text-xs text-muted-foreground">
                  This represents the number of algorithms using this business case
                </p>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancel</Button>
            <Button onClick={handleEditBusinessCase}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              {deletingBusinessCase && (
                <>
                  You are about to delete the business case <strong>{deletingBusinessCase.name}</strong>.
                  {deletingBusinessCase.usage && deletingBusinessCase.usage > 0 ? (
                    <p className="mt-2 text-red-500">
                      Warning: This business case is currently used by {deletingBusinessCase.usage} algorithms. 
                      Deleting it will remove this categorization from these algorithms.
                    </p>
                  ) : (
                    <p className="mt-2">
                      This business case is not currently used by any algorithms.
                    </p>
                  )}
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteBusinessCase}
              className="bg-red-500 hover:bg-red-600"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default BusinessCaseSettings;