import React from 'react';
import { useMutation } from '@tanstack/react-query';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  ArrowLeft, 
  Plus,
  X
} from 'lucide-react';
import { Link, useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Badge } from '@/components/ui/badge';

// Types
type ModelType = 'Native' | 'Azure' | 'AWS' | 'MLflow';

// Form validation schema
const formSchema = z.object({
  name: z.string().min(1, "Model name is required"),
  description: z.string().min(1, "Description is required"),
  type: z.enum(['Native', 'Azure', 'AWS', 'MLflow'] as const),
  team_id: z.number().nullable().optional(),
  tags: z.array(z.string()).optional(),
});

// Form type derived from schema
type FormValues = z.infer<typeof formSchema>;

const CreateModel: React.FC = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [tagInput, setTagInput] = React.useState('');

  // Setup form with Zod validation
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      description: '',
      type: 'Native',
      team_id: null,
      tags: [],
    },
  });

  // Handle tag input
  const addTag = () => {
    if (!tagInput) return;
    
    const currentTags = form.getValues('tags') || [];
    if (!currentTags.includes(tagInput)) {
      form.setValue('tags', [...currentTags, tagInput]);
    }
    setTagInput('');
  };

  const removeTag = (tagToRemove: string) => {
    const currentTags = form.getValues('tags') || [];
    form.setValue('tags', currentTags.filter(tag => tag !== tagToRemove));
  };

  // Handle keydown in tag input
  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addTag();
    }
  };

  // Create model mutation
  const createModelMutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const response = await apiRequest('POST', '/api/model-registry/models', values);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create model');
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate models cache
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/models'] });
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/dashboard'] });
      
      toast({
        title: "Success",
        description: "Model created successfully",
      });
      
      // Redirect to models list
      setLocation('/model-registry');
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (values: FormValues) => {
    createModelMutation.mutate(values);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex flex-col space-y-8 max-w-2xl mx-auto">
        <div className="flex items-center">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setLocation('/model-registry')}
            className="mr-4"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
          <h1 className="text-2xl font-bold">Register New Model</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Model Information</CardTitle>
            <CardDescription>
              Enter basic information about the model or external service to register
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Model Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter model name" {...field} />
                      </FormControl>
                      <FormDescription>
                        A unique name to identify this model
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Enter a detailed description" 
                          rows={4}
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        Describe the purpose, functionality, and key features of this model
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Model Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select model type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Native">Native</SelectItem>
                          <SelectItem value="Azure">Azure Cognitive Services</SelectItem>
                          <SelectItem value="AWS">AWS AI Services</SelectItem>
                          <SelectItem value="MLflow">MLflow Model</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        {field.value === 'Native' && "Models trained and stored within the AI/ML Playbook"}
                        {field.value === 'Azure' && "Models and services from Azure Cognitive Services"}
                        {field.value === 'AWS' && "Models and services from AWS AI/ML services"}
                        {field.value === 'MLflow' && "Models tracked and registered with MLflow"}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>Tags</FormLabel>
                  <div className="flex mt-1.5 mb-2">
                    <Input
                      placeholder="Add tags (comma or enter to add)"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyDown={handleTagKeyDown}
                      className="mr-2"
                    />
                    <Button 
                      type="button" 
                      onClick={addTag}
                      variant="outline"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {form.watch('tags')?.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-sm flex items-center gap-1">
                        {tag}
                        <button 
                          type="button" 
                          onClick={() => removeTag(tag)}
                          className="text-gray-500 hover:text-gray-700"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                    {!form.watch('tags')?.length && (
                      <div className="text-sm text-gray-500">No tags added</div>
                    )}
                  </div>
                  <FormDescription>
                    Add tags to help categorize and search for this model
                  </FormDescription>
                </div>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => setLocation('/model-registry')}
            >
              Cancel
            </Button>
            <Button 
              onClick={form.handleSubmit(onSubmit)}
              disabled={createModelMutation.isPending}
            >
              {createModelMutation.isPending ? "Creating..." : "Register Model"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default CreateModel;