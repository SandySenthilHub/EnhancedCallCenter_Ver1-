import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  LineChart, Line, AreaChart, Area, BarChart, Bar, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { Progress } from '@/components/ui/progress';
import { Plus, RefreshCw, ZapIcon, TrendingUp, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

const Experiments: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('active');
  
  // Fetch experiments (placeholder query)
  const { data: experiments = [], isLoading: isLoadingExperiments } = useQuery<any[]>({
    queryKey: ['/api/experiments'],
    enabled: true,
  });
  
  // Demo data for charts
  const experimentPerformanceData = [
    { name: 'Day 1', control: 0.24, variant: 0.21 },
    { name: 'Day 2', control: 0.23, variant: 0.22 },
    { name: 'Day 3', control: 0.25, variant: 0.24 },
    { name: 'Day 4', control: 0.22, variant: 0.26 },
    { name: 'Day 5', control: 0.23, variant: 0.28 },
    { name: 'Day 6', control: 0.24, variant: 0.29 },
    { name: 'Day 7', control: 0.25, variant: 0.31 },
    { name: 'Day 8', control: 0.26, variant: 0.33 },
    { name: 'Day 9', control: 0.25, variant: 0.34 },
    { name: 'Day 10', control: 0.24, variant: 0.36 },
  ];
  
  const experimentTrafficData = [
    { name: 'Day 1', control: 520, variant: 480 },
    { name: 'Day 2', control: 510, variant: 490 },
    { name: 'Day 3', control: 515, variant: 485 },
    { name: 'Day 4', control: 505, variant: 495 },
    { name: 'Day 5', control: 500, variant: 500 },
    { name: 'Day 6', control: 520, variant: 480 },
    { name: 'Day 7', control: 510, variant: 490 },
    { name: 'Day 8', control: 505, variant: 495 },
    { name: 'Day 9', control: 500, variant: 500 },
    { name: 'Day 10', control: 510, variant: 490 },
  ];
  
  return (
    <>
      <Helmet>
        <title>Experiments | AI/ML Playbook</title>
        <meta 
          name="description" 
          content="Design and run A/B tests for models, algorithms, and feature sets to improve ML performance."
        />
      </Helmet>
      
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">ML Experiments</h1>
          <p className="text-muted-foreground mt-2">
            A/B testing for models, features, and algorithms
          </p>
        </div>
        
        <Tabs defaultValue="active" value={activeTab} onValueChange={setActiveTab}>
          <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4">
            <TabsList>
              <TabsTrigger value="active">Active Experiments</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
              <TabsTrigger value="create">Create Experiment</TabsTrigger>
            </TabsList>
            
            {activeTab !== 'create' && (
              <Button className="mt-4 sm:mt-0">
                <Plus className="mr-2 h-4 w-4" />
                New Experiment
              </Button>
            )}
          </div>
          
          <TabsContent value="active">
            {isLoadingExperiments ? (
              <div className="flex justify-center py-8">
                <RefreshCw className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : (
              <div className="space-y-6">
                <ExperimentCard 
                  title="Feature Importance Optimization"
                  description="Testing improved feature selection algorithm against baseline for customer churn prediction"
                  status="running"
                  progress={65}
                  metrics={{
                    controlAccuracy: 0.76,
                    variantAccuracy: 0.79,
                    improvement: 3.9,
                    confidence: 91
                  }}
                  daysRunning={10}
                  daysRemaining={5}
                  id="exp-001"
                />
                
                <ExperimentCard 
                  title="Ensemble Method Comparison"
                  description="Comparing gradient boosting vs random forest for fraud detection"
                  status="running"
                  progress={42}
                  metrics={{
                    controlAccuracy: 0.88,
                    variantAccuracy: 0.86,
                    improvement: -2.3,
                    confidence: 78
                  }}
                  daysRunning={6}
                  daysRemaining={8}
                  id="exp-002"
                />
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="completed">
            <div className="space-y-6">
              <ExperimentCard 
                title="Neural Network Architecture Test"
                description="Testing LSTM vs Transformer architecture for time series forecasting"
                status="completed"
                progress={100}
                metrics={{
                  controlAccuracy: 0.72,
                  variantAccuracy: 0.81,
                  improvement: 12.5,
                  confidence: 99
                }}
                daysRunning={14}
                daysRemaining={0}
                id="exp-003"
                result="variant_won"
              />
              
              <ExperimentCard 
                title="Hyperparameter Tuning Comparison"
                description="Bayesian vs Grid Search for hyperparameter optimization"
                status="completed"
                progress={100}
                metrics={{
                  controlAccuracy: 0.82,
                  variantAccuracy: 0.84,
                  improvement: 2.4,
                  confidence: 86
                }}
                daysRunning={10}
                daysRemaining={0}
                id="exp-004"
                result="inconclusive"
              />
            </div>
          </TabsContent>
          
          <TabsContent value="create">
            <Card>
              <CardHeader>
                <CardTitle>Create New Experiment</CardTitle>
                <CardDescription>
                  Design an A/B test to compare models, features, or algorithms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-center text-muted-foreground py-6">
                  Experiment creation form would be implemented here
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <Card>
          <CardHeader>
            <CardTitle>How ML Experiments Work</CardTitle>
            <CardDescription>Guidelines for running effective A/B tests for machine learning</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="prose max-w-none">
              <section className="mb-6">
                <h3 className="text-lg font-medium">What is ML Experimentation?</h3>
                <p>
                  ML experimentation is a systematic approach to comparing different models, features, 
                  or algorithms to determine which performs better for a specific task. The platform 
                  supports:
                </p>
                <ul className="list-disc pl-6 mt-2">
                  <li>Model vs. model comparisons (e.g., random forest vs. gradient boosting)</li>
                  <li>Feature set comparisons (e.g., testing new engineered features)</li>
                  <li>Algorithm parameter variations (e.g., different hyperparameter settings)</li>
                  <li>Training methodology comparisons (e.g., different optimization algorithms)</li>
                </ul>
              </section>

              <section className="mb-6">
                <h3 className="text-lg font-medium">Best Practices</h3>
                <p>
                  For meaningful experiment results:
                </p>
                <ul className="list-disc pl-6 mt-2">
                  <li>Clearly define a single hypothesis for each experiment</li>
                  <li>Ensure both control and variant receive similar input data distributions</li>
                  <li>Run experiments long enough to reach statistical significance</li>
                  <li>Monitor for unexpected side effects or drift during the experiment</li>
                  <li>Document findings and learnings, regardless of outcome</li>
                </ul>
              </section>

              <section>
                <h3 className="text-lg font-medium">Interpreting Results</h3>
                <p>
                  When evaluating experiment outcomes:
                </p>
                <ul className="list-disc pl-6 mt-2">
                  <li>Consider statistical significance (confidence score)</li>
                  <li>Look beyond primary metrics to secondary effects</li>
                  <li>Evaluate computational efficiency alongside accuracy improvements</li>
                  <li>Consider the operational complexity of implementing the winning variant</li>
                </ul>
              </section>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

interface ExperimentCardProps {
  title: string;
  description: string;
  status: 'running' | 'completed' | 'paused';
  progress: number;
  metrics: {
    controlAccuracy: number;
    variantAccuracy: number;
    improvement: number;
    confidence: number;
  };
  daysRunning: number;
  daysRemaining: number;
  id: string;
  result?: 'control_won' | 'variant_won' | 'inconclusive';
}

function ExperimentCard({
  title,
  description,
  status,
  progress,
  metrics,
  daysRunning,
  daysRemaining,
  id,
  result
}: ExperimentCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  
  // Demo data for charts - in a real app, this would come from the API
  const experimentPerformanceData = [
    { name: 'Day 1', control: 0.24, variant: 0.21 },
    { name: 'Day 2', control: 0.23, variant: 0.22 },
    { name: 'Day 3', control: 0.25, variant: 0.24 },
    { name: 'Day 4', control: 0.22, variant: 0.26 },
    { name: 'Day 5', control: 0.23, variant: 0.28 },
    { name: 'Day 6', control: 0.24, variant: 0.29 },
    { name: 'Day 7', control: 0.25, variant: 0.31 },
    { name: 'Day 8', control: 0.26, variant: 0.33 },
    { name: 'Day 9', control: 0.25, variant: 0.34 },
    { name: 'Day 10', control: 0.24, variant: 0.36 },
  ];
  
  const experimentTrafficData = [
    { name: 'Day 1', control: 520, variant: 480 },
    { name: 'Day 2', control: 510, variant: 490 },
    { name: 'Day 3', control: 515, variant: 485 },
    { name: 'Day 4', control: 505, variant: 495 },
    { name: 'Day 5', control: 500, variant: 500 },
    { name: 'Day 6', control: 520, variant: 480 },
    { name: 'Day 7', control: 510, variant: 490 },
    { name: 'Day 8', control: 505, variant: 495 },
    { name: 'Day 9', control: 500, variant: 500 },
    { name: 'Day 10', control: 510, variant: 490 },
  ];
  const getStatusBadge = () => {
    switch (status) {
      case 'running':
        return <Badge className="bg-blue-500">Running</Badge>;
      case 'completed':
        return <Badge className="bg-green-500">Completed</Badge>;
      case 'paused':
        return <Badge variant="outline">Paused</Badge>;
      default:
        return null;
    }
  };
  
  const getResultBadge = () => {
    if (!result || status !== 'completed') return null;
    
    switch (result) {
      case 'control_won':
        return (
          <Badge variant="outline" className="ml-2 text-blue-500 border-blue-500">
            <CheckCircle className="h-3 w-3 mr-1" />
            Control Won
          </Badge>
        );
      case 'variant_won':
        return (
          <Badge variant="outline" className="ml-2 text-green-500 border-green-500">
            <CheckCircle className="h-3 w-3 mr-1" />
            Variant Won
          </Badge>
        );
      case 'inconclusive':
        return (
          <Badge variant="outline" className="ml-2 text-amber-500 border-amber-500">
            <AlertCircle className="h-3 w-3 mr-1" />
            Inconclusive
          </Badge>
        );
      default:
        return null;
    }
  };
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          <div className="flex items-center">
            {getStatusBadge()}
            {getResultBadge()}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-0">
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-1 text-sm">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} />
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="border rounded-md p-3">
              <div className="text-sm text-muted-foreground">Control</div>
              <div className="text-xl font-bold">{(metrics.controlAccuracy * 100).toFixed(1)}%</div>
            </div>
            <div className="border rounded-md p-3">
              <div className="text-sm text-muted-foreground">Variant</div>
              <div className="text-xl font-bold">{(metrics.variantAccuracy * 100).toFixed(1)}%</div>
            </div>
            <div className="border rounded-md p-3">
              <div className="text-sm text-muted-foreground">Improvement</div>
              <div className={`text-xl font-bold ${metrics.improvement > 0 ? 'text-green-500' : metrics.improvement < 0 ? 'text-red-500' : ''}`}>
                {metrics.improvement > 0 ? '+' : ''}{metrics.improvement.toFixed(1)}%
              </div>
            </div>
            <div className="border rounded-md p-3">
              <div className="text-sm text-muted-foreground">Confidence</div>
              <div className="text-xl font-bold">{metrics.confidence}%</div>
            </div>
          </div>
          
          {showDetails && (
            <div className="pt-4">
              <h4 className="text-sm font-medium mb-3">Performance Over Time</h4>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={experimentPerformanceData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="control" stroke="#8884d8" name="Control" />
                  <Line type="monotone" dataKey="variant" stroke="#82ca9d" name="Variant" />
                </LineChart>
              </ResponsiveContainer>
              
              <h4 className="text-sm font-medium mb-3 mt-6">Traffic Distribution</h4>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={experimentTrafficData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="control" fill="#8884d8" name="Control" />
                  <Bar dataKey="variant" fill="#82ca9d" name="Variant" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between pt-4">
        <div className="text-sm text-muted-foreground">
          {status === 'completed' 
            ? `Ran for ${daysRunning} days` 
            : `Running for ${daysRunning} days, ${daysRemaining} days remaining`
          }
        </div>
        <Button variant="outline" size="sm" onClick={() => setShowDetails(!showDetails)}>
          {showDetails ? 'Hide Details' : 'Show Details'}
        </Button>
      </CardFooter>
    </Card>
  );
}

export default Experiments;