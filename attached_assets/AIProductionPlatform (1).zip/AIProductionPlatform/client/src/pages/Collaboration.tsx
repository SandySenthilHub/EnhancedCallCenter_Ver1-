import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { 
  AlertCircle, 
  Check, 
  ChevronRight, 
  Edit,
  Loader2, 
  Plus, 
  Search,
  Trash2,
  User,
  Users,
  X,
  MessageSquare,
  Archive
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/hooks/use-auth';

// Type definitions
type Team = {
  id: number;
  name: string;
  description: string;
  createdAt: string;
};

type TeamMember = {
  id: number;
  teamId: number;
  userId: number;
  role: string;
  joinedAt: string;
  user?: User;
};

type User = {
  id: number;
  username: string;
  email: string;
  role: string;
};

type Comment = {
  id: number;
  content: string;
  entityType: string;
  entityId: number;
  userId: number;
  createdAt: string;
  updatedAt: string;
  user?: User;
};

type Model = {
  id: number;
  name: string;
  type: string;
  algorithm: string;
  status: string;
};

type Feature = {
  id: number;
  name: string;
  description: string;
  dataType: string;
};

type CommentEntity = {
  id: number;
  name: string;
  type: string;
};

// Helper components
const UserAvatar = ({ user, size = "md" }: { user: User, size?: "sm" | "md" | "lg" }) => {
  const sizeClass = 
    size === "sm" ? "h-6 w-6 text-xs" : 
    size === "lg" ? "h-12 w-12 text-lg" : 
    "h-9 w-9 text-base";
  
  // Generate initials from username
  const initials = user.username
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
  
  return (
    <Avatar className={sizeClass}>
      <AvatarImage src={`https://avatar.vercel.sh/${user.username}?size=128`} alt={user.username} />
      <AvatarFallback>{initials}</AvatarFallback>
    </Avatar>
  );
};

// Main Component
const Collaboration: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('teams');
  
  const [isCreateTeamDialogOpen, setIsCreateTeamDialogOpen] = useState(false);
  const [isAddTeamMemberDialogOpen, setIsAddTeamMemberDialogOpen] = useState(false);
  const [isAddCommentDialogOpen, setIsAddCommentDialogOpen] = useState(false);
  const [selectedTeamId, setSelectedTeamId] = useState<number | null>(null);
  const [selectedEntityForComment, setSelectedEntityForComment] = useState<CommentEntity | null>(null);
  
  // Queries
  const {
    data: teams = [],
    isLoading: isTeamsLoading,
    error: teamsError
  } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
    queryFn: () => apiRequest('GET', '/api/teams').then(res => res.json()),
  });

  const {
    data: teamMembers = [],
    isLoading: isTeamMembersLoading,
  } = useQuery<TeamMember[]>({
    queryKey: ['/api/team-members', selectedTeamId],
    queryFn: () => selectedTeamId ? 
      apiRequest('GET', `/api/team-members?teamId=${selectedTeamId}`).then(res => res.json()) : 
      Promise.resolve([]),
    enabled: !!selectedTeamId,
  });

  const {
    data: users = [],
    isLoading: isUsersLoading,
  } = useQuery<User[]>({
    queryKey: ['/api/users'],
    queryFn: () => apiRequest('GET', '/api/users').then(res => res.json()),
  });

  const {
    data: models = [],
    isLoading: isModelsLoading,
  } = useQuery<Model[]>({
    queryKey: ['/api/models'],
    queryFn: () => apiRequest('GET', '/api/models').then(res => res.json()),
  });

  const {
    data: features = [],
    isLoading: isFeaturesLoading,
  } = useQuery<Feature[]>({
    queryKey: ['/api/features'],
    queryFn: () => apiRequest('GET', '/api/features').then(res => res.json()),
  });

  const {
    data: comments = [],
    isLoading: isCommentsLoading,
    error: commentsError
  } = useQuery<Comment[]>({
    queryKey: ['/api/comments', selectedEntityForComment?.type, selectedEntityForComment?.id],
    queryFn: () => selectedEntityForComment ? 
      apiRequest('GET', `/api/comments?entityType=${selectedEntityForComment.type}&entityId=${selectedEntityForComment.id}`).then(res => res.json()) : 
      Promise.resolve([]),
    enabled: !!selectedEntityForComment,
  });

  // Create Team mutation
  const createTeamMutation = useMutation({
    mutationFn: async (team: Partial<Team>) => {
      const res = await apiRequest('POST', '/api/teams', team);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/teams'] });
      setIsCreateTeamDialogOpen(false);
      toast({
        title: "Team created",
        description: "Team was created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create team",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Add Team Member mutation
  const addTeamMemberMutation = useMutation({
    mutationFn: async (member: { teamId: number, userId: number, role: string }) => {
      const res = await apiRequest('POST', '/api/team-members', member);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/team-members', selectedTeamId] });
      setIsAddTeamMemberDialogOpen(false);
      toast({
        title: "Member added",
        description: "Team member was added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add member",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Add Comment mutation
  const addCommentMutation = useMutation({
    mutationFn: async (comment: Partial<Comment>) => {
      const res = await apiRequest('POST', '/api/comments', comment);
      return res.json();
    },
    onSuccess: () => {
      if (selectedEntityForComment) {
        queryClient.invalidateQueries({ 
          queryKey: ['/api/comments', selectedEntityForComment.type, selectedEntityForComment.id] 
        });
      }
      setIsAddCommentDialogOpen(false);
      toast({
        title: "Comment added",
        description: "Your comment was added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add comment",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Create Team form
  const TeamForm = () => {
    const [formData, setFormData] = useState({
      name: '',
      description: '',
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.name) {
        toast({
          title: "Missing fields",
          description: "Please provide a team name",
          variant: "destructive",
        });
        return;
      }

      createTeamMutation.mutate(formData);
    };

    return (
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 py-2 pb-4">
          <div className="space-y-2">
            <Label htmlFor="name">Team Name</Label>
            <Input 
              id="name" 
              placeholder="Enter team name"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea 
              id="description" 
              placeholder="Enter team description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={createTeamMutation.isPending}>
            {createTeamMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Team
          </Button>
        </DialogFooter>
      </form>
    );
  };

  // Add Team Member form
  const AddTeamMemberForm = () => {
    const [formData, setFormData] = useState({
      userId: '',
      role: 'member',
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.userId || !selectedTeamId) {
        toast({
          title: "Missing fields",
          description: "Please select a user to add to the team",
          variant: "destructive",
        });
        return;
      }

      addTeamMemberMutation.mutate({
        teamId: selectedTeamId,
        userId: parseInt(formData.userId),
        role: formData.role
      });
    };

    const nonTeamMembers = users.filter(u => 
      !teamMembers.some(tm => tm.userId === u.id)
    );

    return (
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 py-2 pb-4">
          <div className="space-y-2">
            <Label htmlFor="userId">Select User</Label>
            <Select 
              value={formData.userId}
              onValueChange={(value) => setFormData({...formData, userId: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a user" />
              </SelectTrigger>
              <SelectContent>
                {nonTeamMembers.map(user => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.username} ({user.email})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="role">Role</Label>
            <Select 
              value={formData.role}
              onValueChange={(value) => setFormData({...formData, role: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="owner">Owner</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="member">Member</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={addTeamMemberMutation.isPending}>
            {addTeamMemberMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Add Member
          </Button>
        </DialogFooter>
      </form>
    );
  };

  // Add Comment form
  const AddCommentForm = () => {
    const [formData, setFormData] = useState({
      content: '',
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.content || !selectedEntityForComment) {
        toast({
          title: "Missing content",
          description: "Please enter a comment",
          variant: "destructive",
        });
        return;
      }

      addCommentMutation.mutate({
        content: formData.content,
        entityType: selectedEntityForComment.type,
        entityId: selectedEntityForComment.id,
        userId: user?.id
      });
    };

    return (
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 py-2 pb-4">
          <div className="space-y-2">
            <Label htmlFor="content">Comment</Label>
            <Textarea 
              id="content" 
              placeholder="Enter your comment"
              value={formData.content}
              onChange={(e) => setFormData({...formData, content: e.target.value})}
              className="min-h-[100px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={addCommentMutation.isPending}>
            {addCommentMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Add Comment
          </Button>
        </DialogFooter>
      </form>
    );
  };

  // Render functions
  const renderTeamMembers = () => {
    if (!selectedTeamId) {
      return (
        <div className="text-center py-12 text-muted-foreground">
          Select a team to view members
        </div>
      );
    }

    if (isTeamMembersLoading) {
      return (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (teamMembers.length === 0) {
      return (
        <div className="text-center py-12 border rounded-md border-dashed">
          <User className="h-12 w-12 mx-auto text-muted-foreground" />
          <h3 className="mt-4 text-lg font-semibold">No Team Members</h3>
          <p className="text-muted-foreground mt-2">Add members to this team to enable collaboration.</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => setIsAddTeamMemberDialogOpen(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Member
          </Button>
        </div>
      );
    }

    const getSelectedTeam = () => teams.find(t => t.id === selectedTeamId);

    return (
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">
            {getSelectedTeam()?.name} - Members
          </h3>
          <Button size="sm" onClick={() => setIsAddTeamMemberDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Member
          </Button>
        </div>
        <Card>
          <CardContent className="p-0">
            <div className="divide-y">
              {teamMembers.map(member => (
                <div key={member.id} className="flex items-center justify-between p-4">
                  <div className="flex items-center">
                    <UserAvatar user={member.user || { id: member.userId, username: 'User', email: '', role: '' }} />
                    <div className="ml-3">
                      <p className="font-medium">{member.user?.username || `User ${member.userId}`}</p>
                      <p className="text-xs text-muted-foreground">{member.user?.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <Badge variant={member.role === 'owner' ? 'default' : 'outline'} className="mr-2">
                      {member.role}
                    </Badge>
                    <Button variant="ghost" size="icon">
                      <Trash2 className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderComments = () => {
    const renderCommentableEntities = () => {
      if (isModelsLoading || isFeaturesLoading) {
        return (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        );
      }

      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Models</CardTitle>
              <CardDescription>Comment on models and algorithms</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-64">
                <div className="divide-y">
                  {models.map(model => (
                    <button
                      key={model.id}
                      className={`w-full flex items-center justify-between p-4 text-left hover:bg-muted ${
                        selectedEntityForComment?.id === model.id && selectedEntityForComment?.type === 'model' 
                          ? 'bg-primary/10' 
                          : ''
                      }`}
                      onClick={() => setSelectedEntityForComment({ id: model.id, name: model.name, type: 'model' })}
                    >
                      <div>
                        <p className="font-medium">{model.name}</p>
                        <p className="text-xs text-muted-foreground">{model.type} - {model.algorithm}</p>
                      </div>
                      <Badge variant="outline" className="ml-2">
                        {model.status}
                      </Badge>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Features</CardTitle>
              <CardDescription>Comment on features and transformations</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-64">
                <div className="divide-y">
                  {features.map(feature => (
                    <button
                      key={feature.id}
                      className={`w-full flex items-center justify-between p-4 text-left hover:bg-muted ${
                        selectedEntityForComment?.id === feature.id && selectedEntityForComment?.type === 'feature' 
                          ? 'bg-primary/10' 
                          : ''
                      }`}
                      onClick={() => setSelectedEntityForComment({ id: feature.id, name: feature.name, type: 'feature' })}
                    >
                      <div>
                        <p className="font-medium">{feature.name}</p>
                        <p className="text-xs text-muted-foreground">{feature.dataType}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      );
    };

    const renderSelectedEntityComments = () => {
      if (!selectedEntityForComment) {
        return (
          <div className="text-center py-12 border rounded-md border-dashed mt-6">
            <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground" />
            <h3 className="mt-4 text-lg font-semibold">No Item Selected</h3>
            <p className="text-muted-foreground mt-2">Select a model or feature to view and add comments.</p>
          </div>
        );
      }

      if (isCommentsLoading) {
        return (
          <div className="flex justify-center items-center py-12 mt-6">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        );
      }

      return (
        <div className="mt-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold">
              Comments for {selectedEntityForComment.name} ({selectedEntityForComment.type})
            </h3>
            <Button onClick={() => setIsAddCommentDialogOpen(true)}>
              <MessageSquare className="h-4 w-4 mr-2" />
              Add Comment
            </Button>
          </div>

          {comments.length === 0 ? (
            <div className="text-center py-8 border rounded-md border-dashed">
              <p className="text-muted-foreground">No comments yet. Be the first to add one!</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setIsAddCommentDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Comment
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {comments.map(comment => (
                <Card key={comment.id}>
                  <CardContent className="pt-6">
                    <div className="flex">
                      <UserAvatar 
                        user={comment.user || { id: comment.userId, username: `User ${comment.userId}`, email: '', role: '' }}
                        size="sm"
                      />
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between">
                          <p className="text-sm font-medium">
                            {comment.user?.username || `User ${comment.userId}`}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(comment.createdAt).toLocaleString()}
                          </p>
                        </div>
                        <p className="mt-2">{comment.content}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      );
    };

    return (
      <div>
        <p className="text-muted-foreground mb-4">
          Select a model or feature to view and add comments.
        </p>
        {renderCommentableEntities()}
        {renderSelectedEntityComments()}
      </div>
    );
  };

  return (
    <div className="container mx-auto py-6">
      <Helmet>
        <title>Collaboration - AI/ML Playbook</title>
        <meta name="description" content="Collaborate with your team on ML models, features, and experiments." />
      </Helmet>
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Collaboration</h1>
          <p className="text-muted-foreground">Collaborate with your team on ML models, features, and experiments.</p>
        </div>
        <div className="flex space-x-2">
          {activeTab === 'teams' && (
            <Dialog open={isCreateTeamDialogOpen} onOpenChange={setIsCreateTeamDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Team
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Team</DialogTitle>
                  <DialogDescription>
                    Create a new team to collaborate on ML projects.
                  </DialogDescription>
                </DialogHeader>
                <TeamForm />
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <Dialog open={isAddTeamMemberDialogOpen} onOpenChange={setIsAddTeamMemberDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Team Member</DialogTitle>
            <DialogDescription>
              Add a new member to this team.
            </DialogDescription>
          </DialogHeader>
          <AddTeamMemberForm />
        </DialogContent>
      </Dialog>

      <Dialog open={isAddCommentDialogOpen} onOpenChange={setIsAddCommentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Comment</DialogTitle>
            <DialogDescription>
              {selectedEntityForComment && (
                `Add a comment to ${selectedEntityForComment.name} (${selectedEntityForComment.type})`
              )}
            </DialogDescription>
          </DialogHeader>
          <AddCommentForm />
        </DialogContent>
      </Dialog>

      <Tabs defaultValue="teams" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="teams">Teams & Members</TabsTrigger>
          <TabsTrigger value="comments">Comments & Discussions</TabsTrigger>
        </TabsList>
        
        <TabsContent value="teams">
          {isTeamsLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : teamsError ? (
            <div className="flex justify-center items-center py-12 text-destructive">
              <AlertCircle className="h-6 w-6 mr-2" />
              <p>Failed to load teams</p>
            </div>
          ) : teams.length === 0 ? (
            <div className="text-center py-12 border rounded-md border-dashed">
              <Users className="h-12 w-12 mx-auto text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">No Teams</h3>
              <p className="text-muted-foreground mt-2">Get started by creating your first team.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setIsCreateTeamDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Team
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
              <div className="col-span-1">
                <h3 className="text-lg font-semibold mb-4">Teams</h3>
                <Card>
                  <CardContent className="p-0">
                    <div className="divide-y">
                      {teams.map(team => (
                        <button
                          key={team.id}
                          className={`w-full flex items-center justify-between p-4 text-left hover:bg-muted ${
                            selectedTeamId === team.id ? 'bg-primary/10' : ''
                          }`}
                          onClick={() => setSelectedTeamId(team.id)}
                        >
                          <div>
                            <p className="font-medium">{team.name}</p>
                            <p className="text-xs text-muted-foreground">{team.description}</p>
                          </div>
                          <ChevronRight className={`h-4 w-4 ${selectedTeamId === team.id ? 'text-primary' : 'text-muted-foreground'}`} />
                        </button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="col-span-1 md:col-span-2">
                {renderTeamMembers()}
              </div>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="comments">
          {renderComments()}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Collaboration;