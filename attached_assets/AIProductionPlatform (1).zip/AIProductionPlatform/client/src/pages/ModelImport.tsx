import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft } from 'lucide-react';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Define the form schema for Azure models
const azureModelSchema = z.object({
  name: z.string().min(1, "Model name is required"),
  description: z.string().min(1, "Description is required"),
  service_type: z.string().min(1, "Service type is required"),
  endpoint: z.string().min(1, "Endpoint is required"),
  credential_reference: z.string().optional(),
  region: z.string().optional(),
});

type AzureModelFormValues = z.infer<typeof azureModelSchema>;

// Define the form schema for AWS models
const awsModelSchema = z.object({
  name: z.string().min(1, "Model name is required"),
  description: z.string().min(1, "Description is required"),
  service_type: z.string().min(1, "Service type is required"),
  region: z.string().min(1, "Region is required"),
  credential_reference: z.string().optional(),
});

type AwsModelFormValues = z.infer<typeof awsModelSchema>;

// Define the form schema for MLflow models
const mlflowModelSchema = z.object({
  name: z.string().min(1, "Model name is required"),
  description: z.string().min(1, "Description is required"),
  tracking_uri: z.string().min(1, "MLflow tracking URI is required"),
});

type MlflowModelFormValues = z.infer<typeof mlflowModelSchema>;

// Main ModelImport component
const ModelImport: React.FC = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Form initialization for Azure
  const azureForm = useForm<AzureModelFormValues>({
    resolver: zodResolver(azureModelSchema),
    defaultValues: {
      name: '',
      description: '',
      service_type: '',
      endpoint: '',
      credential_reference: '',
      region: '',
    },
  });

  // Form initialization for AWS
  const awsForm = useForm<AwsModelFormValues>({
    resolver: zodResolver(awsModelSchema),
    defaultValues: {
      name: '',
      description: '',
      service_type: '',
      region: '',
      credential_reference: '',
    },
  });

  // Form initialization for MLflow
  const mlflowForm = useForm<MlflowModelFormValues>({
    resolver: zodResolver(mlflowModelSchema),
    defaultValues: {
      name: '',
      description: '',
      tracking_uri: '',
    },
  });

  // Mutation for importing Azure model
  const importAzureModelMutation = useMutation({
    mutationFn: async (data: AzureModelFormValues) => {
      const response = await apiRequest('POST', '/api/model-registry/import/azure', {
        ...data,
        type: 'Azure', // Set the model type
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to import Azure model');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Azure model imported successfully",
      });
      
      // Invalidate queries to refresh the model list
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/models'] });
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/dashboard'] });
      
      // Redirect to model registry
      setLocation('/model-registry');
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation for importing AWS model
  const importAwsModelMutation = useMutation({
    mutationFn: async (data: AwsModelFormValues) => {
      const response = await apiRequest('POST', '/api/model-registry/import/aws', {
        ...data,
        type: 'AWS', // Set the model type
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to import AWS model');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "AWS model imported successfully",
      });
      
      // Invalidate queries to refresh the model list
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/models'] });
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/dashboard'] });
      
      // Redirect to model registry
      setLocation('/model-registry');
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation for importing MLflow model
  const importMlflowModelMutation = useMutation({
    mutationFn: async (data: MlflowModelFormValues) => {
      const response = await apiRequest('POST', '/api/model-registry/import/mlflow', {
        ...data,
        type: 'MLflow', // Set the model type
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to import MLflow model');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "MLflow model imported successfully",
      });
      
      // Invalidate queries to refresh the model list
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/models'] });
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/dashboard'] });
      
      // Redirect to model registry
      setLocation('/model-registry');
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handlers
  const onSubmitAzure = (data: AzureModelFormValues) => {
    importAzureModelMutation.mutate(data);
  };

  const onSubmitAws = (data: AwsModelFormValues) => {
    importAwsModelMutation.mutate(data);
  };

  const onSubmitMlflow = (data: MlflowModelFormValues) => {
    importMlflowModelMutation.mutate(data);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Import External Service</h1>
          <p className="text-gray-500 mt-1">
            Import models from external ML services like Azure ML, AWS SageMaker, or MLflow
          </p>
        </div>
        <Button 
          variant="outline"
          onClick={() => setLocation('/model-registry')}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Model Registry
        </Button>
      </div>

      <Tabs defaultValue="azure" className="w-full">
        <TabsList className="grid w-[450px] grid-cols-3">
          <TabsTrigger value="azure">Azure ML</TabsTrigger>
          <TabsTrigger value="aws">AWS SageMaker</TabsTrigger>
          <TabsTrigger value="mlflow">MLflow</TabsTrigger>
        </TabsList>
        
        {/* Azure ML Tab */}
        <TabsContent value="azure">
          <Card>
            <CardHeader>
              <CardTitle>Import Azure ML Service</CardTitle>
              <CardDescription>
                Import models from Azure Machine Learning services, Cognitive Services, or OpenAI
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...azureForm}>
                <form onSubmit={azureForm.handleSubmit(onSubmitAzure)} className="space-y-6">
                  <FormField
                    control={azureForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Enter a name for this model" />
                        </FormControl>
                        <FormDescription>
                          A unique name to identify this model in the registry
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={azureForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea {...field} placeholder="Describe the model and its purpose" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={azureForm.control}
                    name="service_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Service Type</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select service type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="azure-ml">Azure ML</SelectItem>
                              <SelectItem value="cognitive-services">Cognitive Services</SelectItem>
                              <SelectItem value="azure-openai">Azure OpenAI</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={azureForm.control}
                    name="endpoint"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Endpoint URL</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="https://example.azureml.net/service" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={azureForm.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Region</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., eastus" />
                        </FormControl>
                        <FormDescription>
                          The Azure region where the service is deployed
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={azureForm.control}
                    name="credential_reference"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Credential Reference</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Reference to stored credentials" />
                        </FormControl>
                        <FormDescription>
                          Reference to access keys or connection strings stored in a secure location
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={importAzureModelMutation.isPending}
                  >
                    {importAzureModelMutation.isPending ? "Importing..." : "Import Azure Service"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* AWS SageMaker Tab */}
        <TabsContent value="aws">
          <Card>
            <CardHeader>
              <CardTitle>Import AWS SageMaker Model</CardTitle>
              <CardDescription>
                Import models from AWS SageMaker, Bedrock, or other AWS ML services
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...awsForm}>
                <form onSubmit={awsForm.handleSubmit(onSubmitAws)} className="space-y-6">
                  <FormField
                    control={awsForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Enter a name for this model" />
                        </FormControl>
                        <FormDescription>
                          A unique name to identify this model in the registry
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={awsForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea {...field} placeholder="Describe the model and its purpose" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={awsForm.control}
                    name="service_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Service Type</FormLabel>
                        <FormControl>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select service type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="sagemaker-endpoint">SageMaker Endpoint</SelectItem>
                              <SelectItem value="bedrock">Bedrock</SelectItem>
                              <SelectItem value="comprehend">Comprehend</SelectItem>
                              <SelectItem value="rekognition">Rekognition</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={awsForm.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Region</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., us-west-2" />
                        </FormControl>
                        <FormDescription>
                          The AWS region where the service is deployed
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={awsForm.control}
                    name="credential_reference"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Credential Reference</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Reference to stored credentials" />
                        </FormControl>
                        <FormDescription>
                          Reference to AWS IAM credentials stored in a secure location
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={importAwsModelMutation.isPending}
                  >
                    {importAwsModelMutation.isPending ? "Importing..." : "Import AWS Service"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* MLflow Tab */}
        <TabsContent value="mlflow">
          <Card>
            <CardHeader>
              <CardTitle>Import MLflow Model</CardTitle>
              <CardDescription>
                Import models from MLflow tracking servers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...mlflowForm}>
                <form onSubmit={mlflowForm.handleSubmit(onSubmitMlflow)} className="space-y-6">
                  <FormField
                    control={mlflowForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Enter a name for this model" />
                        </FormControl>
                        <FormDescription>
                          A unique name to identify this model in the registry
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={mlflowForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea {...field} placeholder="Describe the model and its purpose" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={mlflowForm.control}
                    name="tracking_uri"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>MLflow Tracking URI</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="http://mlflow-server:5000" />
                        </FormControl>
                        <FormDescription>
                          The URI of the MLflow tracking server
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={importMlflowModelMutation.isPending}
                  >
                    {importMlflowModelMutation.isPending ? "Importing..." : "Import MLflow Model"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ModelImport;