import React, { useState, useMemo, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { 
  Package, 
  Plus, 
  Trash, 
  Edit, 
  Save, 
  Terminal, 
  Download, 
  RefreshCw, 
  Loader2, 
  CheckCircle2, 
  XCircle, 
  FileCode,
  Link,
  FileText,
  Code,
  Beaker,
  Shield,
  AlertTriangle,
  Search,
  Upload,
  Database
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from "@/components/ui/checkbox";

// Type definitions
interface AlgorithmDependency {
  id: number;
  name: string;
  version: string | null;
  packageManager: string;
  category: string | null;
  description: string | null;
  createdAt: string;
  updatedAt: string;
}

interface AlgorithmDependencyMapping {
  id: number;
  algorithmName: string;
  dependencyId: number;
  required: boolean;
  createdAt: string;
  updatedAt: string;
}

interface Algorithm {
  id: number;
  name: string;
  type: string;
  algorithm: string;
  version: string;
  dependenciesInstalled: boolean;
}

// Error boundary to catch and display errors gracefully
class ErrorBoundary extends React.Component<{children: React.ReactNode}, {hasError: boolean, error: Error | null}> {
  constructor(props: {children: React.ReactNode}) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-6 bg-red-50 border border-red-200 rounded-md">
          <h2 className="text-lg font-semibold text-red-700 mb-2">Something went wrong</h2>
          <details className="border p-2 rounded mb-4 bg-white">
            <summary className="cursor-pointer">Error Details</summary>
            <pre className="text-xs overflow-auto p-2 mt-2 bg-gray-100 rounded">
              {this.state.error?.toString()}
            </pre>
          </details>
          <p className="text-sm">
            Please try refreshing the page or contact support if the issue persists.
          </p>
        </div>
      );
    }

    return this.props.children;
  }
}

const AlgorithmDependencies: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('dependencies');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isMapDialogOpen, setIsMapDialogOpen] = useState(false);
  const [isInstallDialogOpen, setIsInstallDialogOpen] = useState(false);
  const [isLockDialogOpen, setIsLockDialogOpen] = useState(false);
  const [isAdvancedDialogOpen, setIsAdvancedDialogOpen] = useState(false);
  const [isDocumentationDialogOpen, setIsDocumentationDialogOpen] = useState(false);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<string>('');
  const [selectedDependencyIds, setSelectedDependencyIds] = useState<number[]>([]);
  const [dependencySearchQuery, setDependencySearchQuery] = useState('');
  const [installResults, setInstallResults] = useState<any[] | null>(null);
  const [lockResults, setLockResults] = useState<any | null>(null);
  const [documentationContent, setDocumentationContent] = useState<string>('');
  const [cicdSelection, setCicdSelection] = useState<string>('github');
  const [environmentSelection, setEnvironmentSelection] = useState<string>('development');
  const [isInstalling, setIsInstalling] = useState(false);
  const [isLocking, setIsLocking] = useState(false);
  const [isGeneratingDoc, setIsGeneratingDoc] = useState(false);

  // State for filtering dependencies by category
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [showCsvUploadDialog, setShowCsvUploadDialog] = useState(false);
  const [csvUploadFile, setCsvUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Package search and dropdown related states
  const [showPackageSearch, setShowPackageSearch] = useState(false);
  const [packageSearchQuery, setPackageSearchQuery] = useState('');
  const [availablePackages, setAvailablePackages] = useState<{name: string, version: string, category: string}[]>([]);
  
  // Extended form data
  const [formData, setFormData] = useState({
    name: '',
    version: '',
    versionConstraint: 'exact',
    packageManager: 'pip',
    category: '',
    description: ''
  });

  // Reset form data when dialog closes
  const resetFormData = () => {
    setFormData({
      name: '',
      version: '',
      versionConstraint: 'exact',
      packageManager: 'pip',
      category: '',
      description: ''
    });
  };

  // Fetch dependencies
  const {
    data: allDependencies = [],
    isLoading: isDependenciesLoading,
    error: dependenciesError
  } = useQuery<AlgorithmDependency[]>({
    queryKey: ['/api/algorithm-dependencies'],
    queryFn: () => apiRequest('GET', '/api/algorithm-dependencies').then(res => res.json()),
  });
  
  // Filter dependencies by category if a category filter is set
  const dependencies = useMemo(() => {
    if (!categoryFilter) return allDependencies;
    return allDependencies.filter(dep => dep.category === categoryFilter);
  }, [allDependencies, categoryFilter]);
  
  // Get unique categories for the filter dropdown
  const uniqueCategories = useMemo(() => {
    const categories = allDependencies
      .map(dep => dep.category)
      .filter((category): category is string => 
        category !== null && category !== undefined && category !== ''
      );
    return Array.from(new Set(categories)).sort();
  }, [allDependencies]);
  
  // Load library data when component mounts
  useEffect(() => {
    // Library data from the provided file
    const libraryData = `name,version,category
boto3,1.35.24,AWS SDK
numpy,2.1.1,Scientific Computing
pandas,2.2.3,Data Analysis
requests,2.32.3,HTTP Requests
tensorflow,2.17.0,Machine Learning
torch,2.4.1,Machine Learning
scikit-learn,1.5.2,Machine Learning
matplotlib,3.9.2,Data Visualization
seaborn,0.13.2,Data Visualization
flask,3.0.3,Web Framework
django,5.1.1,Web Framework
sqlalchemy,2.0.35,ORM
pytest,8.3.3,Testing
beautifulsoup4,4.12.3,Web Scraping
opencv-python,4.10.0,Computer Vision
pillow,10.4.0,Image Processing
scipy,1.14.1,Scientific Computing
jupyter,1.1.1,Interactive Computing
fastapi,0.115.0,Web Framework
httpx,0.27.2,HTTP Client`;
    
    // Process the CSV data and populate available packages
    const packages = processCsvData(libraryData);
    setAvailablePackages(packages);
    
    console.log("Loaded library packages:", packages);
  }, []);

  // Filter available packages based on search query
  // Group packages by category for better organization
  const packagesByCategory = useMemo(() => {
    const grouped = availablePackages.reduce((acc, pkg) => {
      const category = pkg.category || 'Uncategorized';
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(pkg);
      return acc;
    }, {} as Record<string, typeof availablePackages>);
    
    // Sort categories alphabetically
    return Object.keys(grouped)
      .sort()
      .reduce((acc, key) => {
        acc[key] = grouped[key];
        return acc;
      }, {} as Record<string, typeof availablePackages>);
  }, [availablePackages]);
  
  // Filter packages by search query across name and category
  const filteredPackages = useMemo(() => {
    // If no search query, return all packages
    if (!packageSearchQuery) return availablePackages;
    
    const query = packageSearchQuery.toLowerCase().trim();
    
    // Filter by name or category
    return availablePackages.filter(pkg => 
      pkg.name.toLowerCase().includes(query) || 
      (pkg.category && pkg.category.toLowerCase().includes(query))
    );
  }, [packageSearchQuery, availablePackages]);

  // Fetch models/algorithms
  const {
    data: algorithms = [],
    isLoading: isAlgorithmsLoading,
    error: algorithmsError
  } = useQuery<Algorithm[]>({
    queryKey: ['/api/models'],
    queryFn: () => apiRequest('GET', '/api/models')
      .then(res => res.json())
      .catch(error => {
        console.error("Error fetching algorithms:", error);
        // Return empty array as fallback to prevent crashes
        return [];
      }),
  });

  // Fetch mappings for selected algorithm
  const {
    data: mappings = [],
    isLoading: isMappingsLoading,
    error: mappingsError,
    refetch: refetchMappings
  } = useQuery<AlgorithmDependencyMapping[]>({
    queryKey: ['/api/algorithm-mappings', selectedAlgorithm],
    queryFn: () => {
      if (!selectedAlgorithm) return Promise.resolve([]);
      return apiRequest('GET', `/api/algorithm-mappings/${selectedAlgorithm}`).then(res => res.json());
    },
    enabled: !!selectedAlgorithm,
  });

  // Process the CSV data
  const processCsvData = (csvContent: string) => {
    try {
      // Simple CSV parsing
      const lines = csvContent.split("\n");
      const headers = lines[0].split(",").map(h => h.trim());
      
      // Extract packages
      const packages: {name: string, version: string, category: string, packageManager: string, description: string}[] = [];
      
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        const values = line.split(",").map(v => v.trim());
        
        // Basic validation
        if (values.length < 1) continue;
        
        const pkg = {
          name: values[0],
          version: values.length > 1 ? values[1] || '' : '',
          category: values.length > 2 ? values[2] || '' : '',
          packageManager: 'pip', // Default to pip
          description: `${values[0]} ${values.length > 2 && values[2] ? `- ${values[2]}` : ''} library`
        };
        
        packages.push(pkg);
      }
      
      console.log(`Processed ${packages.length} dependencies from CSV`);
      
      // Update the available packages for search
      setAvailablePackages(packages);
      
      return packages;
    } catch (error) {
      console.error("Error processing CSV:", error);
      toast({
        title: "CSV Processing Error",
        description: "Failed to parse the CSV file. Please check the format.",
        variant: "destructive"
      });
      return [];
    }
  };
  
  // CSV upload mutation
  const uploadCsvMutation = useMutation({
    mutationFn: async (csvContent: string) => {
      // Process the CSV data locally
      const packages = processCsvData(csvContent);
      
      if (packages.length === 0) {
        throw new Error("No valid packages found in the CSV file");
      }
      
      console.log(`Sending ${packages.length} dependencies for batch import`, packages);
      
      try {
        // Create bulk import API request
        const res = await apiRequest('POST', '/api/algorithm-dependencies/batch-import', { 
          dependencies: packages
        });
        
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.error || "Server error processing dependencies");
        }
        
        return await res.json();
      } catch (error) {
        console.error("Error during CSV upload:", error);
        throw error;
      }
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/algorithm-dependencies'] });
      setShowCsvUploadDialog(false);
      toast({
        title: "CSV Upload Complete",
        description: `Successfully imported ${data.count || 'multiple'} dependencies from CSV.`,
      });
    },
    onError: (error: any) => {
      console.error("CSV upload error details:", error);
      toast({
        title: "CSV Upload Failed",
        description: error.message || "Unknown error occurred during upload",
        variant: "destructive",
      });
    }
  });

  // Function to create a direct file input for CSV upload
  const createDirectFileUpload = () => {
    // Create a file input element
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.csv';
    fileInput.style.display = 'none';
    
    // Add event listener to handle file selection
    fileInput.addEventListener('change', async (event) => {
      // @ts-ignore
      const file = event.target?.files?.[0];
      if (!file) return;
      
      setIsLoading(true);
      console.log(`Selected file: ${file.name}`);
      
      try {
        // Create a FormData object to send the file
        const formData = new FormData();
        formData.append('csvFile', file);
        
        // Send the file directly to the server using fetch (not apiRequest)
        const response = await fetch('/api/algorithm-dependencies/upload-csv', {
          method: 'POST',
          body: formData,
          // Don't set Content-Type header - browser will set it with boundary for FormData
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(errorText || `Server error: ${response.status}`);
        }
        
        const result = await response.json();
        
        // Refresh the list
        queryClient.invalidateQueries({ queryKey: ['/api/algorithm-dependencies'] });
        
        // Show success message
        toast({
          title: "Import Successful",
          description: `Successfully imported ${result.count} dependencies.`,
        });
      } catch (error) {
        console.error("Import error:", error);
        toast({
          title: "Import Failed",
          description: error instanceof Error ? error.message : "Unknown error during import",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
      
      // Clean up
      document.body.removeChild(fileInput);
    });
    
    // Add to document and trigger click
    document.body.appendChild(fileInput);
    fileInput.click();
  };
  
  // Load sample libraries function - now triggers a file selection dialog
  const loadSampleLibraries = async () => {
    createDirectFileUpload();
  };

  // Create dependency mutation
  const createDependencyMutation = useMutation({
    mutationFn: async (dependency: Omit<AlgorithmDependency, 'id' | 'createdAt' | 'updatedAt'>) => {
      const res = await apiRequest('POST', '/api/algorithm-dependencies', dependency);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/algorithm-dependencies'] });
      setIsAddDialogOpen(false);
      resetFormData();
      toast({
        title: "Dependency added",
        description: "The dependency was added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add dependency",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Create mapping mutation
  const createMappingMutation = useMutation({
    mutationFn: async (mapping: Omit<AlgorithmDependencyMapping, 'id' | 'createdAt' | 'updatedAt'>) => {
      const res = await apiRequest('POST', '/api/algorithm-mappings', mapping);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/algorithm-mappings', selectedAlgorithm] });
      setIsMapDialogOpen(false);
      setSelectedDependencyIds([]);
      toast({
        title: "Mapping created",
        description: "The dependency was mapped to the algorithm successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create mapping",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Delete dependency mutation
  const deleteDependencyMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/algorithm-dependencies/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/algorithm-dependencies'] });
      toast({
        title: "Dependency deleted",
        description: "The dependency was deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete dependency",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Delete mapping mutation
  const deleteMappingMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/algorithm-mappings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/algorithm-mappings', selectedAlgorithm] });
      toast({
        title: "Mapping deleted",
        description: "The dependency mapping was removed successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete mapping",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Install dependencies mutation
  const installDependenciesMutation = useMutation({
    mutationFn: async ({ algorithmName, modelId }: { algorithmName: string, modelId?: number }) => {
      setIsInstalling(true);
      const res = await apiRequest('POST', `/api/algorithm-dependencies/install/${algorithmName}`, { modelId });
      setIsInstalling(false);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
      setInstallResults(data.details);
      toast({
        title: data.success ? "Dependencies installed" : "Installation issues",
        description: data.message,
        variant: data.success ? "default" : "destructive",
      });
    },
    onError: (error: Error) => {
      setIsInstalling(false);
      toast({
        title: "Failed to install dependencies",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Lock dependencies mutation
  const lockDependenciesMutation = useMutation({
    mutationFn: async ({ algorithmName, environment }: { algorithmName: string, environment: string }) => {
      setIsLocking(true);
      const res = await apiRequest('POST', `/api/algorithm-dependencies/lock/${algorithmName}`, { environment });
      setIsLocking(false);
      return res.json();
    },
    onSuccess: (data) => {
      setLockResults(data);
      
      if (!data.conflicts?.hasConflicts && !data.vulnerabilities?.hasVulnerabilities) {
        toast({
          title: "Dependencies Locked",
          description: "Dependency lock files created successfully",
        });
      } else {
        let description = "Lock files created with issues:";
        if (data.conflicts?.hasConflicts) description += " Dependency conflicts detected.";
        if (data.vulnerabilities?.hasVulnerabilities) description += " Security vulnerabilities found.";
        
        toast({
          title: "Dependencies Locked with Warnings",
          description,
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      setIsLocking(false);
      toast({
        title: "Failed to lock dependencies",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Fetch documentation mutation
  const fetchDocumentationMutation = useMutation({
    mutationFn: async (algorithmName: string) => {
      setIsGeneratingDoc(true);
      const res = await fetch(`/api/algorithm-dependencies/doc/${algorithmName}`, {
        method: 'GET',
        headers: { 'Accept': 'text/markdown' }
      });
      setIsGeneratingDoc(false);
      if (!res.ok) {
        throw new Error(`Failed to fetch documentation: ${res.statusText}`);
      }
      return res.text();
    },
    onSuccess: (data) => {
      setDocumentationContent(data);
    },
    onError: (error: Error) => {
      setIsGeneratingDoc(false);
      toast({
        title: "Failed to generate documentation",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Get algorithm by name
  const getAlgorithmByName = (name: string) => {
    return algorithms.find(alg => alg.algorithm === name);
  };

  // Get dependency by ID
  const getDependencyById = (id: number) => {
    return dependencies.find(dep => dep.id === id);
  };

  // Handle form submission
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createDependencyMutation.mutate(formData);
  };

  // Handle mapping form submission
  const handleMappingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAlgorithm || selectedDependencyIds.length === 0) {
      toast({
        title: "Missing fields",
        description: "Please select both an algorithm and at least one dependency.",
        variant: "destructive",
      });
      return;
    }

    // Create mappings for all selected dependencies
    const createPromises = selectedDependencyIds.map(dependencyId => 
      createMappingMutation.mutateAsync({
        algorithmName: selectedAlgorithm,
        dependencyId: dependencyId,
        required: true
      })
    );
    
    Promise.all(createPromises)
      .then(() => {
        toast({
          title: "Dependencies Mapped",
          description: `Successfully mapped ${selectedDependencyIds.length} dependencies to ${selectedAlgorithm}.`,
        });
        setIsMapDialogOpen(false);
        setSelectedDependencyIds([]);
      })
      .catch(error => {
        toast({
          title: "Mapping Failed",
          description: error.message || "Failed to map some dependencies.",
          variant: "destructive",
        });
      });
  };

  // Handle install dependencies
  const handleInstallDependencies = () => {
    if (!selectedAlgorithm) {
      toast({
        title: "No algorithm selected",
        description: "Please select an algorithm first.",
        variant: "destructive",
      });
      return;
    }

    const algorithm = getAlgorithmByName(selectedAlgorithm);
    
    installDependenciesMutation.mutate({
      algorithmName: selectedAlgorithm,
      modelId: algorithm?.id
    });
  };
  
  // Handle lock dependencies
  const handleLockDependencies = () => {
    if (!selectedAlgorithm) {
      toast({
        title: "No algorithm selected",
        description: "Please select an algorithm first.",
        variant: "destructive",
      });
      return;
    }
    
    lockDependenciesMutation.mutate({
      algorithmName: selectedAlgorithm,
      environment: environmentSelection
    });
  };
  
  // Handle generate documentation
  const handleGenerateDocumentation = () => {
    if (!selectedAlgorithm) {
      toast({
        title: "No algorithm selected",
        description: "Please select an algorithm first.",
        variant: "destructive",
      });
      return;
    }
    
    setIsDocumentationDialogOpen(true);
    setDocumentationContent('');
    setIsGeneratingDoc(true);
    
    fetchDocumentationMutation.mutate(selectedAlgorithm);
  };
  
  // Handle download CI/CD config
  const handleDownloadCiCdConfig = () => {
    if (!selectedAlgorithm) {
      toast({
        title: "No algorithm selected",
        description: "Please select an algorithm first.",
        variant: "destructive",
      });
      return;
    }
    
    // Use fetch instead of changing window.location to avoid full page navigation
    fetch(`/api/algorithm-dependencies/cicd/${selectedAlgorithm}/${cicdSelection}`)
      .then(res => {
        if (!res.ok) throw new Error(`Failed to generate config: ${res.statusText}`);
        return res.blob();
      })
      .then(blob => {
        // Create a blob URL and trigger download
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        
        // Determine filename based on CI/CD system
        const filename = cicdSelection === 'github' 
          ? 'github-workflow.yml' 
          : cicdSelection === 'gitlab' 
            ? '.gitlab-ci.yml' 
            : 'Jenkinsfile';
            
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        
        // Cleanup
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        toast({
          title: "Configuration Downloaded",
          description: `${cicdSelection} configuration file created successfully`,
        });
      })
      .catch(error => {
        toast({
          title: "Download Failed",
          description: error.message,
          variant: "destructive",
        });
      });
  };

  // Render the dependencies list
  const renderDependenciesList = () => {
    if (isDependenciesLoading) {
      return (
        <div className="flex justify-center my-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (dependenciesError) {
      return (
        <div className="text-center text-destructive my-8">
          <p>Error loading dependencies</p>
        </div>
      );
    }

    if (dependencies.length === 0) {
      return (
        <div className="text-center my-8 border border-dashed rounded-md p-12">
          <Package className="h-12 w-12 mx-auto text-muted-foreground" />
          <h3 className="mt-4 text-xl font-semibold">No dependencies added yet</h3>
          <p className="text-muted-foreground mt-2">
            Algorithm dependencies define the external libraries that need to be installed for specific algorithms.
          </p>
          <div className="flex gap-2 justify-center mt-4">
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Dependency
            </Button>
            <Button variant="secondary" onClick={loadSampleLibraries} disabled={isLoading}>
              <Database className="h-4 w-4 mr-2" />
              {isLoading ? "Loading..." : "Load Sample Libraries"}
            </Button>
          </div>
        </div>
      );
    }

    return (
      <div>
        {/* We're now using the dynamic file input creation approach */}
        
        <div className="flex justify-between mb-4">
          <h3 className="text-lg font-semibold">Algorithm Dependencies ({dependencies.length})</h3>
          <div className="flex gap-2">
            <Button 
              variant="secondary" 
              onClick={createDirectFileUpload}
              disabled={isLoading}
            >
              <Upload className="h-4 w-4 mr-2" />
              {isLoading ? "Loading..." : "Upload CSV File"}
            </Button>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Dependency
            </Button>
          </div>
        </div>
        
        {/* Category Filter */}
        <div className="flex items-center gap-2 mb-4">
          <Label htmlFor="categoryFilter" className="w-24">Filter by:</Label>
          <Select
            value={categoryFilter || "all_categories"}
            onValueChange={(value) => setCategoryFilter(value === "all_categories" ? null : value)}
          >
            <SelectTrigger id="categoryFilter" className="w-[200px]">
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all_categories">All categories</SelectItem>
              {uniqueCategories
                .filter(category => category && category.trim() !== '')
                .map((category) => (
                  <SelectItem key={category} value={category || `category_${Math.random()}`}>
                    {category}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
          
          {categoryFilter && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setCategoryFilter(null)} 
              className="h-8 px-2"
            >
              <XCircle className="h-4 w-4 mr-1" />
              Clear filter
            </Button>
          )}
          
          <div className="ml-auto text-sm text-muted-foreground">
            {dependencies.length} {dependencies.length === 1 ? 'dependency' : 'dependencies'} {categoryFilter ? `in ${categoryFilter}` : 'total'}
          </div>
        </div>
        
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Version</TableHead>
                <TableHead>Package Manager</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dependencies.map((dependency) => (
                <TableRow key={dependency.id}>
                  <TableCell className="font-medium">{dependency.name}</TableCell>
                  <TableCell>{dependency.version || 'Latest'}</TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {dependency.packageManager}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {dependency.category ? (
                      <Badge className="bg-primary/10 text-primary hover:bg-primary/20">
                        {dependency.category}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground text-sm">Uncategorized</span>
                    )}
                  </TableCell>
                  <TableCell className="max-w-md truncate">
                    {dependency.description || 'No description'}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button variant="outline" size="icon" onClick={() => {
                      /* Implement edit functionality */
                      toast({
                        title: "Edit not implemented",
                        description: "Editing dependencies is not implemented yet",
                      });
                    }}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="text-destructive hover:text-destructive"
                      onClick={() => {
                        if (window.confirm(`Are you sure you want to delete ${dependency.name}?`)) {
                          deleteDependencyMutation.mutate(dependency.id);
                        }
                      }}
                    >
                      <Trash className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    );
  };

  // Render algorithm mappings
  const renderAlgorithmMappings = () => {
    if (isAlgorithmsLoading) {
      return (
        <div className="flex justify-center my-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (algorithmsError) {
      return (
        <div className="text-center text-destructive my-8">
          <p>Error loading algorithms</p>
        </div>
      );
    }

    return (
      <div className="space-y-8">
        <div>
          <Label htmlFor="algorithm-select">Select Algorithm</Label>
          <Select
            value={selectedAlgorithm}
            onValueChange={setSelectedAlgorithm}
          >
            <SelectTrigger className="mt-2">
              <SelectValue placeholder="Select an algorithm" />
            </SelectTrigger>
            <SelectContent>
              {algorithms
                .filter(algorithm => algorithm.algorithm && algorithm.algorithm.trim() !== '')
                .map(algorithm => (
                  <SelectItem key={algorithm.id} value={algorithm.algorithm || `algorithm_${algorithm.id}`}>
                    {algorithm.name} ({algorithm.algorithm})
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>

        {selectedAlgorithm && (
          <div>
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-lg font-semibold">
                  {selectedAlgorithm} Dependencies
                </h3>
                <p className="text-sm text-muted-foreground">
                  {getAlgorithmByName(selectedAlgorithm)?.dependenciesInstalled ? (
                    <span className="text-green-600 flex items-center">
                      <CheckCircle2 className="h-4 w-4 mr-1" />
                      Dependencies installed
                    </span>
                  ) : (
                    <span className="text-amber-600 flex items-center">
                      <XCircle className="h-4 w-4 mr-1" />
                      Dependencies not installed
                    </span>
                  )}
                </p>
              </div>
              <div className="space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setIsMapDialogOpen(true)}
                  disabled={!selectedAlgorithm}
                >
                  <Link className="h-4 w-4 mr-2" />
                  Map Dependency
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    window.location.href = `/api/algorithm-dependencies/export/${selectedAlgorithm}`;
                  }}
                  disabled={!selectedAlgorithm || mappings.length === 0}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Export Requirements
                </Button>
                <div className="flex flex-wrap gap-2">
                  <Button 
                    onClick={() => {
                      setIsInstallDialogOpen(true);
                      setInstallResults(null);
                    }}
                    disabled={!selectedAlgorithm || mappings.length === 0}
                  >
                    <Terminal className="h-4 w-4 mr-2" />
                    Install Dependencies
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setIsLockDialogOpen(true);
                      setLockResults(null);
                    }}
                    disabled={!selectedAlgorithm || mappings.length === 0}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Lock Dependencies
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={handleGenerateDocumentation}
                    disabled={!selectedAlgorithm || mappings.length === 0}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Documentation
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={() => setIsAdvancedDialogOpen(true)}
                    disabled={!selectedAlgorithm || mappings.length === 0}
                  >
                    <Code className="h-4 w-4 mr-2" />
                    CI/CD Tools
                  </Button>
                </div>
              </div>
            </div>

            {isMappingsLoading ? (
              <div className="flex justify-center my-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : mappings.length === 0 ? (
              <div className="text-center my-8 border border-dashed rounded-md p-12">
                <Package className="h-12 w-12 mx-auto text-muted-foreground" />
                <h3 className="mt-4 text-xl font-semibold">No dependencies mapped</h3>
                <p className="text-muted-foreground mt-2">
                  This algorithm has no dependencies mapped to it yet.
                </p>
                <Button className="mt-4" onClick={() => setIsMapDialogOpen(true)}>
                  <Link className="h-4 w-4 mr-2" />
                  Map Dependency
                </Button>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Package Name</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Package Manager</TableHead>
                      <TableHead>Required</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mappings.map(mapping => {
                      const dependency = getDependencyById(mapping.dependencyId);
                      return (
                        <TableRow key={mapping.id}>
                          <TableCell className="font-medium">{dependency?.name || 'Unknown'}</TableCell>
                          <TableCell>{dependency?.version || 'Latest'}</TableCell>
                          <TableCell>
                            {dependency?.category ? (
                              <Badge variant="secondary">{dependency.category}</Badge>
                            ) : (
                              <span className="text-muted-foreground text-sm">Uncategorized</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {dependency?.packageManager || 'Unknown'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={mapping.required ? "default" : "secondary"}>
                              {mapping.required ? 'Required' : 'Optional'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="text-destructive hover:text-destructive"
                              onClick={() => {
                                if (window.confirm(`Are you sure you want to remove this dependency mapping?`)) {
                                  deleteMappingMutation.mutate(mapping.id);
                                }
                              }}
                            >
                              <Trash className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="p-6">
      <Helmet>
        <title>Algorithm Dependencies | AI/ML Playbook</title>
        <meta name="description" content="Manage algorithm dependencies for your machine learning models" />
      </Helmet>
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Algorithm Dependencies</h1>
          <p className="text-muted-foreground">
            Manage external libraries and packages required for machine learning algorithms
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={async () => {
              setIsLoading(true);
              try {
                // Create a file with all the CSV data
                const csvContent = `name,version,category
boto3,1.35.24,AWS SDK
numpy,2.1.1,Scientific Computing
pandas,2.2.3,Data Analysis
requests,2.32.3,HTTP Requests
tensorflow,2.17.0,Machine Learning
torch,2.4.1,Machine Learning
scikit-learn,1.5.2,Machine Learning
matplotlib,3.9.2,Data Visualization
seaborn,0.13.2,Data Visualization
flask,3.0.3,Web Framework
django,5.1.1,Web Framework
sqlalchemy,2.0.35,ORM
pytest,8.3.3,Testing
beautifulsoup4,4.12.3,Web Scraping
opencv-python,4.10.0,Computer Vision
pillow,10.4.0,Image Processing
scipy,1.14.1,Scientific Computing
jupyter,1.1.1,Interactive Computing
fastapi,0.115.0,Web Framework
httpx,0.27.2,HTTP Client
aiohttp,3.10.5,Asynchronous HTTP
asyncpg,0.29.0,Database
black,24.8.0,Code Formatting
celery,5.4.0,Task Queue
click,8.1.7,Command Line Interface
dask,2024.9.0,Parallel Computing
faker,28.4.1,Data Generation
gensim,4.3.3,Natural Language Processing
gradio,4.44.0,Web Interface
h5py,3.11.0,Data Storage
httplib2,0.22.0,HTTP Client
isort,5.13.2,Code Formatting
jinja2,3.1.4,Templating
keras,3.5.0,Machine Learning
langchain,0.3.1,Natural Language Processing
lxml,5.3.0,XML Processing
mypy,1.11.2,Static Typing
networkx,3.3,Graph Analysis
nltk,3.9.1,Natural Language Processing
numba,0.60.0,Performance Optimization
openpyxl,3.1.5,Excel Processing
orjson,3.10.7,JSON Processing
plotly,5.24.1,Data Visualization
psycopg2-binary,2.9.9,Database
pydantic,2.9.2,Data Validation
pyarrow,17.0.0,Data Processing
pycryptodome,3.20.0,Cryptography
pymongo,4.8.0,Database
pyodbc,5.1.0,Database
pytest-cov,5.0.0,Testing
python-dotenv,1.0.1,Environment Management
pytz,2024.2,Time Zone Handling
pywavelets,1.7.0,Signal Processing
redis,5.0.8,Database
regex,2024.9.11,Regular Expressions
s3fs,2024.9.0,File System
spacy,3.7.6,Natural Language Processing
statsmodels,0.14.2,Statistical Modeling
sympy,1.13.2,Symbolic Mathematics
tabulate,0.9.0,Data Formatting
uvicorn,0.30.6,Web Server
xgboost,2.1.1,Machine Learning
yfinance,0.2.44,Financial Data
alabaster,0.7.16,Documentation
anaconda-client,1.12.3,Package Management
argon2-cffi,23.1.0,Security
astropy,6.1.3,Astronomy
attrs,24.2.0,Utilities
backoff,2.2.1,Retry Logic
bleach,6.1.0,Text Sanitization
bokeh,3.6.0,Data Visualization
bottleneck,1.4.0,Performance Optimization
cachetools,5.5.0,Caching
cffi,1.17.1,Foreign Function Interface
charset-normalizer,3.3.2,Text Encoding
cloudpickle,3.0.0,Serialization
coverage,7.6.1,Testing
cryptography,43.0.1,Security
cycler,0.12.1,Data Visualization
cython,3.0.11,Performance Optimization
djangorestframework,3.15.2,Web Framework
docopt,0.6.2,Command Line Interface
et-xmlfile,1.1.0,Excel Processing
filelock,3.16.1,File Locking
fire,0.7.0,Command Line Interface
fsspec,2024.9.0,File System
future,1.0.0,Compatibility
gunicorn,23.0.0,Web Server
hypothesis,6.111.1,Testing
imageio,2.35.1,Image Processing
imbalanced-learn,0.12.3,Machine Learning
inflection,0.5.1,Text Processing
joblib,1.4.2,Parallel Computing
jsonschema,4.23.0,Data Validation
kiwisolver,1.4.7,Data Visualization
loguru,0.7.2,Logging
markdown,3.7,Text Formatting
markupsafe,2.1.5,Templating
more-itertools,10.5.0,Utilities
msgpack,1.0.8,Serialization
nest-asyncio,1.6.0,Asynchronous
oauthlib,3.2.2,Authentication
packaging,24.1,Packaging
paramiko,3.5.0,SSH
patsy,0.5.6,Statistical Modeling
pendulum,3.0.0,DateTime Handling
platformdirs,4.3.2,Platform Utilities
prometheus-client,0.20.0,Monitoring
py4j,0.10.9.7,Java Integration
pydot,3.0.1,Graph Visualization
pyparsing,3.1.4,Parsing
pysocks,1.7.1,Networking
python-dateutil,2.9.0,DateTime Handling
pyyaml,6.0.2,Configuration
retrying,1.3.4,Retry Logic
six,1.16.0,Compatibility
snowballstemmer,2.2.0,Text Processing
sortedcontainers,2.4.0,Data Structures
soupsieve,2.6,Web Scraping
termcolor,2.4.0,Text Formatting
textblob,0.18.0,Natural Language Processing
threadpoolctl,3.5.0,Parallel Computing
toml,0.10.2,Configuration
tornado,6.4.1,Web Framework
tqdm,4.66.5,Progress Bar
typing-extensions,4.12.2,Static Typing
urllib3,2.2.3,HTTP Client
virtualenv,20.26.3,Environment Management
websocket-client,1.8.0,WebSocket
werkzeug,3.0.4,Web Framework
wrapt,1.16.0,Utilities
zipp,3.20.2,Packaging`;

                // Create a File object from the text
                const file = new File([csvContent], 'library-names.csv', { type: 'text/csv' });
                
                // Create a FormData object
                const formData = new FormData();
                formData.append('csvFile', file);
                
                // Upload the file directly
                const response = await fetch('/api/algorithm-dependencies/upload-csv', {
                  method: 'POST',
                  body: formData
                });
                
                if (!response.ok) {
                  throw new Error('Failed to import library dependencies');
                }
                
                const result = await response.json();
                
                // Refresh the list
                queryClient.invalidateQueries({ queryKey: ['/api/algorithm-dependencies'] });
                
                // Show success message
                toast({
                  title: "Import Successful",
                  description: `Successfully imported ${result.count} dependencies.`,
                });
              } catch (error) {
                console.error("Error importing libraries:", error);
                toast({
                  title: "Import Failed",
                  description: error instanceof Error ? error.message : "Unknown error during import",
                  variant: "destructive"
                });
              } finally {
                setIsLoading(false);
              }
            }}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Importing...
              </>
            ) : (
              <>
                <Database className="h-4 w-4 mr-2" />
                Import All Libraries
              </>
            )}
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="dependencies" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="dependencies">Dependencies</TabsTrigger>
          <TabsTrigger value="algorithms">Algorithm Mappings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="dependencies" className="py-4">
          {renderDependenciesList()}
        </TabsContent>
        
        <TabsContent value="algorithms" className="py-4">
          {renderAlgorithmMappings()}
        </TabsContent>
      </Tabs>
      
      {/* Add Dependency Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={(isOpen) => {
        setIsAddDialogOpen(isOpen);
        if (!isOpen) resetFormData();
      }}>
        <DialogContent className="sm:max-w-[500px]">
          <form onSubmit={handleFormSubmit}>
            <DialogHeader>
              <DialogTitle>Add Dependency</DialogTitle>
              <DialogDescription>
                Add a new library or package dependency for ML algorithms
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Package Name</Label>
                <div className="relative">
                  <Input 
                    id="name" 
                    placeholder="Type to search for packages"
                    value={formData.name}
                    onChange={(e) => {
                      setFormData({ ...formData, name: e.target.value });
                      // Show dropdown when typing
                      if (e.target.value.length > 0) {
                        setShowPackageSearch(true);
                      }
                    }}
                    onFocus={() => setShowPackageSearch(true)}
                    required
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    className="absolute right-1 top-1 h-6 w-6 p-0"
                    onClick={() => setShowPackageSearch(!showPackageSearch)}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                  
                  {showPackageSearch && (
                    <div className="absolute z-10 mt-1 w-full rounded-md border bg-popover shadow-md">
                      <div className="max-h-80 overflow-auto p-2">
                        <Input
                          placeholder="Search packages by name or category..."
                          value={packageSearchQuery}
                          onChange={(e) => setPackageSearchQuery(e.target.value)}
                          className="mb-3"
                        />
                        
                        {/* If search is active, show flat filtered list */}
                        {packageSearchQuery ? (
                          <div className="space-y-1.5">
                            {filteredPackages.map((pkg, index) => (
                              <div
                                key={`search-${index}`}
                                className="flex items-center justify-between rounded-md px-3 py-2 hover:bg-muted cursor-pointer transition-colors"
                                onClick={() => {
                                  setFormData({ ...formData, name: pkg.name, category: pkg.category || formData.category, version: pkg.version || '' });
                                  setShowPackageSearch(false);
                                  setPackageSearchQuery('');
                                }}
                              >
                                <div className="font-medium">{pkg.name}</div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-muted-foreground">{pkg.version}</span>
                                  {pkg.category && (
                                    <Badge variant="outline" className="bg-secondary">{pkg.category}</Badge>
                                  )}
                                </div>
                              </div>
                            ))}
                            {filteredPackages.length === 0 && (
                              <div className="text-center py-3 text-sm text-muted-foreground">
                                No packages found. You can add a new one.
                              </div>
                            )}
                          </div>
                        ) : (
                          /* If no search, show organized by category */
                          <div className="space-y-3">
                            {Object.entries(packagesByCategory).map(([category, pkgs]) => (
                              <div key={`cat-${category}`} className="mb-2">
                                <h3 className="text-sm font-semibold mb-1.5 text-muted-foreground border-b pb-1">{category}</h3>
                                <div className="space-y-1">
                                  {pkgs.map((pkg, idx) => (
                                    <div 
                                      key={`cat-pkg-${category}-${idx}`}
                                      className="flex items-center justify-between rounded-md px-2 py-1.5 hover:bg-muted cursor-pointer transition-colors"
                                      onClick={() => {
                                        setFormData({ ...formData, name: pkg.name, category: pkg.category || formData.category, version: pkg.version || '' });
                                        setShowPackageSearch(false);
                                        setPackageSearchQuery('');
                                      }}
                                    >
                                      <div className="font-medium">{pkg.name}</div>
                                      <span className="text-xs text-muted-foreground">{pkg.version}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="versionNumber">Version Number</Label>
                  <Input 
                    id="versionNumber" 
                    placeholder="e.g., 1.0.2"
                    value={formData.version}
                    onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="versionConstraint">Version Constraint</Label>
                  <Select
                    value={formData.versionConstraint || "exact"}
                    onValueChange={(value) => setFormData({ ...formData, versionConstraint: value })}
                  >
                    <SelectTrigger id="versionConstraint">
                      <SelectValue placeholder="Select constraint" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="exact">Exact (=)</SelectItem>
                      <SelectItem value="compatible">Compatible (^)</SelectItem>
                      <SelectItem value="atleast">At least {'(>=)'}</SelectItem>
                      <SelectItem value="latest">Latest</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="packageManager">Package Manager</Label>
                <Select 
                  value={formData.packageManager}
                  onValueChange={(value) => setFormData({ ...formData, packageManager: value })}
                >
                  <SelectTrigger id="packageManager">
                    <SelectValue placeholder="Select package manager" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pip">pip (Python)</SelectItem>
                    <SelectItem value="conda">conda (Python)</SelectItem>
                    <SelectItem value="npm">npm (JavaScript)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="category">Category (optional)</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                    <SelectItem value="Data Analysis">Data Analysis</SelectItem>
                    <SelectItem value="Data Visualization">Data Visualization</SelectItem>
                    <SelectItem value="NLP">Natural Language Processing</SelectItem>
                    <SelectItem value="Computer Vision">Computer Vision</SelectItem>
                    <SelectItem value="Deep Learning">Deep Learning</SelectItem>
                    <SelectItem value="Statistics">Statistics</SelectItem>
                    <SelectItem value="Utilities">Utilities</SelectItem>
                    <SelectItem value="Web Framework">Web Framework</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Textarea 
                  id="description" 
                  placeholder="Briefly describe what this package is used for"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={createDependencyMutation.isPending}>
                {createDependencyMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Dependency
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Map Dependency to Algorithm Dialog */}
      <Dialog open={isMapDialogOpen} onOpenChange={(isOpen) => {
        setIsMapDialogOpen(isOpen);
        if (!isOpen) setSelectedDependencyIds([]);
      }}>
        <DialogContent className="sm:max-w-[500px]">
          <form onSubmit={handleMappingSubmit}>
            <DialogHeader>
              <DialogTitle>Map Dependency to Algorithm</DialogTitle>
              <DialogDescription>
                Connect a dependency to the selected algorithm
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="algorithm">Algorithm</Label>
                <Input 
                  id="algorithm" 
                  value={selectedAlgorithm}
                  disabled
                  className="bg-muted"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dependency-search">Select Dependencies</Label>
                <div className="rounded-md border border-input">
                  <div className="flex items-center px-3 py-2 bg-muted rounded-t-md border-b">
                    <Search className="h-4 w-4 mr-2 text-muted-foreground" />
                    <input
                      id="dependency-search"
                      placeholder="Search dependencies..."
                      className="flex-1 bg-transparent border-0 focus:ring-0 focus:outline-none text-sm"
                      value={dependencySearchQuery}
                      onChange={(e) => setDependencySearchQuery(e.target.value)}
                    />
                    {dependencySearchQuery && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0"
                        onClick={() => setDependencySearchQuery('')}
                      >
                        <XCircle className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="max-h-[200px] overflow-y-auto p-1">
                    {dependencies
                      .filter(dep => 
                        !dependencySearchQuery || 
                        dep.name.toLowerCase().includes(dependencySearchQuery.toLowerCase()) ||
                        (dep.category && dep.category.toLowerCase().includes(dependencySearchQuery.toLowerCase()))
                      )
                      .map(dependency => (
                        <div 
                          key={dependency.id} 
                          className={`flex items-center justify-between px-3 py-2 rounded-md cursor-pointer hover:bg-muted ${
                            selectedDependencyIds.includes(dependency.id) ? 'bg-primary/10' : ''
                          }`}
                          onClick={() => {
                            setSelectedDependencyIds(prev => 
                              prev.includes(dependency.id)
                                ? prev.filter(id => id !== dependency.id)
                                : [...prev, dependency.id]
                            )
                          }}
                        >
                          <div className="flex items-center">
                            <Checkbox
                              checked={selectedDependencyIds.includes(dependency.id)}
                              className="mr-2"
                              onCheckedChange={() => {
                                setSelectedDependencyIds(prev => 
                                  prev.includes(dependency.id)
                                    ? prev.filter(id => id !== dependency.id)
                                    : [...prev, dependency.id]
                                )
                              }}
                            />
                            <div>
                              <span className="font-medium">{dependency.name}</span>
                              {dependency.version && <span className="text-sm text-muted-foreground ml-1">({dependency.version})</span>}
                            </div>
                          </div>
                          {dependency.category && (
                            <Badge variant="outline">{dependency.category}</Badge>
                          )}
                        </div>
                      ))
                    }
                    
                    {dependencies.filter(dep => 
                      !dependencySearchQuery || 
                      dep.name.toLowerCase().includes(dependencySearchQuery.toLowerCase()) ||
                      (dep.category && dep.category.toLowerCase().includes(dependencySearchQuery.toLowerCase()))
                    ).length === 0 && (
                      <div className="px-3 py-4 text-center text-sm text-muted-foreground">
                        No dependencies found
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-sm pt-1">
                  <span className="text-muted-foreground">
                    {selectedDependencyIds.length} selected
                  </span>
                  
                  {selectedDependencyIds.length > 0 && (
                    <Button 
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-7"
                      onClick={() => setSelectedDependencyIds([])}
                    >
                      Clear selection
                    </Button>
                  )}
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsMapDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createMappingMutation.isPending || selectedDependencyIds.length === 0}
              >
                {createMappingMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Link className="h-4 w-4 mr-2" />
                    Map {selectedDependencyIds.length > 0 ? selectedDependencyIds.length : ''} Dependencies
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
      
      {/* Install Dependencies Dialog */}
      <Dialog open={isInstallDialogOpen} onOpenChange={setIsInstallDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Install Dependencies</DialogTitle>
            <DialogDescription>
              Install required dependencies for {selectedAlgorithm}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <FileCode className="h-5 w-5 mr-2 text-primary" />
                    <span className="font-medium">{selectedAlgorithm}</span>
                  </div>
                  <Badge variant={getAlgorithmByName(selectedAlgorithm)?.dependenciesInstalled ? "default" : "outline"}>
                    {getAlgorithmByName(selectedAlgorithm)?.dependenciesInstalled ? "Installed" : "Not Installed"}
                  </Badge>
                </div>
                <Separator className="my-3" />
                <div className="text-sm">
                  <p><strong>Dependencies:</strong></p>
                  <ul className="list-disc list-inside mt-1">
                    {mappings.map(mapping => {
                      const dependency = getDependencyById(mapping.dependencyId);
                      return (
                        <li key={mapping.id}>
                          {dependency?.name} {dependency?.version ? `(${dependency.version})` : ''}
                          <Badge variant="outline" className="ml-2">{dependency?.packageManager}</Badge>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>
              
              {installResults && (
                <div className="rounded-md border bg-card p-4">
                  <h3 className="text-lg font-semibold mb-2">Installation Results</h3>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {installResults.map((result, index) => (
                      <div key={index} className="flex items-center">
                        {result.success ? (
                          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500 mr-2" />
                        )}
                        <div>
                          <p className="font-medium">{result.name}</p>
                          {!result.success && (
                            <p className="text-sm text-destructive">{result.error}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsInstallDialogOpen(false)}>
              Close
            </Button>
            <Button 
              onClick={handleInstallDependencies}
              disabled={isInstalling || mappings.length === 0}
            >
              {isInstalling ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Installing...
                </>
              ) : (
                <>
                  <Terminal className="h-4 w-4 mr-2" />
                  Install Dependencies
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Lock Dependencies Dialog */}
      <Dialog open={isLockDialogOpen} onOpenChange={setIsLockDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Lock Dependencies</DialogTitle>
            <DialogDescription>
              Create dependency lock files for {selectedAlgorithm}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <h3 className="text-lg font-medium">Lock dependencies for: <span className="font-bold">{selectedAlgorithm}</span></h3>
              <p className="text-sm text-muted-foreground mt-1">
                This will create locked dependency files for reproducible environments
              </p>
            </div>
            
            <div className="grid gap-4">
              <div>
                <Label htmlFor="environment-selection">Environment</Label>
                <Select 
                  value={environmentSelection} 
                  onValueChange={setEnvironmentSelection}
                >
                  <SelectTrigger id="environment-selection">
                    <SelectValue placeholder="Select environment" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="development">Development</SelectItem>
                    <SelectItem value="testing">Testing</SelectItem>
                    <SelectItem value="production">Production</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  Production environment will create exact version locks
                </p>
              </div>
            </div>
            
            {lockResults && (
              <div className="rounded-md border p-4 mt-4">
                <h4 className="text-md font-medium mb-2">Lock Results:</h4>
                
                {lockResults.conflicts?.hasConflicts && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-md mb-3">
                    <h5 className="text-sm font-semibold text-amber-800 flex items-center">
                      <AlertTriangle className="h-4 w-4 mr-1" />
                      Conflicts Detected
                    </h5>
                    <p className="text-xs text-amber-700 mt-1">{lockResults.conflicts.details}</p>
                  </div>
                )}
                
                {lockResults.vulnerabilities?.hasVulnerabilities && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-md mb-3">
                    <h5 className="text-sm font-semibold text-red-800 flex items-center">
                      <AlertTriangle className="h-4 w-4 mr-1" />
                      Vulnerabilities Detected
                    </h5>
                    <ul className="text-xs text-red-700 mt-1 list-disc pl-5">
                      {lockResults.vulnerabilities.details.map((detail: string, idx: number) => (
                        <li key={idx}>{detail}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div>
                  <h5 className="text-sm font-semibold">Generated Files:</h5>
                  <ul className="text-xs mt-1 space-y-1">
                    {lockResults.lockedFiles?.map((file: string, idx: number) => (
                      <li key={idx} className="flex items-center">
                        <FileCode className="h-3 w-3 mr-1" />
                        {file}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <p className="text-xs text-muted-foreground mt-3">
                  Files saved to: {lockResults.directory}
                </p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsLockDialogOpen(false)}>
              Close
            </Button>
            <Button 
              onClick={handleLockDependencies}
              disabled={isLocking || mappings.length === 0}
            >
              {isLocking ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Locking...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Lock Dependencies
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* CI/CD Tools Dialog */}
      <Dialog open={isAdvancedDialogOpen} onOpenChange={setIsAdvancedDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>CI/CD Configuration</DialogTitle>
            <DialogDescription>
              Generate CI/CD configuration for {selectedAlgorithm}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <h3 className="text-lg font-medium">CI/CD Tools for: <span className="font-bold">{selectedAlgorithm}</span></h3>
              <p className="text-sm text-muted-foreground mt-1">
                Generate configuration files for CI/CD pipelines
              </p>
            </div>
            
            <div className="grid gap-4">
              <div>
                <Label htmlFor="cicd-selection">CI/CD System</Label>
                <Select 
                  value={cicdSelection} 
                  onValueChange={setCicdSelection}
                >
                  <SelectTrigger id="cicd-selection">
                    <SelectValue placeholder="Select CI/CD system" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="github">GitHub Actions</SelectItem>
                    <SelectItem value="gitlab">GitLab CI</SelectItem>
                    <SelectItem value="jenkins">Jenkins</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="rounded-md bg-muted p-4">
                <h4 className="text-sm font-medium mb-2">This will generate:</h4>
                <ul className="text-sm space-y-1">
                  <li className="flex items-center">
                    <Code className="h-4 w-4 mr-2" />
                    {cicdSelection === 'github' ? 'GitHub Actions workflow YAML' : 
                     cicdSelection === 'gitlab' ? 'GitLab CI YAML' : 'Jenkinsfile'}
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Dependency installation commands
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-4 w-4 mr-2" />
                    Security scanning setup
                  </li>
                  <li className="flex items-center">
                    <Beaker className="h-4 w-4 mr-2" />
                    Testing commands
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsAdvancedDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleDownloadCiCdConfig}
              disabled={!selectedAlgorithm}
            >
              <Download className="h-4 w-4 mr-2" />
              Download Config
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* CSV Upload Dialog */}
      <Dialog open={showCsvUploadDialog} onOpenChange={(isOpen) => {
        setShowCsvUploadDialog(isOpen);
        if (!isOpen) setCsvUploadFile(null);
      }}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Upload Dependencies CSV</DialogTitle>
            <DialogDescription>
              Bulk import algorithm dependencies from a CSV file
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="csvFile">Select Your CSV File</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-md p-6 flex flex-col items-center justify-center bg-gray-50">
                <Upload className="h-10 w-10 text-gray-400 mb-2" />
                <p className="text-sm text-center text-muted-foreground mb-2">
                  Drag and drop your CSV file here, or click to browse
                </p>
                <Input 
                  id="csvFile" 
                  type="file" 
                  accept=".csv"
                  className="max-w-xs"
                  onChange={(e) => {
                    if (e.target.files && e.target.files.length > 0) {
                      setCsvUploadFile(e.target.files[0]);
                    }
                  }}
                />
              </div>
              <div className="flex items-center justify-between mt-3">
                <p className="text-sm text-muted-foreground">
                  <strong>Format:</strong> name, version, category
                </p>
                <Button 
                  type="button" 
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-1 text-xs"
                  onClick={() => {
                    // Create sample CSV content
                    const csvContent = `name,version,category
boto3,1.35.24,AWS SDK
numpy,2.1.1,Scientific Computing
pandas,2.2.3,Data Analysis
requests,2.32.3,HTTP Requests
tensorflow,2.17.0,Machine Learning
torch,2.4.1,Machine Learning
scikit-learn,1.5.2,Machine Learning
matplotlib,3.9.2,Data Visualization
seaborn,0.13.2,Data Visualization
flask,3.0.3,Web Framework`;
                    
                    // Create a blob and trigger download
                    const blob = new Blob([csvContent], { type: 'text/csv' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'sample_libraries.csv';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    
                    toast({
                      title: "Sample CSV Downloaded",
                      description: "You can now upload this file or modify it as needed."
                    });
                  }}
                >
                  <Download className="h-3 w-3" />
                  Download Sample CSV
                </Button>
              </div>
              
              <div className="mt-4">
                <Button 
                  type="button" 
                  variant="secondary"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    // Create sample data from a subset of your CSV
                    const predefinedData = `name,version,category
boto3,1.35.24,AWS SDK
numpy,2.1.1,Scientific Computing
pandas,2.2.3,Data Analysis
requests,2.32.3,HTTP Requests
tensorflow,2.17.0,Machine Learning
torch,2.4.1,Machine Learning
scikit-learn,1.5.2,Machine Learning
matplotlib,3.9.2,Data Visualization
seaborn,0.13.2,Data Visualization
flask,3.0.3,Web Framework`;
                    
                    // Create a Blob with the CSV content
                    const blob = new Blob([predefinedData], { type: 'text/csv' });
                    const file = new File([blob], 'sample_libraries.csv', { type: 'text/csv' });
                    
                    // Create a DataTransfer object to set the files property of the input element
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    
                    const fileInput = document.getElementById('csvFile') as HTMLInputElement;
                    if (fileInput) {
                      fileInput.files = dataTransfer.files;
                      setCsvUploadFile(file);
                      
                      toast({
                        title: "Sample Data Loaded",
                        description: "Sample CSV data has been loaded. Click 'Upload' to import it."
                      });
                    }
                  }}
                >
                  Use Sample Data (10 Libraries)
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                CSV should have columns: name, version, category
              </p>
            </div>
            
            <div className="bg-muted p-4 rounded-md">
              <h4 className="font-medium mb-2">Example CSV Format:</h4>
              <pre className="text-sm overflow-auto whitespace-pre">
                name,version,category<br/>
                numpy,2.1.1,Scientific Computing<br/>
                pandas,2.2.3,Data Analysis<br/>
                scikit-learn,1.5.2,Machine Learning
              </pre>
              <p className="text-xs text-muted-foreground mt-2">
                This format matches the provided libraries file.
              </p>
            </div>
            
            <div className="bg-amber-50 border border-amber-200 rounded-md p-3">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-amber-800">Important Note:</p>
                  <p className="mt-1 text-amber-700">
                    After importing, libraries will be available in the package search dropdown, but 
                    they won't be automatically mapped to algorithms. You'll need to create mappings 
                    separately.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setShowCsvUploadDialog(false)}>
              Cancel
            </Button>
            <Button 
              type="button" 
              disabled={!csvUploadFile || uploadCsvMutation.isPending} 
              onClick={() => {
                if (csvUploadFile) {
                  const reader = new FileReader();
                  reader.onload = (e) => {
                    if (e.target?.result) {
                      uploadCsvMutation.mutate(e.target.result as string);
                    }
                  };
                  reader.readAsText(csvUploadFile);
                }
              }}
            >
              {uploadCsvMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4 mr-2" />
                  Upload CSV
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Documentation Dialog */}
      <Dialog open={isDocumentationDialogOpen} onOpenChange={setIsDocumentationDialogOpen}>
        <DialogContent className="sm:max-w-[800px] max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Dependency Documentation</DialogTitle>
            <DialogDescription>
              Documentation for {selectedAlgorithm} dependencies
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 overflow-y-auto">
            {isGeneratingDoc ? (
              <div className="flex justify-center items-center p-12">
                <Loader2 className="h-8 w-8 animate-spin mr-2" />
                <p>Generating documentation...</p>
              </div>
            ) : documentationContent ? (
              <div className="prose max-w-none dark:prose-invert">
                <pre className="whitespace-pre-wrap p-4 bg-muted rounded-md overflow-auto text-sm">
                  {documentationContent}
                </pre>
              </div>
            ) : (
              <p className="text-center text-muted-foreground">
                No documentation available
              </p>
            )}
          </div>
          
          <DialogFooter>
            <Button onClick={() => setIsDocumentationDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Wrap the component with our error boundary for better error handling
const WrappedAlgorithmDependencies = () => (
  <ErrorBoundary>
    <AlgorithmDependencies />
  </ErrorBoundary>
);

export default WrappedAlgorithmDependencies;