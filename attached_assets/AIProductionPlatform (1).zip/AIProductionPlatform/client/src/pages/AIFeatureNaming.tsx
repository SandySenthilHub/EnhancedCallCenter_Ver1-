import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Brain, Download, InfoIcon, Upload, FileUp, FileCode, Table, HelpCircle } from 'lucide-react';
import AIFeatureNameSuggestion from '@/components/feature-engineering/AIFeatureNameSuggestion';

const EXAMPLE_FEATURES = [
  { 
    id: 1,
    originalName: "f1", 
    description: "Customer age in years",
    dataType: "numerical"
  },
  { 
    id: 2,
    originalName: "f2", 
    description: "Annual income in USD",
    dataType: "numerical"
  },
  { 
    id: 3,
    originalName: "f3", 
    description: "Geographic location of customer",
    dataType: "categorical"
  },
  { 
    id: 4,
    originalName: "f4", 
    description: "Number of previous purchases",
    dataType: "numerical"
  },
  { 
    id: 5,
    originalName: "f5", 
    description: "Subscription status (active/inactive)",
    dataType: "boolean"
  },
];

const AIFeatureNaming: React.FC = () => {
  const { toast } = useToast();
  const [selectedFeature, setSelectedFeature] = useState<any>(EXAMPLE_FEATURES[0]);
  const [mode, setMode] = useState<'example' | 'upload' | 'integration'>('example');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  
  const handleFeatureSelect = (feature: any) => {
    setSelectedFeature(feature);
  };
  
  const handleNameSelected = (name: string) => {
    toast({
      title: "Name Applied",
      description: `Feature "${selectedFeature.originalName}" renamed to "${name}"`,
    });
    
    // In a real application, this would update the feature in the state/backend
    setSelectedFeature({
      ...selectedFeature,
      newName: name
    });
  };
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      toast({
        title: "File Uploaded",
        description: `Successfully uploaded ${file.name}`,
      });
    }
  };
  
  const renderExamplesTab = () => (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="w-full lg:w-1/3">
          <Card>
            <CardHeader>
              <CardTitle>Example Features</CardTitle>
              <CardDescription>
                Select a feature to get AI naming suggestions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {EXAMPLE_FEATURES.map((feature) => (
                  <div 
                    key={feature.id}
                    className={`p-3 border rounded-md cursor-pointer hover:bg-muted transition-colors ${
                      selectedFeature?.id === feature.id ? 'border-primary bg-primary/5' : ''
                    }`}
                    onClick={() => handleFeatureSelect(feature)}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{feature.originalName}</div>
                        <div className="text-sm text-muted-foreground">{feature.description}</div>
                      </div>
                      <Badge>{feature.dataType}</Badge>
                    </div>
                    {selectedFeature?.id === feature.id && selectedFeature.newName && (
                      <div className="mt-2 text-sm">
                        <span className="text-muted-foreground">New name:</span> <span className="font-medium text-primary">{selectedFeature.newName}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="flex-1">
          {selectedFeature && (
            <AIFeatureNameSuggestion
              initialFeatureName={selectedFeature.originalName}
              dataType={selectedFeature.dataType}
              domain="retail"
              onSelect={handleNameSelected}
            />
          )}
        </div>
      </div>
      
      <div className="flex items-center p-4 bg-muted rounded-lg">
        <InfoIcon className="h-5 w-5 text-blue-500 mr-3 flex-shrink-0" />
        <div className="text-sm">
          <p>
            The AI feature naming system analyzes your data and suggests contextually appropriate names for your features based on their patterns, distributions, and relationship to other features.
          </p>
        </div>
      </div>
    </div>
  );
  
  const renderUploadTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Upload Your Dataset</CardTitle>
          <CardDescription>
            Upload a CSV file to get AI feature naming suggestions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!uploadedFile ? (
            <div className="flex flex-col items-center justify-center py-10 border-2 border-dashed rounded-md">
              <FileUp className="h-10 w-10 text-muted-foreground mb-4" />
              <p className="mb-2 text-sm text-muted-foreground">
                Upload a CSV file containing your features
              </p>
              <label htmlFor="csv-upload" className="cursor-pointer">
                <div className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-md text-sm">
                  Select File
                </div>
                <input
                  id="csv-upload"
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </label>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div className="flex items-center">
                  <FileCode className="h-8 w-8 text-blue-500 mr-3" />
                  <div>
                    <div className="font-medium">{uploadedFile.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {Math.round(uploadedFile.size / 1024)} KB
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => setUploadedFile(null)}>
                  Remove
                </Button>
              </div>
              
              <Alert>
                <InfoIcon className="h-4 w-4" />
                <AlertTitle>File Processing</AlertTitle>
                <AlertDescription>
                  This is a demo interface. In a complete implementation, the CSV would be processed to extract feature information and display it for AI naming suggestions.
                </AlertDescription>
              </Alert>
              
              <div className="flex justify-end">
                <Button>
                  <Table className="mr-2 h-4 w-4" />
                  Process Dataset
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
          <CardDescription>
            Understanding the AI feature naming process
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border rounded-md">
                <div className="flex items-center mb-2">
                  <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 flex items-center justify-center font-medium mr-2">
                    1
                  </div>
                  <h3 className="font-medium">Data Analysis</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  AI examines your data, analyzing distributions, patterns, and relationships between features.
                </p>
              </div>
              <div className="p-4 border rounded-md">
                <div className="flex items-center mb-2">
                  <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 flex items-center justify-center font-medium mr-2">
                    2
                  </div>
                  <h3 className="font-medium">Context Understanding</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Based on domain knowledge and statistical analysis, the AI understands the meaning behind each feature.
                </p>
              </div>
              <div className="p-4 border rounded-md">
                <div className="flex items-center mb-2">
                  <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 flex items-center justify-center font-medium mr-2">
                    3
                  </div>
                  <h3 className="font-medium">Name Generation</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Multiple name suggestions are generated with explanations for why each is appropriate.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
  
  const renderIntegrationTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Integration with Your Workflow</CardTitle>
          <CardDescription>
            Use AI feature naming in your machine learning pipeline
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Usage Examples</h3>
            
            <div className="space-y-3">
              <div className="p-4 border rounded-md">
                <h4 className="font-medium mb-2">Feature Store Integration</h4>
                <p className="text-sm text-muted-foreground mb-2">
                  When adding new features to your feature store, use AI naming to ensure consistency 
                  and clarity across your organization.
                </p>
                <Button variant="outline" size="sm">
                  View Feature Store
                </Button>
              </div>
              
              <div className="p-4 border rounded-md">
                <h4 className="font-medium mb-2">Data Pipeline Preprocessing</h4>
                <p className="text-sm text-muted-foreground mb-2">
                  Embed AI feature naming in your data preprocessing steps to automatically generate 
                  meaningful names for transformed or engineered features.
                </p>
                <Button variant="outline" size="sm">
                  View Data Pipelines
                </Button>
              </div>
              
              <div className="p-4 border rounded-md">
                <h4 className="font-medium mb-2">Batch Renaming</h4>
                <p className="text-sm text-muted-foreground mb-2">
                  Use the batch mode to rename multiple features at once, saving time and ensuring 
                  naming consistency across your dataset.
                </p>
                <AIFeatureNameSuggestion
                  initialFeatureName=""
                  showMultiFeatureMode={true}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
  
  return (
    <>
      <Helmet>
        <title>AI Feature Naming | AI/ML Playbook</title>
        <meta 
          name="description" 
          content="AI-powered feature naming suggestions to improve feature clarity and consistency"
        />
      </Helmet>

      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight flex items-center">
              <Brain className="mr-3 h-10 w-10 text-primary" />
              AI Feature Naming
            </h1>
            <p className="text-muted-foreground mt-2">
              Automatically generate meaningful and consistent feature names using AI
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Download Guide
            </Button>
            <Button variant="outline">
              <HelpCircle className="h-4 w-4 mr-2" />
              Help
            </Button>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <Tabs defaultValue="example" onValueChange={(value) => setMode(value as any)}>
          <TabsList className="grid w-full max-w-md grid-cols-3 mb-8">
            <TabsTrigger value="example">Examples</TabsTrigger>
            <TabsTrigger value="upload">Upload Data</TabsTrigger>
            <TabsTrigger value="integration">Integration</TabsTrigger>
          </TabsList>
          
          <TabsContent value="example">
            {renderExamplesTab()}
          </TabsContent>
          
          <TabsContent value="upload">
            {renderUploadTab()}
          </TabsContent>
          
          <TabsContent value="integration">
            {renderIntegrationTab()}
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default AIFeatureNaming;