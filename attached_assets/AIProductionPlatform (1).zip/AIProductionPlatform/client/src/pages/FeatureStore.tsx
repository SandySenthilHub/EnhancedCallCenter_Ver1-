import React from 'react';
import { Helmet } from 'react-helmet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
// We'll implement a simpler table instead of using DataTable
// import { DataTable } from '@/components/ui/data-table';
import { Plus, ListFilter, Download, FileUp, RefreshCw } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';

const FeatureStore: React.FC = () => {
  // Fetch features (placeholder query)
  const { data: features = [], isLoading: isLoadingFeatures } = useQuery<any[]>({
    queryKey: ['/api/features'],
    enabled: true,
  });

  // Fetch feature sets (placeholder query)
  const { data: featureSets = [], isLoading: isLoadingFeatureSets } = useQuery<any[]>({
    queryKey: ['/api/feature-sets'],
    enabled: true,
  });

  return (
    <>
      <Helmet>
        <title>Feature Store | AI/ML Playbook</title>
        <meta 
          name="description" 
          content="Centralized feature repository for machine learning. Create, manage, and reuse features across projects and models."
        />
      </Helmet>
      
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Feature Store</h1>
          <p className="text-muted-foreground mt-2">
            Centralized repository for feature management and sharing
          </p>
        </div>

        <Tabs defaultValue="features">
          <TabsList className="mb-4">
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="feature-sets">Feature Sets</TabsTrigger>
            <TabsTrigger value="statistics">Statistics</TabsTrigger>
          </TabsList>

          <TabsContent value="features">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                  <div>
                    <CardTitle className="text-xl">Features Catalog</CardTitle>
                    <CardDescription>
                      Create, manage, and reuse features across models
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2 mt-4 sm:mt-0">
                    <Button variant="outline" size="sm">
                      <ListFilter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Export
                    </Button>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      New Feature
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingFeatures ? (
                  <div className="flex justify-center py-8">
                    <RefreshCw className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <FeaturesList features={features} />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="feature-sets">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center">
                  <div>
                    <CardTitle className="text-xl">Feature Sets</CardTitle>
                    <CardDescription>
                      Group features for specific use cases and models
                    </CardDescription>
                  </div>
                  <div className="flex space-x-2 mt-4 sm:mt-0">
                    <Button variant="outline" size="sm">
                      <ListFilter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      New Feature Set
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingFeatureSets ? (
                  <div className="flex justify-center py-8">
                    <RefreshCw className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <FeatureSetList featureSets={featureSets} />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="statistics">
            <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
              <StatCard 
                title="Total Features" 
                value={features.length.toString()}
                description="Number of registered features" 
              />
              <StatCard 
                title="Feature Sets" 
                value={featureSets.length.toString()} 
                description="Grouped feature collections" 
              />
              <StatCard 
                title="Active Features" 
                value={features.filter((f: any) => f.isActive).length.toString()}
                description="Features marked as active" 
              />
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Feature Store Documentation</CardTitle>
                <CardDescription>
                  How to effectively use the feature store for ML projects
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <section className="mb-6">
                    <h3 className="text-lg font-medium">What is a Feature Store?</h3>
                    <p>
                      A feature store is a centralized repository for storing, managing, and serving 
                      machine learning features. It solves several key challenges in ML workflows:
                    </p>
                    <ul className="list-disc pl-6 mt-2">
                      <li>Feature reuse across multiple models and projects</li>
                      <li>Consistent feature transformation logic between training and serving</li>
                      <li>Feature versioning and lineage tracking</li>
                      <li>Efficient storage and retrieval of features</li>
                      <li>Point-in-time correctness for historical feature values</li>
                    </ul>
                  </section>

                  <section className="mb-6">
                    <h3 className="text-lg font-medium">Working with Features</h3>
                    <p>
                      Features are individual data attributes used as inputs to ML models. Good features:
                    </p>
                    <ul className="list-disc pl-6 mt-2">
                      <li>Have clear business meaning and interpretability</li>
                      <li>Are properly documented with metadata</li>
                      <li>Include transformation logic and data sources</li>
                      <li>Can be calculated both in batch and real-time when needed</li>
                    </ul>
                    <p className="mt-2">
                      Use the <strong>Features Catalog</strong> to browse, search, and reuse existing features
                      before creating new ones to avoid duplication.
                    </p>
                  </section>

                  <section>
                    <h3 className="text-lg font-medium">Using Feature Sets</h3>
                    <p>
                      Feature sets are logical groupings of features for specific use cases:
                    </p>
                    <ul className="list-disc pl-6 mt-2">
                      <li>Create feature sets for specific ML models or problem domains</li>
                      <li>Feature sets can be exported for training or real-time inference</li>
                      <li>Share feature sets across teams for collaborative ML development</li>
                      <li>Version feature sets to maintain reproducibility</li>
                    </ul>
                  </section>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

interface FeaturesListProps {
  features: any[];
}

function FeaturesList({ features }: FeaturesListProps) {
  if (features.length === 0) {
    return (
      <div className="text-center py-8 border rounded-md bg-muted/20">
        <p className="text-muted-foreground">No features found</p>
        <p className="text-sm text-muted-foreground mt-1">Create your first feature to get started</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[450px]">
      <div className="space-y-4">
        {[1, 2, 3, 4, 5].map((id) => (
          <FeatureCard 
            key={id}
            name={`customer_lifetime_value_${id}`}
            description="Predicted total revenue from a customer over the lifetime of their relationship"
            dataType="numeric"
            source="Derived from transaction history"
            tags={["financial", "customer", "prediction"]}
            isActive={true}
          />
        ))}
      </div>
    </ScrollArea>
  );
}

interface FeatureSetListProps {
  featureSets: any[];
}

function FeatureSetList({ featureSets }: FeatureSetListProps) {
  if (featureSets.length === 0) {
    return (
      <div className="text-center py-8 border rounded-md bg-muted/20">
        <p className="text-muted-foreground">No feature sets found</p>
        <p className="text-sm text-muted-foreground mt-1">Create your first feature set to get started</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[450px]">
      <div className="space-y-4">
        {[1, 2, 3].map((id) => (
          <FeatureSetCard 
            key={id}
            name={`Customer Segmentation Set ${id}`}
            description="Features for customer segmentation models including behavioral and demographic data"
            featureCount={8}
            tags={["customer", "segmentation", "demographics"]}
            isActive={true}
          />
        ))}
      </div>
    </ScrollArea>
  );
}

interface FeatureCardProps {
  name: string;
  description: string;
  dataType: string;
  source: string;
  tags: string[];
  isActive: boolean;
}

function FeatureCard({ name, description, dataType, source, tags, isActive }: FeatureCardProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-base font-medium">{name}</CardTitle>
            <CardDescription className="text-sm">{description}</CardDescription>
          </div>
          <Badge variant={isActive ? "default" : "outline"}>
            {isActive ? "Active" : "Inactive"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pb-3 pt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Data Type</p>
            <p>{dataType}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Source</p>
            <p>{source}</p>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-1">
          {tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

interface FeatureSetCardProps {
  name: string;
  description: string;
  featureCount: number;
  tags: string[];
  isActive: boolean;
}

function FeatureSetCard({ name, description, featureCount, tags, isActive }: FeatureSetCardProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-base font-medium">{name}</CardTitle>
            <CardDescription className="text-sm">{description}</CardDescription>
          </div>
          <Badge variant={isActive ? "default" : "outline"}>
            {isActive ? "Active" : "Inactive"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pb-3 pt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Features</p>
            <p>{featureCount} features</p>
          </div>
          <div>
            <p className="text-muted-foreground">Last Updated</p>
            <p>2 days ago</p>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-1">
          {tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  description: string;
}

function StatCard({ title, value, description }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-3xl font-bold">{value}</p>
      </CardContent>
    </Card>
  );
}

export default FeatureStore;