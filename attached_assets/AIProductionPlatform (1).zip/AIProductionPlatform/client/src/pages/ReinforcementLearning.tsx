import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { 
  AlertCircle, 
  ArrowRight, 
  Brain, 
  Check, 
  ChevronRight, 
  Code, 
  Edit, 
  Gamepad2, 
  Loader2, 
  Plus, 
  Play, 
  SquareCode, 
  Trash2
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/hooks/use-auth';
import { Progress } from '@/components/ui/progress';

// Type definitions
type RlAgent = {
  id: number;
  name: string;
  description: string;
  algorithm: string;
  parameters: Record<string, any>;
  environment: string;
  status: string;
  metrics: Record<string, any>;
  userId: number;
  createdAt: string;
  updatedAt: string;
};

type RlEnvironment = {
  id: number;
  name: string;
  description: string;
  type: string;
  config: Record<string, any>;
  observationSpace: Record<string, any>;
  actionSpace: Record<string, any>;
  rewardFunction?: string;
  userId: number;
  createdAt: string;
  updatedAt: string;
};

// Helper components
const StatusBadge = ({ status }: { status: string }) => {
  const color = 
    status === 'active' ? 'bg-green-100 text-green-800' : 
    status === 'training' ? 'bg-blue-100 text-blue-800' : 
    status === 'failed' ? 'bg-red-100 text-red-800' : 
    status === 'completed' ? 'bg-green-100 text-green-800' : 
    'bg-gray-100 text-gray-800';

  return (
    <Badge variant="outline" className={`${color} border-0`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
};

// Algorithm descriptions for the RL agent form
const algorithmDescriptions: Record<string, string> = {
  dqn: "Deep Q-Network (DQN) - For environments with discrete action spaces. Uses deep neural networks to approximate the Q-function.",
  ppo: "Proximal Policy Optimization (PPO) - A policy gradient method that works well for both discrete and continuous action spaces.",
  a2c: "Advantage Actor-Critic (A2C) - Combines policy-based and value-based methods for stability.",
  ddpg: "Deep Deterministic Policy Gradient (DDPG) - Specialized for continuous action spaces using deterministic policy gradient.",
  sac: "Soft Actor-Critic (SAC) - Maximizes both expected reward and entropy for better exploration.",
};

// Main Component
const ReinforcementLearning: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('agents');
  
  const [isCreateAgentDialogOpen, setIsCreateAgentDialogOpen] = useState(false);
  const [isCreateEnvironmentDialogOpen, setIsCreateEnvironmentDialogOpen] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState<RlAgent | null>(null);
  const [trainingProgress, setTrainingProgress] = useState(0);
  const [isTraining, setIsTraining] = useState(false);
  
  // Queries
  const {
    data: rlAgents = [],
    isLoading: isAgentsLoading,
    error: agentsError
  } = useQuery<RlAgent[]>({
    queryKey: ['/api/rl-agents'],
    queryFn: () => apiRequest('GET', '/api/rl-agents').then(res => res.json()),
  });

  const {
    data: rlEnvironments = [],
    isLoading: isEnvironmentsLoading,
    error: environmentsError
  } = useQuery<RlEnvironment[]>({
    queryKey: ['/api/rl-environments'],
    queryFn: () => apiRequest('GET', '/api/rl-environments').then(res => res.json()),
  });

  // Mutations
  const createAgentMutation = useMutation({
    mutationFn: async (agent: any) => {
      const res = await apiRequest('POST', '/api/rl-agents', agent);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rl-agents'] });
      setIsCreateAgentDialogOpen(false);
      toast({
        title: "Agent created",
        description: "Reinforcement learning agent was created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create agent",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const createEnvironmentMutation = useMutation({
    mutationFn: async (environment: any) => {
      const res = await apiRequest('POST', '/api/rl-environments', environment);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/rl-environments'] });
      setIsCreateEnvironmentDialogOpen(false);
      toast({
        title: "Environment created",
        description: "Reinforcement learning environment was created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create environment",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Simulate agent training
  const startTraining = (agent: RlAgent) => {
    setSelectedAgent(agent);
    setIsTraining(true);
    setTrainingProgress(0);
    
    const interval = setInterval(() => {
      setTrainingProgress(prev => {
        const newProgress = prev + Math.random() * 5;
        if (newProgress >= 100) {
          clearInterval(interval);
          setIsTraining(false);
          toast({
            title: "Training completed",
            description: `Agent '${agent.name}' has completed training.`,
          });
          return 100;
        }
        return newProgress;
      });
    }, 500);
  };

  // Create RL Agent form
  const RlAgentForm = () => {
    const [formData, setFormData] = useState({
      name: '',
      description: '',
      algorithm: '',
      environment: '',
      parameters: {
        learning_rate: 0.001,
        gamma: 0.99,
        batch_size: 64,
        buffer_size: 10000,
        exploration_rate: 0.1
      }
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.name || !formData.algorithm || !formData.environment) {
        toast({
          title: "Missing fields",
          description: "Please fill in all required fields",
          variant: "destructive",
        });
        return;
      }

      createAgentMutation.mutate({
        ...formData,
        userId: user?.id,
        status: 'draft',
        metrics: {}
      });
    };

    return (
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 py-2 pb-4">
          <div className="space-y-2">
            <Label htmlFor="name">Agent Name</Label>
            <Input 
              id="name" 
              placeholder="Enter agent name"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea 
              id="description" 
              placeholder="Enter description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="algorithm">RL Algorithm</Label>
            <Select 
              value={formData.algorithm}
              onValueChange={(value) => setFormData({...formData, algorithm: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select algorithm" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dqn">Deep Q-Network (DQN)</SelectItem>
                <SelectItem value="ppo">Proximal Policy Optimization (PPO)</SelectItem>
                <SelectItem value="a2c">Advantage Actor-Critic (A2C)</SelectItem>
                <SelectItem value="ddpg">Deep Deterministic Policy Gradient (DDPG)</SelectItem>
                <SelectItem value="sac">Soft Actor-Critic (SAC)</SelectItem>
              </SelectContent>
            </Select>
            {formData.algorithm && (
              <p className="text-sm text-muted-foreground mt-1">
                {algorithmDescriptions[formData.algorithm]}
              </p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="environment">Environment</Label>
            <Select 
              value={formData.environment}
              onValueChange={(value) => setFormData({...formData, environment: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select environment" />
              </SelectTrigger>
              <SelectContent>
                {rlEnvironments.map(env => (
                  <SelectItem key={env.id} value={env.name}>
                    {env.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Hyperparameters</Label>
            <Card>
              <CardContent className="pt-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="learning_rate" className="text-xs">Learning Rate</Label>
                    <Input 
                      id="learning_rate"
                      type="number"
                      step="0.0001"
                      min="0.0001"
                      max="1"
                      value={formData.parameters.learning_rate}
                      onChange={(e) => setFormData({
                        ...formData, 
                        parameters: {
                          ...formData.parameters,
                          learning_rate: parseFloat(e.target.value)
                        }
                      })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gamma" className="text-xs">Discount Factor (γ)</Label>
                    <Input 
                      id="gamma"
                      type="number"
                      step="0.01"
                      min="0"
                      max="1"
                      value={formData.parameters.gamma}
                      onChange={(e) => setFormData({
                        ...formData, 
                        parameters: {
                          ...formData.parameters,
                          gamma: parseFloat(e.target.value)
                        }
                      })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="batch_size" className="text-xs">Batch Size</Label>
                    <Input 
                      id="batch_size"
                      type="number"
                      min="1"
                      value={formData.parameters.batch_size}
                      onChange={(e) => setFormData({
                        ...formData, 
                        parameters: {
                          ...formData.parameters,
                          batch_size: parseInt(e.target.value)
                        }
                      })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="exploration_rate" className="text-xs">Exploration Rate (ε)</Label>
                    <Input 
                      id="exploration_rate"
                      type="number"
                      step="0.01"
                      min="0"
                      max="1"
                      value={formData.parameters.exploration_rate}
                      onChange={(e) => setFormData({
                        ...formData, 
                        parameters: {
                          ...formData.parameters,
                          exploration_rate: parseFloat(e.target.value)
                        }
                      })}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={createAgentMutation.isPending}>
            {createAgentMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Agent
          </Button>
        </DialogFooter>
      </form>
    );
  };

  // Create RL Environment form
  const RlEnvironmentForm = () => {
    const [formData, setFormData] = useState({
      name: '',
      description: '',
      type: 'custom',
      observationSpace: {
        type: 'box',
        shape: [4],
        low: [-3, -3, -3, -3],
        high: [3, 3, 3, 3]
      },
      actionSpace: {
        type: 'discrete',
        n: 2
      },
      config: {},
      rewardFunction: '# Define reward function\ndef calculate_reward(state, action, next_state):\n    # Add custom reward logic here\n    return reward'
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.name || !formData.type) {
        toast({
          title: "Missing fields",
          description: "Please fill in all required fields",
          variant: "destructive",
        });
        return;
      }

      createEnvironmentMutation.mutate({
        ...formData,
        userId: user?.id
      });
    };

    return (
      <form onSubmit={handleSubmit}>
        <div className="space-y-4 py-2 pb-4">
          <div className="space-y-2">
            <Label htmlFor="name">Environment Name</Label>
            <Input 
              id="name" 
              placeholder="Enter environment name"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea 
              id="description" 
              placeholder="Enter description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="type">Environment Type</Label>
            <Select 
              value={formData.type}
              onValueChange={(value) => setFormData({...formData, type: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gym">OpenAI Gym</SelectItem>
                <SelectItem value="unity">Unity ML-Agents</SelectItem>
                <SelectItem value="custom">Custom Environment</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Observation Space</Label>
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="obs_type" className="text-xs">Type</Label>
                    <Select 
                      value={formData.observationSpace.type}
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        observationSpace: {
                          ...formData.observationSpace,
                          type: value
                        }
                      })}
                    >
                      <SelectTrigger id="obs_type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="box">Box (Continuous)</SelectItem>
                        <SelectItem value="discrete">Discrete</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {formData.observationSpace.type === 'box' && (
                    <div className="space-y-2">
                      <Label htmlFor="obs_shape" className="text-xs">Shape</Label>
                      <Input 
                        id="obs_shape"
                        value={JSON.stringify(formData.observationSpace.shape)}
                        onChange={(e) => {
                          try {
                            const shape = JSON.parse(e.target.value);
                            setFormData({
                              ...formData, 
                              observationSpace: {
                                ...formData.observationSpace,
                                shape
                              }
                            });
                          } catch (error) {}
                        }}
                      />
                    </div>
                  )}
                  {formData.observationSpace.type === 'discrete' && (
                    <div className="space-y-2">
                      <Label htmlFor="obs_n" className="text-xs">n (number of states)</Label>
                      <Input 
                        id="obs_n"
                        type="number"
                        min="1"
                        value={formData.observationSpace.n || 1}
                        onChange={(e) => setFormData({
                          ...formData, 
                          observationSpace: {
                            ...formData.observationSpace,
                            n: parseInt(e.target.value)
                          }
                        })}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-2">
            <Label>Action Space</Label>
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="action_type" className="text-xs">Type</Label>
                    <Select 
                      value={formData.actionSpace.type}
                      onValueChange={(value) => setFormData({
                        ...formData, 
                        actionSpace: {
                          ...formData.actionSpace,
                          type: value
                        }
                      })}
                    >
                      <SelectTrigger id="action_type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="box">Box (Continuous)</SelectItem>
                        <SelectItem value="discrete">Discrete</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {formData.actionSpace.type === 'discrete' && (
                    <div className="space-y-2">
                      <Label htmlFor="action_n" className="text-xs">n (number of actions)</Label>
                      <Input 
                        id="action_n"
                        type="number"
                        min="1"
                        value={formData.actionSpace.n || 1}
                        onChange={(e) => setFormData({
                          ...formData, 
                          actionSpace: {
                            ...formData.actionSpace,
                            n: parseInt(e.target.value)
                          }
                        })}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="rewardFunction">Reward Function</Label>
            <Textarea 
              id="rewardFunction"
              className="font-mono text-xs h-32"
              value={formData.rewardFunction}
              onChange={(e) => setFormData({...formData, rewardFunction: e.target.value})}
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={createEnvironmentMutation.isPending}>
            {createEnvironmentMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Environment
          </Button>
        </DialogFooter>
      </form>
    );
  };

  return (
    <div className="container mx-auto py-6">
      <Helmet>
        <title>Reinforcement Learning - AI/ML Playbook</title>
        <meta name="description" content="Design, train and evaluate reinforcement learning agents in custom environments." />
      </Helmet>
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reinforcement Learning</h1>
          <p className="text-muted-foreground">Design, train and evaluate reinforcement learning agents in custom environments.</p>
        </div>
        <div className="flex space-x-2">
          {activeTab === 'agents' ? (
            <Dialog open={isCreateAgentDialogOpen} onOpenChange={setIsCreateAgentDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New RL Agent
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Create Reinforcement Learning Agent</DialogTitle>
                  <DialogDescription>
                    Configure a new RL agent with algorithm selection and hyperparameters.
                  </DialogDescription>
                </DialogHeader>
                <RlAgentForm />
              </DialogContent>
            </Dialog>
          ) : (
            <Dialog open={isCreateEnvironmentDialogOpen} onOpenChange={setIsCreateEnvironmentDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Environment
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Create RL Environment</DialogTitle>
                  <DialogDescription>
                    Define a new reinforcement learning environment with observation and action spaces.
                  </DialogDescription>
                </DialogHeader>
                <RlEnvironmentForm />
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {isTraining && selectedAgent && (
        <Card className="mb-6 border-blue-200 bg-blue-50">
          <CardContent className="pt-6">
            <div className="flex items-center mb-2">
              <Loader2 className="h-4 w-4 mr-2 animate-spin text-blue-600" />
              <h3 className="font-medium text-blue-700">
                Training Agent: {selectedAgent.name}
              </h3>
            </div>
            <Progress value={trainingProgress} className="h-2 mb-2" />
            <div className="flex justify-between text-xs text-blue-600">
              <span>Progress: {Math.round(trainingProgress)}%</span>
              <span>Estimated time remaining: {Math.ceil((100 - trainingProgress) / 10)} minutes</span>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="agents" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="agents">RL Agents</TabsTrigger>
          <TabsTrigger value="environments">Environments</TabsTrigger>
        </TabsList>
        
        <TabsContent value="agents">
          {isAgentsLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : agentsError ? (
            <div className="flex justify-center items-center py-12 text-destructive">
              <AlertCircle className="h-6 w-6 mr-2" />
              <p>Failed to load RL agents</p>
            </div>
          ) : rlAgents.length === 0 ? (
            <div className="text-center py-12 border rounded-md border-dashed">
              <Brain className="h-12 w-12 mx-auto text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">No RL Agents</h3>
              <p className="text-muted-foreground mt-2">Get started by creating your first reinforcement learning agent.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setIsCreateAgentDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Agent
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {rlAgents.map(agent => (
                <Card key={agent.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{agent.name}</CardTitle>
                      <StatusBadge status={agent.status} />
                    </div>
                    <CardDescription className="line-clamp-2">
                      {agent.description || "No description provided"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <Badge variant="outline" className="mr-2">
                          {agent.algorithm.toUpperCase()}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          Environment: {agent.environment}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="bg-muted p-2 rounded">
                          <span className="font-semibold block mb-1">Learning Rate</span>
                          {agent.parameters?.learning_rate || 0.001}
                        </div>
                        <div className="bg-muted p-2 rounded">
                          <span className="font-semibold block mb-1">Discount (γ)</span>
                          {agent.parameters?.gamma || 0.99}
                        </div>
                      </div>
                      
                      {Object.keys(agent.metrics).length > 0 && (
                        <div className="pt-2">
                          <h4 className="text-sm font-medium mb-1">Performance Metrics</h4>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            {Object.entries(agent.metrics).map(([key, value]) => (
                              <div key={key} className="flex justify-between">
                                <span>{key}:</span>
                                <span className="font-medium">{value}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2">
                    <div className="flex justify-between items-center w-full">
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => startTraining(agent)}
                        disabled={isTraining}
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Train
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="environments">
          {isEnvironmentsLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : environmentsError ? (
            <div className="flex justify-center items-center py-12 text-destructive">
              <AlertCircle className="h-6 w-6 mr-2" />
              <p>Failed to load RL environments</p>
            </div>
          ) : rlEnvironments.length === 0 ? (
            <div className="text-center py-12 border rounded-md border-dashed">
              <Gamepad2 className="h-12 w-12 mx-auto text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">No RL Environments</h3>
              <p className="text-muted-foreground mt-2">Create your first environment for reinforcement learning agents.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={() => setIsCreateEnvironmentDialogOpen(true)}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Environment
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              {rlEnvironments.map(env => (
                <Card key={env.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{env.name}</CardTitle>
                      <Badge variant="outline" className="bg-purple-100 text-purple-800 border-0">
                        {env.type}
                      </Badge>
                    </div>
                    <CardDescription className="line-clamp-2">
                      {env.description || "No description provided"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <h4 className="text-sm font-medium mb-1">Observation Space</h4>
                          <div className="bg-muted p-2 rounded text-xs">
                            <div><span className="font-semibold">Type:</span> {env.observationSpace.type}</div>
                            {env.observationSpace.type === 'box' && (
                              <div><span className="font-semibold">Shape:</span> {JSON.stringify(env.observationSpace.shape)}</div>
                            )}
                            {env.observationSpace.type === 'discrete' && (
                              <div><span className="font-semibold">n:</span> {env.observationSpace.n}</div>
                            )}
                          </div>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium mb-1">Action Space</h4>
                          <div className="bg-muted p-2 rounded text-xs">
                            <div><span className="font-semibold">Type:</span> {env.actionSpace.type}</div>
                            {env.actionSpace.type === 'discrete' && (
                              <div><span className="font-semibold">n:</span> {env.actionSpace.n}</div>
                            )}
                            {env.actionSpace.type === 'box' && (
                              <>
                                <div><span className="font-semibold">Shape:</span> {JSON.stringify(env.actionSpace.shape)}</div>
                                <div><span className="font-semibold">Low:</span> {JSON.stringify(env.actionSpace.low)}</div>
                                <div><span className="font-semibold">High:</span> {JSON.stringify(env.actionSpace.high)}</div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      {env.rewardFunction && (
                        <div>
                          <h4 className="text-sm font-medium mb-1">Reward Function</h4>
                          <div className="bg-muted overflow-hidden rounded">
                            <div className="bg-neutral-800 text-neutral-300 text-xs px-3 py-1 font-medium">Python</div>
                            <pre className="text-xs p-3 overflow-auto max-h-24">
                              <code>{env.rewardFunction}</code>
                            </pre>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-2">
                    <div className="flex justify-between items-center w-full">
                      <Button variant="ghost" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button variant="ghost" size="sm">
                        <SquareCode className="h-4 w-4 mr-2" />
                        Preview
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ReinforcementLearning;