import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface Dependency {
  id: number;
  name: string;
  version: string;
  package_manager: string;
  description: string;
}

const DependenciesTest = () => {
  const [dependencies, setDependencies] = useState<Dependency[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchDependencies = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/public/algorithm-dependencies');
      if (!response.ok) {
        throw new Error(`Failed to fetch dependencies: ${response.statusText}`);
      }
      const data = await response.json();
      setDependencies(data);
      toast({
        title: "Success",
        description: `Loaded ${data.length} dependencies`,
      });
    } catch (err: any) {
      console.error('Error fetching dependencies:', err);
      setError(err.message || 'Failed to fetch dependencies');
      toast({
        title: "Error",
        description: err.message || 'Failed to fetch dependencies',
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDependencies();
  }, []);

  return (
    <div className="container mx-auto py-8">
      <Card>
        <CardHeader>
          <CardTitle>Algorithm Dependencies Test</CardTitle>
          <CardDescription>
            This page tests the public endpoint for algorithm dependencies
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center p-4">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : error ? (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
              <p>{error}</p>
            </div>
          ) : (
            <div>
              <div className="mb-4">
                <p className="text-sm text-slate-500">Total Dependencies: {dependencies.length}</p>
              </div>
              <div className="border rounded-md overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Version</TableHead>
                      <TableHead>Package Manager</TableHead>
                      <TableHead>Description</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dependencies.slice(0, 10).map((dep) => (
                      <TableRow key={dep.id}>
                        <TableCell className="font-medium">{dep.name}</TableCell>
                        <TableCell>{dep.version}</TableCell>
                        <TableCell>{dep.package_manager}</TableCell>
                        <TableCell>{dep.description}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              {dependencies.length > 10 && (
                <p className="text-sm text-slate-500 mt-2">
                  Showing 10 of {dependencies.length} dependencies
                </p>
              )}
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button
            onClick={fetchDependencies}
            disabled={loading}
          >
            {loading ? 'Loading...' : 'Refresh Dependencies'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default DependenciesTest;