import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import DashboardStats from '@/components/dashboard/DashboardStats';
import BusinessUseCases from '@/components/dashboard/BusinessUseCases';
import RecentActivity from '@/components/dashboard/RecentActivity';
import { RealTimeMonitor } from '@/components/monitoring/RealTimeMonitor';
import { ModelMonitoring } from '@/components/monitoring/ModelMonitoring';
import { MonitoringTest } from '@/components/monitoring/MonitoringTest';

const Dashboard: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Dashboard | AI/ML Playbook</title>
        <meta name="description" content="AI/ML Playbook dashboard with key metrics, business use cases, and recent activities." />
      </Helmet>
      
      <section id="dashboard-section">
        <DashboardStats />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <RealTimeMonitor />
          <ModelMonitoring />
        </div>
        
        <div className="mt-6">
          <MonitoringTest />
        </div>
        
        <BusinessUseCases />
        <RecentActivity />
      </section>
    </>
  );
};

export default Dashboard;
