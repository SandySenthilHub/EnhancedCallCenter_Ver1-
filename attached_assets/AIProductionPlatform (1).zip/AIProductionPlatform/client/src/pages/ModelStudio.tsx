import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { CirclePlus, PenBox, Rocket, HardDrive, AlignLeft, Copy, LineChart, Brain, Plus, Edit, Trash2, Code, Save, X, Filter, PlusCircle, Search, CheckCircle, XCircle, Package, Layout } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';

// Type definitions
interface Algorithm {
  id: number;
  name: string;
  description: string;
  code?: string;
  parameters?: Record<string, any>;
  complexity?: string;
  accuracy?: string;
  tags?: string[];
  businessCases?: string[];
}

interface Model {
  id: number;
  name: string;
  type: string;
  algorithm: string;
  parameters: Record<string, any>;
  metrics: Record<string, any>;
  status: string;
  dataSourceId?: number;
  userId?: number;
  version: string;
  dependenciesInstalled: boolean;
  createdAt: string;
  updatedAt: string;
}

interface NewModel {
  name: string;
  type: string;
  algorithm: string;
  parameters: Record<string, any>;
  metrics: Record<string, any>;
  status: string;
  dataSourceId?: number;
  version: string;
  dependenciesInstalled: boolean;
}

interface ModelType {
  id: string;
  name: string;
  description: string;
  algorithms: Algorithm[];
}

const ModelStudio: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  
  // State management
  const [showModelDialog, setShowModelDialog] = useState(false);
  const [newModel, setNewModel] = useState<NewModel>({
    name: '',
    type: 'regression',
    algorithm: '',
    parameters: {},
    metrics: {},
    status: 'draft',
    version: '1.0.0',
    dependenciesInstalled: false
  });
  
  // Fetch models from API
  const { 
    data: models = [], 
    isLoading: isModelsLoading,
    error: modelsError
  } = useQuery<Model[]>({
    queryKey: ['/api/models'],
    queryFn: () => apiRequest('GET', '/api/models').then(res => res.json()),
  });
  
  // Create model mutation
  const createModelMutation = useMutation({
    mutationFn: async (model: NewModel) => {
      const res = await apiRequest('POST', '/api/models', model);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Model created',
        description: 'The model has been created successfully.',
      });
      setShowModelDialog(false);
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error creating model',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Handle form submit for new model
  const handleCreateModel = () => {
    if (!newModel.name || !newModel.type || !newModel.algorithm) {
      toast({
        title: 'Missing fields',
        description: 'Please fill in all required fields.',
        variant: 'destructive',
      });
      return;
    }
    
    createModelMutation.mutate(newModel);
  };
  
  const [modelTypes, setModelTypes] = useState<ModelType[]>([
    {
      id: 'regression',
      name: 'Regression',
      description: 'Algorithms for predicting continuous values',
      algorithms: [
        { 
          id: 1, 
          name: 'Linear Regression', 
          description: 'Simple linear regression model',
          code: 'from sklearn.linear_model import LinearRegression\n\ndef train_linear_regression(X_train, y_train, **kwargs):\n    model = LinearRegression(**kwargs)\n    model.fit(X_train, y_train)\n    return model',
          parameters: {
            'fit_intercept': true,
            'normalize': false,
            'copy_X': true
          },
          complexity: 'O(n²p)',
          accuracy: 'Medium',
          tags: ['linear', 'basic', 'fast'],
          businessCases: ['Sales Forecasting', 'Price Optimization', 'Demand Prediction', 'Financial Analysis']
        },
        { 
          id: 2, 
          name: 'Ridge Regression', 
          description: 'Linear regression with L2 regularization',
          code: 'from sklearn.linear_model import Ridge\n\ndef train_ridge_regression(X_train, y_train, alpha=1.0, **kwargs):\n    model = Ridge(alpha=alpha, **kwargs)\n    model.fit(X_train, y_train)\n    return model',
          parameters: {
            'alpha': 1.0,
            'fit_intercept': true,
            'normalize': false,
            'max_iter': 1000
          },
          complexity: 'O(n²p)',
          accuracy: 'Medium-High',
          tags: ['linear', 'regularized', 'stable'],
          businessCases: ['Sales Forecasting', 'Price Optimization', 'Financial Analysis', 'Demand Prediction']
        }
      ]
    },
    {
      id: 'classification',
      name: 'Classification',
      description: 'Algorithms for categorical outcome prediction',
      algorithms: [
        { 
          id: 3, 
          name: 'Logistic Regression', 
          description: 'Binary classification using logistic function',
          code: 'from sklearn.linear_model import LogisticRegression\n\ndef train_logistic_regression(X_train, y_train, **kwargs):\n    model = LogisticRegression(**kwargs)\n    model.fit(X_train, y_train)\n    return model',
          parameters: {
            'C': 1.0,
            'penalty': 'l2',
            'max_iter': 100,
            'solver': 'lbfgs'
          },
          complexity: 'O(n²p)',
          accuracy: 'Medium',
          tags: ['binary', 'probabilistic', 'linear'],
          businessCases: ['Customer Churn', 'Fraud Detection', 'Email Spam', 'Medical Diagnosis']
        },
        { 
          id: 4, 
          name: 'Random Forest Classifier', 
          description: 'Ensemble of decision trees for classification',
          code: 'from sklearn.ensemble import RandomForestClassifier\n\ndef train_random_forest_classifier(X_train, y_train, **kwargs):\n    model = RandomForestClassifier(**kwargs)\n    model.fit(X_train, y_train)\n    return model',
          parameters: {
            'n_estimators': 100,
            'criterion': 'gini',
            'max_depth': null,
            'min_samples_split': 2
          },
          complexity: 'O(n log n * features * trees)',
          accuracy: 'High',
          tags: ['ensemble', 'tree-based', 'robust'],
          businessCases: ['Customer Segmentation', 'Fraud Detection', 'Risk Assessment', 'Image Classification']
        }
      ]
    },
    {
      id: 'clustering',
      name: 'Clustering',
      description: 'Algorithms for grouping similar data points',
      algorithms: [
        { 
          id: 5, 
          name: 'K-Means', 
          description: 'Partitioning clustering by minimizing distances to centroids',
          code: 'from sklearn.cluster import KMeans\n\ndef train_kmeans(X, n_clusters=3, **kwargs):\n    model = KMeans(n_clusters=n_clusters, **kwargs)\n    model.fit(X)\n    return model',
          parameters: {
            'n_clusters': 3,
            'init': 'k-means++',
            'n_init': 10,
            'max_iter': 300
          },
          complexity: 'O(n * k * i * d)',
          accuracy: 'Depends on data',
          tags: ['partitioning', 'centroid-based', 'iterative'],
          businessCases: ['Customer Segmentation', 'Image Compression', 'Document Clustering', 'Anomaly Detection']
        },
        { 
          id: 6, 
          name: 'DBSCAN', 
          description: 'Density-based spatial clustering of applications with noise',
          code: 'from sklearn.cluster import DBSCAN\n\ndef train_dbscan(X, eps=0.5, min_samples=5, **kwargs):\n    model = DBSCAN(eps=eps, min_samples=min_samples, **kwargs)\n    model.fit(X)\n    return model',
          parameters: {
            'eps': 0.5,
            'min_samples': 5,
            'metric': 'euclidean',
            'algorithm': 'auto'
          },
          complexity: 'O(n²) or O(n log n) with indexing',
          accuracy: 'High for irregular clusters',
          tags: ['density-based', 'non-parametric', 'noise-tolerant'],
          businessCases: ['Anomaly Detection', 'Spatial Data Analysis', 'Image Segmentation', 'Network Analysis']
        }
      ]
    }
  ]);
  
  const [selectedTab, setSelectedTab] = useState('regression');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<Algorithm | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTags, setFilterTags] = useState<string[]>([]);
  
  // Dialog state
  const [showAlgorithmDialog, setShowAlgorithmDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [showModelTypeDialog, setShowModelTypeDialog] = useState(false);
  
  // Algorithm form state
  const [newAlgorithm, setNewAlgorithm] = useState<Omit<Algorithm, 'id'>>({
    name: '',
    description: '',
    code: '',
    parameters: {},
    complexity: '',
    accuracy: '',
    tags: [],
    businessCases: []
  });
  
  const [editedAlgorithm, setEditedAlgorithm] = useState<Algorithm>({
    id: 0,
    name: '',
    description: '',
    code: '',
    parameters: {},
    complexity: '',
    accuracy: '',
    tags: [],
    businessCases: []
  });
  
  // New model type state
  const [newModelType, setNewModelType] = useState<Omit<ModelType, 'algorithms'>>({
    id: '',
    name: '',
    description: ''
  });
  
  // Filter state
  const [tagInput, setTagInput] = useState('');
  const [businessCaseFilter, setBusinessCaseFilter] = useState('');
  
  // Business case constants
  const BUSINESS_CASES = [
    'Sales Forecasting',
    'Demand Prediction',
    'Customer Segmentation',
    'Price Optimization',
    'Fraud Detection',
    'Risk Assessment',
    'Medical Diagnosis',
    'Image Classification',
    'Sentiment Analysis',
    'Recommendation Systems',
    'Market Basket Analysis',
    'Credit Scoring',
    'Churn Prediction',
    'Inventory Management',
    'Anomaly Detection',
    'Predictive Maintenance'
  ];
  
  // Get unique tags from all algorithms
  const getAllTags = () => {
    const tags = new Set<string>();
    modelTypes.forEach(type => {
      type.algorithms.forEach(algo => {
        algo.tags?.forEach(tag => tags.add(tag));
      });
    });
    return Array.from(tags);
  };
  
  // Handler for adding filter tag
  const handleAddFilterTag = () => {
    if (tagInput && !filterTags.includes(tagInput)) {
      setFilterTags([...filterTags, tagInput]);
      setTagInput('');
    }
  };
  
  // Handler for removing filter tag
  const handleRemoveFilterTag = (tag: string) => {
    setFilterTags(filterTags.filter(t => t !== tag));
  };
  
  // Get selected model type object
  const getSelectedModelType = () => {
    return modelTypes.find(type => type.id === selectedTab);
  };
  
  // Handler for algorithm selection
  const handleSelectAlgorithm = (algorithm: Algorithm) => {
    setSelectedAlgorithm(algorithm);
  };
  
  // Filter algorithms based on search term and tags
  const getFilteredAlgorithms = () => {
    const modelType = getSelectedModelType();
    if (!modelType) return [];
    
    return modelType.algorithms.filter(algo => {
      const matchesSearch = 
        algo.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        algo.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesTags = filterTags.length === 0 || 
        filterTags.every(tag => algo.tags?.includes(tag));
      
      return matchesSearch && matchesTags;
    });
  };
  
  // Add a new algorithm
  const handleAddAlgorithm = () => {
    const modelType = getSelectedModelType();
    if (!modelType) return;
    
    const maxId = Math.max(0, ...modelType.algorithms.map(a => a.id));
    const newAlgoWithId = {
      ...newAlgorithm,
      id: maxId + 1
    };
    
    // Create a new array of model types with the updated algorithms
    const updatedModelTypes = modelTypes.map(type => {
      if (type.id === selectedTab) {
        return {
          ...type,
          algorithms: [...type.algorithms, newAlgoWithId]
        };
      }
      return type;
    });
    
    setModelTypes(updatedModelTypes);
    setNewAlgorithm({
      name: '',
      description: '',
      code: '',
      parameters: {},
      complexity: '',
      accuracy: '',
      tags: [],
      businessCases: []
    });
    setShowAlgorithmDialog(false);
  };
  
  // Edit an existing algorithm
  const handleEditAlgorithm = () => {
    const updatedModelTypes = modelTypes.map(type => {
      if (type.id === selectedTab) {
        return {
          ...type,
          algorithms: type.algorithms.map(algo => 
            algo.id === editedAlgorithm.id ? editedAlgorithm : algo
          )
        };
      }
      return type;
    });
    
    setModelTypes(updatedModelTypes);
    setShowEditDialog(false);
    setEditMode(false);
  };
  
  // Delete an algorithm
  const handleDeleteAlgorithm = (id: number) => {
    const updatedModelTypes = modelTypes.map(type => {
      if (type.id === selectedTab) {
        return {
          ...type,
          algorithms: type.algorithms.filter(algo => algo.id !== id)
        };
      }
      return type;
    });
    
    setModelTypes(updatedModelTypes);
    if (selectedAlgorithm?.id === id) {
      setSelectedAlgorithm(null);
    }
  };
  
  // Add a new model type
  const handleAddModelType = () => {
    if (!newModelType.id || !newModelType.name) return;
    
    const newType: ModelType = {
      ...newModelType,
      algorithms: []
    };
    
    setModelTypes([...modelTypes, newType]);
    setSelectedTab(newModelType.id);
    setNewModelType({
      id: '',
      name: '',
      description: ''
    });
    setShowModelTypeDialog(false);
  };
  
  // Handle tag input in forms
  const handleTagInput = (e: React.KeyboardEvent<HTMLInputElement>, formType: 'new' | 'edit') => {
    if (e.key === 'Enter' && e.currentTarget.value) {
      e.preventDefault();
      const newTag = e.currentTarget.value;
      
      if (formType === 'new') {
        if (!newAlgorithm.tags?.includes(newTag)) {
          setNewAlgorithm({
            ...newAlgorithm,
            tags: [...(newAlgorithm.tags || []), newTag]
          });
        }
      } else {
        if (!editedAlgorithm.tags?.includes(newTag)) {
          setEditedAlgorithm({
            ...editedAlgorithm,
            tags: [...(editedAlgorithm.tags || []), newTag]
          });
        }
      }
      
      e.currentTarget.value = '';
    }
  };
  
  // Render the table view of algorithms
  const renderTableView = () => {
    const filteredAlgorithms = getFilteredAlgorithms();
    
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Tags</TableHead>
              <TableHead>Accuracy</TableHead>
              <TableHead>Complexity</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAlgorithms.map((algorithm) => (
              <TableRow 
                key={algorithm.id}
                className={selectedAlgorithm?.id === algorithm.id ? 'bg-muted/50' : ''}
                onClick={() => handleSelectAlgorithm(algorithm)}
                style={{ cursor: 'pointer' }}
              >
                <TableCell className="font-medium">{algorithm.name}</TableCell>
                <TableCell>{algorithm.description}</TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {algorithm.tags?.map((tag, idx) => (
                      <Badge key={idx} variant="outline">{tag}</Badge>
                    ))}
                  </div>
                </TableCell>
                <TableCell>{algorithm.accuracy}</TableCell>
                <TableCell>{algorithm.complexity}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectAlgorithm(algorithm);
                      }}
                    >
                      <Code className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditedAlgorithm(algorithm);
                        setEditMode(true);
                        setShowEditDialog(true);
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteAlgorithm(algorithm.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  };
  
  // Render card view of algorithms
  const renderCardView = () => {
    const selectedTypeObj = getSelectedModelType();
    if (!selectedTypeObj) return null;
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {selectedTypeObj.algorithms.map((algorithm) => (
          <Card 
            key={algorithm.id}
            className={selectedAlgorithm?.id === algorithm.id ? 'border-primary' : ''}
          >
            <CardHeader className="pb-2">
              <CardTitle>{algorithm.name}</CardTitle>
              <CardDescription>{algorithm.description}</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex flex-wrap gap-1 mb-3">
                {algorithm.tags?.map((tag, index) => (
                  <Badge key={index} variant="secondary">{tag}</Badge>
                ))}
              </div>
              <div className="text-sm space-y-1">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Accuracy:</span>
                  <span>{algorithm.accuracy}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Complexity:</span>
                  <span>{algorithm.complexity}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => handleSelectAlgorithm(algorithm)}
              >
                <Code className="h-4 w-4 mr-2" />
                View Code
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => {
                  setEditedAlgorithm(algorithm);
                  setEditMode(true);
                  setShowEditDialog(true);
                }}
              >
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => handleDeleteAlgorithm(algorithm.id)}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  };
  
  return (
    <>
      <Helmet>
        <title>Model Studio | AI/ML Playbook</title>
        <meta name="description" content="Build, train, and manage machine learning models" />
      </Helmet>

      <div className="flex flex-col space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Model Studio</h1>
            <p className="text-muted-foreground mt-2">Build, train, and manage machine learning models</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => setShowModelTypeDialog(true)} variant="outline">
              <PlusCircle className="h-4 w-4 mr-2" />
              New Model Type
            </Button>
            <Button onClick={() => setShowModelDialog(true)}>
              <CirclePlus className="h-4 w-4 mr-2" />
              New Model
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-6">
          {/* Model type tabs */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle>Model Types</CardTitle>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className={viewMode === 'table' ? 'bg-muted' : ''}
                    onClick={() => setViewMode('table')}
                  >
                    <Filter className="h-4 w-4 mr-2" />
                    Table
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className={viewMode === 'cards' ? 'bg-muted' : ''}
                    onClick={() => setViewMode('cards')}
                  >
                    <Layout className="h-4 w-4 mr-2" />
                    Cards
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pb-2">
              <Tabs value={selectedTab} onValueChange={setSelectedTab}>
                <TabsList className="mb-4">
                  {modelTypes.map((type) => (
                    <TabsTrigger key={type.id} value={type.id}>{type.name}</TabsTrigger>
                  ))}
                </TabsList>
                
                <div className="flex items-center justify-between mb-4">
                  <div className="flex-1 max-w-sm">
                    <div className="relative">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search algorithms..."
                        className="pl-8"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-2 ml-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setShowAlgorithmDialog(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Algorithm
                    </Button>
                  </div>
                </div>
                
                {/* Filter by tags */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-sm font-medium">Filter by tags:</h3>
                    <div className="flex gap-1">
                      <Input 
                        placeholder="Add tag filter..."
                        value={tagInput}
                        onChange={(e) => setTagInput(e.target.value)}
                        className="h-8 w-32"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddFilterTag();
                          }
                        }}
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="h-8 px-2"
                        onClick={handleAddFilterTag}
                      >
                        Add
                      </Button>
                    </div>
                  </div>
                  
                  {filterTags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-2">
                      {filterTags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="px-2 py-1">
                          {tag}
                          <button 
                            className="ml-1 opacity-70 hover:opacity-100"
                            onClick={() => handleRemoveFilterTag(tag)}
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="h-7 px-2 text-xs"
                        onClick={() => setFilterTags([])}
                      >
                        Clear all
                      </Button>
                    </div>
                  )}
                </div>
                
                {viewMode === 'table' ? renderTableView() : renderCardView()}
              </Tabs>
            </CardContent>
          </Card>
          
          {/* Selected algorithm details */}
          {selectedAlgorithm && (
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{selectedAlgorithm.name}</CardTitle>
                    <CardDescription>{selectedAlgorithm.description}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Save className="h-4 w-4 mr-2" />
                      Create Model
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Implementation Code</h3>
                  <div className="bg-muted rounded-md p-4 overflow-auto">
                    <pre className="text-sm">
                      <code>{selectedAlgorithm.code || 'No implementation code available'}</code>
                    </pre>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Parameters</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(selectedAlgorithm.parameters || {}).map(([key, value]) => (
                      <div key={key} className="flex justify-between">
                        <span className="font-medium">{key}:</span>
                        <span>{value === null ? 'null' : value.toString()}</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-2">Business Cases</h3>
                  <div className="flex flex-wrap gap-1">
                    {selectedAlgorithm.businessCases?.map((businessCase, idx) => (
                      <Badge key={idx} variant="secondary">{businessCase}</Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      
      {/* Add Algorithm Dialog */}
      <Dialog open={showAlgorithmDialog} onOpenChange={setShowAlgorithmDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add New Algorithm</DialogTitle>
            <DialogDescription>
              Create a new algorithm for the {getSelectedModelType()?.name} category
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="algo-name">Algorithm Name</Label>
              <Input 
                id="algo-name" 
                value={newAlgorithm.name}
                onChange={(e) => setNewAlgorithm({...newAlgorithm, name: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="algo-description">Description</Label>
              <Input 
                id="algo-description" 
                value={newAlgorithm.description}
                onChange={(e) => setNewAlgorithm({...newAlgorithm, description: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="algo-code">Implementation Code</Label>
              <Textarea 
                id="algo-code" 
                className="font-mono h-36"
                value={newAlgorithm.code}
                onChange={(e) => setNewAlgorithm({...newAlgorithm, code: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="algo-complexity">Complexity</Label>
                <Input 
                  id="algo-complexity"
                  placeholder="e.g., O(n log n)"
                  value={newAlgorithm.complexity}
                  onChange={(e) => setNewAlgorithm({...newAlgorithm, complexity: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="algo-accuracy">Accuracy</Label>
                <Select 
                  value={newAlgorithm.accuracy} 
                  onValueChange={(value) => setNewAlgorithm({...newAlgorithm, accuracy: value})}
                >
                  <SelectTrigger id="algo-accuracy">
                    <SelectValue placeholder="Select accuracy" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Medium-High">Medium-High</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Very High">Very High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="algo-tags">Tags</Label>
              <div className="flex flex-wrap gap-1 mb-2">
                {newAlgorithm.tags?.map((tag, idx) => (
                  <Badge key={idx} variant="secondary" className="px-2 py-1">
                    {tag}
                    <button 
                      className="ml-1 opacity-70 hover:opacity-100"
                      onClick={() => {
                        setNewAlgorithm({
                          ...newAlgorithm,
                          tags: newAlgorithm.tags?.filter((_, i) => i !== idx)
                        });
                      }}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
              <Input 
                id="algo-tags"
                placeholder="Type tag and press Enter"
                onKeyDown={(e) => handleTagInput(e, 'new')}
              />
              <p className="text-xs text-muted-foreground">
                Common tags: linear, tree-based, ensemble, deep-learning, classification, etc.
              </p>
            </div>
            
            <div className="grid gap-2">
              <Label>Business Cases</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Filter cases..."
                  className="pl-8"
                  value={businessCaseFilter}
                  onChange={(e) => setBusinessCaseFilter(e.target.value)}
                />
              </div>
              <div className="border rounded-md p-4 h-[200px] overflow-y-auto grid grid-cols-2 gap-2">
                {BUSINESS_CASES.filter(bc => 
                  bc.toLowerCase().includes(businessCaseFilter.toLowerCase())
                ).map((businessCase) => (
                  <div key={businessCase} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`business-case-${businessCase.replace(/\s+/g, '-').toLowerCase()}`}
                      checked={newAlgorithm.businessCases?.includes(businessCase)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setNewAlgorithm({
                            ...newAlgorithm,
                            businessCases: [...(newAlgorithm.businessCases || []), businessCase]
                          });
                        } else {
                          setNewAlgorithm({
                            ...newAlgorithm,
                            businessCases: newAlgorithm.businessCases?.filter(bc => bc !== businessCase)
                          });
                        }
                      }}
                    />
                    <Label htmlFor={`business-case-${businessCase.replace(/\s+/g, '-').toLowerCase()}`}>{businessCase}</Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAlgorithmDialog(false)}>Cancel</Button>
            <Button onClick={handleAddAlgorithm}>Add Algorithm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Algorithm Dialog */}
      <Dialog open={showEditDialog && editMode} onOpenChange={(open) => {
        setShowEditDialog(open);
        if (!open) setEditMode(false);
      }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Algorithm</DialogTitle>
            <DialogDescription>
              Edit details for {editedAlgorithm.name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="edit-algo-name">Algorithm Name</Label>
              <Input 
                id="edit-algo-name" 
                value={editedAlgorithm.name}
                onChange={(e) => setEditedAlgorithm({...editedAlgorithm, name: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="edit-algo-description">Description</Label>
              <Input 
                id="edit-algo-description" 
                value={editedAlgorithm.description}
                onChange={(e) => setEditedAlgorithm({...editedAlgorithm, description: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="edit-algo-code">Implementation Code</Label>
              <Textarea 
                id="edit-algo-code" 
                className="font-mono h-36"
                value={editedAlgorithm.code}
                onChange={(e) => setEditedAlgorithm({...editedAlgorithm, code: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-algo-complexity">Complexity</Label>
                <Input 
                  id="edit-algo-complexity"
                  placeholder="e.g., O(n log n)"
                  value={editedAlgorithm.complexity}
                  onChange={(e) => setEditedAlgorithm({...editedAlgorithm, complexity: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-algo-accuracy">Accuracy</Label>
                <Select 
                  value={editedAlgorithm.accuracy} 
                  onValueChange={(value) => setEditedAlgorithm({...editedAlgorithm, accuracy: value})}
                >
                  <SelectTrigger id="edit-algo-accuracy">
                    <SelectValue placeholder="Select accuracy" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Medium-High">Medium-High</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Very High">Very High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="edit-algo-tags">Tags</Label>
              <div className="flex flex-wrap gap-1 mb-2">
                {editedAlgorithm.tags?.map((tag, idx) => (
                  <Badge key={idx} variant="secondary" className="px-2 py-1">
                    {tag}
                    <button 
                      className="ml-1 opacity-70 hover:opacity-100"
                      onClick={() => {
                        setEditedAlgorithm({
                          ...editedAlgorithm,
                          tags: editedAlgorithm.tags?.filter((_, i) => i !== idx)
                        });
                      }}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
              <Input 
                id="edit-algo-tags"
                placeholder="Type tag and press Enter"
                onKeyDown={(e) => handleTagInput(e, 'edit')}
              />
            </div>
            
            <div className="grid gap-2">
              <Label>Business Cases</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Filter cases..."
                  className="pl-8"
                  value={businessCaseFilter}
                  onChange={(e) => setBusinessCaseFilter(e.target.value)}
                />
              </div>
              <div className="border rounded-md p-4 h-[200px] overflow-y-auto grid grid-cols-2 gap-2">
                {BUSINESS_CASES.filter(bc => 
                  bc.toLowerCase().includes(businessCaseFilter.toLowerCase())
                ).map((businessCase) => (
                  <div key={businessCase} className="flex items-center space-x-2">
                    <Checkbox 
                      id={`edit-business-case-${businessCase.replace(/\s+/g, '-').toLowerCase()}`}
                      checked={editedAlgorithm.businessCases?.includes(businessCase)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setEditedAlgorithm({
                            ...editedAlgorithm,
                            businessCases: [...(editedAlgorithm.businessCases || []), businessCase]
                          });
                        } else {
                          setEditedAlgorithm({
                            ...editedAlgorithm,
                            businessCases: editedAlgorithm.businessCases?.filter(bc => bc !== businessCase)
                          });
                        }
                      }}
                    />
                    <Label htmlFor={`edit-business-case-${businessCase.replace(/\s+/g, '-').toLowerCase()}`}>{businessCase}</Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowEditDialog(false);
              setEditMode(false);
            }}>Cancel</Button>
            <Button onClick={handleEditAlgorithm}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* New Model Type Dialog */}
      <Dialog open={showModelTypeDialog} onOpenChange={setShowModelTypeDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New Model Type</DialogTitle>
            <DialogDescription>
              Create a new category of machine learning algorithms
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="type-id">Type ID</Label>
              <Input 
                id="type-id" 
                placeholder="e.g., time_series"
                value={newModelType.id}
                onChange={(e) => setNewModelType({...newModelType, id: e.target.value.toLowerCase().replace(/\s+/g, '_')})}
              />
              <p className="text-xs text-muted-foreground">
                Unique identifier without spaces (use underscores)
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="type-name">Display Name</Label>
              <Input 
                id="type-name" 
                placeholder="e.g., Time Series"
                value={newModelType.name}
                onChange={(e) => setNewModelType({...newModelType, name: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="type-description">Description</Label>
              <Textarea 
                id="type-description" 
                placeholder="Describe this category of algorithms"
                value={newModelType.description}
                onChange={(e) => setNewModelType({...newModelType, description: e.target.value})}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModelTypeDialog(false)}>Cancel</Button>
            <Button onClick={handleAddModelType}>Add Model Type</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create New Model Dialog */}
      <Dialog open={showModelDialog} onOpenChange={(isOpen) => {
        setShowModelDialog(isOpen);
        if (!isOpen) {
          setNewModel({
            name: '',
            type: 'regression',
            algorithm: '',
            parameters: {},
            metrics: {},
            status: 'draft',
            version: '1.0.0',
            dependenciesInstalled: false
          });
        }
      }}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Model</DialogTitle>
            <DialogDescription>
              Create a new machine learning model based on an algorithm.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="model-name">Model Name</Label>
              <Input 
                id="model-name" 
                placeholder="Enter model name"
                value={newModel.name}
                onChange={(e) => setNewModel({...newModel, name: e.target.value})}
              />
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="model-type">Model Type</Label>
              <Select 
                value={newModel.type} 
                onValueChange={(value) => setNewModel({...newModel, type: value})}
              >
                <SelectTrigger id="model-type">
                  <SelectValue placeholder="Select model type" />
                </SelectTrigger>
                <SelectContent>
                  {modelTypes.map((type) => (
                    <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="model-algorithm">Algorithm</Label>
              <Select 
                value={newModel.algorithm} 
                onValueChange={(value) => setNewModel({...newModel, algorithm: value})}
              >
                <SelectTrigger id="model-algorithm">
                  <SelectValue placeholder="Select algorithm" />
                </SelectTrigger>
                <SelectContent>
                  {modelTypes
                    .find(type => type.id === newModel.type)?.algorithms
                    .map((algorithm) => (
                      <SelectItem key={algorithm.id} value={algorithm.name}>{algorithm.name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="model-status">Status</Label>
              <Select 
                value={newModel.status} 
                onValueChange={(value) => setNewModel({...newModel, status: value})}
              >
                <SelectTrigger id="model-status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="training">Training</SelectItem>
                  <SelectItem value="ready">Ready</SelectItem>
                  <SelectItem value="deployed">Deployed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-1 gap-2">
              <Label htmlFor="model-version">Version</Label>
              <Input 
                id="model-version" 
                placeholder="1.0.0"
                value={newModel.version}
                onChange={(e) => setNewModel({...newModel, version: e.target.value})}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="dependencies-installed"
                checked={newModel.dependenciesInstalled}
                onCheckedChange={(checked) => 
                  setNewModel({...newModel, dependenciesInstalled: !!checked})
                }
              />
              <Label htmlFor="dependencies-installed">
                Dependencies Installed
              </Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModelDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleCreateModel}
              disabled={createModelMutation.isPending}
            >
              {createModelMutation.isPending && (
                <span className="mr-2 h-4 w-4 animate-spin">⟳</span>
              )}
              Create Model
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ModelStudio;
