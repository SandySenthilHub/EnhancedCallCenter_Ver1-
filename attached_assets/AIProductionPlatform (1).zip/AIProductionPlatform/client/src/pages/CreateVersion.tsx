import React, { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  ArrowLeft, 
  Upload,
  Plus,
  X,
  AlertCircle
} from 'lucide-react';
import { Link, useLocation, useParams } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

// Types
type ModelType = 'Native' | 'Azure' | 'AWS' | 'MLflow';
type NativeVersionFormValues = z.infer<typeof nativeVersionSchema>;
type AzureVersionFormValues = z.infer<typeof azureVersionSchema>;
type AwsVersionFormValues = z.infer<typeof awsVersionSchema>;
type MlflowVersionFormValues = z.infer<typeof mlflowVersionSchema>;

interface Model {
  id: number;
  name: string;
  description: string;
  type: ModelType;
  created_by: number;
  team_id: number | null;
  created_at: string;
  updated_at: string;
  is_active: boolean;
  tags: string[] | null;
}

// Form schemas
const nativeVersionSchema = z.object({
  version: z.string().min(1, "Version is required"),
  description: z.string().min(1, "Description is required"),
  framework: z.string().optional(),
  algorithm: z.string().optional(),
  input_schema: z.string().optional(),
  output_schema: z.string().optional(),
  metrics: z.record(z.string(), z.union([z.string(), z.number()])).optional(),
  dependencies: z.record(z.string(), z.string()).optional(),
});

const azureVersionSchema = z.object({
  version: z.string().min(1, "Version is required"),
  description: z.string().min(1, "Description is required"),
  service_type: z.string().min(1, "Service type is required"),
  endpoint: z.string().min(1, "Endpoint is required"),
  region: z.string().optional(),
  credential_reference: z.string().optional(),
  config: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
});

const awsVersionSchema = z.object({
  version: z.string().min(1, "Version is required"),
  description: z.string().min(1, "Description is required"),
  service_type: z.string().min(1, "Service type is required"),
  region: z.string().min(1, "Region is required"),
  credential_reference: z.string().optional(),
  config: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
});

const mlflowVersionSchema = z.object({
  version: z.string().min(1, "Version is required"),
  description: z.string().min(1, "Description is required"),
  mlflow_tracking_uri: z.string().min(1, "MLflow tracking URI is required"),
  mlflow_model_name: z.string().min(1, "MLflow model name is required"),
  mlflow_model_version: z.string().min(1, "MLflow model version is required"),
  config: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional(),
});

// CreateVersion component
const CreateVersion: React.FC = () => {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const modelId = parseInt(params.id);

  // Fetch model to get its type
  const { data: model, isLoading: isLoadingModel } = useQuery<Model>({
    queryKey: [`/api/model-registry/models/${modelId}`],
  });

  // Get suggested next version number
  const { data: nextVersion } = useQuery<{ version: string }>({
    queryKey: [`/api/model-registry/models/${modelId}/suggest-version`],
    enabled: !!modelId,
  });

  // State for metrics and dependencies
  const [metricKey, setMetricKey] = useState('');
  const [metricValue, setMetricValue] = useState('');
  const [dependencyName, setDependencyName] = useState('');
  const [dependencyVersion, setDependencyVersion] = useState('');
  const [configKey, setConfigKey] = useState('');
  const [configValue, setConfigValue] = useState('');

  // Native model version form
  const nativeForm = useForm<NativeVersionFormValues>({
    resolver: zodResolver(nativeVersionSchema),
    defaultValues: {
      version: '',
      description: '',
      framework: '',
      algorithm: '',
      input_schema: '',
      output_schema: '',
      metrics: {},
      dependencies: {},
    },
  });

  // Azure version form
  const azureForm = useForm<AzureVersionFormValues>({
    resolver: zodResolver(azureVersionSchema),
    defaultValues: {
      version: '',
      description: '',
      service_type: '',
      endpoint: '',
      region: '',
      credential_reference: '',
      config: {},
    },
  });

  // AWS version form
  const awsForm = useForm<AwsVersionFormValues>({
    resolver: zodResolver(awsVersionSchema),
    defaultValues: {
      version: '',
      description: '',
      service_type: '',
      region: '',
      credential_reference: '',
      config: {},
    },
  });

  // MLflow version form
  const mlflowForm = useForm<MlflowVersionFormValues>({
    resolver: zodResolver(mlflowVersionSchema),
    defaultValues: {
      version: '',
      description: '',
      mlflow_tracking_uri: '',
      mlflow_model_name: '',
      mlflow_model_version: '',
      config: {},
    },
  });

  // Update version field with suggested next version when available
  useEffect(() => {
    if (nextVersion) {
      nativeForm.setValue('version', nextVersion.version);
      azureForm.setValue('version', nextVersion.version);
      awsForm.setValue('version', nextVersion.version);
      mlflowForm.setValue('version', nextVersion.version);
    }
  }, [nextVersion]);

  // Handle metrics operations
  const addMetric = () => {
    if (!metricKey || !metricValue) return;
    
    const currentMetrics = nativeForm.getValues('metrics') || {};
    // Try to convert to number if possible
    const numValue = !isNaN(Number(metricValue)) ? Number(metricValue) : metricValue;
    
    nativeForm.setValue('metrics', {
      ...currentMetrics,
      [metricKey]: numValue
    });
    
    setMetricKey('');
    setMetricValue('');
  };

  const removeMetric = (key: string) => {
    const currentMetrics = nativeForm.getValues('metrics') || {};
    const { [key]: _, ...rest } = currentMetrics;
    nativeForm.setValue('metrics', rest);
  };

  // Handle dependencies operations
  const addDependency = () => {
    if (!dependencyName || !dependencyVersion) return;
    
    const currentDependencies = nativeForm.getValues('dependencies') || {};
    nativeForm.setValue('dependencies', {
      ...currentDependencies,
      [dependencyName]: dependencyVersion
    });
    
    setDependencyName('');
    setDependencyVersion('');
  };

  const removeDependency = (key: string) => {
    const currentDependencies = nativeForm.getValues('dependencies') || {};
    const { [key]: _, ...rest } = currentDependencies;
    nativeForm.setValue('dependencies', rest);
  };

  // Handle config operations for external services
  const addConfigItem = (formType: 'azure' | 'aws' | 'mlflow') => {
    if (!configKey || !configValue) return;
    
    // Try to convert to number if possible
    let processedValue: string | number | boolean = configValue;
    if (!isNaN(Number(configValue))) {
      processedValue = Number(configValue);
    } else if (configValue.toLowerCase() === 'true') {
      processedValue = true;
    } else if (configValue.toLowerCase() === 'false') {
      processedValue = false;
    }
    
    switch (formType) {
      case 'azure':
        const azureConfig = azureForm.getValues('config') || {};
        azureForm.setValue('config', {
          ...azureConfig,
          [configKey]: processedValue
        });
        break;
      case 'aws':
        const awsConfig = awsForm.getValues('config') || {};
        awsForm.setValue('config', {
          ...awsConfig,
          [configKey]: processedValue
        });
        break;
      case 'mlflow':
        const mlflowConfig = mlflowForm.getValues('config') || {};
        mlflowForm.setValue('config', {
          ...mlflowConfig,
          [configKey]: processedValue
        });
        break;
    }
    
    setConfigKey('');
    setConfigValue('');
  };

  const removeConfigItem = (key: string, formType: 'azure' | 'aws' | 'mlflow') => {
    switch (formType) {
      case 'azure':
        const azureConfig = azureForm.getValues('config') || {};
        const { [key]: _, ...azureRest } = azureConfig;
        azureForm.setValue('config', azureRest);
        break;
      case 'aws':
        const awsConfig = awsForm.getValues('config') || {};
        const { [key]: __, ...awsRest } = awsConfig;
        awsForm.setValue('config', awsRest);
        break;
      case 'mlflow':
        const mlflowConfig = mlflowForm.getValues('config') || {};
        const { [key]: ___, ...mlflowRest } = mlflowConfig;
        mlflowForm.setValue('config', mlflowRest);
        break;
    }
  };

  // Mutations for creating different version types
  const createNativeVersionMutation = useMutation({
    mutationFn: async (values: NativeVersionFormValues) => {
      const response = await apiRequest(
        'POST', 
        `/api/model-registry/models/${modelId}/versions/native`, 
        values
      );
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create version');
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: [`/api/model-registry/models/${modelId}/versions`] });
      
      toast({
        title: "Success",
        description: "Model version created successfully",
      });
      
      // Redirect to model detail page
      setLocation(`/model-registry/model/${modelId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createAzureVersionMutation = useMutation({
    mutationFn: async (values: AzureVersionFormValues) => {
      const response = await apiRequest(
        'POST', 
        `/api/model-registry/models/${modelId}/versions/azure`, 
        values
      );
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create version');
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: [`/api/model-registry/models/${modelId}/versions`] });
      
      toast({
        title: "Success",
        description: "Azure service version created successfully",
      });
      
      // Redirect to model detail page
      setLocation(`/model-registry/model/${modelId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createAwsVersionMutation = useMutation({
    mutationFn: async (values: AwsVersionFormValues) => {
      const response = await apiRequest(
        'POST', 
        `/api/model-registry/models/${modelId}/versions/aws`, 
        values
      );
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create version');
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: [`/api/model-registry/models/${modelId}/versions`] });
      
      toast({
        title: "Success",
        description: "AWS service version created successfully",
      });
      
      // Redirect to model detail page
      setLocation(`/model-registry/model/${modelId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createMlflowVersionMutation = useMutation({
    mutationFn: async (values: MlflowVersionFormValues) => {
      const response = await apiRequest(
        'POST', 
        `/api/model-registry/models/${modelId}/versions/mlflow`, 
        values
      );
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create version');
      }
      return response.json();
    },
    onSuccess: () => {
      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: [`/api/model-registry/models/${modelId}/versions`] });
      
      toast({
        title: "Success",
        description: "MLflow model version created successfully",
      });
      
      // Redirect to model detail page
      setLocation(`/model-registry/model/${modelId}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form submission handlers
  const onSubmitNative = (values: NativeVersionFormValues) => {
    createNativeVersionMutation.mutate(values);
  };

  const onSubmitAzure = (values: AzureVersionFormValues) => {
    createAzureVersionMutation.mutate(values);
  };

  const onSubmitAws = (values: AwsVersionFormValues) => {
    createAwsVersionMutation.mutate(values);
  };

  const onSubmitMlflow = (values: MlflowVersionFormValues) => {
    createMlflowVersionMutation.mutate(values);
  };

  // If model is loading, show loading state
  if (isLoadingModel) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex justify-center items-center h-64">
          <p>Loading model...</p>
        </div>
      </div>
    );
  }

  // If model not found, show error
  if (!model) {
    return (
      <div className="container mx-auto py-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Model not found. Please go back to the Model Registry and try again.
          </AlertDescription>
        </Alert>
        <Button 
          className="mt-4"
          onClick={() => setLocation('/model-registry')}
        >
          Back to Model Registry
        </Button>
      </div>
    );
  }

  // Determine which form to show based on model type
  const renderForm = () => {
    switch (model.type) {
      case 'Native':
        return (
          <Form {...nativeForm}>
            <form onSubmit={nativeForm.handleSubmit(onSubmitNative)} className="space-y-6">
              <FormField
                control={nativeForm.control}
                name="version"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Version</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., 1.0.0" />
                    </FormControl>
                    <FormDescription>
                      Semantic version (Major.Minor.Patch)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={nativeForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Describe this version" 
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={nativeForm.control}
                  name="framework"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Framework</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., TensorFlow, PyTorch" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={nativeForm.control}
                  name="algorithm"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Algorithm</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., Random Forest, LSTM" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={nativeForm.control}
                name="input_schema"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Input Schema (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="JSON schema of expected inputs" 
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={nativeForm.control}
                name="output_schema"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Output Schema (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="JSON schema of expected outputs" 
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <FormLabel>Metrics</FormLabel>
                <div className="flex mt-1.5 mb-2 gap-2">
                  <Input
                    placeholder="Metric name"
                    value={metricKey}
                    onChange={(e) => setMetricKey(e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    placeholder="Value"
                    value={metricValue}
                    onChange={(e) => setMetricValue(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    onClick={addMetric}
                    variant="outline"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                <div className="border rounded-md p-3">
                  {Object.keys(nativeForm.watch('metrics') || {}).length > 0 ? (
                    <div className="space-y-2">
                      {Object.entries(nativeForm.watch('metrics') || {}).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-center p-2 border rounded-md">
                          <div>
                            <span className="font-medium">{key}:</span>{' '}
                            <span>{typeof value === 'number' ? value.toString() : value}</span>
                          </div>
                          <button 
                            type="button" 
                            onClick={() => removeMetric(key)}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-2">No metrics added yet</div>
                  )}
                </div>
                <FormDescription>
                  Add performance metrics for this model version
                </FormDescription>
              </div>

              <div>
                <FormLabel>Dependencies</FormLabel>
                <div className="flex mt-1.5 mb-2 gap-2">
                  <Input
                    placeholder="Library name"
                    value={dependencyName}
                    onChange={(e) => setDependencyName(e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    placeholder="Version"
                    value={dependencyVersion}
                    onChange={(e) => setDependencyVersion(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    onClick={addDependency}
                    variant="outline"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                <div className="border rounded-md p-3">
                  {Object.keys(nativeForm.watch('dependencies') || {}).length > 0 ? (
                    <div className="space-y-2">
                      {Object.entries(nativeForm.watch('dependencies') || {}).map(([name, version]) => (
                        <div key={name} className="flex justify-between items-center p-2 border rounded-md">
                          <div>
                            <span className="font-medium">{name}</span>{' '}
                            <Badge variant="outline">{version}</Badge>
                          </div>
                          <button 
                            type="button" 
                            onClick={() => removeDependency(name)}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-2">No dependencies added yet</div>
                  )}
                </div>
                <FormDescription>
                  Add library dependencies required for this model
                </FormDescription>
              </div>

              <div className="flex justify-between pt-4">
                <Button 
                  type="button"
                  variant="outline" 
                  onClick={() => setLocation(`/model-registry/model/${modelId}`)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createNativeVersionMutation.isPending}
                >
                  {createNativeVersionMutation.isPending ? "Creating..." : "Create Version"}
                </Button>
              </div>
            </form>
          </Form>
        );

      case 'Azure':
        return (
          <Form {...azureForm}>
            <form onSubmit={azureForm.handleSubmit(onSubmitAzure)} className="space-y-6">
              <FormField
                control={azureForm.control}
                name="version"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Version</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., 1.0.0" />
                    </FormControl>
                    <FormDescription>
                      Semantic version (Major.Minor.Patch)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={azureForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Describe this Azure service" 
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={azureForm.control}
                name="service_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Azure Service Type</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Azure service" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Text Analytics">Text Analytics</SelectItem>
                        <SelectItem value="Computer Vision">Computer Vision</SelectItem>
                        <SelectItem value="Speech Service">Speech Service</SelectItem>
                        <SelectItem value="Language Understanding">Language Understanding</SelectItem>
                        <SelectItem value="Anomaly Detector">Anomaly Detector</SelectItem>
                        <SelectItem value="Form Recognizer">Form Recognizer</SelectItem>
                        <SelectItem value="Custom Vision">Custom Vision</SelectItem>
                        <SelectItem value="Face API">Face API</SelectItem>
                        <SelectItem value="OpenAI">Azure OpenAI</SelectItem>
                        <SelectItem value="Custom">Custom Service</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={azureForm.control}
                  name="endpoint"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Endpoint URL</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="https://example.cognitiveservices.azure.com" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={azureForm.control}
                  name="region"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Region (Optional)</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., eastus" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={azureForm.control}
                name="credential_reference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credential Reference (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Key Vault or credential reference" 
                      />
                    </FormControl>
                    <FormDescription>
                      Reference to stored credentials (do not enter actual API keys)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <FormLabel>Configuration Parameters</FormLabel>
                <div className="flex mt-1.5 mb-2 gap-2">
                  <Input
                    placeholder="Parameter name"
                    value={configKey}
                    onChange={(e) => setConfigKey(e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    placeholder="Value"
                    value={configValue}
                    onChange={(e) => setConfigValue(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    onClick={() => addConfigItem('azure')}
                    variant="outline"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                <div className="border rounded-md p-3">
                  {Object.keys(azureForm.watch('config') || {}).length > 0 ? (
                    <div className="space-y-2">
                      {Object.entries(azureForm.watch('config') || {}).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-center p-2 border rounded-md">
                          <div>
                            <span className="font-medium">{key}:</span>{' '}
                            <span>{typeof value === 'boolean' ? (value ? 'true' : 'false') : value.toString()}</span>
                          </div>
                          <button 
                            type="button" 
                            onClick={() => removeConfigItem(key, 'azure')}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-2">No configuration parameters added yet</div>
                  )}
                </div>
                <FormDescription>
                  Add configuration parameters for the Azure service
                </FormDescription>
              </div>

              <div className="flex justify-between pt-4">
                <Button 
                  type="button"
                  variant="outline" 
                  onClick={() => setLocation(`/model-registry/model/${modelId}`)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createAzureVersionMutation.isPending}
                >
                  {createAzureVersionMutation.isPending ? "Creating..." : "Create Version"}
                </Button>
              </div>
            </form>
          </Form>
        );

      case 'AWS':
        return (
          <Form {...awsForm}>
            <form onSubmit={awsForm.handleSubmit(onSubmitAws)} className="space-y-6">
              <FormField
                control={awsForm.control}
                name="version"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Version</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., 1.0.0" />
                    </FormControl>
                    <FormDescription>
                      Semantic version (Major.Minor.Patch)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={awsForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Describe this AWS service" 
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={awsForm.control}
                name="service_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>AWS Service Type</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select AWS service" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="SageMaker">SageMaker</SelectItem>
                        <SelectItem value="Rekognition">Rekognition</SelectItem>
                        <SelectItem value="Comprehend">Comprehend</SelectItem>
                        <SelectItem value="Textract">Textract</SelectItem>
                        <SelectItem value="Translate">Translate</SelectItem>
                        <SelectItem value="Polly">Polly</SelectItem>
                        <SelectItem value="Lex">Lex</SelectItem>
                        <SelectItem value="Forecast">Forecast</SelectItem>
                        <SelectItem value="Personalize">Personalize</SelectItem>
                        <SelectItem value="Custom">Custom Service</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={awsForm.control}
                name="region"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>AWS Region</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select AWS region" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="us-east-1">US East (N. Virginia)</SelectItem>
                        <SelectItem value="us-east-2">US East (Ohio)</SelectItem>
                        <SelectItem value="us-west-1">US West (N. California)</SelectItem>
                        <SelectItem value="us-west-2">US West (Oregon)</SelectItem>
                        <SelectItem value="eu-west-1">EU (Ireland)</SelectItem>
                        <SelectItem value="eu-central-1">EU (Frankfurt)</SelectItem>
                        <SelectItem value="ap-northeast-1">Asia Pacific (Tokyo)</SelectItem>
                        <SelectItem value="ap-northeast-2">Asia Pacific (Seoul)</SelectItem>
                        <SelectItem value="ap-southeast-1">Asia Pacific (Singapore)</SelectItem>
                        <SelectItem value="ap-southeast-2">Asia Pacific (Sydney)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={awsForm.control}
                name="credential_reference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credential Reference (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Secrets Manager or credential reference" 
                      />
                    </FormControl>
                    <FormDescription>
                      Reference to stored credentials (do not enter actual API keys)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <FormLabel>Configuration Parameters</FormLabel>
                <div className="flex mt-1.5 mb-2 gap-2">
                  <Input
                    placeholder="Parameter name"
                    value={configKey}
                    onChange={(e) => setConfigKey(e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    placeholder="Value"
                    value={configValue}
                    onChange={(e) => setConfigValue(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    onClick={() => addConfigItem('aws')}
                    variant="outline"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                <div className="border rounded-md p-3">
                  {Object.keys(awsForm.watch('config') || {}).length > 0 ? (
                    <div className="space-y-2">
                      {Object.entries(awsForm.watch('config') || {}).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-center p-2 border rounded-md">
                          <div>
                            <span className="font-medium">{key}:</span>{' '}
                            <span>{typeof value === 'boolean' ? (value ? 'true' : 'false') : value.toString()}</span>
                          </div>
                          <button 
                            type="button" 
                            onClick={() => removeConfigItem(key, 'aws')}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-2">No configuration parameters added yet</div>
                  )}
                </div>
                <FormDescription>
                  Add configuration parameters for the AWS service
                </FormDescription>
              </div>

              <div className="flex justify-between pt-4">
                <Button 
                  type="button"
                  variant="outline" 
                  onClick={() => setLocation(`/model-registry/model/${modelId}`)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createAwsVersionMutation.isPending}
                >
                  {createAwsVersionMutation.isPending ? "Creating..." : "Create Version"}
                </Button>
              </div>
            </form>
          </Form>
        );

      case 'MLflow':
        return (
          <Form {...mlflowForm}>
            <form onSubmit={mlflowForm.handleSubmit(onSubmitMlflow)} className="space-y-6">
              <FormField
                control={mlflowForm.control}
                name="version"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Version</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., 1.0.0" />
                    </FormControl>
                    <FormDescription>
                      Semantic version (Major.Minor.Patch)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={mlflowForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        placeholder="Describe this MLflow model" 
                        rows={3}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={mlflowForm.control}
                name="mlflow_tracking_uri"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>MLflow Tracking URI</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="e.g., http://localhost:5000"
                      />
                    </FormControl>
                    <FormDescription>
                      URI of the MLflow tracking server
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={mlflowForm.control}
                  name="mlflow_model_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>MLflow Model Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., credit_scoring_model" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={mlflowForm.control}
                  name="mlflow_model_version"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>MLflow Model Version</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., 1 or production" />
                      </FormControl>
                      <FormDescription>
                        Version or stage in MLflow
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div>
                <FormLabel>Additional Configuration</FormLabel>
                <div className="flex mt-1.5 mb-2 gap-2">
                  <Input
                    placeholder="Parameter name"
                    value={configKey}
                    onChange={(e) => setConfigKey(e.target.value)}
                    className="flex-1"
                  />
                  <Input
                    placeholder="Value"
                    value={configValue}
                    onChange={(e) => setConfigValue(e.target.value)}
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    onClick={() => addConfigItem('mlflow')}
                    variant="outline"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
                <div className="border rounded-md p-3">
                  {Object.keys(mlflowForm.watch('config') || {}).length > 0 ? (
                    <div className="space-y-2">
                      {Object.entries(mlflowForm.watch('config') || {}).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-center p-2 border rounded-md">
                          <div>
                            <span className="font-medium">{key}:</span>{' '}
                            <span>{typeof value === 'boolean' ? (value ? 'true' : 'false') : value.toString()}</span>
                          </div>
                          <button 
                            type="button" 
                            onClick={() => removeConfigItem(key, 'mlflow')}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-2">No configuration parameters added yet</div>
                  )}
                </div>
                <FormDescription>
                  Add additional configuration parameters for MLflow
                </FormDescription>
              </div>

              <div className="flex justify-between pt-4">
                <Button 
                  type="button"
                  variant="outline" 
                  onClick={() => setLocation(`/model-registry/model/${modelId}`)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createMlflowVersionMutation.isPending}
                >
                  {createMlflowVersionMutation.isPending ? "Creating..." : "Create Version"}
                </Button>
              </div>
            </form>
          </Form>
        );

      default:
        return (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Unsupported Model Type</AlertTitle>
            <AlertDescription>
              The model type "{model.type}" is not supported for version creation.
            </AlertDescription>
          </Alert>
        );
    }
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex flex-col space-y-8 max-w-3xl mx-auto">
        <div className="flex items-center">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setLocation(`/model-registry/model/${modelId}`)}
            className="mr-4"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Create New Version</h1>
            <p className="text-gray-500">
              {model?.name} - {model?.type} Model
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Version Information</CardTitle>
            <CardDescription>
              Add details for this new version
            </CardDescription>
          </CardHeader>
          <CardContent>
            {renderForm()}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CreateVersion;