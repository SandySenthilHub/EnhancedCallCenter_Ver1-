import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Search, 
  PlusCircle, 
  FileSymlink
} from 'lucide-react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { MODEL_TYPES } from '@shared/model-registry-schema';

// Simplified Model interface
interface Model {
  id: number;
  name: string;
  description: string;
  type: string;
  created_at: string;
  updated_at: string;
  is_active: boolean;
}

// Main Model Registry component - simplified for stability
const ModelRegistry: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Fetch models only - we'll add dashboard stats later when this is stable
  const { 
    data: models,
    isLoading: isLoadingModels,
    error: modelsError,
    refetch
  } = useQuery<Model[]>({ 
    queryKey: ['/api/model-registry/models'],
  });

  // Error handling
  useEffect(() => {
    if (modelsError) {
      console.error("Model Registry Error:", modelsError);
      toast({
        title: "Error",
        description: "Failed to load models. Please try again later.",
        variant: "destructive",
      });
    }
  }, [modelsError, toast]);

  // Filtered models based on search and type filter
  const filteredModels = models?.filter(model => {
    if (!model) return false;
    
    const matchesSearch = searchQuery === '' || 
      (model.name && model.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (model.description && model.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = typeFilter === 'all' || model.type === typeFilter;
    
    return matchesSearch && matchesType;
  }) || [];

  return (
    <div className="container mx-auto py-8">
      <div className="flex flex-col space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Model Registry</h1>
            <p className="text-gray-500 mt-2">
              Centralized repository for managing and versioning all machine learning models
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => setLocation('/model-registry/new-model')}
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Register Model
            </Button>
            <Button
              variant="default"
              onClick={() => setLocation('/model-registry/import')}
            >
              <FileSymlink className="mr-2 h-4 w-4" />
              Import External Service
            </Button>
          </div>
        </div>

        {/* Simple list view of models */}
        <Card>
          <CardHeader>
            <CardTitle>Registered Models</CardTitle>
            <CardDescription>Browse and manage your machine learning models</CardDescription>
            
            <div className="flex justify-between items-center mt-4">
              <div className="relative w-full max-w-sm">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  placeholder="Search models..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex gap-2 items-center">
                <span className="text-sm text-gray-500">Filter by type:</span>
                <Select
                  value={typeFilter}
                  onValueChange={setTypeFilter}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    {MODEL_TYPES.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            {isLoadingModels ? (
              <div className="flex justify-center items-center h-64">
                <p>Loading models...</p>
              </div>
            ) : filteredModels.length > 0 ? (
              <div className="space-y-4">
                {filteredModels.map((model) => (
                  <div 
                    key={model.id} 
                    className="border rounded-lg p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => setLocation(`/model-registry/model/${model.id}`)}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-lg">{model.name}</h3>
                        <p className="text-gray-500 mt-1">{model.description}</p>
                      </div>
                      <Badge variant="outline">{model.type}</Badge>
                    </div>
                    <div className="flex justify-between items-center mt-4 text-sm text-gray-500">
                      <div>
                        Last updated: {new Date(model.updated_at).toLocaleString()}
                      </div>
                      <Badge variant={model.is_active ? "default" : "secondary"}>
                        {model.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium">No models found</h3>
                {searchQuery || typeFilter !== 'all' ? (
                  <p className="text-gray-500 mt-2">
                    Try adjusting your search or filter criteria
                  </p>
                ) : (
                  <p className="text-gray-500 mt-2">
                    Get started by registering a new model or importing from an external service
                  </p>
                )}
                
                <div className="flex justify-center gap-4 mt-6">
                  {(searchQuery || typeFilter !== 'all') && (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSearchQuery('');
                        setTypeFilter('all');
                      }}
                    >
                      Clear Filters
                    </Button>
                  )}
                  
                  <Button
                    onClick={() => setLocation('/model-registry/new-model')}
                  >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Register Model
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        
        {models && models.length > 0 && (
          <div className="flex justify-center">
            <Button onClick={() => refetch()} variant="outline">
              Refresh Models
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ModelRegistry;