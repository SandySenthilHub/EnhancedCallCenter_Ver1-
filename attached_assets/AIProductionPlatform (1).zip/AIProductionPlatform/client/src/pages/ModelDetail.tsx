import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ArrowLeft, 
  MoreHorizontal, 
  PlusCircle, 
  Clock,
  CheckCircle,
  Archive,
  AlertCircle,
  CloudLightning,
  Server,
  Database,
  BarChart4,
  FileText,
  Code,
  FileJson,
  Package,
  Calendar,
  User,
  Tag,
  GitBranch
} from 'lucide-react';
import { Link, useLocation, useParams } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';

// Types
type ModelType = 'Native' | 'Azure' | 'AWS' | 'MLflow';
type ModelStage = 'Development' | 'Staging' | 'Production' | 'Archived' | 'Rejected';

interface Model {
  id: number;
  name: string;
  description: string;
  type: ModelType;
  created_by: number;
  team_id: number | null;
  created_at: string;
  updated_at: string;
  is_active: boolean;
  tags: string[] | null;
}

interface ModelVersion {
  id: number;
  model_id: number;
  version: string;
  description: string;
  stage: ModelStage;
  created_by: number;
  created_at: string;
  updated_at: string;
  metrics: Record<string, any> | null;
  framework: string | null;
  algorithm: string | null;
  input_schema: string | null;
  output_schema: string | null;
  training_dataset_id: number | null;
  dependencies: Record<string, string> | null;
}

interface ModelArtifact {
  id: number;
  version_id: number;
  name: string;
  type: string;
  path: string;
  size: number;
  hash: string;
  created_at: string;
  metadata: Record<string, any> | null;
}

interface StageTransition {
  id: number;
  version_id: number;
  from_stage: ModelStage;
  to_stage: ModelStage;
  requester_id: number;
  approver_id: number | null;
  requested_at: string;
  approved_at: string | null;
  status: 'Pending' | 'Approved' | 'Rejected';
  comments: string | null;
}

interface ModelEvent {
  id: number;
  model_id: number | null;
  version_id: number | null;
  user_id: number;
  event_type: string;
  event_details: Record<string, any>;
  timestamp: string;
}

interface ExternalServiceConfig {
  id: number;
  version_id: number;
  service_type: string;
  config: Record<string, any>;
  credential_reference: string | null;
  region: string | null;
  endpoint: string | null;
}

// Badge components for model types and stages
const ModelTypeBadge: React.FC<{ type: ModelType }> = ({ type }) => {
  const variants: Record<ModelType, { color: string, icon: React.ReactNode }> = {
    'Native': { 
      color: 'bg-green-100 text-green-800 hover:bg-green-200', 
      icon: <Database className="h-3 w-3 mr-1" />
    },
    'Azure': { 
      color: 'bg-blue-100 text-blue-800 hover:bg-blue-200', 
      icon: <CloudLightning className="h-3 w-3 mr-1" />
    },
    'AWS': { 
      color: 'bg-orange-100 text-orange-800 hover:bg-orange-200', 
      icon: <Server className="h-3 w-3 mr-1" />
    },
    'MLflow': { 
      color: 'bg-purple-100 text-purple-800 hover:bg-purple-200', 
      icon: <BarChart4 className="h-3 w-3 mr-1" />
    },
  };

  return (
    <Badge className={`flex items-center ${variants[type].color}`} variant="outline">
      {variants[type].icon}
      {type}
    </Badge>
  );
};

const ModelStageBadge: React.FC<{ stage: ModelStage }> = ({ stage }) => {
  const variants: Record<ModelStage, { color: string, icon: React.ReactNode }> = {
    'Development': { 
      color: 'bg-blue-100 text-blue-800 hover:bg-blue-200', 
      icon: <Clock className="h-3 w-3 mr-1" />
    },
    'Staging': { 
      color: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200', 
      icon: <AlertCircle className="h-3 w-3 mr-1" />
    },
    'Production': { 
      color: 'bg-green-100 text-green-800 hover:bg-green-200', 
      icon: <CheckCircle className="h-3 w-3 mr-1" />
    },
    'Archived': { 
      color: 'bg-gray-100 text-gray-800 hover:bg-gray-200', 
      icon: <Archive className="h-3 w-3 mr-1" />
    },
    'Rejected': { 
      color: 'bg-red-100 text-red-800 hover:bg-red-200', 
      icon: <AlertCircle className="h-3 w-3 mr-1" />
    },
  };

  return (
    <Badge className={`flex items-center ${variants[stage].color}`} variant="outline">
      {variants[stage].icon}
      {stage}
    </Badge>
  );
};

// Artifact type badge component
const ArtifactTypeBadge: React.FC<{ type: string }> = ({ type }) => {
  const getIcon = () => {
    switch(type.toLowerCase()) {
      case 'model':
        return <Package className="h-3 w-3 mr-1" />;
      case 'code':
      case 'script':
        return <Code className="h-3 w-3 mr-1" />;
      case 'documentation':
        return <FileText className="h-3 w-3 mr-1" />;
      case 'schema':
      case 'config':
        return <FileJson className="h-3 w-3 mr-1" />;
      default:
        return <FileText className="h-3 w-3 mr-1" />;
    }
  };

  return (
    <Badge className="flex items-center bg-gray-100 text-gray-800 hover:bg-gray-200" variant="outline">
      {getIcon()}
      {type}
    </Badge>
  );
};

// Format size in bytes to human readable format
const formatBytes = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// Format date for display
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
};

// StageTransitionDialog component
const StageTransitionDialog: React.FC<{
  versionId: number,
  currentStage: ModelStage,
  onSuccess: () => void
}> = ({ versionId, currentStage, onSuccess }) => {
  const [open, setOpen] = useState(false);
  const [targetStage, setTargetStage] = useState<ModelStage | ''>('');
  const [comments, setComments] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!targetStage) {
      toast({
        title: "Error",
        description: "Please select a target stage",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await apiRequest(
        'POST',
        `/api/model-registry/versions/${versionId}/stage-transitions`,
        { to_stage: targetStage, comments }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to request stage transition');
      }

      toast({
        title: "Success",
        description: `Stage transition request to ${targetStage} submitted successfully`,
      });
      setOpen(false);
      onSuccess();
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to request stage transition",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter out current stage from options
  const stageOptions = ['Development', 'Staging', 'Production', 'Archived', 'Rejected'].filter(
    stage => stage !== currentStage
  ) as ModelStage[];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Change Stage</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Request Stage Transition</DialogTitle>
          <DialogDescription>
            Request to move this model version to a different stage in the lifecycle.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <label htmlFor="stage" className="text-sm font-medium">
              Current Stage
            </label>
            <div className="flex items-center h-10 px-3 rounded-md border border-gray-300">
              <ModelStageBadge stage={currentStage} />
            </div>
          </div>
          <div className="grid gap-2">
            <label htmlFor="target-stage" className="text-sm font-medium">
              Target Stage
            </label>
            <Select value={targetStage} onValueChange={(value) => setTargetStage(value as ModelStage)}>
              <SelectTrigger>
                <SelectValue placeholder="Select target stage" />
              </SelectTrigger>
              <SelectContent>
                {stageOptions.map((stage) => (
                  <SelectItem key={stage} value={stage}>
                    <div className="flex items-center">
                      <ModelStageBadge stage={stage} />
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2">
            <label htmlFor="comments" className="text-sm font-medium">
              Comments
            </label>
            <Textarea
              id="comments"
              placeholder="Add comments or justification for this stage transition"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              rows={4}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting || !targetStage}>
            {isSubmitting ? "Submitting..." : "Request Transition"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Main ModelDetail component
const ModelDetail: React.FC = () => {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const modelId = parseInt(params.id);

  // Fetch model
  const { 
    data: model,
    isLoading: isLoadingModel,
    error: modelError
  } = useQuery<Model>({ 
    queryKey: [`/api/model-registry/models/${modelId}`],
  });

  // Fetch model versions
  const { 
    data: versions,
    isLoading: isLoadingVersions,
    error: versionsError,
    refetch: refetchVersions
  } = useQuery<ModelVersion[]>({ 
    queryKey: [`/api/model-registry/models/${modelId}/versions`],
  });

  // Error handling
  if (modelError || versionsError) {
    toast({
      title: "Error",
      description: "Failed to load model details. Please try again.",
      variant: "destructive",
    });
  }

  // Get the production version if any
  const productionVersion = versions?.find(v => v.stage === 'Production');
  
  // Get the latest version
  const latestVersion = versions?.length ? 
    versions.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0] 
    : null;

  // Selected version for the details tab
  const [selectedVersionId, setSelectedVersionId] = useState<number | null>(null);
  
  // Get the selected version or default to latest
  const selectedVersion = selectedVersionId 
    ? versions?.find(v => v.id === selectedVersionId) 
    : latestVersion;

  // Fetch artifacts for selected version
  const { 
    data: artifacts,
    isLoading: isLoadingArtifacts
  } = useQuery<ModelArtifact[]>({ 
    queryKey: [`/api/model-registry/versions/${selectedVersion?.id}/artifacts`],
    enabled: !!selectedVersion,
  });

  // Fetch external service config for selected version
  const { 
    data: externalConfig,
    isLoading: isLoadingExternalConfig
  } = useQuery<ExternalServiceConfig>({ 
    queryKey: [`/api/model-registry/versions/${selectedVersion?.id}/external-config`],
    enabled: !!selectedVersion && model?.type !== 'Native',
  });

  // Fetch stage transitions for selected version
  const { 
    data: stageTransitions,
    isLoading: isLoadingStageTransitions
  } = useQuery<StageTransition[]>({ 
    queryKey: [`/api/model-registry/versions/${selectedVersion?.id}/stage-transitions`],
    enabled: !!selectedVersion,
  });

  // Fetch model events
  const { 
    data: events,
    isLoading: isLoadingEvents
  } = useQuery<ModelEvent[]>({ 
    queryKey: [`/api/model-registry/events?modelId=${modelId}`],
  });

  // Get formatted metrics
  const getMetricsDisplay = (metrics: Record<string, any> | null) => {
    if (!metrics) return <span className="text-gray-400">No metrics</span>;
    
    return (
      <div className="space-y-1">
        {Object.entries(metrics).map(([key, value]) => (
          <div key={key} className="flex justify-between">
            <span className="text-sm font-medium">{key}:</span>
            <span className="text-sm">
              {typeof value === 'number' ? value.toFixed(4) : String(value)}
            </span>
          </div>
        ))}
      </div>
    );
  };

  // Handle version selection
  const handleVersionSelect = (versionId: number) => {
    setSelectedVersionId(versionId);
  };

  // Delete model handler
  const handleDeleteModel = async () => {
    try {
      const response = await apiRequest(
        'DELETE',
        `/api/model-registry/models/${modelId}`,
        null
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete model');
      }

      // Invalidate models cache
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/models'] });
      queryClient.invalidateQueries({ queryKey: ['/api/model-registry/dashboard'] });
      
      toast({
        title: "Success",
        description: "Model deleted successfully",
      });
      
      // Redirect to models list
      setLocation('/model-registry');
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete model",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex flex-col space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setLocation('/model-registry')}
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to Registry
            </Button>
            {!isLoadingModel && model && (
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-bold">{model.name}</h1>
                <ModelTypeBadge type={model.type} />
              </div>
            )}
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant="outline"
              onClick={() => setLocation(`/model-registry/model/${modelId}/new-version`)}
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Version
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">Delete Model</Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action will mark the model as inactive. It can't be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDeleteModel}>Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        {isLoadingModel ? (
          <div className="flex justify-center items-center h-64">
            <p>Loading model...</p>
          </div>
        ) : model ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Model information card */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Model Information</CardTitle>
                <CardDescription>General information and metadata about this model</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Description</h3>
                  <p className="mt-1">{model.description}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Created Date</h3>
                    <p className="mt-1">{formatDate(model.created_at)}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Last Updated</h3>
                    <p className="mt-1">{formatDate(model.updated_at)}</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Tags</h3>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {model.tags && model.tags.length > 0 ? (
                      model.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary">
                          {tag}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-gray-400">No tags</span>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Version summary card */}
            <Card>
              <CardHeader>
                <CardTitle>Version Summary</CardTitle>
                <CardDescription>Latest and production versions</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Latest Version</h3>
                  {latestVersion ? (
                    <div className="mt-1 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{latestVersion.version}</span>
                        <ModelStageBadge stage={latestVersion.stage} />
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleVersionSelect(latestVersion.id)}
                      >
                        View
                      </Button>
                    </div>
                  ) : (
                    <p className="mt-1 text-gray-400">No versions available</p>
                  )}
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Production Version</h3>
                  {productionVersion ? (
                    <div className="mt-1 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{productionVersion.version}</span>
                        <ModelStageBadge stage="Production" />
                      </div>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleVersionSelect(productionVersion.id)}
                      >
                        View
                      </Button>
                    </div>
                  ) : (
                    <p className="mt-1 text-gray-400">No production version</p>
                  )}
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Total Versions</h3>
                  <p className="mt-1 font-medium">{versions?.length || 0}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : null}

        <Tabs defaultValue="versions" className="w-full">
          <TabsList className="grid w-[600px] grid-cols-3">
            <TabsTrigger value="versions">Versions</TabsTrigger>
            <TabsTrigger value="details">Version Details</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="versions" className="mt-6">
            {isLoadingVersions ? (
              <div className="flex justify-center items-center h-64">
                <p>Loading versions...</p>
              </div>
            ) : versions && versions.length > 0 ? (
              <div className="bg-white rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Version</TableHead>
                      <TableHead>Stage</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Framework</TableHead>
                      {model?.type !== 'Native' && <TableHead>Service Type</TableHead>}
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {versions.map((version) => (
                      <TableRow key={version.id}>
                        <TableCell>
                          <div className="font-medium">{version.version}</div>
                          <div className="text-sm text-gray-500 truncate max-w-md">
                            {version.description.substring(0, 60)}
                            {version.description.length > 60 ? '...' : ''}
                          </div>
                        </TableCell>
                        <TableCell>
                          <ModelStageBadge stage={version.stage} />
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{formatDate(version.created_at)}</div>
                        </TableCell>
                        <TableCell>
                          {version.framework ? (
                            <span>{version.framework}</span>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        {model?.type !== 'Native' && (
                          <TableCell>
                            <span>{model?.type}</span>
                          </TableCell>
                        )}
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleVersionSelect(version.id)}
                            >
                              Details
                            </Button>
                            <StageTransitionDialog 
                              versionId={version.id}
                              currentStage={version.stage}
                              onSuccess={refetchVersions}
                            />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>No Versions Available</CardTitle>
                  <CardDescription>
                    This model doesn't have any versions yet.
                  </CardDescription>
                </CardHeader>
                <CardFooter>
                  <Button 
                    onClick={() => setLocation(`/model-registry/model/${modelId}/new-version`)}
                  >
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Add First Version
                  </Button>
                </CardFooter>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="details" className="mt-6">
            {!selectedVersion ? (
              <Card>
                <CardHeader>
                  <CardTitle>No Version Selected</CardTitle>
                  <CardDescription>
                    Please select a version from the Versions tab to view details.
                  </CardDescription>
                </CardHeader>
              </Card>
            ) : (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          Version {selectedVersion.version}
                          <ModelStageBadge stage={selectedVersion.stage} />
                        </CardTitle>
                        <CardDescription>
                          Created on {formatDate(selectedVersion.created_at)}
                        </CardDescription>
                      </div>
                      <StageTransitionDialog 
                        versionId={selectedVersion.id}
                        currentStage={selectedVersion.stage}
                        onSuccess={refetchVersions}
                      />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-500">Description</h3>
                      <p className="mt-1">{selectedVersion.description}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      {selectedVersion.framework && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Framework</h3>
                          <p className="mt-1">{selectedVersion.framework}</p>
                        </div>
                      )}
                      
                      {selectedVersion.algorithm && (
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">Algorithm</h3>
                          <p className="mt-1">{selectedVersion.algorithm}</p>
                        </div>
                      )}
                    </div>
                    
                    {model?.type !== 'Native' && externalConfig && (
                      <div className="border rounded-md p-4">
                        <h3 className="text-sm font-medium text-gray-500 mb-2">External Service Configuration</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-xs font-medium text-gray-500">Service Type</h4>
                            <p className="mt-1">{externalConfig.service_type}</p>
                          </div>
                          
                          {externalConfig.endpoint && (
                            <div>
                              <h4 className="text-xs font-medium text-gray-500">Endpoint</h4>
                              <p className="mt-1 truncate">{externalConfig.endpoint}</p>
                            </div>
                          )}
                          
                          {externalConfig.region && (
                            <div>
                              <h4 className="text-xs font-medium text-gray-500">Region</h4>
                              <p className="mt-1">{externalConfig.region}</p>
                            </div>
                          )}
                        </div>
                        
                        <div className="mt-2">
                          <h4 className="text-xs font-medium text-gray-500">Configuration</h4>
                          <pre className="mt-1 text-xs bg-gray-50 p-2 rounded overflow-auto max-h-32">
                            {JSON.stringify(externalConfig.config, null, 2)}
                          </pre>
                        </div>
                      </div>
                    )}
                    
                    {selectedVersion.metrics && Object.keys(selectedVersion.metrics).length > 0 && (
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Metrics</h3>
                        <div className="mt-1 border rounded-md p-3">
                          {getMetricsDisplay(selectedVersion.metrics)}
                        </div>
                      </div>
                    )}
                    
                    {selectedVersion.dependencies && Object.keys(selectedVersion.dependencies).length > 0 && (
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Dependencies</h3>
                        <div className="mt-1 grid grid-cols-2 gap-2">
                          {Object.entries(selectedVersion.dependencies).map(([name, version]) => (
                            <div key={name} className="flex justify-between items-center p-2 border rounded-md">
                              <span className="font-medium text-sm">{name}</span>
                              <Badge variant="outline">{version}</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {model?.type === 'Native' && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Artifacts</CardTitle>
                      <CardDescription>Files and resources associated with this version</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {isLoadingArtifacts ? (
                        <div className="flex justify-center items-center h-20">
                          <p>Loading artifacts...</p>
                        </div>
                      ) : artifacts && artifacts.length > 0 ? (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Name</TableHead>
                              <TableHead>Type</TableHead>
                              <TableHead>Size</TableHead>
                              <TableHead>Created</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {artifacts.map((artifact) => (
                              <TableRow key={artifact.id}>
                                <TableCell>
                                  <div className="font-medium">{artifact.name}</div>
                                </TableCell>
                                <TableCell>
                                  <ArtifactTypeBadge type={artifact.type} />
                                </TableCell>
                                <TableCell>
                                  {formatBytes(artifact.size)}
                                </TableCell>
                                <TableCell>
                                  {formatDate(artifact.created_at)}
                                </TableCell>
                                <TableCell>
                                  <Button variant="ghost" size="sm">
                                    Download
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      ) : (
                        <div className="text-center py-4">
                          <p>No artifacts available for this version</p>
                          <Button className="mt-2" variant="outline" size="sm">
                            <PlusCircle className="mr-2 h-4 w-4" />
                            Upload Artifact
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
                
                <Card>
                  <CardHeader>
                    <CardTitle>Stage Transitions</CardTitle>
                    <CardDescription>
                      History of stage changes for this version
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {isLoadingStageTransitions ? (
                      <div className="flex justify-center items-center h-20">
                        <p>Loading transitions...</p>
                      </div>
                    ) : stageTransitions && stageTransitions.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>From</TableHead>
                            <TableHead>To</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Requested</TableHead>
                            <TableHead>Approved/Rejected</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {stageTransitions.map((transition) => (
                            <TableRow key={transition.id}>
                              <TableCell>
                                <ModelStageBadge stage={transition.from_stage} />
                              </TableCell>
                              <TableCell>
                                <ModelStageBadge stage={transition.to_stage} />
                              </TableCell>
                              <TableCell>
                                <Badge 
                                  variant={
                                    transition.status === 'Approved' ? 'success' : 
                                    transition.status === 'Rejected' ? 'destructive' : 
                                    'secondary'
                                  }
                                >
                                  {transition.status}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {formatDate(transition.requested_at)}
                              </TableCell>
                              <TableCell>
                                {transition.approved_at ? 
                                  formatDate(transition.approved_at) : 
                                  <span className="text-gray-400">-</span>
                                }
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-4">
                        <p>No stage transitions yet</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="history" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Activity History</CardTitle>
                <CardDescription>
                  Timeline of all events related to this model
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingEvents ? (
                  <div className="flex justify-center items-center h-64">
                    <p>Loading history...</p>
                  </div>
                ) : events && events.length > 0 ? (
                  <div className="relative">
                    <div className="absolute left-[19px] top-0 bottom-0 w-0.5 bg-gray-200"></div>
                    <div className="space-y-6">
                      {events.map((event) => (
                        <div key={event.id} className="relative pl-10">
                          <div className="absolute left-0 top-1 w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center">
                            {event.event_type.includes('Create') || event.event_type.includes('Added') ? (
                              <PlusCircle className="h-5 w-5 text-green-500" />
                            ) : event.event_type.includes('Update') ? (
                              <GitBranch className="h-5 w-5 text-blue-500" />
                            ) : event.event_type.includes('Delete') ? (
                              <AlertCircle className="h-5 w-5 text-red-500" />
                            ) : event.event_type.includes('Stage') ? (
                              <CheckCircle className="h-5 w-5 text-purple-500" />
                            ) : event.event_type.includes('Role') ? (
                              <User className="h-5 w-5 text-orange-500" />
                            ) : (
                              <Calendar className="h-5 w-5 text-gray-500" />
                            )}
                          </div>
                          <div className="bg-white p-3 rounded-md border">
                            <div className="flex justify-between items-start">
                              <div className="font-medium">{event.event_type}</div>
                              <div className="text-xs text-gray-500">{formatDate(event.timestamp)}</div>
                            </div>
                            <div className="mt-2 text-sm">
                              {event.version_id && (
                                <div className="text-gray-500">
                                  Version: {versions?.find(v => v.id === event.version_id)?.version || event.version_id}
                                </div>
                              )}
                              <pre className="mt-1 text-xs bg-gray-50 p-2 rounded overflow-auto max-h-24">
                                {JSON.stringify(event.event_details, null, 2)}
                              </pre>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p>No activity recorded yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ModelDetail;