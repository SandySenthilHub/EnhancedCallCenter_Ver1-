import React from 'react';
import { Helmet } from 'react-helmet';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import FeatureSelectionWizard from '@/components/feature-engineering/FeatureSelectionWizard';

const FeatureSelectionPage: React.FC = () => {
  const { toast } = useToast();

  const handleFeatureSelectionComplete = (selectedFeatures: string[]) => {
    toast({
      title: "Feature Selection Complete",
      description: `You've selected ${selectedFeatures.length} features for your model.`,
    });
    
    // In a real application, you might store these features in a global state or redirect to the next step
    console.log('Selected features:', selectedFeatures);
  };

  return (
    <>
      <Helmet>
        <title>Feature Selection | AI/ML Playbook</title>
        <meta 
          name="description" 
          content="Interactive feature selection wizard for machine learning models"
        />
      </Helmet>

      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Feature Selection</h1>
          <p className="text-muted-foreground mt-2">
            Use our interactive wizard to visualize, analyze, and select the best features for your ML model
          </p>
        </div>
        
        <Separator className="my-6" />
        
        <FeatureSelectionWizard onComplete={handleFeatureSelectionComplete} />
      </div>
    </>
  );
};

export default FeatureSelectionPage;