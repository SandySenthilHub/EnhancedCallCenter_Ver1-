import React, { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, Server, Database, CloudCog, Gauge } from "lucide-react";
import MainLayout from "@/components/layout/MainLayout";

const ModelTraining = () => {
  const { toast } = useToast();
  const [platform, setPlatform] = useState<string>("azure");
  const [modelType, setModelType] = useState<string>("classification");
  const [algorithm, setAlgorithm] = useState<string>("logistic_regression");
  const [modelName, setModelName] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [datasetId, setDatasetId] = useState<string>("");
  const [targetColumn, setTargetColumn] = useState<string>("");
  const [saveToRegistry, setSaveToRegistry] = useState<boolean>(true);
  const [hyperparameters, setHyperparameters] = useState<{ [key: string]: string }>({
    C: "1.0",
    max_iter: "100"
  });

  const classificationAlgorithms = [
    { value: "logistic_regression", label: "Logistic Regression" },
    { value: "random_forest", label: "Random Forest" },
    { value: "gradient_boosting", label: "Gradient Boosting" },
    { value: "svm", label: "Support Vector Machine" },
    { value: "decision_tree", label: "Decision Tree" }
  ];

  const regressionAlgorithms = [
    { value: "linear_regression", label: "Linear Regression" },
    { value: "random_forest_regressor", label: "Random Forest Regressor" },
    { value: "gradient_boosting_regressor", label: "Gradient Boosting Regressor" },
    { value: "svr", label: "Support Vector Regression" },
    { value: "decision_tree_regressor", label: "Decision Tree Regressor" }
  ];

  const handleHyperparameterChange = (key: string, value: string) => {
    setHyperparameters({
      ...hyperparameters,
      [key]: value
    });
  };

  const getHyperparameterFields = () => {
    switch (algorithm) {
      case "logistic_regression":
      case "linear_regression":
        return (
          <>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="C">Regularization Strength (C)</Label>
              <Input
                id="C"
                value={hyperparameters.C || "1.0"}
                onChange={(e) => handleHyperparameterChange("C", e.target.value)}
              />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="max_iter">Max Iterations</Label>
              <Input
                id="max_iter"
                value={hyperparameters.max_iter || "100"}
                onChange={(e) => handleHyperparameterChange("max_iter", e.target.value)}
              />
            </div>
          </>
        );
      case "random_forest":
      case "random_forest_regressor":
        return (
          <>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="n_estimators">Number of Estimators</Label>
              <Input
                id="n_estimators"
                value={hyperparameters.n_estimators || "100"}
                onChange={(e) => handleHyperparameterChange("n_estimators", e.target.value)}
              />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="max_depth">Max Depth</Label>
              <Input
                id="max_depth"
                value={hyperparameters.max_depth || "None"}
                onChange={(e) => handleHyperparameterChange("max_depth", e.target.value)}
              />
            </div>
          </>
        );
      case "gradient_boosting":
      case "gradient_boosting_regressor":
        return (
          <>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="n_estimators">Number of Estimators</Label>
              <Input
                id="n_estimators"
                value={hyperparameters.n_estimators || "100"}
                onChange={(e) => handleHyperparameterChange("n_estimators", e.target.value)}
              />
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="learning_rate">Learning Rate</Label>
              <Input
                id="learning_rate"
                value={hyperparameters.learning_rate || "0.1"}
                onChange={(e) => handleHyperparameterChange("learning_rate", e.target.value)}
              />
            </div>
          </>
        );
      case "svm":
      case "svr":
        return (
          <>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="kernel">Kernel</Label>
              <Select 
                value={hyperparameters.kernel || "rbf"} 
                onValueChange={(value) => handleHyperparameterChange("kernel", value)}
              >
                <SelectTrigger id="kernel">
                  <SelectValue placeholder="Select Kernel" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="linear">Linear</SelectItem>
                  <SelectItem value="poly">Polynomial</SelectItem>
                  <SelectItem value="rbf">Radial Basis Function</SelectItem>
                  <SelectItem value="sigmoid">Sigmoid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid w-full items-center gap-1.5">
              <Label htmlFor="C">Regularization Strength (C)</Label>
              <Input
                id="C"
                value={hyperparameters.C || "1.0"}
                onChange={(e) => handleHyperparameterChange("C", e.target.value)}
              />
            </div>
          </>
        );
      default:
        return null;
    }
  };

  const trainModelMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/model-training/train", data);
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Model Training Initiated",
        description: `Training job started for ${modelName}. Job ID: ${data.jobId}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Training Failed",
        description: error.message || "Failed to start model training",
        variant: "destructive",
      });
    },
  });

  const handleTrainModel = () => {
    if (!modelName) {
      toast({
        title: "Validation Error",
        description: "Please provide a model name",
        variant: "destructive",
      });
      return;
    }

    if (!datasetId) {
      toast({
        title: "Validation Error",
        description: "Please select a dataset",
        variant: "destructive",
      });
      return;
    }

    if (!targetColumn) {
      toast({
        title: "Validation Error",
        description: "Please provide a target column",
        variant: "destructive",
      });
      return;
    }

    const trainingData = {
      modelName,
      description,
      platform,
      modelType,
      algorithm,
      datasetId,
      targetColumn,
      hyperparameters,
      saveToRegistry
    };

    trainModelMutation.mutate(trainingData);
  };

  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-6">Model Training</h1>
        
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="basic">Basic Configuration</TabsTrigger>
            <TabsTrigger value="advanced">Advanced Options</TabsTrigger>
            <TabsTrigger value="platform">Platform Settings</TabsTrigger>
          </TabsList>
          
          <TabsContent value="basic">
            <Card>
              <CardHeader>
                <CardTitle>Model Configuration</CardTitle>
                <CardDescription>
                  Configure the basic settings for your model training job
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="modelName">Model Name</Label>
                  <Input
                    id="modelName"
                    placeholder="Enter model name"
                    value={modelName}
                    onChange={(e) => setModelName(e.target.value)}
                  />
                </div>
                
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="description">Description</Label>
                  <Input
                    id="description"
                    placeholder="Enter model description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
                
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="modelType">Model Type</Label>
                  <Select value={modelType} onValueChange={setModelType}>
                    <SelectTrigger id="modelType">
                      <SelectValue placeholder="Select model type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="classification">Classification</SelectItem>
                      <SelectItem value="regression">Regression</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="algorithm">Algorithm</Label>
                  <Select value={algorithm} onValueChange={setAlgorithm}>
                    <SelectTrigger id="algorithm">
                      <SelectValue placeholder="Select algorithm" />
                    </SelectTrigger>
                    <SelectContent>
                      {modelType === "classification" ? (
                        classificationAlgorithms.map((algo) => (
                          <SelectItem key={algo.value} value={algo.value}>
                            {algo.label}
                          </SelectItem>
                        ))
                      ) : (
                        regressionAlgorithms.map((algo) => (
                          <SelectItem key={algo.value} value={algo.value}>
                            {algo.label}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="datasetId">Dataset ID</Label>
                  <Input
                    id="datasetId"
                    placeholder="Enter dataset ID"
                    value={datasetId}
                    onChange={(e) => setDatasetId(e.target.value)}
                  />
                </div>
                
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="targetColumn">Target Column</Label>
                  <Input
                    id="targetColumn"
                    placeholder="Enter target column name"
                    value={targetColumn}
                    onChange={(e) => setTargetColumn(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="advanced">
            <Card>
              <CardHeader>
                <CardTitle>Hyperparameters</CardTitle>
                <CardDescription>
                  Configure algorithm-specific hyperparameters
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {getHyperparameterFields()}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="platform">
            <Card>
              <CardHeader>
                <CardTitle>Platform Settings</CardTitle>
                <CardDescription>
                  Configure platform-specific settings for training
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="platform">Training Platform</Label>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger id="platform">
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="azure">
                        <div className="flex items-center">
                          <CloudCog className="mr-2 h-4 w-4" />
                          <span>Azure ML</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="aws">
                        <div className="flex items-center">
                          <Server className="mr-2 h-4 w-4" />
                          <span>AWS SageMaker</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="local">
                        <div className="flex items-center">
                          <Database className="mr-2 h-4 w-4" />
                          <span>Local Training</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="saveToRegistry"
                    checked={saveToRegistry}
                    onCheckedChange={setSaveToRegistry}
                  />
                  <Label htmlFor="saveToRegistry">Save to Model Registry</Label>
                </div>
                
                {platform === "azure" && (
                  <>
                    <Separator className="my-4" />
                    <h3 className="text-lg font-medium">Azure ML Compute Settings</h3>
                    <div className="grid w-full items-center gap-1.5">
                      <Label htmlFor="compute_target">Compute Target</Label>
                      <Select defaultValue="aml-cluster">
                        <SelectTrigger id="compute_target">
                          <SelectValue placeholder="Select compute target" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="aml-cluster">AML Compute Cluster</SelectItem>
                          <SelectItem value="aml-instance">AML Compute Instance</SelectItem>
                          <SelectItem value="kubernetes">AKS Cluster</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}
                
                {platform === "aws" && (
                  <>
                    <Separator className="my-4" />
                    <h3 className="text-lg font-medium">AWS SageMaker Settings</h3>
                    <div className="grid w-full items-center gap-1.5">
                      <Label htmlFor="instance_type">Instance Type</Label>
                      <Select defaultValue="ml.m5.large">
                        <SelectTrigger id="instance_type">
                          <SelectValue placeholder="Select instance type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ml.m5.large">ml.m5.large</SelectItem>
                          <SelectItem value="ml.m5.xlarge">ml.m5.xlarge</SelectItem>
                          <SelectItem value="ml.m5.2xlarge">ml.m5.2xlarge</SelectItem>
                          <SelectItem value="ml.g4dn.xlarge">ml.g4dn.xlarge (GPU)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <div className="mt-6 flex justify-end">
          <Button
            onClick={handleTrainModel}
            disabled={trainModelMutation.isPending}
            size="lg"
          >
            {trainModelMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Starting Training...
              </>
            ) : (
              <>
                <Gauge className="mr-2 h-4 w-4" />
                Train Model
              </>
            )}
          </Button>
        </div>
      </div>
    </MainLayout>
  );
};

export default ModelTraining;