import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import PipelineDesigner from '@/components/pipeline/PipelineDesigner';
import PipelineManagement from '@/components/pipeline/PipelineManagement';

const PipelineOrchestrator: React.FC = () => {
  // Set page title
  useEffect(() => {
    document.title = "Pipeline Orchestrator | AI/ML Playbook";
  }, []);

  return (
    <>
      <Helmet>
        <title>Pipeline Orchestrator | AI/ML Playbook</title>
        <meta name="description" content="Design, schedule, and monitor end-to-end MLOps pipelines." />
      </Helmet>
      
      <div className="mb-6">
        <h2 className="text-xl font-bold text-neutral-600 mb-4">Pipeline Orchestrator</h2>
        <p className="text-neutral-500 mb-4">Design, schedule, and monitor end-to-end MLOps pipelines.</p>
        
        <div className="flex flex-wrap gap-4 mb-8">
          <Button className="bg-primary text-white">
            <span className="material-icons text-sm mr-2">add</span>
            New Pipeline
          </Button>
          <Button variant="outline">
            <span className="material-icons text-sm mr-2">upload_file</span>
            Import Pipeline
          </Button>
        </div>
      </div>
      
      <PipelineDesigner />
      <PipelineManagement />
    </>
  );
};

export default PipelineOrchestrator;
