import React from 'react';
import { Helmet } from 'react-helmet';
import { IntegrationsList } from '@/components/integrations/IntegrationsList';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const Integrations: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Integrations | AI/ML Playbook</title>
        <meta name="description" content="Manage external system integrations with Apache NiFi, Spark, and Flink for your AI/ML workflows." />
      </Helmet>
      
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Integrations</h1>
          <p className="text-muted-foreground mt-2">
            Connect to external data processing and orchestration systems
          </p>
        </div>

        <Tabs defaultValue="manage">
          <TabsList className="mb-4">
            <TabsTrigger value="manage">Manage Integrations</TabsTrigger>
            <TabsTrigger value="dashboard">Integration Status</TabsTrigger>
            <TabsTrigger value="docs">Documentation</TabsTrigger>
          </TabsList>

          <TabsContent value="manage">
            <IntegrationsList />
          </TabsContent>

          <TabsContent value="dashboard">
            <div className="grid gap-6 grid-cols-1 lg:grid-cols-3">
              <IntegrationStatusCard 
                title="Apache NiFi" 
                description="Data flow and ETL orchestration" 
                count={0} 
                connected={0} 
              />
              <IntegrationStatusCard 
                title="Apache Spark" 
                description="Distributed data processing" 
                count={0} 
                connected={0} 
              />
              <IntegrationStatusCard 
                title="Apache Flink" 
                description="Stream processing framework" 
                count={0} 
                connected={0} 
              />
            </div>
          </TabsContent>

          <TabsContent value="docs">
            <div className="prose max-w-none">
              <Card>
                <CardHeader>
                  <CardTitle>Integration Documentation</CardTitle>
                  <CardDescription>How to connect external systems with AI/ML Playbook</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <section>
                      <h3 className="text-lg font-medium">Apache NiFi Integration</h3>
                      <p>
                        Apache NiFi is a dataflow system enabling data routing, transformation, and 
                        system mediation logic. Integration with AI/ML Playbook allows you to:
                      </p>
                      <ul className="list-disc pl-6 mt-2">
                        <li>Define and monitor data processing workflows</li>
                        <li>Automatically ingest data into your ML pipelines</li>
                        <li>Transform data for training and inference</li>
                        <li>Orchestrate complex data flows between systems</li>
                      </ul>
                      <p className="mt-2">
                        To integrate with NiFi, you'll need the NiFi REST API endpoint, typically
                        available at <code>https://your-nifi-server:8443/nifi-api</code>
                      </p>
                    </section>

                    <section>
                      <h3 className="text-lg font-medium">Apache Spark Integration</h3>
                      <p>
                        Apache Spark is a multi-language analytics engine for large-scale data processing.
                        Integration enables:
                      </p>
                      <ul className="list-disc pl-6 mt-2">
                        <li>Running distributed ML training jobs on large datasets</li>
                        <li>Feature engineering at scale</li>
                        <li>Batch inference on Spark clusters</li>
                        <li>Federated learning across distributed data sources</li>
                      </ul>
                      <p className="mt-2">
                        Connect to Spark via the Spark REST API or the Livy REST API, typically at
                        <code>http://spark-master:8998</code>
                      </p>
                    </section>

                    <section>
                      <h3 className="text-lg font-medium">Apache Flink Integration</h3>
                      <p>
                        Apache Flink is a framework and distributed processing engine for stateful 
                        computations over data streams. Integration provides:
                      </p>
                      <ul className="list-disc pl-6 mt-2">
                        <li>Real-time feature calculation for online ML</li>
                        <li>Stream processing for continuous model updates</li>
                        <li>Event-driven ML pipelines</li>
                        <li>Complex event processing for ML triggers</li>
                      </ul>
                      <p className="mt-2">
                        Connect to Flink using the Flink REST API, typically available at
                        <code>http://flink-jobmanager:8081</code>
                      </p>
                    </section>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

interface IntegrationStatusCardProps {
  title: string;
  description: string;
  count: number;
  connected: number;
}

function IntegrationStatusCard({ title, description, count, connected }: IntegrationStatusCardProps) {
  const percent = count > 0 ? Math.round((connected / count) * 100) : 0;
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-2xl font-bold">{count}</p>
              <p className="text-xs text-muted-foreground">Total Integrations</p>
            </div>
            
            <div className="text-right">
              <p className="text-2xl font-bold">{connected}</p>
              <p className="text-xs text-muted-foreground">Connected</p>
            </div>
            
            <div className="text-right">
              <p className="text-2xl font-bold">{percent}%</p>
              <p className="text-xs text-muted-foreground">Success Rate</p>
            </div>
          </div>
          
          {count > 0 ? (
            <div className="w-full bg-muted h-2.5 rounded-full mt-4">
              <div 
                className="bg-primary h-2.5 rounded-full" 
                style={{ width: `${percent}%` }}
              ></div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground mt-4 text-center">
              No integrations configured
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default Integrations;