import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Helmet } from 'react-helmet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { 
  AlertCircle, 
  Check, 
  CloudCog, 
  Cog, 
  Database, 
  FileInput, 
  FileText, 
  Flame, 
  FolderOpen, 
  HardDrive, 
  Loader2, 
  Plus, 
  Server, 
  Trash, 
  Upload, 
  X 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/hooks/use-auth';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';

// Type definitions
interface DataSource {
  id: number;
  name: string;
  type: string;
  connection: string;
  status: string;
  config?: Record<string, any>;
  userId?: number;
  createdAt: string;
}

type DataSourceType = 'azure' | 'aws' | 'local' | 'spark' | 'upload';

interface FileMetadata {
  id: number;
  name: string;
  source: string;
  path: string;
  size: number;
  format: string;
  status: string;
  dataSourceId?: number;
  userId?: number;
  createdAt: string;
}

// Helper components
const DataSourceBadge = ({ type }: { type: string }) => {
  const getColor = (type: string) => {
    switch (type) {
      case 'azure':
        return 'bg-blue-100 text-blue-800';
      case 'aws':
        return 'bg-orange-100 text-orange-800';
      case 'local':
        return 'bg-green-100 text-green-800';
      case 'spark':
        return 'bg-red-100 text-red-800';
      case 'upload':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Badge variant="outline" className={`${getColor(type)} border-0`}>
      {type.charAt(0).toUpperCase() + type.slice(1)}
    </Badge>
  );
};

const StatusBadge = ({ status }: { status: string }) => {
  const getColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'bg-green-100 text-green-800';
      case 'disconnected':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Badge variant="outline" className={`${getColor(status)} border-0`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
};

const DataSourceIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'azure':
      return <CloudCog className="h-8 w-8 text-blue-500" />;
    case 'aws':
      return <CloudCog className="h-8 w-8 text-orange-500" />;
    case 'local':
      return <HardDrive className="h-8 w-8 text-green-500" />;
    case 'spark':
      return <Flame className="h-8 w-8 text-red-500" />;
    case 'upload':
      return <Upload className="h-8 w-8 text-purple-500" />;
    default:
      return <Database className="h-8 w-8 text-gray-500" />;
  }
};

// File format badge
const FormatBadge = ({ format }: { format: string }) => {
  const getColor = (format: string) => {
    switch (format) {
      case 'csv':
        return 'bg-green-100 text-green-800';
      case 'json':
        return 'bg-blue-100 text-blue-800';
      case 'parquet':
        return 'bg-purple-100 text-purple-800';
      case 'wav':
      case 'mp3':
        return 'bg-yellow-100 text-yellow-800';
      case 'txt':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Badge variant="outline" className={`${getColor(format)} border-0`}>
      {format.toUpperCase()}
    </Badge>
  );
};

// Main component
const DataSourcesPage: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('sources');
  const [selectedSourceId, setSelectedSourceId] = useState<number | null>(null);
  const [isAddSourceDialogOpen, setIsAddSourceDialogOpen] = useState(false);
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isSparkJobDialogOpen, setIsSparkJobDialogOpen] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [sourceType, setSourceType] = useState<DataSourceType>('azure');

  // Fetch data sources
  const {
    data: dataSources = [],
    isLoading: isSourcesLoading,
    error: sourcesError
  } = useQuery<DataSource[]>({
    queryKey: ['/api/data-sources'],
    queryFn: () => apiRequest('GET', '/api/data-sources').then(res => res.json()),
  });

  // Fetch files
  const {
    data: files = [],
    isLoading: isFilesLoading,
    error: filesError
  } = useQuery<FileMetadata[]>({
    queryKey: ['/api/files'],
    queryFn: () => apiRequest('GET', '/api/files').then(res => res.json()),
  });

  // Create data source mutation
  const createDataSourceMutation = useMutation({
    mutationFn: async (dataSource: Partial<DataSource>) => {
      const res = await apiRequest('POST', '/api/data-sources', dataSource);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/data-sources'] });
      setIsAddSourceDialogOpen(false);
      toast({
        title: "Data source created",
        description: "Data source was created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create data source",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Upload file mutation
  const uploadFileMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await apiRequest('POST', '/api/upload', formData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      setIsUploadDialogOpen(false);
      setSelectedFiles([]);
      toast({
        title: "Files uploaded",
        description: "Files were uploaded successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to upload files",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Spark job mutation
  const sparkJobMutation = useMutation({
    mutationFn: async (job: any) => {
      const res = await apiRequest('POST', '/api/spark/job', job);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      setIsSparkJobDialogOpen(false);
      toast({
        title: "Spark job submitted",
        description: "Spark job was submitted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit Spark job",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // File upload handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const fileArray = Array.from(e.target.files);
      setSelectedFiles(fileArray);
    }
  };

  const simulateUpload = () => {
    setIsUploading(true);
    setUploadProgress(0);
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        const newProgress = prev + 10;
        if (newProgress >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          
          // Create FormData and call the mutation
          const formData = new FormData();
          selectedFiles.forEach(file => {
            formData.append('files', file);
          });
          formData.append('userId', user?.id.toString() || '1');
          formData.append('source', 'upload');
          
          uploadFileMutation.mutate(formData);
          return 100;
        }
        return newProgress;
      });
    }, 300);
  };

  // Add Data Source form based on selected type
  const renderAddSourceForm = () => {
    // Base form structure that will be customized based on source type
    const [formData, setFormData] = useState({
      name: '',
      type: sourceType,
      connection: '',
      config: {},
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!formData.name) {
        toast({
          title: "Missing fields",
          description: "Please provide a data source name",
          variant: "destructive",
        });
        return;
      }

      createDataSourceMutation.mutate({
        ...formData,
        userId: user?.id,
        status: 'disconnected'
      });
    };

    // Common fields for all source types
    const commonFields = (
      <>
        <div className="space-y-2">
          <Label htmlFor="name">Data Source Name</Label>
          <Input 
            id="name" 
            placeholder="Enter a name for this data source"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="type">Data Source Type</Label>
          <Select 
            value={sourceType}
            onValueChange={(value: DataSourceType) => {
              setSourceType(value);
              setFormData({...formData, type: value});
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="azure">Azure Blob Storage</SelectItem>
              <SelectItem value="aws">AWS S3</SelectItem>
              <SelectItem value="local">Local Server Storage</SelectItem>
              <SelectItem value="spark">Apache Spark Storage</SelectItem>
              <SelectItem value="upload">Local Upload</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </>
    );

    // Render specific fields based on source type
    const renderTypeSpecificFields = () => {
      switch (sourceType) {
        case 'azure':
          return (
            <>
              <div className="space-y-2">
                <Label htmlFor="connection">Connection String</Label>
                <Input 
                  id="connection" 
                  placeholder="Azure storage connection string"
                  value={formData.connection}
                  onChange={(e) => setFormData({...formData, connection: e.target.value})}
                  type="password"
                />
                <p className="text-xs text-muted-foreground">
                  Format: DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="container">Container Name</Label>
                <Input 
                  id="container" 
                  placeholder="Azure blob container name"
                  onChange={(e) => setFormData({
                    ...formData, 
                    config: {...formData.config, container: e.target.value}
                  })}
                />
              </div>
            </>
          );
        
        case 'aws':
          return (
            <>
              <div className="space-y-2">
                <Label htmlFor="accessKey">Access Key ID</Label>
                <Input 
                  id="accessKey" 
                  placeholder="AWS Access Key ID"
                  onChange={(e) => setFormData({
                    ...formData, 
                    config: {...formData.config, accessKey: e.target.value}
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="secretKey">Secret Access Key</Label>
                <Input 
                  id="secretKey" 
                  placeholder="AWS Secret Access Key"
                  type="password"
                  onChange={(e) => setFormData({
                    ...formData, 
                    config: {...formData.config, secretKey: e.target.value}
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bucket">S3 Bucket Name</Label>
                <Input 
                  id="bucket" 
                  placeholder="S3 bucket name"
                  onChange={(e) => setFormData({
                    ...formData, 
                    config: {...formData.config, bucket: e.target.value}
                  })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="region">AWS Region</Label>
                <Input 
                  id="region" 
                  placeholder="e.g., us-east-1"
                  onChange={(e) => setFormData({
                    ...formData, 
                    config: {...formData.config, region: e.target.value}
                  })}
                />
              </div>
            </>
          );
        
        case 'local':
          return (
            <>
              <div className="space-y-2">
                <Label htmlFor="path">Local Server Path</Label>
                <Input 
                  id="path" 
                  placeholder="Path to directory (e.g., /data)"
                  value={formData.connection}
                  onChange={(e) => setFormData({...formData, connection: e.target.value})}
                />
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <Switch 
                  id="readOnly"
                  checked={formData.config && 'readOnly' in formData.config ? (formData.config.readOnly as boolean) : false}
                  onCheckedChange={(checked) => setFormData({
                    ...formData, 
                    config: {...formData.config, readOnly: checked}
                  })}
                />
                <Label htmlFor="readOnly">Read-only mode</Label>
              </div>
            </>
          );
        
        case 'spark':
          return (
            <>
              <div className="space-y-2">
                <Label htmlFor="sparkMaster">Spark Master URL</Label>
                <Input 
                  id="sparkMaster" 
                  placeholder="e.g., local[*] or spark://host:7077"
                  value={formData.connection}
                  onChange={(e) => setFormData({...formData, connection: e.target.value})}
                />
                <p className="text-xs text-muted-foreground">
                  Use 'local[*]' for local mode or 'spark://host:port' for standalone cluster
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="config">Storage Configuration</Label>
                <Textarea 
                  id="config" 
                  placeholder="JSON configuration for Spark storage (e.g., Hadoop config)"
                  rows={4}
                  onChange={(e) => {
                    try {
                      const config = JSON.parse(e.target.value);
                      setFormData({...formData, config});
                    } catch (error) {
                      // Handle invalid JSON
                    }
                  }}
                />
              </div>
            </>
          );
        
        case 'upload':
          return (
            <>
              <div className="space-y-2">
                <Label htmlFor="storage">Storage Path</Label>
                <Input 
                  id="storage" 
                  placeholder="Path to store uploads"
                  value={formData.connection}
                  onChange={(e) => setFormData({...formData, connection: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="allowedFormats">Allowed Formats</Label>
                <Input 
                  id="allowedFormats" 
                  placeholder="e.g., csv,json,parquet"
                  onChange={(e) => setFormData({
                    ...formData, 
                    config: {...formData.config, allowedFormats: e.target.value.split(',')}
                  })}
                />
                <p className="text-xs text-muted-foreground">
                  Comma-separated list of allowed file formats
                </p>
              </div>
            </>
          );
        
        default:
          return null;
      }
    };

    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <DialogHeader>
          <DialogTitle>Add Data Source</DialogTitle>
          <DialogDescription>
            Connect to a data source to access and process data
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {commonFields}
          {renderTypeSpecificFields()}
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setIsAddSourceDialogOpen(false)}>
            Cancel
          </Button>
          <Button type="submit" disabled={createDataSourceMutation.isPending}>
            {createDataSourceMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 mr-2" />
                Create Data Source
              </>
            )}
          </Button>
        </DialogFooter>
      </form>
    );
  };

  // Upload file dialog
  const renderUploadFileDialog = () => {
    return (
      <div className="space-y-4">
        <DialogHeader>
          <DialogTitle>Upload Files</DialogTitle>
          <DialogDescription>
            Upload data files to process in the platform
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="border-2 border-dashed rounded-md p-6 text-center">
            <Upload className="h-8 w-8 mx-auto text-muted-foreground" />
            <p className="mt-2 text-sm text-muted-foreground">
              Drag and drop files here, or click to select files
            </p>
            <Input 
              id="file" 
              type="file"
              multiple
              className="mt-4 mx-auto max-w-sm"
              onChange={handleFileChange}
            />
            {selectedFiles.length > 0 && (
              <div className="mt-4 text-left">
                <p className="text-sm font-medium">Selected Files ({selectedFiles.length})</p>
                <ul className="mt-2 space-y-1 text-sm">
                  {selectedFiles.slice(0, 5).map((file, index) => (
                    <li key={index} className="flex items-center">
                      <FileText className="h-4 w-4 mr-2 text-primary" />
                      <span>{file.name}</span>
                      <span className="ml-auto text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</span>
                    </li>
                  ))}
                  {selectedFiles.length > 5 && (
                    <li className="text-muted-foreground text-center">
                      +{selectedFiles.length - 5} more files
                    </li>
                  )}
                </ul>
              </div>
            )}
            {isUploading && (
              <div className="mt-4">
                <p className="text-sm text-muted-foreground mb-2">Uploading... {uploadProgress}%</p>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
            Cancel
          </Button>
          <Button 
            type="button" 
            disabled={selectedFiles.length === 0 || isUploading}
            onClick={simulateUpload}
          >
            {isUploading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Upload Files
              </>
            )}
          </Button>
        </DialogFooter>
      </div>
    );
  };

  // Spark job dialog
  const SparkJobDialog = () => {
    const [jobData, setJobData] = useState({
      name: '',
      sourceId: '',
      script: '',
      config: {}
    });

    return (
      <form onSubmit={(e) => {
        e.preventDefault();
        sparkJobMutation.mutate(jobData);
      }} className="space-y-4">
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Job Name</Label>
            <Input 
              id="name" 
              placeholder="Enter a name for this job"
              value={jobData.name}
              onChange={(e) => setJobData({...jobData, name: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sourceId">Data Source</Label>
            <Select 
              value={jobData.sourceId}
              onValueChange={(value) => setJobData({...jobData, sourceId: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a data source" />
              </SelectTrigger>
              <SelectContent>
                {dataSources
                  .filter(source => source.type === 'spark')
                  .map(source => (
                    <SelectItem key={source.id} value={source.id.toString()}>
                      {source.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="script">Spark Script</Label>
            <Textarea 
              id="script" 
              placeholder="Enter PySpark or Spark SQL code"
              rows={8}
              value={jobData.script}
              onChange={(e) => setJobData({...jobData, script: e.target.value})}
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setIsSparkJobDialogOpen(false)}>
            Cancel
          </Button>
          <Button type="submit" disabled={sparkJobMutation.isPending}>
            {sparkJobMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Flame className="h-4 w-4 mr-2" />
                Submit Spark Job
              </>
            )}
          </Button>
        </DialogFooter>
      </form>
    );
  };

  // Render data sources list
  const renderDataSources = () => {
    if (isSourcesLoading) {
      return (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (sourcesError) {
      return (
        <div className="flex justify-center items-center py-12 text-destructive">
          <AlertCircle className="h-6 w-6 mr-2" />
          <p>Failed to load data sources</p>
        </div>
      );
    }

    if (dataSources.length === 0) {
      return (
        <div className="space-y-8">
          <div className="text-center py-8 border rounded-md border-dashed">
            <Database className="h-12 w-12 mx-auto text-muted-foreground" />
            <h3 className="mt-4 text-lg font-semibold">No Data Sources</h3>
            <p className="text-muted-foreground mt-2">Get started by adding your first data source.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => setIsAddSourceDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Data Source
            </Button>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Available Data Source Types</h3>
            <p className="text-muted-foreground">Select one of the following data source types to connect to your data:</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => {
                setSourceType('azure');
                setIsAddSourceDialogOpen(true);
              }}>
                <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mb-4">
                    <CloudCog className="h-8 w-8 text-blue-500" />
                  </div>
                  <CardTitle className="text-base mb-2">Azure Blob Storage</CardTitle>
                  <CardDescription>Connect to Microsoft Azure Blob Storage containers</CardDescription>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => {
                setSourceType('aws');
                setIsAddSourceDialogOpen(true);
              }}>
                <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-orange-50 flex items-center justify-center mb-4">
                    <CloudCog className="h-8 w-8 text-orange-500" />
                  </div>
                  <CardTitle className="text-base mb-2">AWS S3</CardTitle>
                  <CardDescription>Connect to Amazon S3 buckets for cloud storage</CardDescription>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => {
                setSourceType('local');
                setIsAddSourceDialogOpen(true);
              }}>
                <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-green-50 flex items-center justify-center mb-4">
                    <HardDrive className="h-8 w-8 text-green-500" />
                  </div>
                  <CardTitle className="text-base mb-2">Local Storage</CardTitle>
                  <CardDescription>Access data from local server directories</CardDescription>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => {
                setSourceType('spark');
                setIsAddSourceDialogOpen(true);
              }}>
                <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center mb-4">
                    <Flame className="h-8 w-8 text-red-500" />
                  </div>
                  <CardTitle className="text-base mb-2">Apache Spark</CardTitle>
                  <CardDescription>Process big data with Apache Spark cluster</CardDescription>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => {
                setSourceType('upload');
                setIsUploadDialogOpen(true);
              }}>
                <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-purple-50 flex items-center justify-center mb-4">
                    <Upload className="h-8 w-8 text-purple-500" />
                  </div>
                  <CardTitle className="text-base mb-2">Upload Files</CardTitle>
                  <CardDescription>Upload data files directly to the platform</CardDescription>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => {
                setIsSparkJobDialogOpen(true);
              }}>
                <CardContent className="pt-6 pb-4 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mb-4">
                    <Server className="h-8 w-8 text-blue-500" />
                  </div>
                  <CardTitle className="text-base mb-2">Apache NiFi</CardTitle>
                  <CardDescription>Create data flows using Apache NiFi</CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold">Your Data Sources</h3>
          <div className="flex space-x-3">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsAddSourceDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add New
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsUploadDialogOpen(true)}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload Files
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {dataSources.map(source => (
            <Card key={source.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <DataSourceIcon type={source.type} />
                    <div className="ml-3">
                      <CardTitle className="text-lg">{source.name}</CardTitle>
                      <CardDescription className="line-clamp-1">
                        <DataSourceBadge type={source.type} />
                      </CardDescription>
                    </div>
                  </div>
                  <StatusBadge status={source.status} />
                </div>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="space-y-2 text-sm">
                  {source.type === 'azure' && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Container:</span>
                      <span>{source.config?.container || 'Not specified'}</span>
                    </div>
                  )}
                  {source.type === 'aws' && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Bucket:</span>
                      <span>{source.config?.bucket || 'Not specified'}</span>
                    </div>
                  )}
                  {source.type === 'local' && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Path:</span>
                      <span>{source.connection}</span>
                    </div>
                  )}
                  {source.type === 'spark' && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Master:</span>
                      <span>{source.connection}</span>
                    </div>
                  )}
                  {source.type === 'upload' && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Storage:</span>
                      <span>{source.connection}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Added:</span>
                    <span>{new Date(source.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <div className="flex justify-between items-center w-full">
                  <Button variant="ghost" size="sm">
                    <Cog className="h-4 w-4 mr-2" />
                    Configure
                  </Button>
                  <Button
                    variant={source.status === 'connected' ? 'destructive' : 'outline'}
                    size="sm"
                  >
                    {source.status === 'connected' ? (
                      <>
                        <X className="h-4 w-4 mr-2" />
                        Disconnect
                      </>
                    ) : (
                      <>
                        <Check className="h-4 w-4 mr-2" />
                        Connect
                      </>
                    )}
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  // Render files list
  const renderFiles = () => {
    if (isFilesLoading) {
      return (
        <div className="flex justify-center items-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }

    if (filesError) {
      return (
        <div className="flex justify-center items-center py-12 text-destructive">
          <AlertCircle className="h-6 w-6 mr-2" />
          <p>Failed to load files</p>
        </div>
      );
    }

    if (files.length === 0) {
      return (
        <div className="text-center py-12 border rounded-md border-dashed">
          <FileText className="h-12 w-12 mx-auto text-muted-foreground" />
          <h3 className="mt-4 text-lg font-semibold">No Files</h3>
          <p className="text-muted-foreground mt-2">Upload files or connect to a data source to get started.</p>
          <div className="flex justify-center space-x-4 mt-4">
            <Button 
              variant="outline"
              onClick={() => setIsUploadDialogOpen(true)}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload Files
            </Button>
            <Button 
              variant="outline"
              onClick={() => setIsSparkJobDialogOpen(true)}
            >
              <Flame className="h-4 w-4 mr-2" />
              Create Spark Job
            </Button>
          </div>
        </div>
      );
    }

    return (
      <div className="mt-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-lg font-semibold">Files ({files.length})</h3>
            <p className="text-sm text-muted-foreground">Manage your uploaded and processed files</p>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setIsUploadDialogOpen(true)}
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload Files
          </Button>
        </div>
        <div className="overflow-auto rounded-md border">
          <table className="min-w-full divide-y divide-border">
            <thead className="bg-muted/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Format
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Size
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Source
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-border">
              {files.map((file) => (
                <tr key={file.id} className="hover:bg-muted/20">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 mr-3 text-muted-foreground" />
                      <div>
                        <div className="text-sm font-medium">{file.name}</div>
                        <div className="text-xs text-muted-foreground">{new Date(file.createdAt).toLocaleDateString()}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <FormatBadge format={file.format} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {(file.size / 1024).toFixed(1)} KB
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <StatusBadge status={file.status} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <DataSourceBadge type={file.source} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="flex justify-end space-x-2">
                      <Button variant="ghost" size="icon">
                        <FolderOpen className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Cog className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Trash className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  // Main render
  return (
    <div className="p-6">
      <Helmet>
        <title>Data Sources | AI/ML Playbook</title>
        <meta name="description" content="Connect and manage data sources for machine learning workflows" />
      </Helmet>
      
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Data Sources</h1>
          <p className="text-muted-foreground">Connect to data sources and manage files</p>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={() => setIsUploadDialogOpen(true)}
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload
          </Button>
          <Button 
            onClick={() => setIsAddSourceDialogOpen(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Data Source
          </Button>
        </div>
      </div>

      {/* Add Data Source Dialog */}
      <Dialog open={isAddSourceDialogOpen} onOpenChange={setIsAddSourceDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          {renderAddSourceForm()}
        </DialogContent>
      </Dialog>

      {/* Upload File Dialog */}
      <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          {renderUploadFileDialog()}
        </DialogContent>
      </Dialog>

      {/* Spark Job Dialog */}
      <Dialog open={isSparkJobDialogOpen} onOpenChange={setIsSparkJobDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create Spark Job</DialogTitle>
            <DialogDescription>
              Submit a Spark job to process data
            </DialogDescription>
          </DialogHeader>
          <SparkJobDialog />
        </DialogContent>
      </Dialog>

      <Tabs defaultValue="sources" value={activeTab} onValueChange={setActiveTab} className="w-full mt-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="sources">Data Sources</TabsTrigger>
          <TabsTrigger value="files">Files</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sources">
          {renderDataSources()}
        </TabsContent>
        
        <TabsContent value="files">
          {renderFiles()}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DataSourcesPage;