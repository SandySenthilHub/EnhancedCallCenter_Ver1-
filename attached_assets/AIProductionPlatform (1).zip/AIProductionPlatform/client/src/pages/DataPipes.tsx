import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { 
  Alert,
  AlertTitle, 
  AlertDescription 
} from '@/components/ui/alert';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { PlusCircle, UploadCloud, Info } from 'lucide-react';
import DataSourcesConfig from '@/components/data-pipes/DataSourcesConfig';
import DataFlowDesigner from '@/components/data-pipes/DataFlowDesigner';

const DataPipes: React.FC = () => {
  // Set page title
  useEffect(() => {
    document.title = "Data Integration | AI/ML Playbook";
  }, []);

  return (
    <>
      <Helmet>
        <title>Data Integration | AI/ML Playbook</title>
        <meta name="description" content="Connect to data sources and create data integration workflows using a visual interface." />
      </Helmet>
      
      <div className="mb-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold mb-2">Data Integration</h2>
            <p className="text-gray-500">Connect to data sources and create data integration workflows</p>
          </div>
          
          <div className="flex flex-wrap gap-3">
            <Button variant="outline">
              <UploadCloud className="mr-2 h-4 w-4" />
              Import Configuration
            </Button>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" />
              New Integration
            </Button>
          </div>
        </div>
      </div>
      
      <Alert className="mb-6 border-blue-200 bg-blue-50">
        <Info className="h-4 w-4" />
        <AlertTitle>Development in progress</AlertTitle>
        <AlertDescription>
          The Data Integration module is currently under development. Some features may be limited or non-functional.
        </AlertDescription>
      </Alert>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Getting Started with Data Integration</CardTitle>
          <CardDescription>Learn how to connect data sources and create data flows</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p>The Data Integration module allows you to:</p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Connect to various data sources like databases, file systems, and cloud storage</li>
              <li>Design visual data transformation workflows similar to Apache NiFi</li>
              <li>Schedule and monitor data pipeline executions</li>
              <li>Prepare data for machine learning models and analytics</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" size="sm">View Documentation</Button>
        </CardFooter>
      </Card>
      
      <DataSourcesConfig />
      <DataFlowDesigner />
    </>
  );
};

export default DataPipes;
