import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import ModelPerformance from '@/components/reports/ModelPerformance';
import ExperimentComparison from '@/components/reports/ExperimentComparison';

const Reports: React.FC = () => {
  // Set page title
  useEffect(() => {
    document.title = "Reports | AI/ML Playbook";
  }, []);

  // Initialize Plotly-like visualization when component mounts
  useEffect(() => {
    // In a real implementation, we would use Plotly or a similar library
    // to create interactive visualizations
    const initVisualizations = () => {
      console.log('Initializing model performance visualizations');
    };
    
    initVisualizations();
  }, []);

  return (
    <>
      <Helmet>
        <title>Reports | AI/ML Playbook</title>
        <meta name="description" content="View model performance metrics, visualizations, and download reports." />
      </Helmet>
      
      <div className="mb-6">
        <h2 className="text-xl font-bold text-neutral-600 mb-4">Results & Reporting</h2>
        <p className="text-neutral-500 mb-4">View model performance metrics, visualizations, and download reports.</p>
      </div>
      
      <ModelPerformance />
      <ExperimentComparison />
    </>
  );
};

export default Reports;
