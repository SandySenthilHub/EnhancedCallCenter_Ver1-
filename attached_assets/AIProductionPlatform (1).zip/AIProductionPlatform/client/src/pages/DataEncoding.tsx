import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { queryClient, apiRequest } from '@/lib/queryClient';
import LoadingSpinner from '../components/ui/loading-spinner';
import { DataSourcesIcon } from '@/lib/icons';

const DataEncoding: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedEncodingType, setSelectedEncodingType] = useState('one-hot');
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [selectedColumn, setSelectedColumn] = useState<string | null>(null);
  const [configName, setConfigName] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [handleMissingValues, setHandleMissingValues] = useState(false);
  const [missingStrategy, setMissingStrategy] = useState('most_frequent');
  const [dropOriginal, setDropOriginal] = useState(false);
  const [addPrefix, setAddPrefix] = useState(true);
  const [columnPrefix, setColumnPrefix] = useState('');
  const [availableColumns, setAvailableColumns] = useState<string[]>([]);
  const [isLoadingColumns, setIsLoadingColumns] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [fileName, setFileName] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [fileError, setFileError] = useState('');
  const { toast } = useToast();

  const { data: dataEncodingConfigs = [], isLoading: isLoadingConfigs } = useQuery<any[]>({
    queryKey: ['/api/data-encodings'],
    enabled: activeTab === 'overview'
  });

  const { data: dataSources = [], isLoading: isLoadingDataSources } = useQuery<any[]>({
    queryKey: ['/api/data-sources'],
    enabled: activeTab === 'create'
  });
  
  // Query for data source schema/columns
  const { data: dataSourceColumns = [], isLoading: isLoadingDataSourceColumns } = useQuery<any[]>({
    queryKey: ['/api/data-sources', selectedFile, 'columns'],
    enabled: !!selectedFile && activeTab === 'create'
  });
  
  // Effect to handle data source selection
  useEffect(() => {
    if (selectedFile) {
      setIsLoadingColumns(true);
      setSelectedColumn(null);
    } else {
      setAvailableColumns([]);
    }
  }, [selectedFile]);
  
  // Effect to process column data when it's available
  useEffect(() => {
    if (dataSourceColumns) {
      try {
        if (Array.isArray(dataSourceColumns)) {
          setAvailableColumns(dataSourceColumns.map((col: any) => col.name || col));
        } else if (dataSourceColumns && typeof dataSourceColumns === 'object') {
          // Handle different response formats
          setAvailableColumns(Object.keys(dataSourceColumns));
        } else {
          setAvailableColumns([]);
        }
      } catch (error) {
        console.error('Error processing column data:', error);
        setAvailableColumns([]);
        // We'll handle the toast outside to avoid dependency issues
      } finally {
        setIsLoadingColumns(false);
      }
    }
  }, [dataSourceColumns]);

  const encodingOptions = [
    { 
      value: 'one-hot', 
      label: 'One-Hot Encoding',
      description: 'Creates binary columns for each category. Best for nominal data with few unique values.'
    },
    { 
      value: 'label', 
      label: 'Label Encoding',
      description: 'Assigns a unique integer to each category. Suitable for ordinal data.'
    },
    { 
      value: 'target', 
      label: 'Target Encoding',
      description: 'Replaces categories with the mean of the target. Good for high cardinality features.'
    },
    { 
      value: 'binary', 
      label: 'Binary Encoding',
      description: 'Converts integers to binary code, then creates columns for each digit. Efficient for high cardinality.'
    },
    { 
      value: 'frequency', 
      label: 'Frequency Encoding',
      description: 'Replaces categories with their frequency in the dataset. Good for high cardinality features.'
    },
    { 
      value: 'hashing', 
      label: 'Feature Hashing',
      description: 'Uses a hash function to map categories to vector indices. Memory efficient for extremely high cardinality.'
    },
  ];

  const handleCreateEncoding = async () => {
    // Form validation
    if (!configName) {
      toast({
        title: "Validation Error",
        description: "Please provide a name for the encoding configuration.",
        variant: "destructive"
      });
      return;
    }

    if (!selectedFile) {
      toast({
        title: "Validation Error",
        description: "Please select a data source.",
        variant: "destructive"
      });
      return;
    }

    if (!selectedColumn) {
      toast({
        title: "Validation Error",
        description: "Please select a column to encode.",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsSubmitting(true);
      
      // Prepare configuration object
      const config = {
        missingValueStrategy: handleMissingValues ? missingStrategy : null,
        dropOriginalColumn: dropOriginal,
        addPrefix: addPrefix,
        prefix: addPrefix ? (columnPrefix || selectedColumn) : null
      };
      
      // Prepare output columns (this would typically be calculated by the backend)
      // For frontend preview only
      const outputColumns = 
        selectedEncodingType === 'one-hot' 
          ? [`${selectedColumn}_category1`, `${selectedColumn}_category2`] 
          : [selectedColumn];
          
      const newConfig = {
        name: configName,
        description: description || null,
        encodingType: selectedEncodingType,
        sourceColumn: selectedColumn,
        dataSourceId: parseInt(selectedFile),
        config,
        outputColumns,
        status: 'draft'
      };
      
      // Submit to API
      const response = await apiRequest('POST', '/api/data-encodings', newConfig);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to create encoding configuration');
      }
      
      toast({
        title: "Encoding configuration created",
        description: "Your encoding configuration has been saved.",
      });
      
      // Reset form fields
      setConfigName('');
      setDescription('');
      setSelectedFile(null);
      setSelectedColumn(null);
      setSelectedEncodingType('one-hot');
      setHandleMissingValues(false);
      setMissingStrategy('most_frequent');
      setDropOriginal(false);
      setAddPrefix(true);
      setColumnPrefix('');
      
      // Refresh data and go back to overview
      queryClient.invalidateQueries({ queryKey: ['/api/data-encodings'] });
      setActiveTab('overview');
    } catch (error: any) {
      console.error('Error creating encoding configuration:', error);
      toast({
        title: "Error",
        description: error.message || "An error occurred while creating the encoding configuration.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Function to execute the encoding process
  const handleExecuteEncoding = async (configId: number) => {
    try {
      // Set executing state to true to show loading indicator
      setIsExecuting(true);
      
      // Call the API to execute the encoding
      const response = await apiRequest('POST', `/api/data-encodings/${configId}/apply`, {});
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to execute encoding');
      }
      
      const result = await response.json();
      
      console.log('Encoding execution result:', result);
      
      // Show success message with metrics from the result
      if (result.history && result.history.results) {
        toast({
          title: "Encoding executed successfully",
          description: `Transformed ${result.history.results.transformedRows} rows with ${result.history.results.outputColumns.length} output columns.`,
        });
      } else {
        toast({
          title: "Encoding executed successfully",
          description: "The encoding was applied to the data source.",
        });
      }
      
      // Refresh data after successful execution
      queryClient.invalidateQueries({ queryKey: ['/api/data-encodings'] });
    } catch (error: any) {
      console.error('Error executing encoding:', error);
      toast({
        title: "Error",
        description: error.message || "An error occurred while executing the encoding.",
        variant: "destructive"
      });
    } finally {
      // Always reset the executing state
      setIsExecuting(false);
    }
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError('');
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      // Validate file type
      if (!file.name.endsWith('.csv')) {
        setFileError('Only CSV files are supported');
        return;
      }
      setFileToUpload(file);
      // If no name is set yet, use the filename (without extension)
      if (!fileName) {
        setFileName(file.name.replace(/\.csv$/, ''));
      }
    }
  };

  // Handle file upload
  const handleFileUpload = async () => {
    if (!fileToUpload) {
      setFileError('Please select a file to upload');
      return;
    }

    if (!fileName) {
      setFileError('Please provide a name for this data source');
      return;
    }

    setIsUploading(true);
    setFileError('');

    try {
      // Create a FormData object to send the file
      const formData = new FormData();
      formData.append('files', fileToUpload); // 'files' is the expected field name
      // Also create a data source with this name
      formData.append('dataSourceName', fileName);

      // Send the file to the server using the existing upload endpoint
      // The user ID will be obtained from the session on the server
      formData.append('source', 'data-encoding');
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      });

      let responseData;
      try {
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to upload file');
        }

        // Handle the response - it could be either a single object or an array
        responseData = await response.json();
      } catch (error: any) {
        if (error?.message?.includes('body already read')) {
          // Handle the case where we might have attempted to read the response body twice
          console.error('Response body already read:', error);
          throw new Error('Error processing server response');
        }
        throw error;
      }
      
      // If it's an array of files, take the first one
      let fileData;
      if (Array.isArray(responseData)) {
        if (!responseData.length) {
          throw new Error('No files were uploaded successfully');
        }
        fileData = responseData[0];
      } else {
        // If it's already a single object, use it directly
        fileData = responseData;
      }
      
      // If fileData is already a data source object (with an id), use it directly
      let newDataSource;
      
      if (fileData.id && fileData.name && fileData.type === 'file') {
        // This is already a data source object
        newDataSource = fileData;
      } else {
        // Create a data source for this file
        const dataSourceResponse = await apiRequest('POST', '/api/data-sources', {
          name: fileName,
          type: 'file',
          connection: `file://${fileData.path}`,
          status: 'connected',
          fileId: fileData.id
        });

        if (!dataSourceResponse.ok) {
          throw new Error('Failed to create data source from uploaded file');
        }

        newDataSource = await dataSourceResponse.json();
      }

      // Update the data sources list
      queryClient.invalidateQueries({ queryKey: ['/api/data-sources'] });

      // Select the newly created data source
      setSelectedFile(newDataSource.id.toString());
      setShowFileUpload(false);

      toast({
        title: "File uploaded successfully",
        description: "Your data source has been created and selected.",
      });
    } catch (error: any) {
      console.error('Error uploading file:', error);
      setFileError(error.message || 'Failed to upload file');
      toast({
        title: "Upload failed",
        description: error.message || "An error occurred while uploading the file.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const renderEncodingOption = (option: { value: string, label: string, description: string }) => (
    <div key={option.value} className="flex flex-col space-y-1">
      <div className="font-medium text-sm">{option.label}</div>
      <div className="text-xs text-neutral-500">{option.description}</div>
    </div>
  );

  return (
    <div className="container mx-auto py-6 max-w-7xl">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Data Encoding</h1>
          <p className="text-neutral-500">
            Convert categorical features to numerical formats for machine learning models
          </p>
        </div>
        <Button 
          onClick={() => setActiveTab('create')}
          className="bg-primary hover:bg-primary/90"
        >
          Create New Encoding
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="create">Create Encoding</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {isLoadingConfigs ? (
            <div className="flex justify-center items-center h-64">
              <LoadingSpinner size="lg" />
            </div>
          ) : (
            <>
              {!dataEncodingConfigs || dataEncodingConfigs.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 flex flex-col items-center justify-center h-64">
                    <DataSourcesIcon className="h-16 w-16 text-neutral-300 mb-4" />
                    <h3 className="text-xl font-medium text-neutral-600 mb-2">No Encoding Configurations</h3>
                    <p className="text-neutral-500 text-center max-w-md mb-4">
                      You haven't created any data encoding configurations yet. Create your first encoding to transform categorical data.
                    </p>
                    <Button onClick={() => setActiveTab('create')}>Create New Encoding</Button>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Encoding Configurations</CardTitle>
                    <CardDescription>
                      Manage your encoding configurations and view processing history
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Source Column</TableHead>
                          <TableHead>Encoding Type</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {dataEncodingConfigs.map((config: any) => (
                          <TableRow key={config.id}>
                            <TableCell className="font-medium">{config.name}</TableCell>
                            <TableCell>{config.sourceColumn}</TableCell>
                            <TableCell>
                              {/* Display a friendly name for the encoding type */}
                              {encodingOptions.find(opt => opt.value === config.encodingType)?.label || config.encodingType}
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant="outline" 
                                className={
                                  config.status === 'active' 
                                    ? 'bg-green-50 text-green-700 border-green-200'
                                    : config.status === 'draft'
                                      ? 'bg-yellow-50 text-yellow-700 border-yellow-200'
                                      : 'bg-blue-50 text-blue-700 border-blue-200'
                                }
                              >
                                {config.status.charAt(0).toUpperCase() + config.status.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {new Date(config.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button variant="ghost" size="sm">View</Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => setActiveTab('create')}
                              >
                                Edit
                              </Button>
                              <Button 
                                variant="default" 
                                size="sm"
                                onClick={() => handleExecuteEncoding(config.id)}
                                disabled={isExecuting}
                              >
                                {isExecuting ? (
                                  <>
                                    <span className="mr-2 h-4 w-4 animate-spin">◌</span>
                                    Processing...
                                  </>
                                ) : (
                                  "Execute"
                                )}
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>

        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Create New Encoding Configuration</CardTitle>
              <CardDescription>
                Configure how to encode your categorical data for machine learning
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="config-name">Configuration Name</Label>
                    <Input 
                      id="config-name" 
                      placeholder="E.g., Product Categories Encoding" 
                      value={configName}
                      onChange={(e) => setConfigName(e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="encoding-description">Description (Optional)</Label>
                    <Input 
                      id="encoding-description" 
                      placeholder="Brief description of this encoding" 
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="data-source">Data Source</Label>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm"
                        onClick={() => setShowFileUpload(!showFileUpload)}
                      >
                        {showFileUpload ? "Use Existing Source" : "Upload File"}
                      </Button>
                    </div>
                    
                    {!showFileUpload ? (
                      <Select 
                        value={selectedFile || undefined}
                        onValueChange={value => setSelectedFile(value)}
                      >
                        <SelectTrigger id="data-source">
                          <SelectValue placeholder="Select a data source" />
                        </SelectTrigger>
                        <SelectContent>
                          {isLoadingDataSources ? (
                            <div className="flex justify-center p-2">
                              <LoadingSpinner size="sm" />
                            </div>
                          ) : (
                            dataSources?.map((source: any) => (
                              <SelectItem key={source.id} value={source.id.toString()}>
                                {source.name}
                              </SelectItem>
                            )) || []
                          )}
                        </SelectContent>
                      </Select>
                    ) : (
                      <div className="space-y-3 border p-4 rounded-md">
                        <div className="grid gap-2">
                          <Label htmlFor="file-name">File Name</Label>
                          <Input
                            id="file-name"
                            value={fileName}
                            onChange={(e) => setFileName(e.target.value)}
                            placeholder="Enter a name for this data source"
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="file-upload">Upload CSV File</Label>
                          <div className="flex items-center gap-2">
                            <Input
                              id="file-upload"
                              type="file"
                              accept=".csv"
                              onChange={handleFileChange}
                              className="flex-1"
                            />
                            <Button 
                              type="button" 
                              onClick={handleFileUpload}
                              disabled={!fileToUpload || isUploading}
                              className="min-w-[100px]"
                            >
                              {isUploading ? (
                                <>
                                  <span className="mr-2 h-4 w-4 animate-spin">◌</span>
                                  Uploading...
                                </>
                              ) : (
                                "Upload"
                              )}
                            </Button>
                          </div>
                          {fileError && <p className="text-red-500 text-sm">{fileError}</p>}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="source-column">Source Column</Label>
                    <Select 
                      value={selectedColumn || undefined}
                      disabled={!selectedFile || isLoadingColumns} 
                      onValueChange={value => setSelectedColumn(value)}
                    >
                      <SelectTrigger id="source-column">
                        <SelectValue placeholder={
                          isLoadingColumns 
                            ? "Loading columns..." 
                            : !selectedFile 
                              ? "Select a data source first" 
                              : "Select a column to encode"
                        } />
                      </SelectTrigger>
                      <SelectContent>
                        {isLoadingColumns ? (
                          <div className="flex justify-center p-2">
                            <LoadingSpinner size="sm" />
                          </div>
                        ) : (
                          availableColumns.length > 0 
                            ? availableColumns.map(column => (
                                <SelectItem key={column} value={column}>
                                  {column}
                                </SelectItem>
                              ))
                            : <div className="p-2 text-sm text-neutral-500">No columns available</div>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <Label className="mb-2 block">Encoding Type</Label>
                  <div className="grid gap-3">
                    {encodingOptions.map(option => (
                      <div 
                        key={option.value}
                        className={`p-3 border rounded-md cursor-pointer ${
                          selectedEncodingType === option.value 
                            ? 'border-primary/50 bg-primary/5' 
                            : 'border-neutral-200 hover:border-neutral-300'
                        }`}
                        onClick={() => setSelectedEncodingType(option.value)}
                      >
                        <div className="flex items-start">
                          <Checkbox 
                            checked={selectedEncodingType === option.value}
                            onCheckedChange={() => setSelectedEncodingType(option.value)}
                            className="mt-0.5 mr-2"
                          />
                          {renderEncodingOption(option)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Advanced Options</h3>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="handling-missing-values">
                    <AccordionTrigger>Handling Missing Values</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 p-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="handle-missing" className="text-sm font-medium">Handle Missing Values</Label>
                            <p className="text-sm text-neutral-500">Automatically manage NULL or NaN values in the data</p>
                          </div>
                          <Switch 
                            id="handle-missing" 
                            checked={handleMissingValues}
                            onCheckedChange={setHandleMissingValues}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="missing-strategy">Strategy</Label>
                          <Select 
                            disabled={!handleMissingValues} 
                            value={missingStrategy}
                            onValueChange={setMissingStrategy}
                          >
                            <SelectTrigger id="missing-strategy">
                              <SelectValue placeholder="Select a strategy" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="most_frequent">Most Frequent</SelectItem>
                              <SelectItem value="new_category">Create New Category</SelectItem>
                              <SelectItem value="drop">Drop Rows</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="output-options">
                    <AccordionTrigger>Output Options</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 p-2">
                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="drop-original" className="text-sm font-medium">Drop Original Column</Label>
                            <p className="text-sm text-neutral-500">Remove the source column after encoding</p>
                          </div>
                          <Switch 
                            id="drop-original" 
                            checked={dropOriginal}
                            onCheckedChange={setDropOriginal}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="prefix-columns" className="text-sm font-medium">Add Prefix to Output Columns</Label>
                            <p className="text-sm text-neutral-500">Prefix encoded column names for clarity</p>
                          </div>
                          <Switch 
                            id="prefix-columns" 
                            checked={addPrefix}
                            onCheckedChange={setAddPrefix}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="column-prefix">Column Prefix</Label>
                          <Input 
                            id="column-prefix" 
                            disabled={!addPrefix}
                            placeholder="E.g., encoded_"
                            value={columnPrefix}
                            onChange={(e) => setColumnPrefix(e.target.value)}
                          />
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  
                  {selectedEncodingType === 'one-hot' && (
                    <AccordionItem value="one-hot-options">
                      <AccordionTrigger>One-Hot Encoding Options</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 p-2">
                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="drop-first" className="text-sm font-medium">Drop First Category</Label>
                              <p className="text-sm text-neutral-500">Avoid the dummy variable trap by dropping one category</p>
                            </div>
                            <Switch id="drop-first" />
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <div>
                              <Label htmlFor="sparse" className="text-sm font-medium">Use Sparse Matrix</Label>
                              <p className="text-sm text-neutral-500">Memory-efficient representation for high cardinality features</p>
                            </div>
                            <Switch id="sparse" defaultChecked />
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}
                  
                  {selectedEncodingType === 'target' && (
                    <AccordionItem value="target-options">
                      <AccordionTrigger>Target Encoding Options</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-4 p-2">
                          <div>
                            <Label htmlFor="target-column">Target Column</Label>
                            <Select disabled={!selectedFile}>
                              <SelectTrigger id="target-column">
                                <SelectValue placeholder="Select target column" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="sales">sales</SelectItem>
                                <SelectItem value="conversion">conversion</SelectItem>
                                <SelectItem value="churn">churn</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div>
                            <Label htmlFor="smoothing">Smoothing Factor (0-100)</Label>
                            <Input id="smoothing" type="number" min="0" max="100" defaultValue="10" />
                            <p className="text-xs text-neutral-500 mt-1">Higher values provide more regularization</p>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}
                </Accordion>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => setActiveTab('overview')}>Cancel</Button>
              <Button 
                onClick={handleCreateEncoding} 
                disabled={isSubmitting || !configName || !selectedFile || !selectedColumn}
              >
                {isSubmitting ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                    Saving...
                  </>
                ) : 'Save Configuration'}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DataEncoding;