import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2, Upload, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const DirectImport: React.FC = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{success: boolean, message: string} | null>(null);

  const importAllLibraries = async () => {
    setIsLoading(true);
    setResult(null);

    try {
      // CSV data from the user's file
      const csvContent = `name,version,category
boto3,1.35.24,AWS SDK
numpy,2.1.1,Scientific Computing
pandas,2.2.3,Data Analysis
requests,2.32.3,HTTP Requests
tensorflow,2.17.0,Machine Learning
torch,2.4.1,Machine Learning
scikit-learn,1.5.2,Machine Learning
matplotlib,3.9.2,Data Visualization
seaborn,0.13.2,Data Visualization
flask,3.0.3,Web Framework
django,5.1.1,Web Framework
sqlalchemy,2.0.35,ORM
pytest,8.3.3,Testing
beautifulsoup4,4.12.3,Web Scraping
opencv-python,4.10.0,Computer Vision
pillow,10.4.0,Image Processing
scipy,1.14.1,Scientific Computing
jupyter,1.1.1,Interactive Computing
fastapi,0.115.0,Web Framework
httpx,0.27.2,HTTP Client
aiohttp,3.10.5,Asynchronous HTTP
asyncpg,0.29.0,Database
black,24.8.0,Code Formatting
celery,5.4.0,Task Queue
click,8.1.7,Command Line Interface
dask,2024.9.0,Parallel Computing
faker,28.4.1,Data Generation
gensim,4.3.3,Natural Language Processing
gradio,4.44.0,Web Interface
h5py,3.11.0,Data Storage
httplib2,0.22.0,HTTP Client
isort,5.13.2,Code Formatting
jinja2,3.1.4,Templating
keras,3.5.0,Machine Learning
langchain,0.3.1,Natural Language Processing
lxml,5.3.0,XML Processing
mypy,1.11.2,Static Typing
networkx,3.3,Graph Analysis
nltk,3.9.1,Natural Language Processing
numba,0.60.0,Performance Optimization
openpyxl,3.1.5,Excel Processing
orjson,3.10.7,JSON Processing
plotly,5.24.1,Data Visualization
psycopg2-binary,2.9.9,Database
pydantic,2.9.2,Data Validation
pyarrow,17.0.0,Data Processing
pycryptodome,3.20.0,Cryptography
pymongo,4.8.0,Database
pyodbc,5.1.0,Database
pytest-cov,5.0.0,Testing
python-dotenv,1.0.1,Environment Management
pytz,2024.2,Time Zone Handling
pywavelets,1.7.0,Signal Processing
redis,5.0.8,Database
regex,2024.9.11,Regular Expressions
s3fs,2024.9.0,File System
spacy,3.7.6,Natural Language Processing
statsmodels,0.14.2,Statistical Modeling
sympy,1.13.2,Symbolic Mathematics
tabulate,0.9.0,Data Formatting
uvicorn,0.30.6,Web Server
xgboost,2.1.1,Machine Learning
yfinance,0.2.44,Financial Data
alabaster,0.7.16,Documentation
anaconda-client,1.12.3,Package Management
argon2-cffi,23.1.0,Security
astropy,6.1.3,Astronomy
attrs,24.2.0,Utilities
backoff,2.2.1,Retry Logic
bleach,6.1.0,Text Sanitization
bokeh,3.6.0,Data Visualization
bottleneck,1.4.0,Performance Optimization
cachetools,5.5.0,Caching
cffi,1.17.1,Foreign Function Interface
charset-normalizer,3.3.2,Text Encoding
cloudpickle,3.0.0,Serialization
coverage,7.6.1,Testing
cryptography,43.0.1,Security
cycler,0.12.1,Data Visualization
cython,3.0.11,Performance Optimization
djangorestframework,3.15.2,Web Framework
docopt,0.6.2,Command Line Interface
et-xmlfile,1.1.0,Excel Processing
filelock,3.16.1,File Locking
fire,0.7.0,Command Line Interface
fsspec,2024.9.0,File System
future,1.0.0,Compatibility
gunicorn,23.0.0,Web Server
hypothesis,6.111.1,Testing
imageio,2.35.1,Image Processing
imbalanced-learn,0.12.3,Machine Learning
inflection,0.5.1,Text Processing
joblib,1.4.2,Parallel Computing
jsonschema,4.23.0,Data Validation
kiwisolver,1.4.7,Data Visualization
loguru,0.7.2,Logging
markdown,3.7,Text Formatting
markupsafe,2.1.5,Templating
more-itertools,10.5.0,Utilities
msgpack,1.0.8,Serialization
nest-asyncio,1.6.0,Asynchronous
oauthlib,3.2.2,Authentication
packaging,24.1,Packaging
paramiko,3.5.0,SSH
patsy,0.5.6,Statistical Modeling
pendulum,3.0.0,DateTime Handling
platformdirs,4.3.2,Platform Utilities
prometheus-client,0.20.0,Monitoring
py4j,0.10.9.7,Java Integration
pydot,3.0.1,Graph Visualization
pyparsing,3.1.4,Parsing
pysocks,1.7.1,Networking
python-dateutil,2.9.0,DateTime Handling
pyyaml,6.0.2,Configuration
retrying,1.3.4,Retry Logic
six,1.16.0,Compatibility
snowballstemmer,2.2.0,Text Processing
sortedcontainers,2.4.0,Data Structures
soupsieve,2.6,Web Scraping
termcolor,2.4.0,Text Formatting
textblob,0.18.0,Natural Language Processing
threadpoolctl,3.5.0,Parallel Computing
toml,0.10.2,Configuration
tornado,6.4.1,Web Framework
tqdm,4.66.5,Progress Bar
typing-extensions,4.12.2,Static Typing
urllib3,2.2.3,HTTP Client
virtualenv,20.26.3,Environment Management
websocket-client,1.8.0,WebSocket
werkzeug,3.0.4,Web Framework
wrapt,1.16.0,Utilities
zipp,3.20.2,Packaging`;

      // Create a file object
      const file = new File([csvContent], 'library-names.csv', { type: 'text/csv' });
      
      // Create FormData
      const formData = new FormData();
      formData.append('csvFile', file);
      
      // Make the API request
      const response = await fetch('/api/algorithm-dependencies/upload-csv', {
        method: 'POST',
        body: formData
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to import libraries');
      }
      
      setResult({
        success: true,
        message: `Successfully imported ${data.count} libraries`
      });
      
      toast({
        title: 'Import Successful',
        description: `Imported ${data.count} libraries from CSV`,
      });
    } catch (error) {
      console.error('Import error:', error);
      
      setResult({
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error occurred'
      });
      
      toast({
        title: 'Import Failed',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-16 px-4">
      <div className="max-w-md mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-2">Library CSV Importer</h1>
          <p className="text-gray-600 mb-6">
            Import all libraries from the CSV file with one click
          </p>
          
          <div className="space-y-6">
            <Button 
              className="w-full py-6 text-lg"
              onClick={importAllLibraries}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-5 w-5" />
                  Import All Libraries
                </>
              )}
            </Button>
            
            {result && (
              <div className={`p-4 rounded-md ${result.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
                <div className="flex items-center">
                  {result.success ? (
                    <CheckCircle className="h-5 w-5 mr-2" />
                  ) : (
                    <AlertCircle className="h-5 w-5 mr-2" />
                  )}
                  <p className="font-medium">{result.message}</p>
                </div>
              </div>
            )}
            
            <div className="border-t pt-4 text-sm text-gray-500">
              <p>This will import all 133 libraries from the provided CSV file.</p>
              <p className="mt-2">Each library will have the following fields:</p>
              <ul className="list-disc pl-5 mt-1 space-y-1">
                <li>Name (e.g., "numpy")</li>
                <li>Version (e.g., "2.1.1")</li>
                <li>Category (e.g., "Scientific Computing")</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DirectImport;