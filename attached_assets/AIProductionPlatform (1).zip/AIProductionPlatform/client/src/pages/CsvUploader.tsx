import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Upload, FilePlus, FileCheck, AlertCircle, Loader2 } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';

const CsvUploader: React.FC = () => {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadResults, setUploadResults] = useState<{
    success: boolean;
    message: string;
    count?: number;
  } | null>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Reset state
    setIsUploading(true);
    setUploadResults(null);

    try {
      // Create FormData
      const formData = new FormData();
      formData.append('csvFile', file);

      // Direct fetch request to upload the file
      const response = await fetch('/api/algorithm-dependencies/upload-csv', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to upload CSV file');
      }

      // Update the results
      setUploadResults({
        success: true,
        message: 'CSV file uploaded successfully',
        count: result.count,
      });

      // Update the cached data
      queryClient.invalidateQueries({ queryKey: ['/api/algorithm-dependencies'] });

      toast({
        title: 'Upload Successful',
        description: `Successfully processed ${result.count} dependencies from CSV.`,
      });
    } catch (error) {
      console.error('Upload error:', error);
      
      setUploadResults({
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error occurred',
      });

      toast({
        title: 'Upload Failed',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="container mx-auto py-8">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl text-center">CSV Dependency Uploader</CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="flex flex-col items-center space-y-6">
            <div className="w-full flex justify-center">
              <div className="relative w-full max-w-xs">
                <Button 
                  variant={isUploading ? "outline" : "default"} 
                  className="w-full py-8 h-auto flex flex-col items-center gap-3"
                  disabled={isUploading}
                  onClick={() => {
                    // Create a file input and trigger click
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = '.csv';
                    input.onchange = (e) => {
                      if (e && e.target) {
                        const event = {
                          target: e.target
                        } as React.ChangeEvent<HTMLInputElement>;
                        handleFileUpload(event);
                      }
                    };
                    input.click();
                  }}
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      <span>Uploading...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="h-8 w-8 text-muted-foreground" />
                      <span>Select CSV File</span>
                      <span className="text-xs text-muted-foreground">
                        Click to browse for a CSV file
                      </span>
                    </>
                  )}
                </Button>
              </div>
            </div>

            {uploadResults && (
              <div 
                className={`text-center p-4 rounded-lg w-full ${
                  uploadResults.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
                }`}
              >
                <div className="flex items-center justify-center gap-2 mb-2">
                  {uploadResults.success ? (
                    <FileCheck className="h-5 w-5" />
                  ) : (
                    <AlertCircle className="h-5 w-5" />
                  )}
                  <span className="font-medium">{uploadResults.success ? 'Success!' : 'Error!'}</span>
                </div>
                <p>{uploadResults.message}</p>
                {uploadResults.count !== undefined && (
                  <p className="mt-1 font-medium">Imported {uploadResults.count} dependencies</p>
                )}
              </div>
            )}

            <div className="text-sm text-center text-muted-foreground">
              <p>Upload a CSV file with the following columns:</p>
              <p className="font-mono mt-1">name, version, category</p>
              <p className="mt-3">Example:</p>
              <p className="font-mono text-xs mt-1">numpy,2.1.1,Scientific Computing</p>
              <p className="font-mono text-xs">pandas,2.2.3,Data Analysis</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CsvUploader;