import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Integration, INTEGRATION_TYPES } from '@shared/schema';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

// Form validation schema
const integrationSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  type: z.enum([INTEGRATION_TYPES.NIFI, INTEGRATION_TYPES.SPARK, INTEGRATION_TYPES.FLINK]),
  endpoint: z.string().url('Must be a valid URL'),
  apiKey: z.string().optional(),
  config: z.object({
    username: z.string().optional(),
    password: z.string().optional(),
    port: z.string().optional(),
    authType: z.string().optional(),
    additionalParams: z.string().optional(),
  }).optional(),
});

type IntegrationFormData = z.infer<typeof integrationSchema>;

// Use any for integration type to avoid TypeScript errors
// In a real production environment, we would create a proper type definition
type FormIntegration = any;

interface IntegrationFormProps {
  integration?: FormIntegration;
  onSubmit: (data: IntegrationFormData) => void;
  isSubmitting: boolean;
  onCancel: () => void;
}

export function IntegrationForm({ 
  integration, 
  onSubmit, 
  isSubmitting,
  onCancel
}: IntegrationFormProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('basic');
  
  // Default values either from the existing integration or empty
  const defaultValues: IntegrationFormData = integration ? {
    name: integration.name,
    type: integration.type as any,
    endpoint: integration.endpoint,
    apiKey: integration.apiKey || '',
    config: {
      username: (integration.config as any)?.username || '',
      password: (integration.config as any)?.password || '',
      port: (integration.config as any)?.port || '',
      authType: (integration.config as any)?.authType || 'basic',
      additionalParams: (integration.config as any)?.additionalParams 
        ? JSON.stringify((integration.config as any).additionalParams, null, 2)
        : ''
    }
  } : {
    name: '',
    type: INTEGRATION_TYPES.NIFI,
    endpoint: '',
    apiKey: '',
    config: {
      username: '',
      password: '',
      port: '',
      authType: 'basic',
      additionalParams: ''
    }
  };

  const form = useForm<IntegrationFormData>({
    resolver: zodResolver(integrationSchema),
    defaultValues
  });

  const handleSubmit = (data: IntegrationFormData) => {
    // Parse additional params if provided
    if (data.config?.additionalParams) {
      try {
        const parsedParams = JSON.parse(data.config.additionalParams);
        data.config.additionalParams = parsedParams;
      } catch (error) {
        toast({
          title: 'Invalid JSON',
          description: 'Additional parameters must be valid JSON',
          variant: 'destructive',
        });
        return;
      }
    }
    
    onSubmit(data);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{integration ? 'Edit Integration' : 'Add New Integration'}</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="basic">Basic Settings</TabsTrigger>
                <TabsTrigger value="advanced">Advanced Settings</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4 mt-4">
                {/* Basic settings */}
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Integration Name</FormLabel>
                      <FormControl>
                        <Input placeholder="MyNiFi" {...field} />
                      </FormControl>
                      <FormDescription>
                        A descriptive name for this integration
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Integration Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value={INTEGRATION_TYPES.NIFI}>Apache NiFi</SelectItem>
                          <SelectItem value={INTEGRATION_TYPES.SPARK}>Apache Spark</SelectItem>
                          <SelectItem value={INTEGRATION_TYPES.FLINK}>Apache Flink</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        The type of system to integrate with
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endpoint"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Endpoint URL</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://nifi.example.com:8443" 
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        The URL of the integration endpoint including protocol and port
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="apiKey"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>API Key (optional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="api-key-123" 
                          {...field} 
                          type="password"
                        />
                      </FormControl>
                      <FormDescription>
                        API key for authentication if required
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>
              
              <TabsContent value="advanced" className="space-y-4 mt-4">
                {/* Advanced settings */}
                <FormField
                  control={form.control}
                  name="config.username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username (optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="admin" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="config.password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password (optional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="password" 
                          {...field} 
                          type="password"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="config.port"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Port Override (optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="8443" {...field} />
                      </FormControl>
                      <FormDescription>
                        Override the port specified in the endpoint URL
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="config.authType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Authentication Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select auth type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="basic">Basic Auth</SelectItem>
                          <SelectItem value="oauth">OAuth</SelectItem>
                          <SelectItem value="kerberos">Kerberos</SelectItem>
                          <SelectItem value="none">None</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="config.additionalParams"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Parameters (JSON)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder='{"paramName": "value"}'
                          {...field}
                          rows={5}
                        />
                      </FormControl>
                      <FormDescription>
                        Additional parameters as JSON
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </TabsContent>
            </Tabs>
            
            <CardFooter className="flex justify-between px-0">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Saving...' : integration ? 'Update Integration' : 'Add Integration'}
              </Button>
            </CardFooter>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}