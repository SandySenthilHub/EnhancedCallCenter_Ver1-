import { useState } from 'react';
import { Integration, INTEGRATION_TYPES } from '@shared/schema';
import { useIntegrations } from '@/hooks/use-integrations';

// Use any for now to avoid TypeScript issues
// In a production environment, we would properly type this
type FormIntegration = any;
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { IntegrationForm } from './IntegrationForm';
import { Plus, MoreVertical, RefreshCw, ExternalLink, Edit, Trash2, CheckCircle, XCircle } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export function IntegrationsList() {
  const [activeTab, setActiveTab] = useState('all');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [currentIntegration, setCurrentIntegration] = useState<FormIntegration | undefined>(undefined);
  const { 
    integrations,
    isLoadingIntegrations, 
    createIntegration, 
    updateIntegration, 
    deleteIntegration, 
    testIntegration,
    isCreating,
    isUpdating,
    isDeleting,
    isTesting
  } = useIntegrations();

  const handleEditIntegration = (integration: FormIntegration) => {
    setCurrentIntegration(integration);
    setIsFormOpen(true);
  };

  const handleDeleteIntegration = (id: number) => {
    if (confirm('Are you sure you want to delete this integration?')) {
      deleteIntegration(id);
    }
  };

  const handleTestIntegration = (id: number) => {
    testIntegration(id);
  };

  const handleSubmit = (data: any) => {
    if (currentIntegration) {
      updateIntegration({ id: currentIntegration.id, data });
    } else {
      createIntegration(data);
    }
    setIsFormOpen(false);
    setCurrentIntegration(undefined);
  };

  const handleAddNewClick = () => {
    setCurrentIntegration(undefined);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setCurrentIntegration(undefined);
  };

  // Filter integrations based on active tab
  const filteredIntegrations = integrations.filter(integration => {
    if (activeTab === 'all') return true;
    return integration.type === activeTab;
  });

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center">
          <div>
            <CardTitle className="text-xl">Integrations</CardTitle>
            <CardDescription>
              Connect to external data processing systems
            </CardDescription>
          </div>
          <Button 
            onClick={handleAddNewClick}
            className="mt-4 sm:mt-0"
          >
            <Plus className="mr-2 h-4 w-4" /> Add Integration
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value={INTEGRATION_TYPES.NIFI}>NiFi</TabsTrigger>
            <TabsTrigger value={INTEGRATION_TYPES.SPARK}>Spark</TabsTrigger>
            <TabsTrigger value={INTEGRATION_TYPES.FLINK}>Flink</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab}>
            {isLoadingIntegrations ? (
              <div className="flex justify-center py-8">
                <RefreshCw className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : filteredIntegrations.length === 0 ? (
              <Alert>
                <AlertTitle>No integrations found</AlertTitle>
                <AlertDescription>
                  {activeTab === 'all' 
                    ? "You haven't created any integrations yet."
                    : `You haven't created any ${activeTab} integrations yet.`
                  }
                </AlertDescription>
              </Alert>
            ) : (
              <ScrollArea className="h-[400px]">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {filteredIntegrations.map((integration) => (
                    <IntegrationCard 
                      key={integration.id} 
                      integration={integration} 
                      onEdit={handleEditIntegration}
                      onDelete={handleDeleteIntegration}
                      onTest={handleTestIntegration}
                      isTesting={isTesting}
                    />
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>
        </Tabs>

        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogContent className="max-w-2xl">
            <IntegrationForm 
              integration={currentIntegration}
              onSubmit={handleSubmit}
              onCancel={handleCloseForm}
              isSubmitting={isCreating || isUpdating}
            />
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}

interface IntegrationCardProps {
  integration: FormIntegration;
  onEdit: (integration: FormIntegration) => void;
  onDelete: (id: number) => void;
  onTest: (id: number) => void;
  isTesting: boolean;
}

function IntegrationCard({ integration, onEdit, onDelete, onTest, isTesting }: IntegrationCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
        return <Badge className="bg-green-500 text-white">Connected</Badge>;
      case 'disconnected':
        return <Badge variant="outline" className="text-red-500 border-red-500">Disconnected</Badge>;
      case 'pending':
        return <Badge variant="outline" className="text-amber-500 border-amber-500">Pending</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case INTEGRATION_TYPES.NIFI:
        return "🔄"; // Flow icon
      case INTEGRATION_TYPES.SPARK:
        return "⚡"; // Lightning bolt
      case INTEGRATION_TYPES.FLINK:
        return "🌊"; // Wave
      default:
        return "🔌"; // Plug
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="p-4 pb-2 space-y-0">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <span className="text-2xl mr-2">{getTypeIcon(integration.type)}</span>
            <div>
              <CardTitle className="text-base">{integration.name}</CardTitle>
              <CardDescription className="text-xs">{integration.type.toUpperCase()}</CardDescription>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit(integration)}>
                <Edit className="mr-2 h-4 w-4" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onTest(integration.id)}>
                <RefreshCw className={`mr-2 h-4 w-4 ${isTesting ? 'animate-spin' : ''}`} /> 
                Test Connection
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onDelete(integration.id)}>
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="mt-2 text-sm">
          <div className="flex items-center mb-1">
            <ExternalLink className="h-3 w-3 mr-2 text-muted-foreground" />
            <span className="text-xs truncate">{integration.endpoint}</span>
          </div>
          <div className="flex items-center justify-between mt-2">
            <div>
              {integration.status === 'connected' ? (
                <div className="flex items-center">
                  <CheckCircle className="h-3 w-3 mr-1 text-green-500" />
                  <span className="text-xs text-green-500">Connected</span>
                </div>
              ) : (
                <div className="flex items-center">
                  <XCircle className="h-3 w-3 mr-1 text-red-500" />
                  <span className="text-xs text-red-500">Disconnected</span>
                </div>
              )}
            </div>
            {getStatusBadge(integration.status)}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}