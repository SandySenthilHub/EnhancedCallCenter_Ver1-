import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface HyperparameterTuningProps {
  algorithmId: string;
}

const HyperparameterTuning: React.FC<HyperparameterTuningProps> = ({ algorithmId }) => {
  // Parameters for linear regression
  const [fitIntercept, setFitIntercept] = useState<boolean>(true);
  const [alpha, setAlpha] = useState<number>(1.0);
  const [normalized, setNormalized] = useState<boolean>(true);
  const [tuningStrategy, setTuningStrategy] = useState<string>('grid_search');
  const [cvFolds, setCvFolds] = useState<number>(5);
  const [scoringMetric, setScoringMetric] = useState<string>('mean_squared_error');

  // Render parameters based on selected algorithm
  const renderAlgorithmParameters = () => {
    switch (algorithmId) {
      case 'linear_regression':
        return (
          <div>
            <h4 className="text-sm font-medium mb-3">Linear Regression Parameters</h4>
            
            <div className="space-y-4">
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  fit_intercept
                </Label>
                <div className="flex items-center space-x-4">
                  <RadioGroup value={fitIntercept ? "true" : "false"} onValueChange={(val) => setFitIntercept(val === "true")}>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="true" id="fit-intercept-true" />
                        <Label htmlFor="fit-intercept-true">True</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="false" id="fit-intercept-false" />
                        <Label htmlFor="fit-intercept-false">False</Label>
                      </div>
                    </div>
                  </RadioGroup>
                </div>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  alpha (regularization strength)
                </Label>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-neutral-500">0.0</span>
                  <Slider
                    defaultValue={[1.0]}
                    max={10}
                    step={0.1}
                    value={[alpha]}
                    onValueChange={([value]) => setAlpha(value)}
                    className="w-full"
                  />
                  <span className="text-sm text-neutral-500">10.0</span>
                </div>
                <div className="text-center text-xs text-neutral-500 mt-1">Current: {alpha.toFixed(1)}</div>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  Normalized
                </Label>
                <RadioGroup value={normalized ? "true" : "false"} onValueChange={(val) => setNormalized(val === "true")}>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="true" id="normalized-true" />
                      <Label htmlFor="normalized-true">True</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="false" id="normalized-false" />
                      <Label htmlFor="normalized-false">False</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>
            </div>
          </div>
        );
      
      case 'kmeans':
        return (
          <div>
            <h4 className="text-sm font-medium mb-3">K-Means Parameters</h4>
            
            <div className="space-y-4">
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  n_clusters
                </Label>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-neutral-500">2</span>
                  <Slider
                    defaultValue={[5]}
                    min={2}
                    max={15}
                    step={1}
                    className="w-full"
                  />
                  <span className="text-sm text-neutral-500">15</span>
                </div>
                <div className="text-center text-xs text-neutral-500 mt-1">Current: 5</div>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  init
                </Label>
                <Select defaultValue="k-means++">
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select initialization method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="k-means++">k-means++</SelectItem>
                    <SelectItem value="random">random</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  max_iter
                </Label>
                <Input type="number" defaultValue="300" min="10" max="1000" />
              </div>
            </div>
          </div>
        );
      
      default:
        return (
          <div className="text-sm text-neutral-500 italic">
            Select an algorithm to configure hyperparameters
          </div>
        );
    }
  };

  return (
    <Card className="bg-white shadow mb-6">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Hyperparameter Tuning</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-medium mb-3">Parameter Configuration</h4>
            
            <div className="space-y-4">
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  Tuning Strategy
                </Label>
                <Select value={tuningStrategy} onValueChange={setTuningStrategy}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select tuning strategy" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grid_search">Grid Search</SelectItem>
                    <SelectItem value="random_search">Random Search</SelectItem>
                    <SelectItem value="bayesian">Bayesian Optimization</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  Cross-Validation Folds
                </Label>
                <Input 
                  type="number" 
                  value={cvFolds} 
                  onChange={(e) => setCvFolds(parseInt(e.target.value))} 
                  min={2} 
                  max={10} 
                />
              </div>
              
              <div>
                <Label className="block text-sm font-medium text-neutral-600 mb-1">
                  Scoring Metric
                </Label>
                <Select value={scoringMetric} onValueChange={setScoringMetric}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select scoring metric" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mean_squared_error">Mean Squared Error</SelectItem>
                    <SelectItem value="root_mean_squared_error">Root Mean Squared Error</SelectItem>
                    <SelectItem value="mean_absolute_error">Mean Absolute Error</SelectItem>
                    <SelectItem value="r2">R² Score</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <div>
            {renderAlgorithmParameters()}
          </div>
        </div>
        
        <div className="mt-6">
          <Button className="bg-primary text-white hover:bg-primary/90">
            <span className="material-icons text-sm mr-2">play_arrow</span>
            Start Hyperparameter Tuning
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default HyperparameterTuning;
