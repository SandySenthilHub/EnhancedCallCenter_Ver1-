import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { FeatureEngineeringStep } from '@/types';

const FeatureEngineeringHub: React.FC = () => {
  const [selectedSteps, setSelectedSteps] = useState<FeatureEngineeringStep[]>([]);
  const [codePreview, setCodePreview] = useState<string>(`# Generated code for feature engineering
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

# Load dataset
df = pd.read_csv("customer_transaction_history.csv")

# 1. Handle missing values
numerical_cols = df.select_dtypes(include=['number']).columns
imputer = SimpleImputer(strategy='mean')
df[numerical_cols] = imputer.fit_transform(df[numerical_cols])

# 2. Feature scaling
scaler = StandardScaler()
df[numerical_cols] = scaler.fit_transform(df[numerical_cols])

# 3. Categorical encoding
categorical_cols = ['customer_type', 'transaction_type', 'region', 'channel']
df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

# Prepare features and target
X = df_encoded.drop('transaction_amount', axis=1)
y = df_encoded['transaction_amount']`);

  const handleStepChange = (checked: boolean, step: FeatureEngineeringStep) => {
    if (checked) {
      setSelectedSteps([...selectedSteps, step]);
    } else {
      setSelectedSteps(selectedSteps.filter(s => 
        s.type !== step.type || s.config.method !== step.config.method
      ));
    }
    
    // In a real implementation, this would call the backend to generate code
    // For now, we're just displaying the static code preview
  };

  return (
    <Card className="bg-white shadow mb-6">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Feature Engineering Hub</h3>
        
        <div className="border border-neutral-300 rounded-lg p-4 mb-4">
          <h4 className="font-medium mb-3">Selected Dataset: <span className="text-primary">customer_transaction_history.csv</span></h4>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <h5 className="text-sm font-medium mb-2">Data Overview</h5>
              <div className="text-sm text-neutral-500">
                <div className="flex justify-between mb-1">
                  <span>Rows:</span>
                  <span>24,561</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span>Columns:</span>
                  <span>18</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span>Missing Values:</span>
                  <span className="text-warning">2.3%</span>
                </div>
              </div>
            </div>
            
            <div>
              <h5 className="text-sm font-medium mb-2">Column Types</h5>
              <div className="text-sm text-neutral-500">
                <div className="flex justify-between mb-1">
                  <span>Numeric:</span>
                  <span>12</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span>Categorical:</span>
                  <span>4</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span>Datetime:</span>
                  <span>2</span>
                </div>
              </div>
            </div>
            
            <div>
              <h5 className="text-sm font-medium mb-2">Target Variable</h5>
              <div className="flex items-center">
                <Select defaultValue="transaction_amount">
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select target variable" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="transaction_amount">transaction_amount</SelectItem>
                    <SelectItem value="is_fraudulent">is_fraudulent</SelectItem>
                    <SelectItem value="customer_lifetime_value">customer_lifetime_value</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <h5 className="text-sm font-medium">Suggested Feature Engineering Steps</h5>
              <button className="text-xs text-primary hover:underline">View All Techniques</button>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center p-2 border border-neutral-200 rounded-md bg-neutral-50">
                <Checkbox 
                  id="fe-missing" 
                  onCheckedChange={(checked) => 
                    handleStepChange(checked as boolean, {
                      type: 'missing_values',
                      config: { method: 'mean' }
                    })
                  }
                />
                <Label htmlFor="fe-missing" className="ml-2 text-sm text-neutral-600">
                  <span className="font-medium">Handle Missing Values</span> - Impute missing values with mean/median
                </Label>
                <div className="ml-auto">
                  <Select defaultValue="mean">
                    <SelectTrigger className="h-6 text-xs min-w-[100px]">
                      <SelectValue placeholder="Method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mean">Mean</SelectItem>
                      <SelectItem value="median">Median</SelectItem>
                      <SelectItem value="mode">Mode</SelectItem>
                      <SelectItem value="zero">Zero</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex items-center p-2 border border-neutral-200 rounded-md bg-neutral-50">
                <Checkbox 
                  id="fe-scaling" 
                  onCheckedChange={(checked) => 
                    handleStepChange(checked as boolean, {
                      type: 'scaling',
                      config: { method: 'standard' }
                    })
                  }
                />
                <Label htmlFor="fe-scaling" className="ml-2 text-sm text-neutral-600">
                  <span className="font-medium">Feature Scaling</span> - Standardize numerical features
                </Label>
                <div className="ml-auto">
                  <Select defaultValue="standard">
                    <SelectTrigger className="h-6 text-xs min-w-[100px]">
                      <SelectValue placeholder="Method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">StandardScaler</SelectItem>
                      <SelectItem value="minmax">MinMaxScaler</SelectItem>
                      <SelectItem value="robust">RobustScaler</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex items-center p-2 border border-neutral-200 rounded-md bg-neutral-50">
                <Checkbox 
                  id="fe-encoding" 
                  onCheckedChange={(checked) => 
                    handleStepChange(checked as boolean, {
                      type: 'encoding',
                      config: { method: 'onehot' }
                    })
                  }
                />
                <Label htmlFor="fe-encoding" className="ml-2 text-sm text-neutral-600">
                  <span className="font-medium">Categorical Encoding</span> - Convert categorical variables to numeric
                </Label>
                <div className="ml-auto">
                  <Select defaultValue="onehot">
                    <SelectTrigger className="h-6 text-xs min-w-[100px]">
                      <SelectValue placeholder="Method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="onehot">One-Hot Encoding</SelectItem>
                      <SelectItem value="label">Label Encoding</SelectItem>
                      <SelectItem value="target">Target Encoding</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h5 className="text-sm font-medium mb-2">Generated Code Preview</h5>
            <pre className="code-editor text-sm rounded-md overflow-x-auto whitespace-pre-wrap">
              {codePreview}
            </pre>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FeatureEngineeringHub;
