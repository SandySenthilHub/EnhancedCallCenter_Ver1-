import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import type { AlgorithmOption, ModelType } from '@/types';

interface AlgorithmSelectionProps {
  modelType: ModelType;
  onSelectAlgorithm: (algorithm: AlgorithmOption) => void;
}

const AlgorithmSelection: React.FC<AlgorithmSelectionProps> = ({ 
  modelType,
  onSelectAlgorithm
}) => {
  const [selectedAlgorithmId, setSelectedAlgorithmId] = useState<string>(
    modelType.algorithms.length > 0 ? modelType.algorithms[0].id : ''
  );

  const handleChange = (value: string) => {
    setSelectedAlgorithmId(value);
    const selectedAlgorithm = modelType.algorithms.find(algo => algo.id === value);
    if (selectedAlgorithm) {
      onSelectAlgorithm(selectedAlgorithm);
    }
  };

  return (
    <Card className="bg-white shadow mb-6">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Algorithm Selection</h3>
        
        <RadioGroup 
          value={selectedAlgorithmId}
          onValueChange={handleChange}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {modelType.algorithms.map((algorithm) => (
            <div 
              key={algorithm.id}
              className={`border rounded-lg p-4 ${
                selectedAlgorithmId === algorithm.id 
                  ? 'border-primary bg-primary bg-opacity-5' 
                  : 'border-neutral-300 hover:border-primary'
              }`}
            >
              <div className="flex items-start">
                <RadioGroupItem id={`algo-${algorithm.id}`} value={algorithm.id} className="mt-1" />
                <div className="ml-2">
                  <Label htmlFor={`algo-${algorithm.id}`} className="font-medium text-neutral-600">
                    {algorithm.name}
                  </Label>
                  <p className="text-sm text-neutral-500 mt-1">
                    {algorithm.description}
                  </p>
                  <div className="flex items-center mt-2 flex-wrap gap-2">
                    {algorithm.features.map((feature, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-neutral-100 text-neutral-600">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  );
};

export default AlgorithmSelection;
