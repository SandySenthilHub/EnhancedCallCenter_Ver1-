import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface TrainingControlsProps {
  modelType: string;
  algorithm: string;
  onStartTraining?: () => void;
}

const TrainingControls: React.FC<TrainingControlsProps> = ({ 
  modelType, 
  algorithm,
  onStartTraining 
}) => {
  const [dataset, setDataset] = useState<string>("customer_transaction_history.csv");
  const [splitRatio, setSplitRatio] = useState<number>(70);
  const [randomSeed, setRandomSeed] = useState<number>(42);
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const { toast } = useToast();

  const handleTrainModel = async () => {
    setIsTraining(true);
    try {
      const response = await apiRequest('POST', '/api/python/train-model', {
        type: modelType,
        algorithm: algorithm,
        dataset: dataset,
        parameters: {
          test_size: (100 - splitRatio) / 100,
          random_state: randomSeed
        }
      });
      
      toast({
        title: "Model Training Started",
        description: "Your model training job has been submitted successfully.",
        variant: "default",
      });
      
      if (onStartTraining) {
        onStartTraining();
      }
    } catch (error) {
      toast({
        title: "Training Error",
        description: "There was an error starting the model training job.",
        variant: "destructive",
      });
      console.error("Error training model:", error);
    } finally {
      setIsTraining(false);
    }
  };

  return (
    <Card className="bg-white shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Model Training</h3>
          <div className="flex space-x-2">
            <Button variant="outline">
              <span className="material-icons text-sm mr-2">save</span>
              Save Configuration
            </Button>
            <Button 
              className="bg-secondary text-white hover:bg-secondary/90" 
              onClick={handleTrainModel}
              disabled={isTraining}
            >
              {isTraining ? (
                <>
                  <span className="material-icons text-sm mr-2 animate-spin">autorenew</span>
                  Training...
                </>
              ) : (
                <>
                  <span className="material-icons text-sm mr-2">play_arrow</span>
                  Train Model
                </>
              )}
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="border border-neutral-300 rounded-lg p-4">
            <Label htmlFor="dataset" className="text-sm font-medium mb-2 block">Training Dataset</Label>
            <Select value={dataset} onValueChange={setDataset}>
              <SelectTrigger id="dataset" className="w-full">
                <SelectValue placeholder="Select dataset" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="customer_transaction_history.csv">customer_transaction_history.csv</SelectItem>
                <SelectItem value="fraud_detection_dataset.csv">fraud_detection_dataset.csv</SelectItem>
                <SelectItem value="customer_segments_data.csv">customer_segments_data.csv</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="border border-neutral-300 rounded-lg p-4">
            <Label className="text-sm font-medium mb-2 block">Train/Test Split</Label>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-neutral-500">70/30</span>
              <Slider 
                defaultValue={[70]} 
                min={50} 
                max={90} 
                step={5} 
                value={[splitRatio]}
                onValueChange={([value]) => setSplitRatio(value)}
                className="w-full"
              />
              <span className="text-sm text-neutral-500">90/10</span>
            </div>
            <div className="text-center text-xs text-neutral-500 mt-1">
              Training: {splitRatio}% | Testing: {100 - splitRatio}%
            </div>
          </div>
          
          <div className="border border-neutral-300 rounded-lg p-4">
            <Label htmlFor="randomSeed" className="text-sm font-medium mb-2 block">Random Seed</Label>
            <Input 
              id="randomSeed"
              type="number" 
              value={randomSeed} 
              onChange={(e) => setRandomSeed(parseInt(e.target.value))}
            />
            <div className="text-xs text-neutral-500 mt-1">For reproducible results</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TrainingControls;
