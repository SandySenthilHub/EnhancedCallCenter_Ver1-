import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import type { ModelType } from '@/types';

const modelTypes: ModelType[] = [
  {
    id: 'regression',
    name: 'Regression',
    description: 'Predict continuous numerical values based on input variables.',
    examples: ['Price prediction', 'Demand forecasting'],
    algorithms: [
      {
        id: 'linear_regression',
        name: 'Linear Regression',
        description: 'Models the relationship between variables with a linear equation.',
        features: ['Interpretable', 'Fast Training']
      },
      {
        id: 'polynomial_regression',
        name: 'Polynomial Regression',
        description: 'Extends linear regression for modeling non-linear relationships.',
        features: ['Non-linear', 'Moderate Complexity']
      },
      {
        id: 'neural_automl',
        name: 'Neural AutoML',
        description: 'Automated neural network optimization for complex regression tasks.',
        features: ['High Complexity', 'High Accuracy']
      }
    ]
  },
  {
    id: 'classification',
    name: 'Classification',
    description: 'Categorize inputs into discrete classes or labels.',
    examples: ['Fraud detection', 'Sentiment analysis'],
    algorithms: [
      {
        id: 'logistic_regression',
        name: 'Logistic Regression',
        description: 'Predicts the probability of categorical dependent variables.',
        features: ['Interpretable', 'Fast Training']
      },
      {
        id: 'random_forest',
        name: 'Random Forest',
        description: 'Ensemble learning method for classification and regression.',
        features: ['High Accuracy', 'Handles Non-linearity']
      },
      {
        id: 'gradient_boosting',
        name: 'Gradient Boosting',
        description: 'Produces a prediction model in the form of an ensemble of weak models.',
        features: ['High Accuracy', 'Prevents Overfitting']
      }
    ]
  },
  {
    id: 'clustering',
    name: 'Clustering',
    description: 'Group similar data points into clusters.',
    examples: ['Customer segmentation', 'Anomaly detection'],
    algorithms: [
      {
        id: 'kmeans',
        name: 'K-Means Clustering',
        description: 'Partitions n observations into k clusters where each observation belongs to the cluster with the nearest mean.',
        features: ['Fast', 'Interpretable']
      },
      {
        id: 'dbscan',
        name: 'DBSCAN',
        description: 'Density-based spatial clustering of applications with noise.',
        features: ['No Predefined Clusters', 'Handles Outliers']
      }
    ]
  }
];

interface ModelTypeSelectionProps {
  onSelectModelType: (modelType: ModelType) => void;
}

const ModelTypeSelection: React.FC<ModelTypeSelectionProps> = ({ onSelectModelType }) => {
  const [selectedTypeId, setSelectedTypeId] = useState<string>('regression');

  const handleChange = (value: string) => {
    setSelectedTypeId(value);
    const selectedType = modelTypes.find(type => type.id === value);
    if (selectedType) {
      onSelectModelType(selectedType);
    }
  };

  return (
    <Card className="bg-white shadow mb-6">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Select Model Type</h3>
        
        <RadioGroup 
          defaultValue="regression"
          value={selectedTypeId}
          onValueChange={handleChange}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          {modelTypes.map((type) => (
            <div 
              key={type.id}
              className={`border rounded-lg p-4 ${
                selectedTypeId === type.id 
                  ? 'border-primary bg-primary bg-opacity-5' 
                  : 'border-neutral-300 hover:border-primary'
              }`}
            >
              <div className="flex items-center mb-3">
                <RadioGroupItem id={`radio-${type.id}`} value={type.id} />
                <Label htmlFor={`radio-${type.id}`} className="ml-2 font-medium text-neutral-600">
                  {type.name}
                </Label>
              </div>
              <p className="text-sm text-neutral-500 mb-2">
                {type.description}
              </p>
              <div className="text-xs text-neutral-400">
                Examples: {type.examples.join(', ')}
              </div>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  );
};

export default ModelTypeSelection;
