import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Sparkles, ThumbsUp, AlertCircle, Info, Check, Copy, Brain } from 'lucide-react';
import { 
  useAISuggestions, 
  FeatureNameSuggestion, 
  FeatureNameSuggestionParams,
  BatchFeatureParams
} from '@/hooks/use-ai-suggestions';

interface AIFeatureNameSuggestionProps {
  initialFeatureName?: string;
  dataType?: string;
  statistics?: any;
  domain?: string;
  onSelect?: (name: string) => void;
  showMultiFeatureMode?: boolean;
}

const AIFeatureNameSuggestion: React.FC<AIFeatureNameSuggestionProps> = ({
  initialFeatureName = '',
  dataType = '',
  statistics,
  domain = '',
  onSelect,
  showMultiFeatureMode = false
}) => {
  const { toast } = useToast();
  const { getFeatureNameSuggestions, getBatchFeatureNameSuggestions } = useAISuggestions();
  const [activeTab, setActiveTab] = useState('single');
  const [suggestions, setSuggestions] = useState<FeatureNameSuggestion[]>([]);
  const [selectedName, setSelectedName] = useState<string>('');
  
  // Single feature mode state
  const [featureName, setFeatureName] = useState(initialFeatureName);
  const [featureType, setFeatureType] = useState(dataType);
  const [featureDomain, setFeatureDomain] = useState(domain);
  const [datasetDescription, setDatasetDescription] = useState('');
  
  // Multi-feature mode state
  const [features, setFeatures] = useState<BatchFeatureParams[]>([
    { name: initialFeatureName, dataType: dataType, statistics: statistics }
  ]);
  const [batchDescription, setBatchDescription] = useState('');
  const [batchDomain, setBatchDomain] = useState(domain);
  
  // Function to handle getting suggestions for a single feature
  const handleGetSuggestions = async () => {
    if (!featureName.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide a current feature name",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const params: FeatureNameSuggestionParams = {
        currentName: featureName,
        dataType: featureType,
        domain: featureDomain,
        datasetDescription: datasetDescription || undefined,
        statistics: statistics
      };
      
      const result = await getFeatureNameSuggestions.mutateAsync(params);
      setSuggestions(result.suggestions);
      
      if (result.suggestions.length === 0) {
        toast({
          title: "No Suggestions",
          description: "AI couldn't generate any name suggestions. Try providing more context.",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to get AI suggestions",
        variant: "destructive"
      });
    }
  };
  
  // Function to handle getting suggestions for multiple features
  const handleGetBatchSuggestions = async () => {
    if (features.length === 0 || !features.some(f => f.name)) {
      toast({
        title: "Missing Information",
        description: "Please provide at least one feature name",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const result = await getBatchFeatureNameSuggestions.mutateAsync({
        features: features,
        datasetDescription: batchDescription || undefined,
        domain: batchDomain || undefined
      });
      
      // Update features with suggestions
      const updatedFeatures = [...features];
      result.suggestions.forEach(suggestion => {
        const featureIndex = features.findIndex(f => f.name === suggestion.originalName);
        if (featureIndex >= 0) {
          updatedFeatures[featureIndex] = {
            ...updatedFeatures[featureIndex],
            suggestedName: suggestion.suggestedName,
            reason: suggestion.reason
          };
        }
      });
      
      setFeatures(updatedFeatures);
      
      toast({
        title: "Suggestions Generated",
        description: `Generated suggestions for ${result.suggestions.length} features`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to get AI suggestions for multiple features",
        variant: "destructive"
      });
    }
  };
  
  // Function to handle selecting a suggestion
  const handleSelectSuggestion = (suggestion: FeatureNameSuggestion) => {
    setSelectedName(suggestion.name);
    if (onSelect) {
      onSelect(suggestion.name);
    }
    
    toast({
      title: "Name Selected",
      description: `Selected "${suggestion.name}" as the feature name`,
    });
  };
  
  // Function to add a new feature to the batch
  const handleAddFeature = () => {
    setFeatures([...features, { name: '', dataType: '' }]);
  };
  
  // Function to remove a feature from the batch
  const handleRemoveFeature = (index: number) => {
    if (features.length > 1) {
      const updatedFeatures = [...features];
      updatedFeatures.splice(index, 1);
      setFeatures(updatedFeatures);
    }
  };
  
  // Function to update a feature in the batch
  const handleFeatureChange = (index: number, field: keyof BatchFeatureParams, value: string) => {
    const updatedFeatures = [...features];
    updatedFeatures[index] = {
      ...updatedFeatures[index],
      [field]: value
    };
    setFeatures(updatedFeatures);
  };
  
  // Function to apply a suggested name
  const handleApplySuggestion = (index: number) => {
    const feature = features[index];
    if (feature.suggestedName && onSelect) {
      onSelect(feature.suggestedName);
      
      toast({
        title: "Name Applied",
        description: `Applied "${feature.suggestedName}" as the feature name`,
      });
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-primary" />
          <CardTitle>AI Feature Name Suggestions</CardTitle>
        </div>
        <CardDescription>
          Use AI to generate meaningful feature names based on data and context
        </CardDescription>
      </CardHeader>
      <CardContent>
        {showMultiFeatureMode ? (
          <Tabs defaultValue="single" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="single">Single Feature</TabsTrigger>
              <TabsTrigger value="multiple">Multiple Features</TabsTrigger>
            </TabsList>
            
            <TabsContent value="single">
              {renderSingleFeatureContent()}
            </TabsContent>
            
            <TabsContent value="multiple">
              {renderBatchFeatureContent()}
            </TabsContent>
          </Tabs>
        ) : (
          renderSingleFeatureContent()
        )}
      </CardContent>
    </Card>
  );
  
  // Render content for single feature mode
  function renderSingleFeatureContent() {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label htmlFor="feature-name">Current Feature Name</Label>
            <Input
              id="feature-name"
              placeholder="e.g., f1, x_12, column_name"
              value={featureName}
              onChange={(e) => setFeatureName(e.target.value)}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="feature-type">Data Type</Label>
              <Select value={featureType} onValueChange={setFeatureType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select data type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="numerical">Numerical</SelectItem>
                  <SelectItem value="categorical">Categorical</SelectItem>
                  <SelectItem value="boolean">Boolean</SelectItem>
                  <SelectItem value="datetime">Date/Time</SelectItem>
                  <SelectItem value="text">Text</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="domain">Domain (Optional)</Label>
              <Select value={featureDomain} onValueChange={setFeatureDomain}>
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="ecommerce">E-Commerce</SelectItem>
                  <SelectItem value="real_estate">Real Estate</SelectItem>
                  <SelectItem value="manufacturing">Manufacturing</SelectItem>
                  <SelectItem value="hr">Human Resources</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="dataset-desc">Dataset Description (Optional)</Label>
            <Textarea
              id="dataset-desc"
              placeholder="Briefly describe what the dataset represents..."
              value={datasetDescription}
              onChange={(e) => setDatasetDescription(e.target.value)}
            />
          </div>
          
          <Button 
            onClick={handleGetSuggestions}
            disabled={getFeatureNameSuggestions.isPending}
            className="w-full"
          >
            {getFeatureNameSuggestions.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Suggestions...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Name Suggestions
              </>
            )}
          </Button>
        </div>
        
        {getFeatureNameSuggestions.isError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              {(getFeatureNameSuggestions.error as Error).message || "Failed to get suggestions"}
            </AlertDescription>
          </Alert>
        )}
        
        {suggestions.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-medium mb-4">Suggested Feature Names</h3>
            <div className="space-y-3">
              {suggestions.map((suggestion, index) => (
                <Card key={index} className={`border ${selectedName === suggestion.name ? 'border-primary' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-base">{suggestion.name}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{suggestion.reason}</p>
                        <div className="flex items-center mt-2">
                          <span className="text-xs text-muted-foreground mr-2">Confidence:</span>
                          <div className="w-24 bg-muted rounded-full h-2">
                            <div
                              className="bg-primary rounded-full h-2"
                              style={{ width: `${suggestion.confidence * 100}%` }}
                            />
                          </div>
                          <span className="text-xs ml-2">{Math.round(suggestion.confidence * 100)}%</span>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => {
                            navigator.clipboard.writeText(suggestion.name);
                            toast({
                              title: "Copied",
                              description: `"${suggestion.name}" copied to clipboard`,
                            });
                          }}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm"
                          variant="default"
                          onClick={() => handleSelectSuggestion(suggestion)}
                        >
                          <Check className="h-4 w-4 mr-1" />
                          Select
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }
  
  // Render content for batch feature mode
  function renderBatchFeatureContent() {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label htmlFor="batch-domain">Domain (Optional)</Label>
            <Select value={batchDomain} onValueChange={setBatchDomain}>
              <SelectTrigger>
                <SelectValue placeholder="Select domain" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="retail">Retail</SelectItem>
                <SelectItem value="ecommerce">E-Commerce</SelectItem>
                <SelectItem value="real_estate">Real Estate</SelectItem>
                <SelectItem value="manufacturing">Manufacturing</SelectItem>
                <SelectItem value="hr">Human Resources</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
                <SelectItem value="general">General</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="batch-desc">Dataset Description (Optional)</Label>
            <Textarea
              id="batch-desc"
              placeholder="Briefly describe what the dataset represents..."
              value={batchDescription}
              onChange={(e) => setBatchDescription(e.target.value)}
            />
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-medium">Features</h3>
              <Button size="sm" variant="outline" onClick={handleAddFeature}>
                Add Feature
              </Button>
            </div>
            
            {features.map((feature, index) => (
              <div key={index} className="border rounded-md p-4 space-y-3">
                <div className="flex justify-between">
                  <h4 className="text-sm font-medium">Feature {index + 1}</h4>
                  {features.length > 1 && (
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      onClick={() => handleRemoveFeature(index)}
                    >
                      Remove
                    </Button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Current Name</Label>
                    <Input
                      value={feature.name || ''}
                      onChange={(e) => handleFeatureChange(index, 'name', e.target.value)}
                      placeholder="Current feature name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Data Type</Label>
                    <Select
                      value={feature.dataType || ''}
                      onValueChange={(value) => handleFeatureChange(index, 'dataType', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select data type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="numerical">Numerical</SelectItem>
                        <SelectItem value="categorical">Categorical</SelectItem>
                        <SelectItem value="boolean">Boolean</SelectItem>
                        <SelectItem value="datetime">Date/Time</SelectItem>
                        <SelectItem value="text">Text</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Description (Optional)</Label>
                  <Textarea
                    value={feature.description || ''}
                    onChange={(e) => handleFeatureChange(index, 'description', e.target.value)}
                    placeholder="Brief description of what this feature represents"
                  />
                </div>
                
                {feature.suggestedName && (
                  <div className="bg-muted p-3 rounded-md mt-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <h5 className="text-sm font-medium">Suggested Name: <span className="text-primary">{feature.suggestedName}</span></h5>
                        {feature.reason && (
                          <p className="text-xs text-muted-foreground mt-1">{feature.reason}</p>
                        )}
                      </div>
                      <Button size="sm" onClick={() => handleApplySuggestion(index)}>Apply</Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          <Button 
            onClick={handleGetBatchSuggestions}
            disabled={getBatchFeatureNameSuggestions.isPending}
            className="w-full"
          >
            {getBatchFeatureNameSuggestions.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Suggestions...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generate Name Suggestions
              </>
            )}
          </Button>
        </div>
        
        {getBatchFeatureNameSuggestions.isError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              {(getBatchFeatureNameSuggestions.error as Error).message || "Failed to get suggestions"}
            </AlertDescription>
          </Alert>
        )}
      </div>
    );
  }
};

export default AIFeatureNameSuggestion;