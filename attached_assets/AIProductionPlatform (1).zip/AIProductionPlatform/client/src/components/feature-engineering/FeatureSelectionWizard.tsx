import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from 'recharts';
import {
  ChevronRight,
  ChevronLeft,
  Upload,
  Download,
  BarChart2,
  PieChart as PieChartIcon,
  ScatterChart as ScatterChartIcon,
  Activity,
  Table,
  CheckCircle2,
  AlertTriangle,
  Info,
  Filter,
  RefreshCw,
  Save,
  Search,
  TrendingUp,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Sample datasets for demonstration
const sampleDatasets = [
  { id: 'housing', name: 'Housing Prices Dataset', features: 14, rows: 506 },
  { id: 'diabetes', name: 'Diabetes Dataset', features: 10, rows: 442 },
  { id: 'iris', name: 'Iris Flower Dataset', features: 4, rows: 150 },
  { id: 'wine', name: 'Wine Quality Dataset', features: 12, rows: 4898 },
  { id: 'custom', name: 'Upload Your Dataset', features: 0, rows: 0 },
];

// Sample data for various visualizations
interface CorrelationData {
  name: string;
  price: number;
  quality: number;
  risk: number;
  [key: string]: string | number;
}

const correlationData: CorrelationData[] = [
  { name: 'age', price: 0.64, quality: -0.12, risk: 0.31 },
  { name: 'income', price: 0.78, quality: 0.42, risk: -0.27 },
  { name: 'rooms', price: 0.69, quality: 0.36, risk: -0.11 },
  { name: 'year', price: -0.34, quality: 0.81, risk: -0.56 },
  { name: 'area', price: 0.92, quality: 0.23, risk: 0.04 },
];

const distributionData = [
  { value: 0, count: 12 },
  { value: 10, count: 19 },
  { value: 20, count: 34 },
  { value: 30, count: 45 },
  { value: 40, count: 37 },
  { value: 50, count: 29 },
  { value: 60, count: 19 },
  { value: 70, count: 14 },
  { value: 80, count: 8 },
  { value: 90, count: 5 },
  { value: 100, count: 2 },
];

const scatterData = Array.from({ length: 100 }, (_, i) => ({
  x: Math.random() * 100,
  y: Math.random() * 100 + Math.random() * 50 * (i % 3),
  z: Math.random() * 30 + 10,
  group: i % 3,
}));

const importanceData = [
  { name: 'area', value: 0.35, color: '#8884d8' },
  { name: 'income', value: 0.23, color: '#83a6ed' },
  { name: 'rooms', value: 0.15, color: '#8dd1e1' },
  { name: 'age', value: 0.12, color: '#82ca9d' },
  { name: 'year', value: 0.08, color: '#a4de6c' },
  { name: 'bathrooms', value: 0.04, color: '#d0ed57' },
  { name: 'floor', value: 0.03, color: '#ffc658' },
];

const radarData = [
  {
    feature: 'area',
    importance: 0.9,
    correlation: 0.8,
    missing_values: 0.1,
  },
  {
    feature: 'income',
    importance: 0.7,
    correlation: 0.6,
    missing_values: 0.2,
  },
  {
    feature: 'rooms',
    importance: 0.6,
    correlation: 0.5,
    missing_values: 0.0,
  },
  {
    feature: 'year',
    importance: 0.3,
    correlation: 0.4,
    missing_values: 0.1,
  },
  {
    feature: 'age',
    importance: 0.5,
    correlation: 0.3,
    missing_values: 0.3,
  },
];

// Features with metadata for selection
const availableFeatures = [
  { 
    name: 'area', 
    type: 'numerical', 
    description: 'Area of property in square feet',
    importance: 0.35,
    missing: 0.01,
    correlation: 0.92,
    selected: true,
    stats: {
      min: 290,
      max: 4500,
      mean: 1420,
      median: 1280,
      std: 520
    }
  },
  { 
    name: 'income', 
    type: 'numerical', 
    description: 'Median income in the area',
    importance: 0.23,
    missing: 0.00,
    correlation: 0.78,
    selected: true,
    stats: {
      min: 18000,
      max: 125000,
      mean: 68500,
      median: 62000,
      std: 22400
    }
  },
  { 
    name: 'rooms', 
    type: 'numerical', 
    description: 'Number of rooms',
    importance: 0.15,
    missing: 0.00,
    correlation: 0.69,
    selected: true,
    stats: {
      min: 1,
      max: 12,
      mean: 5.4,
      median: 5,
      std: 1.8
    }
  },
  { 
    name: 'age', 
    type: 'numerical', 
    description: 'Age of property in years',
    importance: 0.12,
    missing: 0.03,
    correlation: 0.64,
    selected: true,
    stats: {
      min: 0,
      max: 120,
      mean: 38,
      median: 35,
      std: 25
    }
  },
  { 
    name: 'year', 
    type: 'numerical', 
    description: 'Year of construction',
    importance: 0.08,
    missing: 0.02,
    correlation: -0.34,
    selected: true,
    stats: {
      min: 1900,
      max: 2020,
      mean: 1982,
      median: 1995,
      std: 25
    }
  },
  { 
    name: 'bathrooms', 
    type: 'numerical', 
    description: 'Number of bathrooms',
    importance: 0.04,
    missing: 0.00,
    correlation: 0.52,
    selected: false,
    stats: {
      min: 1,
      max: 5,
      mean: 2.1,
      median: 2,
      std: 0.7
    }
  },
  { 
    name: 'floor', 
    type: 'numerical', 
    description: 'Floor level of property',
    importance: 0.03,
    missing: 0.05,
    correlation: 0.28,
    selected: false,
    stats: {
      min: 1,
      max: 30,
      mean: 3.8,
      median: 2,
      std: 4.2
    }
  },
  { 
    name: 'location', 
    type: 'categorical', 
    description: 'Geographic location',
    importance: 0.18,
    missing: 0.00,
    correlation: 0.43,
    selected: false,
    stats: {
      categories: ['urban', 'suburban', 'rural'],
      frequencies: [0.45, 0.42, 0.13]
    }
  },
  { 
    name: 'furnishing', 
    type: 'categorical', 
    description: 'Furnishing status',
    importance: 0.05,
    missing: 0.08,
    correlation: 0.22,
    selected: false,
    stats: {
      categories: ['unfurnished', 'semi-furnished', 'fully-furnished'],
      frequencies: [0.62, 0.25, 0.13]
    }
  },
];

interface FeatureSelectionWizardProps {
  onComplete?: (selectedFeatures: string[]) => void;
}

const FeatureSelectionWizard: React.FC<FeatureSelectionWizardProps> = ({ onComplete }) => {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [selectedDataset, setSelectedDataset] = useState<string | null>(null);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [features, setFeatures] = useState(availableFeatures);
  const [targetFeature, setTargetFeature] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'name' | 'importance' | 'correlation' | 'missing'>('importance');
  const [chartType, setChartType] = useState<'bar' | 'scatter' | 'radar' | 'correlation'>('bar');
  const [correlationTarget, setCorrelationTarget] = useState<'price' | 'quality' | 'risk'>('price');
  
  // Helper function to validate correlation target
  const isValidCorrelationTarget = (value: string): value is 'price' | 'quality' | 'risk' => {
    return value === 'price' || value === 'quality' || value === 'risk';
  };
  const [importanceThreshold, setImportanceThreshold] = useState(0.05);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  
  // Initialize selected features
  useEffect(() => {
    const initialSelected = features.filter(f => f.selected).map(f => f.name);
    setSelectedFeatures(initialSelected);
  }, [features]);

  // Filter features based on search
  const filteredFeatures = features.filter(feature => 
    feature.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    feature.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort features based on selected criteria
  const sortedFeatures = [...filteredFeatures].sort((a, b) => {
    if (sortBy === 'name') return a.name.localeCompare(b.name);
    if (sortBy === 'importance') return b.importance - a.importance;
    if (sortBy === 'correlation') return Math.abs(b.correlation) - Math.abs(a.correlation);
    return a.missing - b.missing;
  });

  const handleDatasetSelect = (datasetId: string) => {
    setIsLoading(true);
    setSelectedDataset(datasetId);
    
    // Simulate loading dataset
    setTimeout(() => {
      setIsLoading(false);
      // For a real implementation, this would fetch the dataset and update features
      toast({
        title: "Dataset Loaded",
        description: `Successfully loaded ${datasetId} dataset`,
      });
    }, 1500);
  };

  const handleFeatureToggle = (featureName: string) => {
    setFeatures(features.map(f => 
      f.name === featureName ? { ...f, selected: !f.selected } : f
    ));
    
    setSelectedFeatures(prev => {
      if (prev.includes(featureName)) {
        return prev.filter(f => f !== featureName);
      } else {
        return [...prev, featureName];
      }
    });
  };

  const handleSelectAllFeatures = () => {
    setFeatures(features.map(f => ({ ...f, selected: true })));
    setSelectedFeatures(features.map(f => f.name));
  };

  const handleDeselectAllFeatures = () => {
    setFeatures(features.map(f => ({ ...f, selected: false })));
    setSelectedFeatures([]);
  };

  const handleSelectImportantFeatures = () => {
    setFeatures(features.map(f => ({ 
      ...f, 
      selected: typeof f.importance === 'number' && f.importance >= importanceThreshold 
    })));
    
    setSelectedFeatures(
      features
        .filter(f => typeof f.importance === 'number' && f.importance >= importanceThreshold)
        .map(f => f.name)
    );
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFileName(file.name);
      setIsLoading(true);
      
      // Simulate file processing
      setTimeout(() => {
        setIsLoading(false);
        setSelectedDataset('custom');
        // In a real implementation, process the file and update features
        toast({
          title: "File Uploaded",
          description: `Successfully uploaded ${file.name}`,
        });
      }, 2000);
    }
  };
  
  const handleImportanceThresholdChange = (value: number[]) => {
    setImportanceThreshold(value[0]);
  };
  
  const handleNextStep = () => {
    if (step < 5) {
      setStep(step + 1);
    } else {
      if (onComplete) {
        onComplete(selectedFeatures);
      }
      toast({
        title: "Feature Selection Complete",
        description: `Selected ${selectedFeatures.length} features for modeling`,
      });
    }
  };
  
  const handlePreviousStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleComplete = () => {
    if (onComplete) {
      onComplete(selectedFeatures);
    }
    
    toast({
      title: "Features Exported",
      description: `${selectedFeatures.length} features have been exported for modeling.`,
    });
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Select a Dataset</h2>
              <p className="text-muted-foreground">
                Choose an existing dataset or upload your own to begin feature selection
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {sampleDatasets.map((dataset) => (
                <Card 
                  key={dataset.id}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedDataset === dataset.id ? 'border-primary' : ''
                  }`}
                  onClick={() => handleDatasetSelect(dataset.id)}
                >
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex justify-between items-center">
                      {dataset.name}
                      {selectedDataset === dataset.id && (
                        <CheckCircle2 className="h-5 w-5 text-primary" />
                      )}
                    </CardTitle>
                    {dataset.id !== 'custom' && (
                      <CardDescription>
                        {dataset.features} features • {dataset.rows} rows
                      </CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    {dataset.id === 'custom' ? (
                      <div className="text-center py-6">
                        <label htmlFor="file-upload" className="cursor-pointer">
                          <div className="flex flex-col items-center">
                            <Upload className="h-12 w-12 text-muted-foreground mb-3" />
                            <span className="text-sm font-medium">
                              {uploadedFileName || 'Click to upload CSV'}
                            </span>
                            {uploadedFileName && (
                              <span className="text-xs text-muted-foreground mt-1">
                                File uploaded successfully
                              </span>
                            )}
                          </div>
                          <input
                            id="file-upload"
                            type="file"
                            accept=".csv"
                            className="hidden"
                            onChange={handleFileUpload}
                          />
                        </label>
                      </div>
                    ) : (
                      <div className="h-24 flex items-center justify-center">
                        <ResponsiveContainer width="100%" height={80}>
                          <BarChart data={correlationData.slice(0, 5)} layout="vertical">
                            <XAxis type="number" hide domain={[0, 1]} />
                            <YAxis
                              dataKey="name"
                              type="category"
                              axisLine={false}
                              tickLine={false}
                              hide
                            />
                            <Bar
                              dataKey="price"
                              fill="#8884d8"
                              background={{ fill: '#eee' }}
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {isLoading && (
              <div className="mt-6">
                <Label>Loading dataset</Label>
                <Progress value={45} className="mt-2" />
              </div>
            )}
          </div>
        );
        
      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Explore Your Data</h2>
              <p className="text-muted-foreground">
                Visualize your data to better understand feature relationships
              </p>
            </div>
            
            <div className="flex flex-col space-y-6">
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                    <div>
                      <CardTitle>Data Visualization</CardTitle>
                      <CardDescription>
                        Explore relationships between features
                      </CardDescription>
                    </div>
                    <div className="flex mt-4 md:mt-0">
                      <Tabs
                        defaultValue="bar"
                        value={chartType}
                        onValueChange={(value) => setChartType(value as any)}
                        className="w-full"
                      >
                        <TabsList className="grid grid-cols-4 w-full">
                          <TabsTrigger value="bar">
                            <BarChart2 className="h-4 w-4 mr-2" />
                            <span className="hidden sm:inline">Importance</span>
                          </TabsTrigger>
                          <TabsTrigger value="scatter">
                            <ScatterChartIcon className="h-4 w-4 mr-2" />
                            <span className="hidden sm:inline">Scatter</span>
                          </TabsTrigger>
                          <TabsTrigger value="correlation">
                            <Activity className="h-4 w-4 mr-2" />
                            <span className="hidden sm:inline">Correlation</span>
                          </TabsTrigger>
                          <TabsTrigger value="radar">
                            <PieChartIcon className="h-4 w-4 mr-2" />
                            <span className="hidden sm:inline">Radar</span>
                          </TabsTrigger>
                        </TabsList>
                      </Tabs>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-96">
                    {chartType === 'bar' && (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={importanceData}
                          layout="vertical"
                          margin={{ top: 20, right: 30, left: 90, bottom: 10 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" domain={[0, 'dataMax']} />
                          <YAxis
                            dataKey="name"
                            type="category"
                            scale="band"
                            width={80}
                          />
                          <Tooltip formatter={(value) => [(value as number).toFixed(2), 'Importance']} />
                          <Legend />
                          <Bar dataKey="value" name="Feature Importance">
                            {importanceData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    )}
                    
                    {chartType === 'scatter' && (
                      <ResponsiveContainer width="100%" height="100%">
                        <ScatterChart
                          margin={{ top: 20, right: 30, bottom: 10, left: 10 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            type="number"
                            dataKey="x"
                            name="Feature 1"
                            unit=""
                          />
                          <YAxis
                            dataKey="y"
                            name="Feature 2"
                            unit=""
                          />
                          <ZAxis
                            dataKey="z"
                            range={[50, 400]}
                            name="Value"
                          />
                          <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                          <Legend />
                          <Scatter
                            name="Data Points"
                            data={scatterData}
                            fill="#8884d8"
                          >
                            {scatterData.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={['#8884d8', '#82ca9d', '#ffc658'][entry.group]}
                              />
                            ))}
                          </Scatter>
                        </ScatterChart>
                      </ResponsiveContainer>
                    )}
                    
                    {chartType === 'correlation' && (
                      <div className="h-full flex flex-col">
                        <div className="mb-4 flex justify-end">
                          <div className="flex items-center space-x-2">
                            <Label htmlFor="target-feature">Target:</Label>
                            <select
                              id="target-feature"
                              value={correlationTarget}
                              onChange={(e) => {
                                const value = e.target.value;
                                if (isValidCorrelationTarget(value)) {
                                  setCorrelationTarget(value);
                                }
                              }}
                              className="px-3 py-1.5 border rounded-md text-sm"
                            >
                              <option value="price">Price</option>
                              <option value="quality">Quality</option>
                              <option value="risk">Risk</option>
                            </select>
                          </div>
                        </div>
                        <ResponsiveContainer width="100%" height="90%">
                          <BarChart
                            data={correlationData}
                            margin={{ top: 20, right: 30, left: 60, bottom: 10 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis
                              domain={[-1, 1]}
                              ticks={[-1, -0.5, 0, 0.5, 1]}
                              tickFormatter={(value) => value.toFixed(1)}
                            />
                            <Tooltip
                              formatter={(value) => [
                                (value as number).toFixed(2),
                                'Correlation',
                              ]}
                            />
                            <Legend />
                            <Bar
                              dataKey={correlationTarget}
                              name={`Correlation with ${correlationTarget}`}
                              fill={(correlationTarget === 'price') ? '#8884d8' : 
                                    (correlationTarget === 'quality') ? '#82ca9d' : '#ffc658'}
                            >
                              {correlationData.map((entry, index) => (
                                <Cell
                                  key={`cell-${index}`}
                                  fill={entry[correlationTarget] >= 0 ? '#8884d8' : '#FF8042'}
                                />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                    
                    {chartType === 'radar' && (
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart outerRadius={150} data={radarData}>
                          <PolarGrid />
                          <PolarAngleAxis dataKey="feature" />
                          <PolarRadiusAxis angle={30} domain={[0, 1]} />
                          <Radar
                            name="Importance"
                            dataKey="importance"
                            stroke="#8884d8"
                            fill="#8884d8"
                            fillOpacity={0.6}
                          />
                          <Radar
                            name="Correlation"
                            dataKey="correlation"
                            stroke="#82ca9d"
                            fill="#82ca9d"
                            fillOpacity={0.6}
                          />
                          <Radar
                            name="Missing Values"
                            dataKey="missing_values"
                            stroke="#ffc658"
                            fill="#ffc658"
                            fillOpacity={0.6}
                          />
                          <Legend />
                        </RadarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="text-sm text-muted-foreground">
                  Visual insights can help identify which features are most relevant for your model.
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>Feature Distribution</CardTitle>
                  <CardDescription>
                    Analyze the distribution of values for key features
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="feature1">
                    <TabsList className="grid grid-cols-4 mb-4">
                      <TabsTrigger value="feature1">Area</TabsTrigger>
                      <TabsTrigger value="feature2">Income</TabsTrigger>
                      <TabsTrigger value="feature3">Rooms</TabsTrigger>
                      <TabsTrigger value="feature4">Age</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="feature1" className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={distributionData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            dataKey="value"
                            label={{ value: 'Value', position: 'bottom' }}
                          />
                          <YAxis
                            label={{ value: 'Frequency', angle: -90, position: 'left' }}
                          />
                          <Tooltip formatter={(value) => [value, 'Count']} />
                          <Bar dataKey="count" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </TabsContent>
                    
                    <TabsContent value="feature2" className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={distributionData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            dataKey="value"
                            label={{ value: 'Value', position: 'bottom' }}
                          />
                          <YAxis
                            label={{ value: 'Frequency', angle: -90, position: 'left' }}
                          />
                          <Tooltip formatter={(value) => [value, 'Count']} />
                          <Line
                            type="monotone"
                            dataKey="count"
                            stroke="#82ca9d"
                            activeDot={{ r: 8 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </TabsContent>
                    
                    <TabsContent value="feature3" className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[...distributionData].slice(0, 6).map(d => ({ value: d.value / 10, count: d.count * 1.5 }))}
                          margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            dataKey="value"
                            label={{ value: 'Rooms', position: 'bottom' }}
                          />
                          <YAxis
                            label={{ value: 'Frequency', angle: -90, position: 'left' }}
                          />
                          <Tooltip formatter={(value) => [value, 'Count']} />
                          <Bar dataKey="count" fill="#ffc658" />
                        </BarChart>
                      </ResponsiveContainer>
                    </TabsContent>
                    
                    <TabsContent value="feature4" className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={distributionData.map(d => ({ ...d, count: d.count * (1 + Math.random() * 0.5) }))}
                          margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis
                            dataKey="value"
                            label={{ value: 'Age', position: 'bottom' }}
                          />
                          <YAxis
                            label={{ value: 'Frequency', angle: -90, position: 'left' }}
                          />
                          <Tooltip formatter={(value) => [value, 'Count']} />
                          <Bar dataKey="count" fill="#FF8042" />
                        </BarChart>
                      </ResponsiveContainer>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </div>
        );
        
      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Feature Selection</h2>
              <p className="text-muted-foreground">
                Choose which features to include in your model
              </p>
            </div>
            
            <Card>
              <CardHeader className="pb-0">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <CardTitle>Available Features</CardTitle>
                    <CardDescription>
                      {selectedFeatures.length} of {features.length} features selected
                    </CardDescription>
                  </div>
                  <div className="flex mt-4 md:mt-0 gap-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        type="text"
                        placeholder="Search features..."
                        className="pl-8 pr-4 py-2"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <select
                      className="px-3 py-2 rounded-md border text-sm"
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                    >
                      <option value="importance">Sort by Importance</option>
                      <option value="correlation">Sort by Correlation</option>
                      <option value="missing">Sort by Missing %</option>
                      <option value="name">Sort by Name</option>
                    </select>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="my-4 flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleSelectAllFeatures}
                  >
                    Select All
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleDeselectAllFeatures}
                  >
                    Deselect All
                  </Button>
                  <div className="flex items-center space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleSelectImportantFeatures}
                    >
                      Select by Importance
                    </Button>
                    <div className="w-32 px-2">
                      <Slider
                        defaultValue={[0.05]}
                        max={0.4}
                        step={0.01}
                        value={[importanceThreshold]}
                        onValueChange={handleImportanceThresholdChange}
                      />
                    </div>
                    <div className="text-xs text-muted-foreground">
                      ≥ {importanceThreshold.toFixed(2)}
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-md">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="py-3 px-4 text-left font-medium text-sm">Select</th>
                        <th className="py-3 px-4 text-left font-medium text-sm">Feature</th>
                        <th className="py-3 px-4 text-left font-medium text-sm">Type</th>
                        <th className="py-3 px-4 text-left font-medium text-sm">Importance</th>
                        <th className="py-3 px-4 text-left font-medium text-sm">Correlation</th>
                        <th className="py-3 px-4 text-left font-medium text-sm">Missing %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedFeatures.map((feature) => (
                        <tr key={feature.name} className="border-b hover:bg-muted/50">
                          <td className="py-3 px-4">
                            <Checkbox
                              checked={selectedFeatures.includes(feature.name)}
                              onCheckedChange={() => handleFeatureToggle(feature.name)}
                              id={`feature-${feature.name}`}
                            />
                          </td>
                          <td className="py-3 px-4 font-medium">
                            <label 
                              htmlFor={`feature-${feature.name}`}
                              className="cursor-pointer"
                            >
                              {feature.name}
                              <div className="text-xs text-muted-foreground">
                                {feature.description}
                              </div>
                            </label>
                          </td>
                          <td className="py-3 px-4">
                            <Badge variant={feature.type === 'numerical' ? 'default' : 'outline'}>
                              {feature.type}
                            </Badge>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center">
                              <div className="w-24 bg-muted rounded-full h-2 mr-2">
                                <div
                                  className="bg-primary rounded-full h-2"
                                  style={{ width: `${feature.importance * 100 * 2.5}%` }}
                                ></div>
                              </div>
                              <span>{feature.importance.toFixed(2)}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center">
                              <div className="w-24 bg-muted rounded-full h-2 mr-2">
                                <div
                                  className={`rounded-full h-2 ${feature.correlation >= 0 ? 'bg-green-500' : 'bg-red-500'}`}
                                  style={{ width: `${Math.abs(feature.correlation) * 100}%` }}
                                ></div>
                              </div>
                              <span>{feature.correlation.toFixed(2)}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            {feature.missing > 0 ? (
                              <div className="flex items-center">
                                <div className="w-24 bg-muted rounded-full h-2 mr-2">
                                  <div
                                    className="bg-amber-500 rounded-full h-2"
                                    style={{ width: `${feature.missing * 100 * 5}%` }}
                                  ></div>
                                </div>
                                <span>{(feature.missing * 100).toFixed(1)}%</span>
                              </div>
                            ) : (
                              <span className="text-green-500">0%</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        );
        
      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Feature Details</h2>
              <p className="text-muted-foreground">
                Review and analyze the features you've selected
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Selected Features Summary</CardTitle>
                  <CardDescription>
                    {selectedFeatures.length} features selected for modeling
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="space-y-2">
                    {features
                      .filter(f => selectedFeatures.includes(f.name))
                      .map(feature => (
                        <div key={feature.name} className="flex items-center justify-between p-2 border rounded-md">
                          <div>
                            <div className="font-medium">{feature.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {feature.description}
                            </div>
                          </div>
                          <div className="flex items-center">
                            <Badge className="mr-2">
                              {feature.type}
                            </Badge>
                            <div className="text-xs text-muted-foreground whitespace-nowrap">
                              Imp: {feature.importance.toFixed(2)}
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="text-sm text-muted-foreground">
                    {selectedFeatures.length === 0 ? (
                      <div className="flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-2 text-amber-500" />
                        No features selected. Please go back and select features.
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <CheckCircle2 className="h-4 w-4 mr-2 text-green-500" />
                        Features are ready for modeling.
                      </div>
                    )}
                  </div>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Statistics & Insights</CardTitle>
                  <CardDescription>
                    Statistical summary of selected numerical features
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[280px]">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="py-2 px-4 text-left font-medium text-sm">Feature</th>
                          <th className="py-2 px-4 text-left font-medium text-sm">Min</th>
                          <th className="py-2 px-4 text-left font-medium text-sm">Max</th>
                          <th className="py-2 px-4 text-left font-medium text-sm">Mean</th>
                          <th className="py-2 px-4 text-left font-medium text-sm">Std</th>
                        </tr>
                      </thead>
                      <tbody>
                        {features
                          .filter(f => selectedFeatures.includes(f.name) && f.type === 'numerical')
                          .map(feature => (
                            <tr key={feature.name} className="border-b">
                              <td className="py-2 px-4 font-medium">{feature.name}</td>
                              <td className="py-2 px-4">{feature.stats.min}</td>
                              <td className="py-2 px-4">{feature.stats.max}</td>
                              <td className="py-2 px-4">{feature.stats.mean}</td>
                              <td className="py-2 px-4">{feature.stats.std}</td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </ScrollArea>
                  
                  <div className="mt-6">
                    <h4 className="text-sm font-medium mb-2">Key Insights</h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <Info className="h-4 w-4 mr-2 mt-0.5 text-blue-500" />
                        <span>
                          {selectedFeatures.length > 0 
                            ? `Top features by importance: ${features
                                .filter(f => selectedFeatures.includes(f.name))
                                .sort((a, b) => b.importance - a.importance)
                                .slice(0, 3)
                                .map(f => f.name)
                                .join(', ')}`
                            : 'No features selected to analyze'
                          }
                        </span>
                      </li>
                      <li className="flex items-start">
                        <TrendingUp className="h-4 w-4 mr-2 mt-0.5 text-green-500" />
                        <span>
                          {selectedFeatures.length > 0
                            ? `Strongest correlations with target: ${features
                                .filter(f => selectedFeatures.includes(f.name))
                                .sort((a, b) => Math.abs(b.correlation) - Math.abs(a.correlation))
                                .slice(0, 2)
                                .map(f => f.name)
                                .join(', ')}`
                            : 'Select features to see correlation analysis'
                          }
                        </span>
                      </li>
                      <li className="flex items-start">
                        <AlertTriangle className="h-4 w-4 mr-2 mt-0.5 text-amber-500" />
                        <span>
                          {features
                            .filter(f => selectedFeatures.includes(f.name) && f.missing > 0)
                            .length > 0
                            ? `${features
                                .filter(f => selectedFeatures.includes(f.name) && f.missing > 0)
                                .length} features have missing values that will need imputation`
                            : 'No missing values in selected features'
                          }
                        </span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Feature Relationships</CardTitle>
                <CardDescription>
                  Visualize interactions between selected features
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart
                      margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis
                        type="number"
                        dataKey="x"
                        name="Income"
                        label={{ value: 'Income', position: 'bottom' }}
                      />
                      <YAxis
                        type="number"
                        dataKey="y"
                        name="Area"
                        label={{ value: 'Area', angle: -90, position: 'left' }}
                      />
                      <ZAxis
                        type="number"
                        dataKey="z"
                        range={[50, 400]}
                        name="Price"
                      />
                      <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                      <Legend />
                      <Scatter
                        name="Properties"
                        data={scatterData}
                        fill="#8884d8"
                      >
                        {scatterData.map((entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={['#8884d8', '#82ca9d', '#ffc658'][entry.group]}
                          />
                        ))}
                      </Scatter>
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="mt-4 text-sm text-muted-foreground">
                  This visualization shows the relationship between Income, Area, and Price (bubble size).
                  Clear patterns indicate strong feature relationships.
                </div>
              </CardContent>
            </Card>
          </div>
        );
        
      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Finalize Feature Selection</h2>
              <p className="text-muted-foreground">
                Review your selections and export features for modeling
              </p>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Selection Summary</CardTitle>
                <CardDescription>
                  Review your feature selection details
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Selected Features</h3>
                    <div className="border rounded-md overflow-hidden">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-muted/50 border-b">
                            <th className="py-2 px-4 text-left font-medium text-sm">Feature</th>
                            <th className="py-2 px-4 text-left font-medium text-sm">Type</th>
                            <th className="py-2 px-4 text-left font-medium text-sm">Importance</th>
                          </tr>
                        </thead>
                        <tbody>
                          {features
                            .filter(f => selectedFeatures.includes(f.name))
                            .sort((a, b) => b.importance - a.importance)
                            .map(feature => (
                              <tr key={feature.name} className="border-b">
                                <td className="py-2 px-4 font-medium">{feature.name}</td>
                                <td className="py-2 px-4">
                                  <Badge variant={feature.type === 'numerical' ? 'default' : 'outline'}>
                                    {feature.type}
                                  </Badge>
                                </td>
                                <td className="py-2 px-4">{feature.importance.toFixed(2)}</td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="text-lg font-medium mb-2">Feature Statistics</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between p-2 border rounded-md">
                          <span>Total Features Available:</span>
                          <span className="font-medium">{features.length}</span>
                        </div>
                        <div className="flex justify-between p-2 border rounded-md">
                          <span>Features Selected:</span>
                          <span className="font-medium">{selectedFeatures.length}</span>
                        </div>
                        <div className="flex justify-between p-2 border rounded-md">
                          <span>Numerical Features:</span>
                          <span className="font-medium">
                            {features.filter(f => selectedFeatures.includes(f.name) && f.type === 'numerical').length}
                          </span>
                        </div>
                        <div className="flex justify-between p-2 border rounded-md">
                          <span>Categorical Features:</span>
                          <span className="font-medium">
                            {features.filter(f => selectedFeatures.includes(f.name) && f.type === 'categorical').length}
                          </span>
                        </div>
                        <div className="flex justify-between p-2 border rounded-md">
                          <span>Features with Missing Values:</span>
                          <span className="font-medium">
                            {features.filter(f => selectedFeatures.includes(f.name) && f.missing > 0).length}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-2">Feature Importance Distribution</h3>
                    <div className="h-64 mb-6">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            dataKey="value"
                            data={importanceData.filter(d => 
                              selectedFeatures.includes(d.name)
                            )}
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            fill="#8884d8"
                            label={({ name, percent }) => 
                              `${name}: ${(percent * 100).toFixed(0)}%`
                            }
                          >
                            {importanceData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => [`${(value as number * 100).toFixed(1)}%`, 'Importance']} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <h3 className="text-lg font-medium mb-2">Recommendations</h3>
                    <div className="space-y-3">
                      <div className="flex items-start p-3 bg-blue-50 dark:bg-blue-950 rounded-md">
                        <Info className="h-5 w-5 mr-3 text-blue-500 flex-shrink-0 mt-0.5" />
                        <div className="text-sm">
                          <p className="font-medium text-blue-700 dark:text-blue-300">Feature Preprocessing</p>
                          <p className="mt-1">
                            Remember to apply scaling to numerical features and encoding to categorical features
                            before training your model.
                          </p>
                        </div>
                      </div>
                      
                      {features.filter(f => selectedFeatures.includes(f.name) && f.missing > 0).length > 0 && (
                        <div className="flex items-start p-3 bg-amber-50 dark:bg-amber-950 rounded-md">
                          <AlertTriangle className="h-5 w-5 mr-3 text-amber-500 flex-shrink-0 mt-0.5" />
                          <div className="text-sm">
                            <p className="font-medium text-amber-700 dark:text-amber-300">Missing Values</p>
                            <p className="mt-1">
                              {features.filter(f => selectedFeatures.includes(f.name) && f.missing > 0).length} selected 
                              features have missing values. Consider using imputation techniques.
                            </p>
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-start p-3 bg-green-50 dark:bg-green-950 rounded-md">
                        <CheckCircle2 className="h-5 w-5 mr-3 text-green-500 flex-shrink-0 mt-0.5" />
                        <div className="text-sm">
                          <p className="font-medium text-green-700 dark:text-green-300">Feature Coverage</p>
                          <p className="mt-1">
                            Your selected features capture {selectedFeatures.length > 3 ? 'a good' : 'a limited'} portion of 
                            the total variance in the dataset.
                            {selectedFeatures.length < 3 && ' Consider adding more features.'}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={handlePreviousStep}>
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  Back to Feature Details
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => {
                    toast({
                      title: "Features Exported",
                      description: `Exported ${selectedFeatures.length} features as CSV`,
                    });
                  }}>
                    <Download className="h-4 w-4 mr-2" />
                    Export as CSV
                  </Button>
                  <Button onClick={handleComplete}>
                    <Save className="h-4 w-4 mr-2" />
                    Complete Selection
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="container max-w-7xl mx-auto px-4 py-8">
      <Card className="mb-6">
        <CardHeader className="pb-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <CardTitle className="text-2xl">
                Feature Selection Wizard
              </CardTitle>
              <CardDescription>
                Visualize, analyze, and select the best features for your model
              </CardDescription>
            </div>
            
            <div className="flex items-center">
              <div className="hidden md:flex items-center space-x-2 mr-6">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div 
                    key={i} 
                    className={`w-3 h-3 rounded-full transition-colors ${
                      i + 1 < step ? 'bg-primary' : i + 1 === step ? 'bg-primary/60' : 'bg-gray-200 dark:bg-gray-700'
                    }`}
                  />
                ))}
              </div>
              
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={handlePreviousStep}
                  disabled={step === 1 || isLoading}
                >
                  <ChevronLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>
                <Button 
                  onClick={handleNextStep}
                  disabled={isLoading || (step === 3 && selectedFeatures.length === 0)}
                >
                  {step === 5 ? (
                    <>
                      Complete
                      <CheckCircle2 className="h-4 w-4 ml-2" />
                    </>
                  ) : (
                    <>
                      Next
                      <ChevronRight className="h-4 w-4 ml-2" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
          
          <div className="w-full bg-muted h-2 rounded-full mt-6">
            <div 
              className="bg-primary h-2 rounded-full transition-all" 
              style={{ width: `${(step / 5) * 100}%` }}
            />
          </div>
        </CardHeader>
      </Card>
      
      {renderStepContent()}
    </div>
  );
};

export default FeatureSelectionWizard;