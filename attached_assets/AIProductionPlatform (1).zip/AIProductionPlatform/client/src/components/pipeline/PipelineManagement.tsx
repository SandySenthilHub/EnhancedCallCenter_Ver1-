import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import type { Pipeline } from '@/types';

const PipelineManagement: React.FC = () => {
  const { data: pipelines, isLoading } = useQuery({
    queryKey: ['/api/pipelines'],
    staleTime: 60000 // 1 minute
  });

  return (
    <Card className="bg-white shadow">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Pipeline Management</h3>
        
        <table className="min-w-full divide-y divide-neutral-200">
          <thead className="bg-neutral-100">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Pipeline Name
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Type
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Schedule
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Last Run
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-neutral-200">
            {isLoading ? (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-neutral-500">
                  Loading pipelines...
                </td>
              </tr>
            ) : pipelines && pipelines.length > 0 ? (
              pipelines.map((pipeline: Pipeline) => (
                <tr key={pipeline.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-neutral-600">{pipeline.name}</div>
                    <div className="text-xs text-neutral-500">Created {new Date(pipeline.createdAt).toLocaleDateString()}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      pipeline.type === 'clustering' ? 'bg-secondary bg-opacity-20 text-secondary' :
                      'bg-primary bg-opacity-20 text-primary'
                    }`}>
                      {pipeline.type.charAt(0).toUpperCase() + pipeline.type.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                    {pipeline.schedule}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                    {pipeline.lastRun ? new Date(pipeline.lastRun).toLocaleString() : 'Never'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      pipeline.status === 'success' ? 'bg-success bg-opacity-20 text-success' :
                      pipeline.status === 'running' ? 'bg-info bg-opacity-20 text-info' :
                      pipeline.status === 'failed' ? 'bg-danger bg-opacity-20 text-danger' :
                      'bg-warning bg-opacity-20 text-warning'
                    }`}>
                      {pipeline.status.charAt(0).toUpperCase() + pipeline.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                    <div className="flex space-x-2">
                      <button className="p-1 text-neutral-400 hover:text-primary">
                        {pipeline.status === 'running' ? (
                          <span className="material-icons text-sm">pause</span>
                        ) : (
                          <span className="material-icons text-sm">play_arrow</span>
                        )}
                      </button>
                      <button className="p-1 text-neutral-400 hover:text-primary">
                        <span className="material-icons text-sm">edit</span>
                      </button>
                      <button className="p-1 text-neutral-400 hover:text-danger">
                        <span className="material-icons text-sm">delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-neutral-500">
                  No pipelines found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
};

export default PipelineManagement;
