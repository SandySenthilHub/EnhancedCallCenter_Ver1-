import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

const PipelineDesigner: React.FC = () => {
  const [pipelineName, setPipelineName] = useState<string>("Customer Segmentation Pipeline");
  const [schedule, setSchedule] = useState<string>("Daily at 2:00 AM");
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const { toast } = useToast();

  const handleSavePipeline = async () => {
    setIsSaving(true);
    try {
      await apiRequest('POST', '/api/python/pipelines', {
        name: pipelineName,
        type: "clustering",
        schedule: schedule,
        config: {
          steps: [
            {
              type: "data_ingestion",
              config: {
                source: "postgresql",
                connection: "customer_data_warehouse"
              }
            },
            {
              type: "data_preprocessing",
              config: {
                job: "data_cleaning.py"
              }
            },
            {
              type: "feature_engineering",
              config: {
                script: "feature_generator.py"
              }
            },
            {
              type: "model_training",
              config: {
                algorithm: "kmeans",
                parameters: {
                  n_clusters: 5
                }
              }
            }
          ]
        }
      });
      
      toast({
        title: "Pipeline Saved",
        description: "Pipeline configuration has been saved successfully.",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Error Saving Pipeline",
        description: "There was an error saving the pipeline configuration.",
        variant: "destructive",
      });
      console.error("Error saving pipeline:", error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="bg-white shadow mb-6">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Pipeline Designer</h3>
        
        <div className="mb-4">
          <div className="flex items-center space-x-4 mb-4">
            <div>
              <Label htmlFor="pipeline-name" className="block text-sm font-medium text-neutral-600 mb-1">
                Pipeline Name
              </Label>
              <Input 
                id="pipeline-name"
                value={pipelineName} 
                onChange={(e) => setPipelineName(e.target.value)} 
                className="w-64"
              />
            </div>
            
            <div>
              <Label htmlFor="schedule" className="block text-sm font-medium text-neutral-600 mb-1">
                Schedule
              </Label>
              <Select value={schedule} onValueChange={setSchedule}>
                <SelectTrigger id="schedule" className="w-48">
                  <SelectValue placeholder="Select schedule" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Daily at 2:00 AM">Daily at 2:00 AM</SelectItem>
                  <SelectItem value="Weekly on Sunday">Weekly on Sunday</SelectItem>
                  <SelectItem value="Monthly on 1st">Monthly on 1st</SelectItem>
                  <SelectItem value="Custom Schedule">Custom Schedule</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        <div className="border border-neutral-300 rounded-lg">
          <div className="bg-neutral-100 p-4 border-b border-neutral-300 flex justify-between items-center">
            <div className="flex space-x-2">
              <Button variant="default" size="sm" className="bg-primary text-white hover:bg-primary/90">
                <span className="material-icons text-sm align-text-bottom mr-1">add</span>
                Add Step
              </Button>
              <Button variant="outline" size="sm">
                <span className="material-icons text-sm align-text-bottom mr-1">add_link</span>
                Connect Steps
              </Button>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <span className="material-icons text-sm align-text-bottom mr-1">play_arrow</span>
                Run
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleSavePipeline}
                disabled={isSaving}
              >
                {isSaving ? (
                  <span className="material-icons text-sm align-text-bottom mr-1 animate-spin">autorenew</span>
                ) : (
                  <span className="material-icons text-sm align-text-bottom mr-1">save</span>
                )}
                Save
              </Button>
            </div>
          </div>
          
          <div className="p-6 min-h-[400px] relative">
            {/* Pipeline visual designer */}
            <div className="flex flex-col items-center">
              {/* Data Ingestion Node */}
              <div className="w-64 rounded-lg bg-white shadow-md border border-neutral-300 p-3 mb-4 relative z-10">
                <div className="flex items-center mb-2">
                  <span className="w-8 h-8 rounded-full bg-primary bg-opacity-20 flex items-center justify-center mr-2">
                    <span className="material-icons text-primary text-sm">storage</span>
                  </span>
                  <h4 className="text-sm font-medium text-neutral-600">Data Ingestion</h4>
                  <div className="ml-auto">
                    <button className="p-1 text-neutral-400 hover:text-primary">
                      <span className="material-icons text-sm">edit</span>
                    </button>
                  </div>
                </div>
                <div className="text-xs text-neutral-500 mb-2">
                  Source: PostgreSQL Database
                </div>
                <div className="text-xs px-2 py-1 bg-success bg-opacity-20 text-success inline-block rounded-full">
                  Configured
                </div>
              </div>
              
              {/* Arrow */}
              <div className="h-8 w-px bg-neutral-300 relative">
                <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 rotate-45 w-2 h-2 border-r border-b border-neutral-300"></div>
              </div>
              
              {/* Data Preprocessing Node */}
              <div className="w-64 rounded-lg bg-white shadow-md border border-neutral-300 p-3 mb-4 relative z-10">
                <div className="flex items-center mb-2">
                  <span className="w-8 h-8 rounded-full bg-info bg-opacity-20 flex items-center justify-center mr-2">
                    <span className="material-icons text-info text-sm">sync</span>
                  </span>
                  <h4 className="text-sm font-medium text-neutral-600">Data Preprocessing</h4>
                  <div className="ml-auto">
                    <button className="p-1 text-neutral-400 hover:text-primary">
                      <span className="material-icons text-sm">edit</span>
                    </button>
                  </div>
                </div>
                <div className="text-xs text-neutral-500 mb-2">
                  Spark Job: data_cleaning.py
                </div>
                <div className="text-xs px-2 py-1 bg-success bg-opacity-20 text-success inline-block rounded-full">
                  Configured
                </div>
              </div>
              
              {/* Arrow */}
              <div className="h-8 w-px bg-neutral-300 relative">
                <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 rotate-45 w-2 h-2 border-r border-b border-neutral-300"></div>
              </div>
              
              {/* Feature Engineering Node */}
              <div className="w-64 rounded-lg bg-white shadow-md border border-neutral-300 p-3 mb-4 relative z-10">
                <div className="flex items-center mb-2">
                  <span className="w-8 h-8 rounded-full bg-warning bg-opacity-20 flex items-center justify-center mr-2">
                    <span className="material-icons text-warning text-sm">integration_instructions</span>
                  </span>
                  <h4 className="text-sm font-medium text-neutral-600">Feature Engineering</h4>
                  <div className="ml-auto">
                    <button className="p-1 text-neutral-400 hover:text-primary">
                      <span className="material-icons text-sm">edit</span>
                    </button>
                  </div>
                </div>
                <div className="text-xs text-neutral-500 mb-2">
                  Python: feature_generator.py
                </div>
                <div className="text-xs px-2 py-1 bg-success bg-opacity-20 text-success inline-block rounded-full">
                  Configured
                </div>
              </div>
              
              {/* Arrow */}
              <div className="h-8 w-px bg-neutral-300 relative">
                <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 rotate-45 w-2 h-2 border-r border-b border-neutral-300"></div>
              </div>
              
              {/* Model Training Node */}
              <div className="w-64 rounded-lg bg-white shadow-md border border-primary p-3 mb-4 relative z-10">
                <div className="flex items-center mb-2">
                  <span className="w-8 h-8 rounded-full bg-primary bg-opacity-20 flex items-center justify-center mr-2">
                    <span className="material-icons text-primary text-sm">model_training</span>
                  </span>
                  <h4 className="text-sm font-medium text-neutral-600">Model Training</h4>
                  <div className="ml-auto">
                    <button className="p-1 text-neutral-400 hover:text-primary">
                      <span className="material-icons text-sm">edit</span>
                    </button>
                  </div>
                </div>
                <div className="text-xs text-neutral-500 mb-2">
                  KMeans Clustering
                </div>
                <div className="text-xs px-2 py-1 bg-warning bg-opacity-20 text-warning inline-block rounded-full">
                  Needs Configuration
                </div>
              </div>
              
              {/* Arrow */}
              <div className="h-8 w-px bg-neutral-300 relative">
                <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 rotate-45 w-2 h-2 border-r border-b border-neutral-300"></div>
              </div>
              
              {/* Model Deployment Node */}
              <div className="w-64 rounded-lg bg-white shadow-md border border-neutral-300 p-3 opacity-50">
                <div className="flex items-center mb-2">
                  <span className="w-8 h-8 rounded-full bg-secondary bg-opacity-20 flex items-center justify-center mr-2">
                    <span className="material-icons text-secondary text-sm">rocket_launch</span>
                  </span>
                  <h4 className="text-sm font-medium text-neutral-600">Model Deployment</h4>
                  <div className="ml-auto">
                    <button className="p-1 text-neutral-400 hover:text-primary">
                      <span className="material-icons text-sm">edit</span>
                    </button>
                  </div>
                </div>
                <div className="text-xs text-neutral-500 mb-2">
                  REST API Endpoint
                </div>
                <div className="text-xs px-2 py-1 bg-neutral-200 text-neutral-500 inline-block rounded-full">
                  Not Configured
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PipelineDesigner;
