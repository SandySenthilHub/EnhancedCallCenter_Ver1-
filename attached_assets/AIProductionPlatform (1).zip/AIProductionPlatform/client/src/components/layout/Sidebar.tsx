import React from 'react';
import { Link, useLocation } from 'wouter';
import { useSidebar } from '@/contexts/SidebarContext';
import {
  DashboardIcon,
  DataPipesIcon,
  DataSourcesIcon,
  ValidationIcon,
  ModelStudioIcon,
  FeatureEngineeringIcon,
  ModelTrainingIcon,
  PipelineIcon,
  ModelRegistryIcon,
  DeploymentIcon,
  ReportsIcon,
  MonitoringIcon,
  MLOpsIcon,
  RLIcon,
  CollaborationIcon,
  DataEncodingIcon
} from '@/lib/icons';

const Sidebar: React.FC = () => {
  const [location] = useLocation();
  const { isSidebarOpen } = useSidebar();

  return (
    <aside 
      id="sidebar" 
      className={`${
        isSidebarOpen ? 'block' : 'hidden'
      } w-64 bg-white shadow-md md:block transition-all duration-300 h-full overflow-y-auto`}
    >
      <div className="p-4 border-b border-neutral-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-md bg-primary flex items-center justify-center text-white font-bold">
            AI
          </div>
          <div>
            <h1 className="font-bold text-lg text-neutral-600">AI/ML Playbook</h1>
            <p className="text-xs text-neutral-400">MLOps Automation Platform</p>
          </div>
        </div>
      </div>
      
      <nav className="p-4">
        <ul>
          <li className="mb-1">
            <Link 
              href="/" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <DashboardIcon className="h-4 w-4 mr-3" />
              Dashboard
            </Link>
          </li>
          
          <li className="mt-4 mb-2">
            <h3 className="px-4 text-xs font-semibold text-neutral-400 uppercase tracking-wider">Data Management</h3>
          </li>
          <li className="mb-1">
            <Link 
              href="/data-pipes" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/data-pipes' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <DataPipesIcon className="h-4 w-4 mr-3" />
              Data Pipes
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/data-sources" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/data-sources' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <DataSourcesIcon className="h-4 w-4 mr-3" />
              Data Sources
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/data-validation" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/data-validation' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <ValidationIcon className="h-4 w-4 mr-3" />
              Data Validation
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/data-encoding" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/data-encoding' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <DataEncodingIcon className="h-4 w-4 mr-3" />
              Data Encoding
            </Link>
          </li>
          
          <li className="mt-4 mb-2">
            <h3 className="px-4 text-xs font-semibold text-neutral-400 uppercase tracking-wider">Model Development</h3>
          </li>
          <li className="mb-1">
            <Link 
              href="/model-studio" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/model-studio' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <ModelStudioIcon className="h-4 w-4 mr-3" />
              Model Studio
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/feature-engineering" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/feature-engineering' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <FeatureEngineeringIcon className="h-4 w-4 mr-3" />
              Feature Engineering
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/feature-selection" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/feature-selection' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <FeatureEngineeringIcon className="h-4 w-4 mr-3" />
              Feature Selection
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/ai-feature-naming" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/ai-feature-naming' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <FeatureEngineeringIcon className="h-4 w-4 mr-3" />
              AI Feature Naming
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/model-training" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/model-training' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <ModelTrainingIcon className="h-4 w-4 mr-3" />
              Model Training
            </Link>
          </li>
          
          <li className="mt-4 mb-2">
            <h3 className="px-4 text-xs font-semibold text-neutral-400 uppercase tracking-wider">MLOps</h3>
          </li>
          <li className="mb-1">
            <Link 
              href="/pipeline-orchestrator" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/pipeline-orchestrator' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <PipelineIcon className="h-4 w-4 mr-3" />
              Pipeline Orchestrator
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/model-registry" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/model-registry' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <ModelRegistryIcon className="h-4 w-4 mr-3" />
              Model Registry
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/deployment" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/deployment' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <DeploymentIcon className="h-4 w-4 mr-3" />
              Deployment
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/integrations" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/integrations' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <PipelineIcon className="h-4 w-4 mr-3" />
              Integrations
            </Link>
          </li>
          
          <li className="mt-4 mb-2">
            <h3 className="px-4 text-xs font-semibold text-neutral-400 uppercase tracking-wider">Feature Management</h3>
          </li>
          <li className="mb-1">
            <Link 
              href="/feature-store" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/feature-store' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <DataSourcesIcon className="h-4 w-4 mr-3" />
              Feature Store
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/experiments" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/experiments' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <ModelTrainingIcon className="h-4 w-4 mr-3" />
              Experiments
            </Link>
          </li>
          
          <li className="mt-4 mb-2">
            <h3 className="px-4 text-xs font-semibold text-neutral-400 uppercase tracking-wider">Results</h3>
          </li>
          <li className="mb-1">
            <Link 
              href="/reports" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/reports' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <ReportsIcon className="h-4 w-4 mr-3" />
              Reports
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/monitoring" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/monitoring' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <MonitoringIcon className="h-4 w-4 mr-3" />
              Monitoring
            </Link>
          </li>
          
          <li className="mt-6 mb-2">
            <h2 className="px-4 text-xs font-semibold text-neutral-400 uppercase tracking-wider">Advanced</h2>
          </li>
          <li className="mb-1">
            <Link 
              href="/mlops-automation" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/mlops-automation' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <MLOpsIcon className="h-4 w-4 mr-3" />
              MLOps Automation
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/reinforcement-learning" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/reinforcement-learning' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <RLIcon className="h-4 w-4 mr-3" />
              Reinforcement Learning
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/collaboration" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/collaboration' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <CollaborationIcon className="h-4 w-4 mr-3" />
              Collaboration
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/algorithm-dependencies" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/algorithm-dependencies' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 mr-3"
              >
                <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z" />
              </svg>
              Algorithm Dependencies
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/library-dependencies" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/library-dependencies' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4 mr-3"
              >
                <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
              </svg>
              Library Dependencies
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/workflow-wizard" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/workflow-wizard' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 mr-3"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m8 3 4 8 5-5 5 15H2L8 3z" />
              </svg>
              ML Workflow Wizard
            </Link>
          </li>
          
          <li className="mt-6 mb-2">
            <h2 className="px-4 text-xs font-semibold text-neutral-400 uppercase tracking-wider">Settings</h2>
          </li>
          <li className="mb-1">
            <Link 
              href="/business-case-settings" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/business-case-settings' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <svg className="h-4 w-4 mr-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M10 3H6a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h4M16 17l5-5-5-5M19.8 12H9" />
              </svg>
              Business Cases
            </Link>
          </li>
          <li className="mb-1">
            <Link 
              href="/database-migration" 
              className={`flex items-center px-4 py-2 text-sm rounded-md ${
                location === '/database-migration' ? 'bg-primary text-white' : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <svg className="h-4 w-4 mr-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="4" width="20" height="16" rx="2" />
                <path d="M8 10v4" />
                <path d="M12 10v4" />
                <path d="M16 10v4" />
              </svg>
              Database Migration
            </Link>
          </li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
