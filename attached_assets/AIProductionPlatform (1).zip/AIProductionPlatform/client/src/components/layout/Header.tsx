import React from 'react';
import { useLocation } from 'wouter';
import { useSidebar } from '@/contexts/SidebarContext';
import { MenuIcon, NotificationsIcon, SettingsIcon, UserIcon } from '@/lib/icons';

const getPageTitle = (location: string): string => {
  switch (location) {
    case '/':
      return 'Dashboard';
    case '/data-pipes':
      return 'Data Pipes';
    case '/model-studio':
      return 'Model Studio';
    case '/pipeline-orchestrator':
      return 'Pipeline Orchestrator';
    case '/reports':
      return 'Reports';
    default:
      return location.split('/').pop()?.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') || 'Dashboard';
  }
};

const Header: React.FC = () => {
  const [location] = useLocation();
  const { toggleSidebar } = useSidebar();
  const pageTitle = getPageTitle(location);

  return (
    <header className="bg-white border-b border-neutral-200 shadow-sm">
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center">
          <button 
            id="sidebar-toggle" 
            className="md:hidden mr-4 text-neutral-500" 
            aria-label="Toggle Sidebar"
            onClick={toggleSidebar}
          >
            <MenuIcon className="h-5 w-5" />
          </button>
          <h2 className="text-lg font-semibold text-neutral-600">{pageTitle}</h2>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="p-2 rounded-full hover:bg-neutral-100" aria-label="Notifications">
            <NotificationsIcon className="h-5 w-5 text-neutral-500" />
          </button>
          <button className="p-2 rounded-full hover:bg-neutral-100" aria-label="Settings">
            <SettingsIcon className="h-5 w-5 text-neutral-500" />
          </button>
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
              <UserIcon className="h-4 w-4" />
            </div>
            <div className="ml-2 hidden md:block">
              <p className="text-sm font-medium text-neutral-600">Data Scientist</p>
              <p className="text-xs text-neutral-400">user@example.com</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
