import React from 'react';
import { Card } from '@/components/ui/card';
import { 
  SecurityIcon, 
  PeopleIcon, 
  ShieldWarningIcon 
} from '@/lib/icons';
import type { UseCase } from '@/types';

const useCasesData: UseCase[] = [
  {
    id: 'aml',
    title: 'Anti-Money Laundering',
    description: 'Detect suspicious transaction patterns and identify potential money laundering activities using ML classification models.',
    status: 'active',
    icon: 'security',
    color: 'primary'
  },
  {
    id: 'segmentation',
    title: 'Customer Segmentation',
    description: 'Group customers into segments based on behavior, demographics, and transaction history using clustering techniques.',
    status: 'active',
    icon: 'people',
    color: 'secondary'
  },
  {
    id: 'fraud',
    title: 'Fraud Detection',
    description: 'Identify fraudulent activities in real-time using advanced anomaly detection and classification algorithms.',
    status: 'in-development',
    icon: 'shield_warning',
    color: 'danger'
  }
];

const BusinessUseCases: React.FC = () => {
  return (
    <>
      <h2 className="text-xl font-bold text-neutral-600 mb-4">Business Use Cases</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {useCasesData.map((useCase) => (
          <Card key={useCase.id} className="bg-white overflow-hidden border border-neutral-200">
            <div className={`h-2 ${
              useCase.color === 'primary' ? 'bg-primary' :
              useCase.color === 'secondary' ? 'bg-secondary' :
              'bg-danger'
            }`}></div>
            <div className="p-6">
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  useCase.color === 'primary' ? 'bg-primary-light bg-opacity-20' :
                  useCase.color === 'secondary' ? 'bg-secondary-light bg-opacity-20' :
                  'bg-danger bg-opacity-20'
                }`}>
                  {useCase.icon === 'security' && 
                    <SecurityIcon className={`h-6 w-6 ${
                      useCase.color === 'primary' ? 'text-primary' :
                      useCase.color === 'secondary' ? 'text-secondary' :
                      'text-danger'
                    }`} />
                  }
                  {useCase.icon === 'people' && 
                    <PeopleIcon className={`h-6 w-6 ${
                      useCase.color === 'primary' ? 'text-primary' :
                      useCase.color === 'secondary' ? 'text-secondary' :
                      'text-danger'
                    }`} />
                  }
                  {useCase.icon === 'shield_warning' && 
                    <ShieldWarningIcon className={`h-6 w-6 ${
                      useCase.color === 'primary' ? 'text-primary' :
                      useCase.color === 'secondary' ? 'text-secondary' :
                      'text-danger'
                    }`} />
                  }
                </div>
                <h3 className="ml-4 text-lg font-semibold text-neutral-600">{useCase.title}</h3>
              </div>
              <p className="text-sm text-neutral-500 mb-4">
                {useCase.description}
              </p>
              <div className="flex items-center justify-between text-sm">
                <span className={`px-2 py-1 rounded-full ${
                  useCase.status === 'active' ? 'bg-success bg-opacity-20 text-success' :
                  'bg-warning bg-opacity-20 text-warning'
                }`}>
                  {useCase.status === 'active' ? 'Active' : 'In Development'}
                </span>
                <a href="#" className="text-primary hover:underline">View pipelines</a>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </>
  );
};

export default BusinessUseCases;
