import React from 'react';
import { Card } from '@/components/ui/card';
import { 
  CheckCircleIcon, 
  SyncIcon, 
  ErrorIcon 
} from '@/lib/icons';
import type { Activity } from '@/types';
import { useQuery } from '@tanstack/react-query';

const RecentActivity: React.FC = () => {
  const { data: activities, isLoading } = useQuery({
    queryKey: ['/api/activities'],
    staleTime: 60000 // 1 minute
  });

  return (
    <div className="mt-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-neutral-600">Recent Activity</h2>
        <a href="#" className="text-sm text-primary hover:underline">View all</a>
      </div>
      
      <Card className="bg-white overflow-hidden">
        <table className="min-w-full divide-y divide-neutral-200">
          <thead className="bg-neutral-100">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Activity
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Pipeline
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Time
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-neutral-200">
            {isLoading ? (
              <tr>
                <td colSpan={4} className="px-6 py-4 text-center text-neutral-500">
                  Loading recent activities...
                </td>
              </tr>
            ) : activities && Array.isArray(activities) && activities.length > 0 ? (
              activities.map((activity: Activity) => (
                <tr key={activity.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {activity.status === 'success' && <CheckCircleIcon className="h-5 w-5 text-success mr-2" />}
                      {activity.status === 'running' && <SyncIcon className="h-5 w-5 text-primary mr-2" />}
                      {activity.status === 'failed' && <ErrorIcon className="h-5 w-5 text-danger mr-2" />}
                      <span className="text-sm text-neutral-600">{activity.activity}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                    {activity.pipeline}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      activity.status === 'success' ? 'bg-success bg-opacity-20 text-success' :
                      activity.status === 'running' ? 'bg-info bg-opacity-20 text-info' :
                      'bg-danger bg-opacity-20 text-danger'
                    }`}>
                      {activity.status === 'success' ? 'Success' :
                       activity.status === 'running' ? 'Running' :
                       'Failed'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                    {new Date(activity.timestamp).toLocaleDateString() + ' ' + new Date(activity.timestamp).toLocaleTimeString()}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4} className="px-6 py-4 text-center text-neutral-500">
                  No recent activities found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

export default RecentActivity;
