import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { 
  ModelStudioIcon, 
  PipelineIcon, 
  DataSourcesIcon 
} from '@/lib/icons';
import type { StatCard } from '@/types';

const statsData: StatCard[] = [
  {
    title: 'Models',
    value: 24,
    change: '+3 this week',
    description: 'Total trained models in registry',
    icon: 'model_training'
  },
  {
    title: 'Pipelines',
    value: 8,
    change: '+1 this week',
    description: 'Active MLOps pipelines',
    icon: 'account_tree'
  },
  {
    title: 'Data Sources',
    value: 12,
    change: 'No change',
    description: 'Connected data sources',
    icon: 'storage'
  }
];

const DashboardStats: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      {statsData.map((stat, index) => (
        <Card key={index} className="bg-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-neutral-600">{stat.title}</h3>
              {stat.icon === 'model_training' && <ModelStudioIcon className="h-6 w-6 text-primary" />}
              {stat.icon === 'account_tree' && <PipelineIcon className="h-6 w-6 text-primary" />}
              {stat.icon === 'storage' && <DataSourcesIcon className="h-6 w-6 text-primary" />}
            </div>
            <div className="flex items-end">
              <p className="text-3xl font-bold text-neutral-600">{stat.value}</p>
              <p className={`ml-2 text-sm ${stat.change.includes('+') ? 'text-success' : 'text-neutral-400'}`}>
                {stat.change}
              </p>
            </div>
            <p className="text-sm text-neutral-400 mt-2">{stat.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DashboardStats;
