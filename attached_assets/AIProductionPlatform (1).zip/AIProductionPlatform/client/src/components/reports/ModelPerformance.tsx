import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import type { Model } from '@/types';

const ModelPerformance: React.FC = () => {
  const [selectedModelId, setSelectedModelId] = useState<number>(1);
  
  const { data: models, isLoading: isLoadingModels } = useQuery({
    queryKey: ['/api/models'],
    staleTime: 60000 // 1 minute
  });
  
  const selectedModel = models?.find((model: Model) => model.id === selectedModelId);

  return (
    <Card className="bg-white shadow mb-6">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Model Performance Dashboard</h3>
          
          <div className="flex items-center space-x-4">
            <div>
              <Select 
                value={selectedModelId?.toString()} 
                onValueChange={(value) => setSelectedModelId(parseInt(value))}
                disabled={isLoadingModels}
              >
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  {models?.map((model: Model) => (
                    <SelectItem key={model.id} value={model.id.toString()}>
                      {model.name} ({model.version})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Button variant="outline">
                <span className="material-icons text-sm mr-2">download</span>
                Download Report
              </Button>
            </div>
          </div>
        </div>
        
        {isLoadingModels ? (
          <div className="py-10 text-center text-neutral-500">
            Loading model data...
          </div>
        ) : selectedModel ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="border border-neutral-300 rounded-lg p-4">
                <h4 className="text-sm font-medium mb-2">Model Info</h4>
                <div className="text-sm">
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-500">Type:</span>
                    <span className="text-neutral-600 font-medium">{selectedModel.type.charAt(0).toUpperCase() + selectedModel.type.slice(1)}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-500">Algorithm:</span>
                    <span className="text-neutral-600 font-medium">{selectedModel.algorithm.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-500">Version:</span>
                    <span className="text-neutral-600 font-medium">{selectedModel.version}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-500">Status:</span>
                    <span className={`px-2 py-0.5 text-xs rounded-full ${
                      selectedModel.status === 'production' ? 'bg-success bg-opacity-20 text-success' :
                      selectedModel.status === 'draft' ? 'bg-warning bg-opacity-20 text-warning' :
                      'bg-info bg-opacity-20 text-info'
                    }`}>
                      {selectedModel.status.charAt(0).toUpperCase() + selectedModel.status.slice(1)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="border border-neutral-300 rounded-lg p-4">
                <h4 className="text-sm font-medium mb-2">Key Parameters</h4>
                <div className="text-sm">
                  {selectedModel.type === 'clustering' && (
                    <>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">n_clusters:</span>
                        <span className="text-neutral-600 font-medium">5</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">init:</span>
                        <span className="text-neutral-600 font-medium">k-means++</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">max_iter:</span>
                        <span className="text-neutral-600 font-medium">300</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">algorithm:</span>
                        <span className="text-neutral-600 font-medium">auto</span>
                      </div>
                    </>
                  )}
                  
                  {selectedModel.type === 'classification' && (
                    <>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">max_depth:</span>
                        <span className="text-neutral-600 font-medium">10</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">n_estimators:</span>
                        <span className="text-neutral-600 font-medium">100</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">min_samples_split:</span>
                        <span className="text-neutral-600 font-medium">2</span>
                      </div>
                    </>
                  )}
                  
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-500">Features:</span>
                    <span className="text-neutral-600 font-medium">14 features</span>
                  </div>
                </div>
              </div>
              
              <div className="border border-neutral-300 rounded-lg p-4">
                <h4 className="text-sm font-medium mb-2">Performance Metrics</h4>
                <div className="text-sm">
                  {selectedModel.type === 'clustering' && (
                    <>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">Silhouette Score:</span>
                        <span className="text-neutral-600 font-medium">{selectedModel.metrics.silhouetteScore || 0.68}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">Inertia:</span>
                        <span className="text-neutral-600 font-medium">{selectedModel.metrics.inertia || 234.75}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">Calinski-Harabasz:</span>
                        <span className="text-neutral-600 font-medium">187.23</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">Davies-Bouldin:</span>
                        <span className="text-neutral-600 font-medium">0.42</span>
                      </div>
                    </>
                  )}
                  
                  {selectedModel.type === 'classification' && (
                    <>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">Accuracy:</span>
                        <span className="text-neutral-600 font-medium">{selectedModel.metrics.accuracy || 0.92}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">Precision:</span>
                        <span className="text-neutral-600 font-medium">{selectedModel.metrics.precision || 0.88}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">Recall:</span>
                        <span className="text-neutral-600 font-medium">{selectedModel.metrics.recall || 0.85}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-neutral-500">F1 Score:</span>
                        <span className="text-neutral-600 font-medium">{selectedModel.metrics.f1 || 0.86}</span>
                      </div>
                    </>
                  )}
                  
                  <div className="flex justify-between mb-1">
                    <span className="text-neutral-500">Execution Time:</span>
                    <span className="text-neutral-600 font-medium">47.3s</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-neutral-300 rounded-lg p-4">
                <h4 className="text-sm font-medium mb-4">{selectedModel.type === 'clustering' ? 'Cluster Visualization' : 'Model Visualization'}</h4>
                <div id="model-visualization" className="h-64 bg-neutral-100 rounded flex items-center justify-center">
                  <div className="text-sm text-neutral-500">Interactive visualization loading...</div>
                </div>
              </div>
              
              <div className="border border-neutral-300 rounded-lg p-4">
                <h4 className="text-sm font-medium mb-4">{selectedModel.type === 'clustering' ? 'Cluster Distribution' : 'Feature Importance'}</h4>
                <div id="distribution-chart" className="h-64 bg-neutral-100 rounded flex items-center justify-center">
                  <div className="text-sm text-neutral-500">Interactive chart loading...</div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="py-10 text-center text-neutral-500">
            No model selected
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ModelPerformance;
