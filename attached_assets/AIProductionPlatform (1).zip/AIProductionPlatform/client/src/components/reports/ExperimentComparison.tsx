import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface ExperimentVersion {
  version: string;
  algorithm: string;
  parameters: string;
  metrics: {
    silhouetteScore?: number;
    inertia?: number;
    accuracy?: number;
    precision?: number;
    recall?: number;
  };
  runtime: string;
  status: 'production' | 'archived';
}

const experimentVersions: ExperimentVersion[] = [
  {
    version: 'v2.1.0',
    algorithm: 'KMeans',
    parameters: 'n_clusters=5',
    metrics: {
      silhouetteScore: 0.68,
      inertia: 234.75
    },
    runtime: '47.3s',
    status: 'production'
  },
  {
    version: 'v2.0.1',
    algorithm: 'KMeans',
    parameters: 'n_clusters=4',
    metrics: {
      silhouetteScore: 0.65,
      inertia: 256.18
    },
    runtime: '39.7s',
    status: 'archived'
  },
  {
    version: 'v2.0.0',
    algorithm: 'DBSCAN',
    parameters: 'eps=0.5, min_samples=5',
    metrics: {
      silhouetteScore: 0.58
    },
    runtime: '62.1s',
    status: 'archived'
  }
];

const ExperimentComparison: React.FC = () => {
  return (
    <Card className="bg-white shadow">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold mb-4">Experiment Comparison</h3>
        <p className="text-neutral-500 mb-4">Compare results across different model versions and hyperparameter configurations.</p>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-neutral-200">
            <thead className="bg-neutral-100">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Version
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Algorithm
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Parameters
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Silhouette Score
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Inertia
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Runtime
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-neutral-200">
              {experimentVersions.map((version, index) => (
                <tr 
                  key={version.version}
                  className={version.status === 'production' ? 'bg-primary bg-opacity-5' : ''}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600 font-medium">
                    {version.version}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                    {version.algorithm}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-neutral-500">
                    {version.parameters}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                    {version.metrics.silhouetteScore}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                    {version.metrics.inertia || 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                    {version.runtime}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Badge 
                      variant="outline"
                      className={`${
                        version.status === 'production' 
                          ? 'bg-success bg-opacity-20 text-success' 
                          : 'bg-neutral-200 text-neutral-600'
                      }`}
                    >
                      {version.status === 'production' ? 'Production' : 'Archived'}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 flex justify-end">
          <Button variant="outline" size="sm">
            <span className="material-icons text-sm mr-2">compare_arrows</span>
            Compare Selected
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExperimentComparison;
