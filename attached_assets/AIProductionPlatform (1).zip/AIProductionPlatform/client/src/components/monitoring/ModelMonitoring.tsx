import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { RefreshCw, CheckCircle, XCircle, AlertTriangle, AlertCircle } from "lucide-react";
import { useModelStatusUpdates, useMonitoring } from '@/contexts/MonitoringContext';
import { MonitoringEvent } from '@/hooks/use-real-time-monitoring';

export function ModelMonitoring() {
  const [modelUpdates, setModelUpdates] = useState<MonitoringEvent[]>([]);
  const monitoring = useMonitoring();
  const updates = useModelStatusUpdates();
  
  useEffect(() => {
    setModelUpdates(updates);
  }, [updates]);
  
  const getStatusIcon = (status?: string) => {
    switch (status) {
      case 'running':
        return <AlertCircle className="h-4 w-4 text-blue-500" />;
      case 'training':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-muted-foreground" />;
    }
  };
  
  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-500 border-green-500';
      case 'failed':
        return 'text-red-500 border-red-500';
      case 'running':
      case 'training':
        return 'text-blue-500 border-blue-500';
      case 'warning':
        return 'text-amber-500 border-amber-500';
      default:
        return 'text-muted-foreground border-muted-foreground';
    }
  };
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Model Monitoring</CardTitle>
          <Badge variant="outline" className={monitoring.connected ? 'text-green-500' : 'text-red-500'}>
            {monitoring.connected ? 'Connected' : 'Disconnected'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[300px]">
          {modelUpdates.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground">
              <p>No model status updates available</p>
              <p className="text-sm mt-2">Model status updates will appear here in real-time</p>
            </div>
          ) : (
            <ul className="divide-y divide-border px-6">
              {modelUpdates.map((update, index) => (
                <li key={index} className="py-3">
                  <div className="flex items-start">
                    <div className="mr-3 mt-1">{getStatusIcon(update.status)}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">{update.name}</p>
                        <Badge className={getStatusColor(update.status)}>
                          {update.status}
                        </Badge>
                      </div>
                      {update.timestamp && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(update.timestamp).toLocaleString()}
                        </p>
                      )}
                      {update.details && (
                        <div className="mt-2 text-sm text-muted-foreground">
                          {typeof update.details === 'object' 
                            ? Object.entries(update.details).map(([key, value]) => (
                                <div key={key} className="flex items-center">
                                  <span className="font-medium mr-2">{key}:</span>
                                  <span>{value?.toString()}</span>
                                </div>
                              ))
                            : update.details
                          }
                        </div>
                      )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}