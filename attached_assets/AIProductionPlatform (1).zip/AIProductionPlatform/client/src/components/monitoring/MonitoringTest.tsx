import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMonitoring } from '@/contexts/MonitoringContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export function MonitoringTest() {
  const { connected } = useMonitoring();
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  
  const generateModelEvent = async () => {
    try {
      setIsGenerating(true);
      // Create model with random ID and status
      const statuses = ['running', 'completed', 'failed', 'warning'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      
      // Call backend API to trigger a real status update
      await apiRequest('POST', '/api/test/model-event', {
        name: `Test Model ${Math.floor(Math.random() * 1000)}`,
        status: randomStatus,
        details: {
          accuracy: Math.random().toFixed(4),
          f1Score: Math.random().toFixed(4),
          trainingTime: `${Math.floor(Math.random() * 120)} mins`
        }
      });
      
      toast({
        title: 'Event Generated',
        description: `A model ${randomStatus} event has been sent to the monitoring system`,
      });
    } catch (error) {
      toast({
        title: 'Failed to Generate Event',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  const generatePipelineEvent = async () => {
    try {
      setIsGenerating(true);
      // Create pipeline with random ID and status
      const statuses = ['running', 'completed', 'failed', 'pending'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      
      // Call backend API to trigger a real status update
      await apiRequest('POST', '/api/test/pipeline-event', {
        name: `Test Pipeline ${Math.floor(Math.random() * 1000)}`,
        status: randomStatus,
        details: {
          steps: Math.floor(Math.random() * 10) + 1,
          currentStep: Math.floor(Math.random() * 5) + 1,
          processingTime: `${Math.floor(Math.random() * 60)} secs`
        }
      });
      
      toast({
        title: 'Event Generated',
        description: `A pipeline ${randomStatus} event has been sent to the monitoring system`,
      });
    } catch (error) {
      toast({
        title: 'Failed to Generate Event',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  const generateAlert = async () => {
    try {
      setIsGenerating(true);
      // Create alert with random severity
      const severities = ['info', 'warning', 'critical'];
      const randomSeverity = severities[Math.floor(Math.random() * severities.length)];
      
      // Call backend API to trigger a real alert
      await apiRequest('POST', '/api/test/alert', {
        severity: randomSeverity,
        source: 'System Monitor',
        message: `Test alert with ${randomSeverity} severity`,
        details: {
          component: 'Test Component',
          errorCode: Math.floor(Math.random() * 1000),
          timestamp: new Date().toISOString()
        }
      });
      
      toast({
        title: 'Alert Generated',
        description: `A ${randomSeverity} alert has been sent to the monitoring system`,
      });
    } catch (error) {
      toast({
        title: 'Failed to Generate Alert',
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Monitoring Test Controls</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              onClick={generateModelEvent} 
              disabled={!connected || isGenerating}
              variant="outline"
            >
              Generate Model Event
            </Button>
            <Button 
              onClick={generatePipelineEvent} 
              disabled={!connected || isGenerating}
              variant="outline"
            >
              Generate Pipeline Event
            </Button>
            <Button 
              onClick={generateAlert} 
              disabled={!connected || isGenerating}
              variant="outline"
            >
              Generate Alert
            </Button>
          </div>
          
          <div className="text-sm text-center text-muted-foreground">
            {connected ? 
              'WebSocket connected. You can generate test events.' : 
              'WebSocket disconnected. Cannot generate events.'}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}