import { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useRealTimeMonitoring, MonitoringEvent } from '@/hooks/use-real-time-monitoring';
import { Bell, Activity, AlertTriangle } from 'lucide-react';

export function RealTimeMonitor() {
  const { connected, events, getAlerts, getStatusUpdates, subscribe } = useRealTimeMonitoring();
  
  // Subscribe to all channels on mount
  useEffect(() => {
    if (connected) {
      subscribe('models');
      subscribe('pipelines');
      subscribe('data_sources');
    }
  }, [connected, subscribe]);
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg">Real-Time Monitoring</CardTitle>
            <CardDescription>System events and alerts</CardDescription>
          </div>
          <ConnectionStatus connected={connected} />
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="w-full justify-start px-6">
            <TabsTrigger value="all">All Events</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
            <TabsTrigger value="status">Status Updates</TabsTrigger>
          </TabsList>
          
          <EventList value="all" events={events} />
          <EventList value="alerts" events={getAlerts()} />
          <EventList value="status" events={getStatusUpdates()} />
        </Tabs>
      </CardContent>
    </Card>
  );
}

function ConnectionStatus({ connected }: { connected: boolean }) {
  return (
    <Badge variant={connected ? "outline" : "destructive"} className="px-2 py-1">
      {connected ? (
        <>
          <span className="h-2 w-2 rounded-full bg-green-500 mr-2 animate-pulse"></span>
          Connected
        </>
      ) : (
        <>
          <span className="h-2 w-2 rounded-full bg-red-500 mr-2"></span>
          Disconnected
        </>
      )}
    </Badge>
  );
}

function EventList({ value, events }: { value: string; events: MonitoringEvent[] }) {
  return (
    <TabsContent value={value} className="m-0">
      <ScrollArea className="h-[300px] px-6 py-4">
        {events.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No events to display
          </div>
        ) : (
          <div className="space-y-4">
            {events.map((event, index) => (
              <EventItem key={index} event={event} />
            ))}
          </div>
        )}
      </ScrollArea>
    </TabsContent>
  );
}

function EventItem({ event }: { event: MonitoringEvent }) {
  const getIcon = () => {
    switch (event.type) {
      case 'alert':
        return <AlertTriangle className={`h-4 w-4 ${getSeverityColor(event.severity)}`} />;
      case 'status_update':
        return <Activity className="h-4 w-4 text-blue-500" />;
      default:
        return <Bell className="h-4 w-4 text-gray-500" />;
    }
  };
  
  const getSeverityColor = (severity?: string) => {
    switch (severity) {
      case 'critical':
        return 'text-red-500';
      case 'warning':
        return 'text-amber-500';
      case 'info':
      default:
        return 'text-blue-500';
    }
  };
  
  const getStatusBadge = () => {
    if (event.type !== 'status_update' || !event.status) return null;
    
    const variantMap: Record<string, "default" | "outline" | "secondary" | "destructive"> = {
      running: "default",
      completed: "outline",
      failed: "destructive",
      pending: "secondary",
    };
    
    return (
      <Badge variant={variantMap[event.status] || "outline"} className="ml-2">
        {event.status}
      </Badge>
    );
  };
  
  const getEventTitle = () => {
    if (event.type === 'alert') {
      return event.message;
    }
    
    if (event.type === 'status_update') {
      return `${event.entityType}: ${event.name}`;
    }
    
    return event.message || 'System event';
  };
  
  const formatTime = (timestamp?: string) => {
    if (!timestamp) return '';
    
    try {
      const date = new Date(timestamp);
      return date.toLocaleTimeString();
    } catch (e) {
      return '';
    }
  };
  
  return (
    <div className="flex items-start space-x-3 p-2 rounded-md border border-border bg-background/50">
      <div className="mt-0.5">{getIcon()}</div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center">
          <p className="text-sm font-medium truncate">{getEventTitle()}</p>
          {getStatusBadge()}
        </div>
        {event.source && (
          <p className="text-xs text-muted-foreground mt-1">Source: {event.source}</p>
        )}
        {event.timestamp && (
          <p className="text-xs text-muted-foreground mt-1">{formatTime(event.timestamp)}</p>
        )}
      </div>
    </div>
  );
}