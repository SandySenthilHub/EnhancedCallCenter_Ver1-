import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  PlusCircle, 
  Play, 
  Square, 
  Link, 
  Database, 
  FileType, 
  Save 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const DataFlowDesigner: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Data Flow Designer</CardTitle>
        <CardDescription>
          Create visual data pipelines with a drag-and-drop interface
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="border rounded-lg p-4 h-[450px] flex flex-col bg-white">
          <div className="mb-4 flex space-x-2 items-center">
            <div className="flex flex-wrap gap-2">
              <Button variant="default" size="sm">
                <PlusCircle className="h-4 w-4 mr-1" />
                Add Processor
              </Button>
              <Button variant="outline" size="sm">
                <Link className="h-4 w-4 mr-1" />
                Connect
              </Button>
              <Button variant="outline" size="sm" className="text-green-600 hover:bg-green-50">
                <Play className="h-4 w-4 mr-1" />
                Run
              </Button>
              <Button variant="outline" size="sm" className="text-red-600 hover:bg-red-50">
                <Square className="h-4 w-4 mr-1" />
                Stop
              </Button>
            </div>
            <div className="ml-auto">
              <Button variant="ghost" size="sm">
                <Save className="h-4 w-4 mr-1" />
                Save
              </Button>
            </div>
          </div>
          
          <div className="flex-1 bg-slate-50 rounded-lg border border-slate-200 relative overflow-hidden">
            <div className="absolute left-4 top-4 text-xs text-slate-500">
              <Badge variant="outline" className="mb-2">Development Preview</Badge>
              <div className="p-2 bg-white rounded border border-slate-200 shadow-sm">
                <p>This is a visual preview of the flow designer.</p>
                <p className="mt-1">The full functionality is under development.</p>
              </div>
            </div>
            
            {/* Source processor */}
            <div className="absolute left-20 top-20">
              <div className="w-44 h-24 rounded-lg bg-white shadow-md border border-blue-200 p-2 flex flex-col">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                  <span className="text-xs font-medium text-slate-700">GetDatabaseData</span>
                  <Badge variant="outline" className="text-[10px] px-1 h-4">Input</Badge>
                </div>
                <div className="flex-1 flex items-center px-2">
                  <div className="flex items-center space-x-2">
                    <Database className="h-4 w-4 text-blue-500" />
                    <div className="text-xs text-slate-600">
                      <div>PostgreSQL</div>
                      <div className="text-[10px] text-slate-400">users_table</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Transformation processor */}
            <div className="absolute right-[180px] top-20">
              <div className="w-44 h-24 rounded-lg bg-white shadow-md border border-amber-200 p-2 flex flex-col">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                  <span className="text-xs font-medium text-slate-700">TransformData</span>
                  <Badge variant="outline" className="text-[10px] px-1 h-4">Process</Badge>
                </div>
                <div className="flex-1 flex items-center px-2">
                  <div className="flex items-center space-x-2">
                    <svg className="h-4 w-4 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M12 3v3m0 12v3M3 12h3m12 0h3m-4-4l-2-2m-6 0L7 7m0 10l2-2m6 0l2 2" />
                    </svg>
                    <div className="text-xs text-slate-600">
                      <div>Filter + Transform</div>
                      <div className="text-[10px] text-slate-400">3 operations</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Destination processor */}
            <div className="absolute right-20 top-[140px]">
              <div className="w-44 h-24 rounded-lg bg-white shadow-md border border-green-200 p-2 flex flex-col">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                  <span className="text-xs font-medium text-slate-700">SaveToParquet</span>
                  <Badge variant="outline" className="text-[10px] px-1 h-4">Output</Badge>
                </div>
                <div className="flex-1 flex items-center px-2">
                  <div className="flex items-center space-x-2">
                    <FileType className="h-4 w-4 text-green-500" />
                    <div className="text-xs text-slate-600">
                      <div>Parquet File</div>
                      <div className="text-[10px] text-slate-400">s3://bucket/data.parquet</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Connection lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              {/* Connection from source to transform */}
              <path 
                d="M160 70 L300 70" 
                stroke="#6B7280" 
                strokeWidth="2" 
                fill="none" 
                strokeDasharray="4,2"
              />
              <polygon 
                points="298,66 306,70 298,74" 
                fill="#6B7280"
              />
              
              {/* Connection from transform to destination */}
              <path 
                d="M360 90 L360 140" 
                stroke="#6B7280" 
                strokeWidth="2" 
                fill="none" 
                strokeDasharray="4,2"
              />
              <polygon 
                points="356,138 360,146 364,138" 
                fill="#6B7280"
              />
            </svg>
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-blue-50 border border-blue-100 rounded-md text-blue-700 text-sm">
          <p>
            <span className="font-medium">Coming Soon:</span> Full integration with Apache NiFi, Spark, and Flink for enterprise-grade 
            data processing pipelines directly from this interface.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default DataFlowDesigner;
