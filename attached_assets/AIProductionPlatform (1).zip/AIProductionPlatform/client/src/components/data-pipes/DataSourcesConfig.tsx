import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Database, 
  Cloud, 
  Server, 
  HardDrive, 
  FileText, 
  Edit, 
  Trash2, 
  Plus 
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

// Define our DataSource interface
interface DataSource {
  id: number;
  name: string;
  type: string;
  connection: string;
  status: string;
}

const DataSourcesConfig: React.FC = () => {
  const { data: dataSources = [], isLoading } = useQuery<DataSource[]>({
    queryKey: ['/api/data-sources'],
    staleTime: 60000 // 1 minute
  });

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>Data Sources</CardTitle>
        <CardDescription>Connect to your data storage systems</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <button 
            className="h-32 border-2 border-dashed border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors flex flex-col items-center justify-center p-4"
            title="Add a new data source"
          >
            <Database className="h-8 w-8 text-gray-400" />
            <span className="mt-2 text-gray-700 font-medium">Database</span>
            <span className="text-xs text-gray-500 mt-1">SQL or NoSQL</span>
          </button>
          
          <button 
            className="h-32 border-2 border-dashed border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors flex flex-col items-center justify-center p-4"
            title="Add a new cloud storage"
          >
            <Cloud className="h-8 w-8 text-gray-400" />
            <span className="mt-2 text-gray-700 font-medium">Cloud Storage</span>
            <span className="text-xs text-gray-500 mt-1">S3, Azure, GCS</span>
          </button>
          
          <button 
            className="h-32 border-2 border-dashed border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors flex flex-col items-center justify-center p-4"
            title="Add file system source"
          >
            <HardDrive className="h-8 w-8 text-gray-400" />
            <span className="mt-2 text-gray-700 font-medium">File System</span>
            <span className="text-xs text-gray-500 mt-1">HDFS, Local files</span>
          </button>
          
          <button 
            className="h-32 border-2 border-dashed border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-colors flex flex-col items-center justify-center p-4"
            title="Add other data source"
          >
            <FileText className="h-8 w-8 text-gray-400" />
            <span className="mt-2 text-gray-700 font-medium">Other</span>
            <span className="text-xs text-gray-500 mt-1">APIs, Streams, etc.</span>
          </button>
        </div>
        
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-medium">Connected Data Sources</h3>
            <Button variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Source
            </Button>
          </div>
          
          <div className="border rounded-md overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Connection Details
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {isLoading ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                      <div className="flex flex-col items-center">
                        <div className="animate-spin h-5 w-5 border-2 border-blue-500 rounded-full border-t-transparent mb-2"></div>
                        <span>Loading data sources...</span>
                      </div>
                    </td>
                  </tr>
                ) : dataSources.length > 0 ? (
                  dataSources.map((source: DataSource) => (
                    <tr key={source.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        {source.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        {source.type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono text-xs">
                        {source.connection}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge variant={source.status === 'connected' ? 'default' : 'outline'} 
                               className={source.status === 'connected' ? 'bg-green-100 text-green-800 hover:bg-green-200 hover:text-green-900' : ''}>
                          {source.status === 'connected' ? 'Connected' : 'Disconnected'}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        <div className="flex space-x-3">
                          <button className="p-1 text-gray-400 hover:text-blue-500" aria-label="Edit">
                            <Edit className="h-4 w-4" />
                          </button>
                          <button className="p-1 text-gray-400 hover:text-red-500" aria-label="Delete">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                      <p>No data sources connected</p>
                      <p className="text-sm mt-1">Click on one of the options above to connect a data source</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DataSourcesConfig;
