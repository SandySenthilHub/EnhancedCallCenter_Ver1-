import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/Dashboard";
import DataPipes from "@/pages/DataPipes";
import ModelStudio from "@/pages/ModelStudio";
import PipelineOrchestrator from "@/pages/PipelineOrchestrator";
import Reports from "@/pages/Reports";
import Integrations from "@/pages/Integrations";
import FeatureStore from "@/pages/FeatureStore";
import Experiments from "@/pages/Experiments";
import FeatureEngineering from "@/pages/FeatureEngineering";
import FeatureSelectionPage from "@/pages/FeatureSelectionPage";
import AIFeatureNaming from "@/pages/AIFeatureNaming";
import BusinessCaseSettings from "@/pages/BusinessCaseSettings";
import MLOpsAutomation from "@/pages/MLOpsAutomation";
import ReinforcementLearning from "@/pages/ReinforcementLearning";
import Collaboration from "@/pages/Collaboration";
import DataSourcesPage from "@/pages/DataSourcesPage";
import WorkflowWizard from "@/pages/WorkflowWizard";
import AlgorithmDependencies from "@/pages/AlgorithmDependencies";
import LibraryDependencies from "@/pages/LibraryDependencies";
import DatabaseMigration from "@/pages/DatabaseMigration";
import CsvUploader from "@/pages/CsvUploader";
import SimpleCsvLoader from "@/pages/SimpleCsvLoader";
import DirectImport from "@/pages/DirectImport";
import DataEncoding from "@/pages/DataEncoding";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DependenciesTest from "@/pages/DependenciesTest";
import ModelTraining from "@/pages/ModelTraining";
// Model Registry
import ModelRegistry from "@/pages/ModelRegistry";
import ModelDetail from "@/pages/ModelDetail";
import CreateModel from "@/pages/CreateModel";
import CreateVersion from "@/pages/CreateVersion";
import ModelImport from "@/pages/ModelImport";
import MainLayout from "@/components/layout/MainLayout";
import { AuthProvider } from "@/hooks/use-auth";
import { MonitoringProvider } from "@/contexts/MonitoringContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/data-pipes" component={DataPipes} />
      <ProtectedRoute path="/data-sources" component={DataSourcesPage} />
      <ProtectedRoute path="/data-encoding" component={DataEncoding} />
      <ProtectedRoute path="/model-studio" component={ModelStudio} />
      <ProtectedRoute path="/pipeline-orchestrator" component={PipelineOrchestrator} />
      <ProtectedRoute path="/reports" component={Reports} />
      <ProtectedRoute path="/integrations" component={Integrations} />
      <ProtectedRoute path="/feature-store" component={FeatureStore} />
      <ProtectedRoute path="/experiments" component={Experiments} />
      <ProtectedRoute path="/feature-engineering" component={FeatureEngineering} />
      <ProtectedRoute path="/feature-selection" component={FeatureSelectionPage} />
      <ProtectedRoute path="/ai-feature-naming" component={AIFeatureNaming} />
      <ProtectedRoute path="/business-case-settings" component={BusinessCaseSettings} />
      <ProtectedRoute path="/mlops-automation" component={MLOpsAutomation} />
      <ProtectedRoute path="/reinforcement-learning" component={ReinforcementLearning} />
      <ProtectedRoute path="/collaboration" component={Collaboration} />
      <ProtectedRoute path="/workflow-wizard" component={WorkflowWizard} />
      <ProtectedRoute path="/algorithm-dependencies" component={AlgorithmDependencies} />
      <ProtectedRoute path="/library-dependencies" component={LibraryDependencies} />
      <ProtectedRoute path="/database-migration" component={DatabaseMigration} />
      <ProtectedRoute path="/csv-uploader" component={CsvUploader} />
      <ProtectedRoute path="/simple-csv-loader" component={SimpleCsvLoader} />
      <ProtectedRoute path="/model-training" component={ModelTraining} />
      <ProtectedRoute path="/model-registry" component={ModelRegistry} />
      <ProtectedRoute path="/model-registry/model/:id" component={ModelDetail} />
      <ProtectedRoute path="/model-registry/new-model" component={CreateModel} />
      <ProtectedRoute path="/model-registry/model/:id/new-version" component={CreateVersion} />
      <ProtectedRoute path="/model-registry/import" component={ModelImport} />
      <Route path="/direct-import" component={DirectImport} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/dependencies-test" component={DependenciesTest} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <MonitoringProvider>
          <TooltipProvider>
            <Toaster />
            <Switch>
              <Route path="/auth" component={AuthPage} />
              <Route>
                <MainLayout>
                  <Router />
                </MainLayout>
              </Route>
            </Switch>
          </TooltipProvider>
        </MonitoringProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
