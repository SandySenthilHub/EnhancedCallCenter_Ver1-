import { Express } from 'express';
import ModelTrainingRoutes from './model-training';

export function registerModelTrainingRoutes(app: Express, isAuthenticated: any) {
  app.use('/api/model-training', isAuthenticated, ModelTrainingRoutes);
  console.log('Model Training routes registered');
}