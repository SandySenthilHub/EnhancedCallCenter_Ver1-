import { Router, Request, Response } from 'express';
import { z } from 'zod';
import sql from 'mssql';
import { executeInsert, executeParameterizedQuery } from '../db';

const router = Router();

const trainModelSchema = z.object({
  modelName: z.string().min(1, "Model name is required"),
  description: z.string().optional(),
  platform: z.enum(["azure", "aws", "local"]),
  modelType: z.enum(["classification", "regression"]),
  algorithm: z.string().min(1, "Algorithm is required"),
  datasetId: z.string().min(1, "Dataset ID is required"),
  targetColumn: z.string().min(1, "Target column is required"),
  hyperparameters: z.record(z.string(), z.string()),
  saveToRegistry: z.boolean().default(true)
});

// Start a model training job
router.post('/train', async (req: Request, res: Response) => {
  try {
    const validatedData = trainModelSchema.parse(req.body);
    
    // Save training job to database
    const trainingJob = await executeInsert<{ id: number }>('ModelTrainingJobs', {
      modelName: validatedData.modelName,
      description: validatedData.description || '',
      platform: validatedData.platform,
      modelType: validatedData.modelType,
      algorithm: validatedData.algorithm,
      datasetId: validatedData.datasetId,
      targetColumn: validatedData.targetColumn,
      hyperparameters: JSON.stringify(validatedData.hyperparameters),
      saveToRegistry: validatedData.saveToRegistry,
      status: 'pending',
      createdAt: new Date().toISOString(),
      userId: req.user?.id || null
    });

    if (!trainingJob) {
      return res.status(500).json({ error: 'Failed to create training job' });
    }

    // For each hyperparameter, save to Hyperparameters table
    for (const [key, value] of Object.entries(validatedData.hyperparameters)) {
      await executeInsert('Hyperparameters', {
        trainingJobId: trainingJob.id,
        name: key,
        value: value
      });
    }

    // Simulate starting a training job (in a production app, this would call Azure ML or AWS SageMaker APIs)
    setTimeout(() => {
      updateTrainingJobStatus(trainingJob.id, 'running');
      
      // Simulate job completion after some time
      setTimeout(() => {
        updateTrainingJobStatus(trainingJob.id, 'completed');
        
        // Simulate saving metrics
        saveTrainingMetrics(trainingJob.id, {
          accuracy: Math.random() * 0.3 + 0.7, // Random value between 0.7 and 1.0
          precision: Math.random() * 0.3 + 0.7,
          recall: Math.random() * 0.3 + 0.7,
          f1_score: Math.random() * 0.3 + 0.7,
          training_time: Math.floor(Math.random() * 300) + 100 // Random time between 100 and 400 seconds
        });
        
        // If saveToRegistry is true, save to model registry
        if (validatedData.saveToRegistry) {
          saveToModelRegistry(trainingJob.id, validatedData);
        }
      }, 30000); // Simulate 30 seconds for training
    }, 5000); // Simulate 5 seconds for job startup

    res.status(200).json({ 
      jobId: trainingJob.id,
      message: 'Training job started successfully' 
    });
  } catch (error) {
    console.error('Error starting training job:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        error: 'Validation failed', 
        details: error.errors 
      });
    }
    res.status(500).json({ 
      error: 'Failed to start training job',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Get all training jobs
router.get('/', async (req: Request, res: Response) => {
  try {
    const userId = req.user?.id;
    let query = 'SELECT * FROM ModelTrainingJobs';
    let params = {};
    
    // If user is authenticated, filter by their ID
    if (userId) {
      query += ' WHERE userId = @userId';
      params = { userId };
    }
    
    query += ' ORDER BY createdAt DESC';
    
    const trainingJobs = await executeParameterizedQuery(query, params);
    
    res.status(200).json(trainingJobs);
  } catch (error) {
    console.error('Error fetching training jobs:', error);
    res.status(500).json({ 
      error: 'Failed to fetch training jobs',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Get a specific training job
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const jobId = parseInt(req.params.id);
    if (isNaN(jobId)) {
      return res.status(400).json({ error: 'Invalid job ID' });
    }
    
    // Get job basic info
    const [job] = await executeParameterizedQuery(
      'SELECT * FROM ModelTrainingJobs WHERE id = @jobId',
      { jobId }
    );
    
    if (!job) {
      return res.status(404).json({ error: 'Training job not found' });
    }
    
    // Get hyperparameters
    const hyperparameters = await executeParameterizedQuery(
      'SELECT name, value FROM Hyperparameters WHERE trainingJobId = @jobId',
      { jobId }
    );
    
    // Get metrics
    const metrics = await executeParameterizedQuery(
      'SELECT name, value FROM Metrics WHERE trainingJobId = @jobId',
      { jobId }
    );
    
    // Format response
    const response = {
      ...job,
      hyperparameters: hyperparameters.reduce((acc: Record<string, string>, curr: any) => {
        acc[curr.name] = curr.value;
        return acc;
      }, {}),
      metrics: metrics.reduce((acc: Record<string, string>, curr: any) => {
        acc[curr.name] = curr.value;
        return acc;
      }, {})
    };
    
    res.status(200).json(response);
  } catch (error) {
    console.error('Error fetching training job:', error);
    res.status(500).json({ 
      error: 'Failed to fetch training job',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Helper function to update training job status
async function updateTrainingJobStatus(jobId: number, status: string) {
  try {
    await executeParameterizedQuery(
      'UPDATE ModelTrainingJobs SET status = @status, updatedAt = @updatedAt WHERE id = @jobId',
      { 
        jobId,
        status,
        updatedAt: new Date().toISOString()
      }
    );
    console.log(`Updated job ${jobId} status to ${status}`);
  } catch (error) {
    console.error(`Error updating job ${jobId} status:`, error);
  }
}

// Helper function to save training metrics
async function saveTrainingMetrics(jobId: number, metrics: Record<string, number>) {
  try {
    for (const [name, value] of Object.entries(metrics)) {
      await executeInsert('Metrics', {
        trainingJobId: jobId,
        name,
        value: value.toString()
      });
    }
    console.log(`Saved metrics for job ${jobId}`);
  } catch (error) {
    console.error(`Error saving metrics for job ${jobId}:`, error);
  }
}

// Helper function to save model to registry
async function saveToModelRegistry(jobId: number, jobData: z.infer<typeof trainModelSchema>) {
  try {
    // Get the training job to access its data
    const [job] = await executeParameterizedQuery(
      'SELECT * FROM ModelTrainingJobs WHERE id = @jobId',
      { jobId }
    );
    
    if (!job) {
      throw new Error('Training job not found');
    }
    
    // Get metrics for this training job
    const metrics = await executeParameterizedQuery(
      'SELECT name, value FROM Metrics WHERE trainingJobId = @jobId',
      { jobId }
    );
    
    const metricsObject = metrics.reduce((acc: Record<string, string>, curr: any) => {
      acc[curr.name] = curr.value;
      return acc;
    }, {});
    
    // Insert into Models table
    await executeInsert('Models', {
      name: job.modelName,
      type: job.modelType,
      algorithm: job.algorithm,
      parameters: job.hyperparameters,
      metrics: JSON.stringify(metricsObject),
      status: 'trained',
      userId: job.userId,
      version: '1.0.0', // Default to 1.0.0 for new models
      platform: job.platform,
      trainingJobId: jobId,
      createdAt: new Date().toISOString()
    });
    
    console.log(`Saved model from job ${jobId} to registry`);
  } catch (error) {
    console.error(`Error saving model to registry for job ${jobId}:`, error);
  }
}

export default router;