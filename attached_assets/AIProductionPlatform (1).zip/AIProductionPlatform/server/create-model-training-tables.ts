/**
 * Script to create model training related tables in SQL Server
 */
import sql from 'mssql';

async function createModelTrainingTables() {
  try {
    // Import the SQL connection
    const { getPool } = await import('./db');
    const pool = await getPool();

    console.log('Creating model training tables...');

    // Create ModelTrainingJobs table
    await pool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ModelTrainingJobs')
      BEGIN
        CREATE TABLE ModelTrainingJobs (
          id INT IDENTITY(1,1) PRIMARY KEY,
          modelName NVARCHAR(255) NOT NULL,
          description NVARCHAR(MAX),
          platform NVARCHAR(50) NOT NULL,
          modelType NVARCHAR(50) NOT NULL,
          algorithm NVARCHAR(100) NOT NULL,
          datasetId NVARCHAR(255) NOT NULL,
          targetColumn NVARCHAR(100) NOT NULL,
          hyperparameters NVARCHAR(MAX),
          saveToRegistry BIT NOT NULL DEFAULT 1,
          status NVARCHAR(50) NOT NULL,
          createdAt NVARCHAR(50) NOT NULL,
          updatedAt NVARCHAR(50),
          userId INT
        );
        PRINT 'Created ModelTrainingJobs table';
      END
      ELSE
      BEGIN
        PRINT 'ModelTrainingJobs table already exists';
      END
    `);

    // Create Hyperparameters table
    await pool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Hyperparameters')
      BEGIN
        CREATE TABLE Hyperparameters (
          id INT IDENTITY(1,1) PRIMARY KEY,
          trainingJobId INT NOT NULL,
          name NVARCHAR(100) NOT NULL,
          value NVARCHAR(255),
          CONSTRAINT FK_Hyperparameters_TrainingJob FOREIGN KEY (trainingJobId)
            REFERENCES ModelTrainingJobs(id) ON DELETE CASCADE
        );
        PRINT 'Created Hyperparameters table';
      END
      ELSE
      BEGIN
        PRINT 'Hyperparameters table already exists';
      END
    `);

    // Create Metrics table
    await pool.request().query(`
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Metrics')
      BEGIN
        CREATE TABLE Metrics (
          id INT IDENTITY(1,1) PRIMARY KEY,
          trainingJobId INT NOT NULL,
          name NVARCHAR(100) NOT NULL,
          value NVARCHAR(255),
          CONSTRAINT FK_Metrics_TrainingJob FOREIGN KEY (trainingJobId)
            REFERENCES ModelTrainingJobs(id) ON DELETE CASCADE
        );
        PRINT 'Created Metrics table';
      END
      ELSE
      BEGIN
        PRINT 'Metrics table already exists';
      END
    `);

    console.log('Model training tables created successfully');
  } catch (error) {
    console.error('Error creating model training tables:', error);
    throw error;
  }
}

// Execute the function when imported
createModelTrainingTables()
  .then(() => {
    console.log('Model training tables setup complete');
  })
  .catch(error => {
    console.error('Failed to create model training tables:', error);
  });

export default createModelTrainingTables;