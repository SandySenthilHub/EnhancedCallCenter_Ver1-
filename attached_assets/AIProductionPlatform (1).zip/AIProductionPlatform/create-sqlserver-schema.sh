#!/bin/bash
# Script to create SQL Server schema

echo "Creating SQL Server schema..."
npx tsx server/execute-sqlserver-schema.ts