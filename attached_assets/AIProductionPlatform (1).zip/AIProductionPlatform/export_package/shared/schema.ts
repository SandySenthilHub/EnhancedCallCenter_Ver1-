import { pgTable, text, serial, integer, boolean, timestamp, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { MODEL_TYPES, MODEL_STAGES, REGISTRY_ROLES } from './model-registry-schema';

// Integration types for external systems
export const INTEGRATION_TYPES = {
  NIFI: 'nifi',
  SPARK: 'spark',
  FLINK: 'flink'
} as const;

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("data_scientist"),
});

// Data source model
export const dataSources = pgTable("data_sources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // e.g., azure, aws, local, spark, upload
  connection: text("connection").notNull(),
  status: text("status").notNull().default("disconnected"),
  config: jsonb("config").notNull().default({}), // Configuration options specific to the data source type
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Files metadata model
export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  source: text("source").notNull(), // e.g., azure, aws, local, spark, upload
  path: text("path").notNull(), // Path or URL to the file
  size: integer("size").notNull(),
  format: text("format").notNull(), // e.g., csv, json, parquet, wav, mp3
  status: text("status").notNull().default("raw"), // e.g., raw, processing, processed
  dataSourceId: integer("data_source_id").references(() => dataSources.id),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Algorithm dependencies table - stores libraries/packages required for algorithms
export const algorithmDependencies = pgTable("algorithm_dependencies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),  // Package/library name
  version: text("version"),               // Version requirement (e.g. ">=1.2.0")
  packageManager: text("package_manager").notNull(), // pip, npm, etc.
  category: text("category"),             // Package category (e.g. "Machine Learning", "Data Analysis")
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Algorithm dependency mappings - connects algorithms to their required dependencies
export const algorithmDependencyMappings = pgTable("algorithm_dependency_mappings", {
  id: serial("id").primaryKey(),
  algorithmName: text("algorithm_name").notNull(), // Name of algorithm (e.g. "xgboost", "kmeans")
  dependencyId: integer("dependency_id").notNull().references(() => algorithmDependencies.id),
  required: boolean("required").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Models table
export const models = pgTable("models", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // regression, classification, clustering
  algorithm: text("algorithm").notNull(), // linear_regression, kmeans, etc.
  parameters: jsonb("parameters").notNull().default({}),
  metrics: jsonb("metrics").notNull().default({}),
  status: text("status").notNull().default("draft"),
  dataSourceId: integer("data_source_id").references(() => dataSources.id),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  version: text("version").notNull(),
  dependenciesInstalled: boolean("dependencies_installed").default(false),
});

// Pipelines table
export const pipelines = pgTable("pipelines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // classification, regression, clustering
  schedule: text("schedule").notNull(),
  status: text("status").notNull().default("draft"),
  config: jsonb("config").notNull().default({}),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  lastRun: timestamp("last_run"),
});

// Activities table
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  activity: text("activity").notNull(),
  pipeline: text("pipeline"),
  status: text("status").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  userId: integer("user_id").references(() => users.id),
});

// Insert schemas
export const insertAlgorithmDependencySchema = createInsertSchema(algorithmDependencies).pick({
  name: true,
  version: true,
  packageManager: true,
  category: true,
  description: true,
});

export const insertAlgorithmDependencyMappingSchema = createInsertSchema(algorithmDependencyMappings).pick({
  algorithmName: true,
  dependencyId: true,
  required: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
});

export const insertDataSourceSchema = createInsertSchema(dataSources).pick({
  name: true,
  type: true,
  connection: true,
  status: true,
  config: true,
  userId: true,
});

export const insertFileSchema = createInsertSchema(files).pick({
  name: true,
  source: true,
  path: true,
  size: true,
  format: true,
  status: true,
  dataSourceId: true,
  userId: true,
});

export const insertModelSchema = createInsertSchema(models).pick({
  name: true,
  type: true,
  algorithm: true,
  parameters: true,
  metrics: true,
  status: true,
  dataSourceId: true,
  userId: true,
  version: true,
  dependenciesInstalled: true,
});

export const insertPipelineSchema = createInsertSchema(pipelines).pick({
  name: true,
  type: true,
  schedule: true,
  status: true,
  config: true,
  userId: true,
});

export const insertActivitySchema = createInsertSchema(activities).pick({
  activity: true,
  pipeline: true,
  status: true,
  userId: true,
});

// Types
export type InsertAlgorithmDependency = z.infer<typeof insertAlgorithmDependencySchema>;
export type AlgorithmDependency = typeof algorithmDependencies.$inferSelect;

export type InsertAlgorithmDependencyMapping = z.infer<typeof insertAlgorithmDependencyMappingSchema>;
export type AlgorithmDependencyMapping = typeof algorithmDependencyMappings.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDataSource = z.infer<typeof insertDataSourceSchema>;
export type DataSource = typeof dataSources.$inferSelect;

export type InsertModel = z.infer<typeof insertModelSchema>;
export type Model = typeof models.$inferSelect;

export type InsertPipeline = z.infer<typeof insertPipelineSchema>;
export type Pipeline = typeof pipelines.$inferSelect;

// Integrations table for external systems (NiFi, Spark, Flink)
export const integrations = pgTable("integrations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // nifi, spark, flink
  endpoint: text("endpoint").notNull(), // Connection URL
  apiKey: text("api_key"), // API key if required
  config: jsonb("config").notNull().default({}), // Configuration specifics
  status: text("status").notNull().default("disconnected"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Features table for feature store 
export const features = pgTable("features", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  dataType: text("data_type").notNull(), // numeric, categorical, text, etc.
  source: text("source").notNull(), // Where this feature comes from
  transformation: text("transformation"), // How this feature was created/transformed
  isActive: boolean("is_active").notNull().default(true),
  metadata: jsonb("metadata").notNull().default({}),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Feature sets for grouping features
export const featureSets = pgTable("feature_sets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  tags: text("tags").array(),
  isActive: boolean("is_active").notNull().default(true),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Feature set mappings
export const featureSetMappings = pgTable("feature_set_mappings", {
  id: serial("id").primaryKey(),
  featureSetId: integer("feature_set_id").notNull().references(() => featureSets.id),
  featureId: integer("feature_id").notNull().references(() => features.id),
});

// Experiments table for A/B testing
export const experiments = pgTable("experiments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  status: text("status").notNull().default("draft"), // draft, active, completed, cancelled
  metrics: jsonb("metrics").notNull().default({}), // What metrics to track
  variants: jsonb("variants").notNull().default([]), // Different variants to test
  userId: integer("user_id").references(() => users.id),
  modelId: integer("model_id").references(() => models.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas for new tables
export const insertIntegrationSchema = createInsertSchema(integrations).pick({
  name: true,
  type: true,
  endpoint: true,
  apiKey: true,
  config: true,
  status: true,
  userId: true,
});

export const insertFeatureSchema = createInsertSchema(features).pick({
  name: true,
  description: true,
  dataType: true,
  source: true,
  transformation: true,
  isActive: true,
  metadata: true,
  userId: true,
});

export const insertFeatureSetSchema = createInsertSchema(featureSets).pick({
  name: true,
  description: true,
  tags: true,
  isActive: true,
  userId: true,
});

export const insertFeatureSetMappingSchema = createInsertSchema(featureSetMappings).pick({
  featureSetId: true,
  featureId: true,
});

export const insertExperimentSchema = createInsertSchema(experiments).pick({
  name: true,
  description: true,
  startDate: true,
  endDate: true,
  status: true,
  metrics: true,
  variants: true,
  userId: true,
  modelId: true,
});

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

export type InsertIntegration = z.infer<typeof insertIntegrationSchema>;
export type Integration = typeof integrations.$inferSelect;

export type InsertFeature = z.infer<typeof insertFeatureSchema>;
export type Feature = typeof features.$inferSelect;

export type InsertFeatureSet = z.infer<typeof insertFeatureSetSchema>;
export type FeatureSet = typeof featureSets.$inferSelect;

export type InsertFeatureSetMapping = z.infer<typeof insertFeatureSetMappingSchema>;
export type FeatureSetMapping = typeof featureSetMappings.$inferSelect;

export type InsertExperiment = z.infer<typeof insertExperimentSchema>;
export type Experiment = typeof experiments.$inferSelect;

// Model Registry Tables

// Create enums for the model registry
export const modelTypeEnum = pgEnum('model_type', MODEL_TYPES);
export const modelStageEnum = pgEnum('model_stage', MODEL_STAGES);
export const registryRoleEnum = pgEnum('registry_role', REGISTRY_ROLES);

// Model Registry: Models table
export const modelRegistryModels = pgTable("model_registry_models", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  type: modelTypeEnum("type").notNull(),
  created_by: integer("created_by").notNull().references(() => users.id),
  team_id: integer("team_id").references(() => teams.id),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
  is_active: boolean("is_active").notNull().default(true),
  tags: text("tags").array(),
});

// Model Registry: Model versions table
export const modelRegistryVersions = pgTable("model_registry_versions", {
  id: serial("id").primaryKey(),
  model_id: integer("model_id").notNull().references(() => modelRegistryModels.id),
  version: text("version").notNull(),
  description: text("description").notNull(),
  stage: modelStageEnum("stage").notNull().default('Development'),
  created_by: integer("created_by").notNull().references(() => users.id),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow(),
  metrics: jsonb("metrics"),
  framework: text("framework"),
  algorithm: text("algorithm"),
  input_schema: text("input_schema"),
  output_schema: text("output_schema"),
  training_dataset_id: integer("training_dataset_id"),
  dependencies: jsonb("dependencies"),
});

// Model Registry: Model artifacts table
export const modelRegistryArtifacts = pgTable("model_registry_artifacts", {
  id: serial("id").primaryKey(),
  version_id: integer("version_id").notNull().references(() => modelRegistryVersions.id),
  name: text("name").notNull(),
  type: text("type").notNull(),
  path: text("path").notNull(),
  size: integer("size").notNull(),
  hash: text("hash").notNull(),
  created_at: timestamp("created_at").defaultNow(),
  metadata: jsonb("metadata"),
});

// Model Registry: External service configuration table
export const modelRegistryExternalConfigs = pgTable("model_registry_external_configs", {
  id: serial("id").primaryKey(),
  version_id: integer("version_id").notNull().references(() => modelRegistryVersions.id),
  service_type: text("service_type").notNull(),
  config: jsonb("config").notNull(),
  credential_reference: text("credential_reference"),
  region: text("region"),
  endpoint: text("endpoint"),
});

// Model Registry: Stage transition requests and approvals
export const modelRegistryStageTransitions = pgTable("model_registry_stage_transitions", {
  id: serial("id").primaryKey(),
  version_id: integer("version_id").notNull().references(() => modelRegistryVersions.id),
  from_stage: modelStageEnum("from_stage").notNull(),
  to_stage: modelStageEnum("to_stage").notNull(),
  requester_id: integer("requester_id").notNull().references(() => users.id),
  approver_id: integer("approver_id").references(() => users.id),
  requested_at: timestamp("requested_at").defaultNow(),
  approved_at: timestamp("approved_at"),
  status: text("status").notNull(),
  comments: text("comments"),
});

// Model Registry: Audit logs for all significant actions
export const modelRegistryEvents = pgTable("model_registry_events", {
  id: serial("id").primaryKey(),
  model_id: integer("model_id").references(() => modelRegistryModels.id),
  version_id: integer("version_id").references(() => modelRegistryVersions.id),
  user_id: integer("user_id").notNull().references(() => users.id),
  event_type: text("event_type").notNull(),
  event_details: jsonb("event_details").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Model Registry: User roles specific to the model registry
export const modelRegistryUserRoles = pgTable("model_registry_user_roles", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  role: registryRoleEnum("role").notNull(),
  model_id: integer("model_id").references(() => modelRegistryModels.id),
  assigned_by: integer("assigned_by").notNull().references(() => users.id),
  assigned_at: timestamp("assigned_at").defaultNow(),
});

// Insert schemas for model registry tables
export const insertModelRegistryModelSchema = createInsertSchema(modelRegistryModels).pick({
  name: true,
  description: true,
  type: true,
  created_by: true,
  team_id: true,
  is_active: true,
  tags: true,
});

export const insertModelRegistryVersionSchema = createInsertSchema(modelRegistryVersions).pick({
  model_id: true,
  version: true,
  description: true,
  stage: true,
  created_by: true,
  metrics: true,
  framework: true,
  algorithm: true,
  input_schema: true,
  output_schema: true,
  training_dataset_id: true,
  dependencies: true,
});

export const insertModelRegistryArtifactSchema = createInsertSchema(modelRegistryArtifacts).pick({
  version_id: true,
  name: true,
  type: true,
  path: true,
  size: true,
  hash: true,
  metadata: true,
});

export const insertModelRegistryExternalConfigSchema = createInsertSchema(modelRegistryExternalConfigs).pick({
  version_id: true,
  service_type: true,
  config: true,
  credential_reference: true,
  region: true,
  endpoint: true,
});

export const insertModelRegistryStageTransitionSchema = createInsertSchema(modelRegistryStageTransitions).pick({
  version_id: true,
  from_stage: true,
  to_stage: true,
  requester_id: true,
  approver_id: true,
  status: true,
  comments: true,
});

export const insertModelRegistryEventSchema = createInsertSchema(modelRegistryEvents).pick({
  model_id: true,
  version_id: true,
  user_id: true,
  event_type: true,
  event_details: true,
});

export const insertModelRegistryUserRoleSchema = createInsertSchema(modelRegistryUserRoles).pick({
  user_id: true,
  role: true,
  model_id: true,
  assigned_by: true,
});

// Types for model registry
export type InsertModelRegistryModel = z.infer<typeof insertModelRegistryModelSchema>;
export type ModelRegistryModel = typeof modelRegistryModels.$inferSelect;

export type InsertModelRegistryVersion = z.infer<typeof insertModelRegistryVersionSchema>;
export type ModelRegistryVersion = typeof modelRegistryVersions.$inferSelect;

export type InsertModelRegistryArtifact = z.infer<typeof insertModelRegistryArtifactSchema>;
export type ModelRegistryArtifact = typeof modelRegistryArtifacts.$inferSelect;

export type InsertModelRegistryExternalConfig = z.infer<typeof insertModelRegistryExternalConfigSchema>;
export type ModelRegistryExternalConfig = typeof modelRegistryExternalConfigs.$inferSelect;

export type InsertModelRegistryStageTransition = z.infer<typeof insertModelRegistryStageTransitionSchema>;
export type ModelRegistryStageTransition = typeof modelRegistryStageTransitions.$inferSelect;

export type InsertModelRegistryEvent = z.infer<typeof insertModelRegistryEventSchema>;
export type ModelRegistryEvent = typeof modelRegistryEvents.$inferSelect;

export type InsertModelRegistryUserRole = z.infer<typeof insertModelRegistryUserRoleSchema>;
export type ModelRegistryUserRole = typeof modelRegistryUserRoles.$inferSelect;

// MLOps Automation: CI/CD Pipelines for ML workflows
export const cicdPipelines = pgTable("cicd_pipelines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  triggerType: text("trigger_type").notNull(), // scheduled, performance-based, manual
  status: text("status").notNull().default("inactive"),
  steps: jsonb("steps").notNull(), // Array of pipeline steps: build, test, deploy, etc.
  modelId: integer("model_id").references(() => models.id),
  thresholds: jsonb("thresholds").notNull().default({}), // Performance thresholds for auto-retraining
  notifications: jsonb("notifications").notNull().default([]), // Notification settings
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// MLOps Automation: Approval Workflows
export const approvalWorkflows = pgTable("approval_workflows", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  modelId: integer("model_id").references(() => models.id),
  stages: jsonb("stages").notNull(), // JSON array of stages, each with approvers
  currentStage: integer("current_stage").notNull().default(0),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  comments: jsonb("comments").notNull().default([]), // Comments from approvers
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Reinforcement Learning: Agents
export const rlAgents = pgTable("rl_agents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  algorithm: text("algorithm").notNull(), // DQN, PPO, A2C, etc.
  parameters: jsonb("parameters").notNull().default({}), // Hyperparameters
  environment: text("environment").notNull(), // Reference to environment setup
  status: text("status").notNull().default("draft"),
  metrics: jsonb("metrics").notNull().default({}), // Performance metrics
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Reinforcement Learning: Environments
export const rlEnvironments = pgTable("rl_environments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(), // custom, gym, unity, etc.
  config: jsonb("config").notNull().default({}), // Environment configuration
  observationSpace: jsonb("observation_space").notNull(), // Observation space definition
  actionSpace: jsonb("action_space").notNull(), // Action space definition
  rewardFunction: text("reward_function"), // Code for custom reward function
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Collaborative Features: Comments
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  entityType: text("entity_type").notNull(), // model, feature, pipeline, etc.
  entityId: integer("entity_id").notNull(), // ID of the entity being commented on
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Collaborative Features: Teams
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Collaborative Features: Team Members
export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull().references(() => teams.id),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role").notNull().default("member"), // owner, admin, member
  joinedAt: timestamp("joined_at").defaultNow(),
});

// Insert schemas for new tables
export const insertCicdPipelineSchema = createInsertSchema(cicdPipelines).pick({
  name: true,
  description: true,
  triggerType: true, 
  status: true,
  steps: true,
  modelId: true,
  thresholds: true, 
  notifications: true,
  userId: true,
});

export const insertApprovalWorkflowSchema = createInsertSchema(approvalWorkflows).pick({
  name: true,
  description: true,
  modelId: true,
  stages: true,
  currentStage: true,
  status: true,
  comments: true,
  userId: true,
});

export const insertRlAgentSchema = createInsertSchema(rlAgents).pick({
  name: true,
  description: true,
  algorithm: true,
  parameters: true,
  environment: true,
  status: true,
  metrics: true,
  userId: true,
});

export const insertRlEnvironmentSchema = createInsertSchema(rlEnvironments).pick({
  name: true,
  description: true,
  type: true,
  config: true,
  observationSpace: true,
  actionSpace: true,
  rewardFunction: true,
  userId: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  content: true,
  entityType: true,
  entityId: true,
  userId: true,
});

export const insertTeamSchema = createInsertSchema(teams).pick({
  name: true,
  description: true,
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).pick({
  teamId: true,
  userId: true,
  role: true,
});

// Types for new schemas
export type InsertCicdPipeline = z.infer<typeof insertCicdPipelineSchema>;
export type CicdPipeline = typeof cicdPipelines.$inferSelect;

export type InsertApprovalWorkflow = z.infer<typeof insertApprovalWorkflowSchema>;
export type ApprovalWorkflow = typeof approvalWorkflows.$inferSelect;

export type InsertRlAgent = z.infer<typeof insertRlAgentSchema>;
export type RlAgent = typeof rlAgents.$inferSelect;

export type InsertRlEnvironment = z.infer<typeof insertRlEnvironmentSchema>;
export type RlEnvironment = typeof rlEnvironments.$inferSelect;

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;

export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

// Workflow Recommendation Wizard
export const workflowRecommendations = pgTable("workflow_recommendations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  businessCase: text("business_case").notNull(),
  dataType: text("data_type").notNull(), // structured, unstructured, time-series, etc.
  objective: text("objective").notNull(), // classification, regression, clustering, recommendation, etc.
  features: jsonb("features").notNull().default({}), // Recommended feature engineering steps
  models: jsonb("models").notNull().default([]), // Recommended models
  pipeline: jsonb("pipeline").notNull().default({}), // Recommended pipeline configuration
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Recommendation Template Types
export const recommendationTemplates = pgTable("recommendation_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(), // industry, use case, data type
  steps: jsonb("steps").notNull().default([]), // Standardized workflow steps
  dataRequirements: jsonb("data_requirements").notNull().default([]), // Required data characteristics
  modelSuggestions: jsonb("model_suggestions").notNull().default([]), // Model types and algorithms 
  metricsSuggestions: jsonb("metrics_suggestions").notNull().default([]), // Recommended evaluation metrics
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User workflow preferences for personalization
export const userWorkflowPreferences = pgTable("user_workflow_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  preferredDataTypes: text("preferred_data_types").array(),
  preferredAlgorithms: text("preferred_algorithms").array(),
  preferredMetrics: text("preferred_metrics").array(),
  domainExpertise: text("domain_expertise").array(),
  skillLevel: text("skill_level").notNull().default("intermediate"), // beginner, intermediate, advanced
  workflowHistory: jsonb("workflow_history").notNull().default([]), // Previous successful workflows
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas for workflow recommendations
export const insertWorkflowRecommendationSchema = createInsertSchema(workflowRecommendations).pick({
  name: true,
  description: true,
  businessCase: true,
  dataType: true,
  objective: true,
  features: true,
  models: true,
  pipeline: true,
  userId: true,
});

export const insertRecommendationTemplateSchema = createInsertSchema(recommendationTemplates).pick({
  name: true,
  description: true,
  category: true,
  steps: true,
  dataRequirements: true,
  modelSuggestions: true,
  metricsSuggestions: true,
  isActive: true,
});

export const insertUserWorkflowPreferenceSchema = createInsertSchema(userWorkflowPreferences).pick({
  userId: true,
  preferredDataTypes: true,
  preferredAlgorithms: true,
  preferredMetrics: true,
  domainExpertise: true,
  skillLevel: true,
  workflowHistory: true,
});

// Types for workflow recommendations
export type InsertWorkflowRecommendation = z.infer<typeof insertWorkflowRecommendationSchema>;
export type WorkflowRecommendation = typeof workflowRecommendations.$inferSelect;

export type InsertRecommendationTemplate = z.infer<typeof insertRecommendationTemplateSchema>;
export type RecommendationTemplate = typeof recommendationTemplates.$inferSelect;

export type InsertUserWorkflowPreference = z.infer<typeof insertUserWorkflowPreferenceSchema>;
export type UserWorkflowPreference = typeof userWorkflowPreferences.$inferSelect;

export type InsertFile = z.infer<typeof insertFileSchema>;
export type File = typeof files.$inferSelect;

// Data Encoding tables
export const dataEncodingConfigs = pgTable("data_encoding_configs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  encodingType: text("encoding_type").notNull(), // one-hot, label, target, binary, frequency, etc.
  sourceColumn: text("source_column").notNull(), // column to encode
  config: jsonb("config").notNull().default({}), // specific configuration options
  outputColumns: text("output_columns").array(), // generated column names
  dataSourceId: integer("data_source_id").references(() => dataSources.id),
  fileId: integer("file_id").references(() => files.id),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  status: text("status").notNull().default("draft"),
});

export const dataEncodingHistory = pgTable("data_encoding_history", {
  id: serial("id").primaryKey(),
  configId: integer("config_id").notNull().references(() => dataEncodingConfigs.id),
  appliedAt: timestamp("applied_at").defaultNow(),
  status: text("status").notNull(),
  results: jsonb("results").notNull().default({}),
  metrics: jsonb("metrics").notNull().default({}), // e.g., cardinality reduction, memory usage before/after
  userId: integer("user_id").references(() => users.id),
});

// Insert schemas for data encoding
export const insertDataEncodingConfigSchema = createInsertSchema(dataEncodingConfigs).pick({
  name: true,
  description: true,
  encodingType: true,
  sourceColumn: true,
  config: true,
  outputColumns: true,
  dataSourceId: true,
  fileId: true,
  userId: true,
  status: true,
});

export const insertDataEncodingHistorySchema = createInsertSchema(dataEncodingHistory).pick({
  configId: true,
  status: true,
  results: true,
  metrics: true,
  userId: true,
});

export type InsertDataEncodingConfig = z.infer<typeof insertDataEncodingConfigSchema>;
export type DataEncodingConfig = typeof dataEncodingConfigs.$inferSelect;

export type InsertDataEncodingHistory = z.infer<typeof insertDataEncodingHistorySchema>;
export type DataEncodingHistory = typeof dataEncodingHistory.$inferSelect;
