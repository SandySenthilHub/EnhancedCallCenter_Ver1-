import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse';
import { executeQuery, executeInsert } from './db';

interface Dependency {
  name: string;
  version: string;
  category: string;
  packageManager?: string;
  description?: string;
}

async function importDependencies() {
  try {
    // Check if table has dependencies already
    const existingDeps = await executeQuery<{ count: number }>('SELECT COUNT(*) as count FROM algorithm_dependencies');
    if (existingDeps.length > 0 && existingDeps[0].count > 0) {
      console.log(`Database already has ${existingDeps[0].count} dependencies. Skipping import.`);
      return;
    }

    // Load the CSV file
    const csvPath = path.join(process.cwd(), 'attached_assets', 'library names.csv');
    if (!fs.existsSync(csvPath)) {
      console.error(`CSV file not found: ${csvPath}`);
      return;
    }

    const csvContent = fs.readFileSync(csvPath, 'utf-8');
    console.log(`Successfully read CSV file with ${csvContent.length} bytes`);

    // Parse the CSV content
    const dependencies: Dependency[] = await new Promise((resolve, reject) => {
      parse(csvContent, {
        columns: true,
        skip_empty_lines: true,
        trim: true
      }, (err, records) => {
        if (err) {
          reject(err);
          return;
        }
        
        // Transform records into dependencies
        const deps = records.map((record: any): Dependency => ({
          name: record.name || '',
          version: record.version || '',
          category: record.category || '',
          packageManager: 'pip',
          description: `${record.name} - ${record.category || ''} library`
        })).filter((dep: Dependency) => dep.name);
        
        resolve(deps);
      });
    });

    console.log(`Parsed ${dependencies.length} dependencies from CSV`);

    // Insert dependencies one by one with direct SQL to ensure column order
    let successCount = 0;
    for (const dep of dependencies) {
      try {
        // Execute direct SQL insert with explicit column names but no category
        const query = `
          INSERT INTO algorithm_dependencies 
            (name, version, package_manager, description, created_at, updated_at) 
          VALUES 
            (@name, @version, @package_manager, @description, @created_at, @updated_at)
        `;
        
        const params = {
          name: dep.name,
          version: dep.version,
          package_manager: 'pip',
          description: `${dep.name} - ${dep.category || ''} library`,
          created_at: new Date(),
          updated_at: new Date()
        };

        // Use executeParameterizedQuery to safely handle SQL parameters
        await executeInsert('algorithm_dependencies', {
          name: dep.name,
          version: dep.version,
          package_manager: 'pip',
          description: `${dep.name} - ${dep.category || ''} library`,
          created_at: new Date(),
          updated_at: new Date()
        });
        
        successCount++;
        if (successCount % 10 === 0) {
          console.log(`Imported ${successCount} dependencies so far...`);
        }
      } catch (error) {
        console.error(`Error inserting dependency ${dep.name}:`, error);
      }
    }

    console.log(`Successfully imported ${successCount} out of ${dependencies.length} dependencies`);
  } catch (error) {
    console.error('Error importing dependencies:', error);
  }
}

// Run the import
importDependencies();