import { getPool } from './db';
import fs from 'fs';
import path from 'path';
import sql from 'mssql';

async function executeSqlServerSchema() {
  try {
    console.log('Executing SQL Server schema script...');
    const pool = await getPool();
    
    // Read the SQL file using import.meta.url
    const moduleUrl = new URL(import.meta.url);
    const modulePath = path.dirname(moduleUrl.pathname);
    const sqlFilePath = path.join(modulePath, 'create-sqlserver-schema.sql');
    const sqlScript = fs.readFileSync(sqlFilePath, 'utf8');
    
    // Split the SQL script into individual statements
    // This approach handles GO statements which are often used in T-SQL scripts
    const sqlStatements = sqlScript
      .split(/\r?\nGO\s*\r?\n/i)
      .filter(stmt => stmt.trim().length > 0);
    
    // Execute each statement
    for (const statement of sqlStatements) {
      if (statement.trim()) {
        try {
          await pool.request().batch(statement);
          console.log('Executed SQL statement successfully');
        } catch (err) {
          console.error('Error executing SQL statement:', err);
          console.error('Statement:', statement);
          throw err;
        }
      }
    }
    
    console.log('SQL Server schema script executed successfully');
  } catch (error) {
    console.error('Error executing SQL Server schema:', error);
    throw error;
  }
}

// Run the function if this file is executed directly
// Using import.meta.url to check if file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  executeSqlServerSchema()
    .then(() => {
      console.log('Done');
      process.exit(0);
    })
    .catch(err => {
      console.error('Failed:', err);
      process.exit(1);
    });
}

export default executeSqlServerSchema;