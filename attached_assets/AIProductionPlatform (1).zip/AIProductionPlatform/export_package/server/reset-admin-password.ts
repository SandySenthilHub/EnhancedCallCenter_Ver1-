import { db } from './db';
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function resetAdminPassword() {
  try {
    console.log('Resetting admin password...');
    
    // Hash the password using our function
    const hashedPassword = await hashPassword('admin123');
    
    // Update the admin user's password
    const updatedUsers = await db
      .update(users)
      .set({ password: hashedPassword })
      .where(eq(users.username, 'admin'))
      .returning();
    
    if (updatedUsers.length > 0) {
      console.log('Admin password reset successfully!');
      console.log('Username: admin');
      console.log('Password: admin123');
    } else {
      console.log('Admin user not found.');
    }
  } catch (error) {
    console.error('Failed to reset admin password:', error);
  }
}

resetAdminPassword();