import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler, OneHotEncoder, LabelEncoder
from typing import List, Dict, Any, Optional, Union
import io

class DataProcessor:
    def __init__(self):
        self.transformers = {}
    
    def load_data(self, file_path: str, file_type: Optional[str] = None) -> pd.DataFrame:
        """Load data from a file."""
        if file_type is None:
            # Try to infer file type from extension
            file_type = file_path.split('.')[-1].lower()
        
        if file_type in ['csv', 'txt']:
            return pd.read_csv(file_path)
        elif file_type == 'parquet':
            return pd.read_parquet(file_path)
        elif file_type in ['xls', 'xlsx']:
            return pd.read_excel(file_path)
        elif file_type == 'json':
            return pd.read_json(file_path)
        else:
            raise ValueError(f"Unsupported file type: {file_type}")
    
    def get_data_summary(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Get summary statistics for a dataset."""
        # Basic info
        summary = {
            "rows": len(data),
            "columns": len(data.columns),
            "column_types": {
                "numeric": len(data.select_dtypes(include=['number']).columns),
                "categorical": len(data.select_dtypes(include=['object', 'category']).columns),
                "datetime": len(data.select_dtypes(include=['datetime']).columns),
                "boolean": len(data.select_dtypes(include=['bool']).columns)
            },
            "missing_values": {
                "total": data.isna().sum().sum(),
                "percentage": float(data.isna().sum().sum() / (data.shape[0] * data.shape[1]) * 100)
            }
        }
        
        # Column details
        column_details = []
        for col in data.columns:
            col_type = str(data[col].dtype)
            missing = data[col].isna().sum()
            unique_count = data[col].nunique()
            
            col_info = {
                "name": col,
                "type": col_type,
                "missing": int(missing),
                "missing_percentage": float(missing / len(data) * 100),
                "unique_values": int(unique_count)
            }
            
            # Add summary statistics for numeric columns
            if pd.api.types.is_numeric_dtype(data[col]):
                col_info.update({
                    "min": float(data[col].min()) if not pd.isna(data[col].min()) else None,
                    "max": float(data[col].max()) if not pd.isna(data[col].max()) else None,
                    "mean": float(data[col].mean()) if not pd.isna(data[col].mean()) else None,
                    "std": float(data[col].std()) if not pd.isna(data[col].std()) else None
                })
            
            column_details.append(col_info)
        
        summary["columns_detail"] = column_details
        
        return summary
    
    def handle_missing_values(self, data: pd.DataFrame, strategy: str = 'mean', columns: Optional[List[str]] = None) -> pd.DataFrame:
        """Handle missing values in a dataset."""
        if columns is None:
            columns = data.select_dtypes(include=['number']).columns
        
        # Create a copy to avoid modifying the original DataFrame
        result = data.copy()
        
        # Handle different strategies
        if strategy in ['mean', 'median', 'most_frequent', 'constant']:
            # Use SimpleImputer for these strategies
            imputer = SimpleImputer(strategy=strategy)
            result[columns] = imputer.fit_transform(result[columns])
            
            # Store the transformer for later reference
            self.transformers[f"imputer_{','.join(columns)}"] = imputer
        elif strategy == 'drop':
            # Drop rows with missing values
            result = result.dropna(subset=columns)
        else:
            raise ValueError(f"Unsupported missing value strategy: {strategy}")
        
        return result
    
    def scale_features(self, data: pd.DataFrame, scaler_type: str = 'standard', columns: Optional[List[str]] = None) -> pd.DataFrame:
        """Scale numerical features in a dataset."""
        if columns is None:
            columns = data.select_dtypes(include=['number']).columns
        
        # Create a copy to avoid modifying the original DataFrame
        result = data.copy()
        
        # Choose scaler based on type
        if scaler_type == 'standard':
            scaler = StandardScaler()
        elif scaler_type == 'minmax':
            scaler = MinMaxScaler()
        elif scaler_type == 'robust':
            scaler = RobustScaler()
        else:
            raise ValueError(f"Unsupported scaler type: {scaler_type}")
        
        # Apply scaling
        result[columns] = scaler.fit_transform(result[columns])
        
        # Store the transformer for later reference
        self.transformers[f"scaler_{','.join(columns)}"] = scaler
        
        return result
    
    def encode_categorical(self, data: pd.DataFrame, encoding_type: str = 'onehot', columns: Optional[List[str]] = None) -> pd.DataFrame:
        """Encode categorical features in a dataset."""
        if columns is None:
            columns = data.select_dtypes(include=['object', 'category']).columns
        
        # Create a copy to avoid modifying the original DataFrame
        result = data.copy()
        
        # Choose encoder based on type
        if encoding_type == 'onehot':
            # Use OneHotEncoder for one-hot encoding
            encoder = OneHotEncoder(sparse=False, handle_unknown='ignore')
            encoded = encoder.fit_transform(result[columns])
            
            # Create DataFrame with encoded columns
            encoded_df = pd.DataFrame(
                encoded,
                columns=encoder.get_feature_names_out(columns),
                index=result.index
            )
            
            # Drop original columns and concatenate encoded ones
            result = pd.concat([result.drop(columns, axis=1), encoded_df], axis=1)
            
            # Store the transformer for later reference
            self.transformers[f"onehot_{','.join(columns)}"] = encoder
        
        elif encoding_type == 'label':
            # Use LabelEncoder for label encoding
            for col in columns:
                encoder = LabelEncoder()
                result[col] = encoder.fit_transform(result[col].astype(str))
                
                # Store the transformer for later reference
                self.transformers[f"label_{col}"] = encoder
        
        else:
            raise ValueError(f"Unsupported encoding type: {encoding_type}")
        
        return result
    
    def generate_feature_engineering_code(self, steps: List[Dict[str, Any]], target_variable: str) -> str:
        """Generate Python code for feature engineering steps."""
        code = []
        
        # Add imports
        code.append("# Generated code for feature engineering")
        code.append("import pandas as pd")
        code.append("import numpy as np")
        
        # Add specific imports based on steps
        imports = set()
        for step in steps:
            step_type = step.get('type', '')
            if step_type == 'missing_values':
                imports.add("from sklearn.impute import SimpleImputer")
            elif step_type == 'scaling':
                if step.get('method', '') == 'standard':
                    imports.add("from sklearn.preprocessing import StandardScaler")
                elif step.get('method', '') == 'minmax':
                    imports.add("from sklearn.preprocessing import MinMaxScaler")
                elif step.get('method', '') == 'robust':
                    imports.add("from sklearn.preprocessing import RobustScaler")
            elif step_type == 'encoding':
                if step.get('method', '') == 'onehot':
                    imports.add("from sklearn.preprocessing import OneHotEncoder")
                elif step.get('method', '') == 'label':
                    imports.add("from sklearn.preprocessing import LabelEncoder")
        
        # Add imports to code
        for imp in sorted(imports):
            code.append(imp)
        
        code.append("")
        code.append("# Load dataset")
        code.append("df = pd.read_csv(\"customer_transaction_history.csv\")")
        code.append("")
        
        # Add code for each feature engineering step
        for i, step in enumerate(steps):
            step_type = step.get('type', '')
            step_config = step.get('config', {})
            
            if step_type == 'missing_values':
                method = step_config.get('method', 'mean')
                columns = step_config.get('columns', [])
                
                code.append(f"# {i+1}. Handle missing values")
                if columns:
                    col_str = "[" + ", ".join(f"'{col}'" for col in columns) + "]"
                    code.append(f"numerical_cols = {col_str}")
                else:
                    code.append("numerical_cols = df.select_dtypes(include=['number']).columns")
                
                code.append(f"imputer = SimpleImputer(strategy='{method}')")
                code.append(f"df[numerical_cols] = imputer.fit_transform(df[numerical_cols])")
                code.append("")
            
            elif step_type == 'scaling':
                method = step_config.get('method', 'standard')
                columns = step_config.get('columns', [])
                
                code.append(f"# {i+1}. Feature scaling")
                if columns:
                    col_str = "[" + ", ".join(f"'{col}'" for col in columns) + "]"
                    code.append(f"numerical_cols = {col_str}")
                else:
                    code.append("numerical_cols = df.select_dtypes(include=['number']).columns")
                
                if method == 'standard':
                    code.append("scaler = StandardScaler()")
                elif method == 'minmax':
                    code.append("scaler = MinMaxScaler()")
                elif method == 'robust':
                    code.append("scaler = RobustScaler()")
                
                code.append("df[numerical_cols] = scaler.fit_transform(df[numerical_cols])")
                code.append("")
            
            elif step_type == 'encoding':
                method = step_config.get('method', 'onehot')
                columns = step_config.get('columns', [])
                
                code.append(f"# {i+1}. Categorical encoding")
                if columns:
                    col_str = "[" + ", ".join(f"'{col}'" for col in columns) + "]"
                    code.append(f"categorical_cols = {col_str}")
                else:
                    code.append("categorical_cols = [col for col in df.columns if df[col].dtype == 'object']")
                
                if method == 'onehot':
                    code.append("df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)")
                    code.append("")
                    code.append("# Update DataFrame")
                    code.append("df = df_encoded")
                elif method == 'label':
                    code.append("for col in categorical_cols:")
                    code.append("    le = LabelEncoder()")
                    code.append("    df[col] = le.fit_transform(df[col].astype(str))")
        
        # Prepare features and target
        code.append("# Prepare features and target")
        code.append(f"X = df.drop('{target_variable}', axis=1)")
        code.append(f"y = df['{target_variable}']")
        
        return "\n".join(code)
