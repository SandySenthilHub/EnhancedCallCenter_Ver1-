// Global types for the application
declare global {
  // Function to send monitoring alerts to connected WebSocket clients
  function sendMonitoringAlert(alert: {
    severity: 'info' | 'warning' | 'critical',
    source: string,
    message: string,
    details?: any
  }): void;

  // Function to send status updates to connected WebSocket clients
  function sendStatusUpdate(update: {
    entityType: 'model' | 'pipeline' | 'data_source',
    id: number,
    name: string,
    status: string,
    details?: any
  }): void;
  
  // Add other global functions or properties here
  namespace NodeJS {
    interface Global {
      sendMonitoringAlert: typeof sendMonitoringAlert;
      sendStatusUpdate: typeof sendStatusUpdate;
    }
  }
}

export {};