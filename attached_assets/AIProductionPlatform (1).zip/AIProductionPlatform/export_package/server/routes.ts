import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { exec } from 'child_process';
import path from 'path';
import fs from 'fs';
import { WebSocketServer, WebSocket } from 'ws';

// WebSocket client management
interface Client {
  ws: WebSocket;
  channels: Set<string>;
}

const clients: Client[] = [];

function broadcastToChannel(channel: string, message: any) {
  const data = JSON.stringify(message);
  clients.forEach(client => {
    if (client.channels.has(channel) && client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(data);
    }
  });
}

// Import route modules
import { registerIntegrationRoutes } from './routes/integrations';
import { registerFeatureStoreRoutes } from './routes/feature-store';
import { registerExperimentRoutes } from './routes/experiments';
import { registerMonitoringRoutes } from './routes/monitoring';
import { registerAdminSetupRoutes } from './routes/admin-setup';
import { registerAISuggestionsRoutes } from './routes/ai-suggestions';
import { registerWorkflowRecommendationsRoutes } from './routes/workflow-recommendations-register';
import { registerAlgorithmDependenciesRoutes } from './routes/algorithm-dependencies-register';
import { registerCsvUploadRoutes } from './routes/csv-upload';
import { registerDataEncodingRoutes } from './routes/data-encoding';
import { registerFileUploadRoutes } from './routes/file-upload';

export async function registerRoutes(app: Express): Promise<Server> {
  // Import dependencies from CSV if needed
  try {
    // Check if table has dependencies already
    const { executeQuery } = await import('./db');
    const existingDeps = await executeQuery<{ count: number }>('SELECT COUNT(*) as count FROM algorithm_dependencies');
    if (!existingDeps.length || existingDeps[0].count === 0) {
      console.log('No algorithm dependencies found in the database. Importing from CSV...');
      import('./import-dependencies').catch(err => {
        console.error('Failed to import dependencies:', err);
      });
    } else {
      console.log(`Found ${existingDeps[0].count} algorithm dependencies in the database.`);
    }
  } catch (error) {
    console.error('Error checking dependencies count:', error);
  }

  // Start FastAPI server
  const fastApiProcess = exec('python server/api.py', (error, stdout, stderr) => {
    if (error) {
      console.error(`Error starting FastAPI server: ${error.message}`);
      return;
    }
  });
  
  fastApiProcess.stdout?.on('data', (data) => {
    console.log(`FastAPI stdout: ${data}`);
  });
  
  fastApiProcess.stderr?.on('data', (data) => {
    console.error(`FastAPI stderr: ${data}`);
  });

  // Setup authentication
  const { isAuthenticated } = setupAuth(app);

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'AI/ML Playbook API is running' });
  });

  // User routes
  app.get('/api/users/:id', async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Data Sources routes - protected by authentication
  app.get('/api/data-sources', isAuthenticated, async (req, res) => {
    try {
      const dataSources = await storage.getDataSources();
      res.json(dataSources);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.get('/api/data-sources/:id', isAuthenticated, async (req, res) => {
    try {
      const dataSource = await storage.getDataSource(parseInt(req.params.id));
      if (!dataSource) {
        return res.status(404).json({ message: 'Data source not found' });
      }
      res.json(dataSource);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.post('/api/data-sources', isAuthenticated, async (req, res) => {
    try {
      // Include the current user's ID with the data source
      console.log('Creating data source:', req.body);
      const newDataSource = await storage.createDataSource({
        ...req.body,
        userId: (req.user as any).id
      });
      
      // Broadcast update to WebSocket clients
      broadcastToChannel('data_sources', { 
        type: 'data_source_created', 
        data: newDataSource 
      });
      
      res.status(201).json(newDataSource);
    } catch (error: any) {
      console.error('Error creating data source:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Models routes - protected by authentication
  app.get('/api/models', isAuthenticated, async (req, res) => {
    try {
      const models = await storage.getModels();
      res.json(models);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.get('/api/models/:id', isAuthenticated, async (req, res) => {
    try {
      const model = await storage.getModel(parseInt(req.params.id));
      if (!model) {
        return res.status(404).json({ message: 'Model not found' });
      }
      res.json(model);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.post('/api/models', isAuthenticated, async (req, res) => {
    try {
      // Include the current user's ID with the model
      const newModel = await storage.createModel({
        ...req.body,
        userId: (req.user as any).id
      });
      
      // Log model creation activity
      await storage.createActivity({
        activity: `Model "${newModel.name}" created`,
        pipeline: null,
        status: 'success',
        userId: (req.user as any).id
      });
      
      res.status(201).json(newModel);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.patch('/api/models/:id', isAuthenticated, async (req, res) => {
    try {
      const updatedModel = await storage.updateModel(parseInt(req.params.id), req.body);
      if (!updatedModel) {
        return res.status(404).json({ message: 'Model not found' });
      }
      res.json(updatedModel);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Pipelines routes - protected by authentication
  app.get('/api/pipelines', isAuthenticated, async (req, res) => {
    try {
      const pipelines = await storage.getPipelines();
      res.json(pipelines);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.get('/api/pipelines/:id', isAuthenticated, async (req, res) => {
    try {
      const pipeline = await storage.getPipeline(parseInt(req.params.id));
      if (!pipeline) {
        return res.status(404).json({ message: 'Pipeline not found' });
      }
      res.json(pipeline);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.post('/api/pipelines', isAuthenticated, async (req, res) => {
    try {
      // Include the current user's ID with the pipeline
      const newPipeline = await storage.createPipeline({
        ...req.body,
        userId: (req.user as any).id
      });
      
      // Log pipeline creation activity
      await storage.createActivity({
        activity: `Pipeline "${newPipeline.name}" created`,
        pipeline: newPipeline.name,
        status: 'success',
        userId: (req.user as any).id
      });
      
      res.status(201).json(newPipeline);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.patch('/api/pipelines/:id', isAuthenticated, async (req, res) => {
    try {
      const updatedPipeline = await storage.updatePipeline(parseInt(req.params.id), req.body);
      if (!updatedPipeline) {
        return res.status(404).json({ message: 'Pipeline not found' });
      }
      res.json(updatedPipeline);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Activities routes - protected by authentication
  app.get('/api/activities', isAuthenticated, async (req, res) => {
    try {
      const activities = await storage.getActivities();
      res.json(activities);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  // Public test endpoint for algorithm dependencies (no authentication required)
  app.get('/api/public/algorithm-dependencies', async (req, res) => {
    try {
      const dependencies = await storage.getAlgorithmDependencies();
      res.json(dependencies);
    } catch (error: any) {
      console.error('Error fetching algorithm dependencies:', error);
      res.status(500).json({ error: 'Failed to fetch algorithm dependencies' });
    }
  });
  
  app.post('/api/activities', isAuthenticated, async (req, res) => {
    try {
      // Include the current user's ID with the activity
      const newActivity = await storage.createActivity({
        ...req.body,
        userId: (req.user as any).id
      });
      res.status(201).json(newActivity);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create the HTTP server
  const httpServer = createServer(app);
  
  // Register additional routes from modules
  registerIntegrationRoutes(app, isAuthenticated);
  registerFeatureStoreRoutes(app, isAuthenticated);
  registerExperimentRoutes(app, isAuthenticated);
  registerMonitoringRoutes(app, isAuthenticated);
  registerAdminSetupRoutes(app);
  registerAISuggestionsRoutes(app, isAuthenticated);
  registerWorkflowRecommendationsRoutes(app);
  registerAlgorithmDependenciesRoutes(app, isAuthenticated);
  registerCsvUploadRoutes(app);
  registerDataEncodingRoutes(app, isAuthenticated);
  registerFileUploadRoutes(app, isAuthenticated);
  
  // Register Model Registry routes
  try {
    import('./model-registry/routes')
      .then(module => {
        module.registerModelRegistryRoutes(app, isAuthenticated);
        console.log('Model Registry routes registered');
      })
      .catch(error => {
        console.warn('Model Registry routes not available:', error);
      });
  } catch (error) {
    console.warn('Error importing Model Registry routes:', error);
  }
  
  // Register database status routes
  try {
    import('./routes/database-status')
      .then(module => {
        module.registerDatabaseStatusRoutes(app);
        console.log('Database status routes registered');
      })
      .catch(error => {
        console.warn('Database status routes not available:', error);
      });
  } catch (error) {
    console.warn('Error importing database status routes:', error);
  }
  
  // Setup WebSocket server for real-time monitoring and updates
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws',
  });
  
  // Store connected clients
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected to real-time monitoring');
    
    // Add client to our set
    clients.add(ws);
    
    // Send initial status message
    ws.send(JSON.stringify({
      type: 'status',
      message: 'Connected to AI/ML Playbook real-time monitoring'
    }));
    
    // Handle client messages
    ws.on('message', (message: any) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Received message:', data);
        
        // Handle different message types
        if (data.type === 'subscribe') {
          // Handle subscription to specific monitoring channels
          ws.send(JSON.stringify({
            type: 'subscribed',
            channel: data.channel
          }));
        }
      } catch (error) {
        console.error('Error processing message:', error);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected from real-time monitoring');
    });
  });
  
  // Function to broadcast messages to all connected clients
  const broadcastMessage = (message: any) => {
    clients.forEach((client: WebSocket) => {
      if (client.readyState === 1) { // 1 = OPEN
        client.send(JSON.stringify(message));
      }
    });
  };
  
  // Function to send monitoring alerts based on model/pipeline events
  global.sendMonitoringAlert = (alert: {
    severity: 'info' | 'warning' | 'critical',
    source: string,
    message: string,
    details?: any
  }) => {
    broadcastMessage({
      type: 'alert',
      timestamp: new Date().toISOString(),
      ...alert
    });
  };
  
  // Function to send model/pipeline status updates
  global.sendStatusUpdate = (update: {
    entityType: 'model' | 'pipeline' | 'data_source',
    id: number,
    name: string,
    status: string,
    details?: any
  }) => {
    broadcastMessage({
      type: 'status_update',
      timestamp: new Date().toISOString(),
      ...update
    });
  };

  return httpServer;
}
