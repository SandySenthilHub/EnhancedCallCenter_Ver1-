from fastapi import FastAPI, HTTPException, Depends, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional, Any, Union
import uvicorn
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import silhouette_score, mean_squared_error, accuracy_score, precision_score, recall_score, f1_score
import json
import os
from models import DataSource, Model, Pipeline, Activity
from data_processor import DataProcessor
from ml_engine import MLEngine

app = FastAPI(title="AI/ML Playbook API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
data_processor = DataProcessor()
ml_engine = MLEngine()

@app.get("/")
async def root():
    return {"message": "AI/ML Playbook API is running"}

@app.get("/api/python/health")
async def health_check():
    return {"status": "healthy", "message": "Python API is running"}

# Data source endpoints
@app.get("/api/python/data-sources")
async def get_data_sources():
    try:
        return [
            {
                "id": 1,
                "name": "Customer Data Warehouse",
                "type": "PostgreSQL",
                "connection": "postgres://user:***@host:5432/db",
                "status": "connected"
            },
            {
                "id": 2,
                "name": "Transaction Logs S3",
                "type": "AWS S3",
                "connection": "s3://transactions-bucket/logs/",
                "status": "connected"
            }
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/python/data-sources")
async def create_data_source(data_source: DataSource):
    try:
        # In a real implementation, we would validate and store the data source
        return {
            "id": 3,
            **data_source.dict(),
            "status": "connected"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Model endpoints
@app.get("/api/python/models")
async def get_models():
    try:
        return [
            {
                "id": 1,
                "name": "Customer Segmentation",
                "type": "clustering",
                "algorithm": "kmeans",
                "version": "2.1.0",
                "status": "production",
                "metrics": {
                    "silhouetteScore": 0.68,
                    "inertia": 234.75
                }
            },
            {
                "id": 2,
                "name": "AML Detection",
                "type": "classification",
                "algorithm": "random_forest",
                "version": "1.3.0",
                "status": "production",
                "metrics": {
                    "accuracy": 0.92,
                    "precision": 0.88,
                    "recall": 0.85
                }
            },
            {
                "id": 3,
                "name": "Fraud Detection",
                "type": "classification",
                "algorithm": "gradient_boosting",
                "version": "0.9.0",
                "status": "draft",
                "metrics": {}
            }
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/python/train-model")
async def train_model(model_config: Dict[str, Any]):
    try:
        # Extract configuration parameters
        model_type = model_config.get("type", "regression")
        algorithm = model_config.get("algorithm", "linear_regression")
        parameters = model_config.get("parameters", {})
        dataset_name = model_config.get("dataset", "customer_transaction_history.csv")
        
        # Simulate model training (in a real implementation, this would use actual data)
        sample_data = {
            'regression': pd.DataFrame({
                'x1': np.random.randn(100),
                'x2': np.random.randn(100),
                'target': np.random.randn(100)
            }),
            'classification': pd.DataFrame({
                'x1': np.random.randn(100),
                'x2': np.random.randn(100),
                'target': np.random.choice([0, 1], size=100)
            }),
            'clustering': pd.DataFrame({
                'x1': np.random.randn(100),
                'x2': np.random.randn(100)
            })
        }
        
        data = sample_data.get(model_type, sample_data['regression'])
        
        # Train model
        metrics = ml_engine.train_model(model_type, algorithm, data, parameters)
        
        return {
            "id": 4,
            "name": f"New {algorithm.replace('_', ' ').title()} Model",
            "type": model_type,
            "algorithm": algorithm,
            "version": "1.0.0",
            "status": "trained",
            "metrics": metrics
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Pipeline endpoints
@app.get("/api/python/pipelines")
async def get_pipelines():
    try:
        return [
            {
                "id": 1,
                "name": "Customer Segmentation Pipeline",
                "type": "clustering",
                "schedule": "Daily at 2:00 AM",
                "status": "success",
                "lastRun": "2023-10-21T02:03:00Z",
                "createdAt": "2023-10-07T15:30:00Z"
            },
            {
                "id": 2,
                "name": "AML Detection Pipeline",
                "type": "classification",
                "schedule": "Hourly",
                "status": "running",
                "lastRun": "2023-10-21T09:00:00Z",
                "createdAt": "2023-09-21T10:45:00Z"
            },
            {
                "id": 3,
                "name": "Fraud Detection Pipeline",
                "type": "classification",
                "schedule": "Real-time",
                "status": "draft",
                "lastRun": None,
                "createdAt": "2023-10-18T14:20:00Z"
            }
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/python/pipelines")
async def create_pipeline(pipeline: Pipeline):
    try:
        return {
            "id": 4,
            **pipeline.dict(),
            "status": "draft",
            "createdAt": "2023-10-21T10:30:00Z"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Activities endpoints
@app.get("/api/python/activities")
async def get_activities():
    try:
        return [
            {
                "id": 1,
                "activity": "Model Training Completed",
                "pipeline": "Customer Segmentation v2",
                "status": "success",
                "timestamp": "2023-10-21T09:50:00Z"
            },
            {
                "id": 2,
                "activity": "Data Ingestion Started",
                "pipeline": "Fraud Detection Daily",
                "status": "running",
                "timestamp": "2023-10-21T09:35:00Z"
            },
            {
                "id": 3,
                "activity": "Pipeline Execution Failed",
                "pipeline": "AML Transaction Screening",
                "status": "failed",
                "timestamp": "2023-10-21T08:00:00Z"
            }
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Feature engineering endpoints
@app.post("/api/python/feature-engineering/preview")
async def preview_feature_engineering(config: Dict[str, Any]):
    try:
        feature_engineering_steps = config.get("steps", [])
        target_variable = config.get("target", "transaction_amount")
        
        # Generate code preview
        code_preview = data_processor.generate_feature_engineering_code(feature_engineering_steps, target_variable)
        
        return {
            "codePreview": code_preview
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Start the server if running as script
if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)
