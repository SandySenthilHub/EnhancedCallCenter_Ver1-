from pydantic import BaseModel
from typing import Dict, List, Optional, Any, Union
from datetime import datetime

class User(BaseModel):
    id: Optional[int] = None
    username: str
    email: str
    password: str
    role: str = "data_scientist"

class DataSource(BaseModel):
    name: str
    type: str
    connection: str
    status: Optional[str] = "disconnected"
    userId: Optional[int] = None

class Model(BaseModel):
    name: str
    type: str
    algorithm: str
    parameters: Dict[str, Any] = {}
    metrics: Dict[str, Any] = {}
    status: str = "draft"
    dataSourceId: Optional[int] = None
    userId: Optional[int] = None
    version: str = "1.0.0"

class Pipeline(BaseModel):
    name: str
    type: str
    schedule: str
    status: Optional[str] = "draft"
    config: Dict[str, Any] = {}
    userId: Optional[int] = None
    lastRun: Optional[datetime] = None

class Activity(BaseModel):
    activity: str
    pipeline: Optional[str] = None
    status: str
    userId: Optional[int] = None
    timestamp: Optional[datetime] = None
