import { db } from './db';
import * as schema from '@shared/schema';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { migrate } from 'drizzle-orm/neon-serverless/migrator';
import { Pool } from '@neondatabase/serverless';
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(scrypt);

// Same hash function as in auth.ts
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function runMigration() {
  console.log('Starting database migration...');
  
  try {
    // Create schema
    console.log('Creating schema...');
    
    // Push the schema to the database
    await db.execute(/* sql */`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'data_scientist'
      );

      CREATE TABLE IF NOT EXISTS data_sources (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        connection TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'disconnected',
        user_id INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS models (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        algorithm TEXT NOT NULL,
        parameters JSONB NOT NULL DEFAULT '{}',
        metrics JSONB NOT NULL DEFAULT '{}',
        status TEXT NOT NULL DEFAULT 'draft',
        data_source_id INTEGER REFERENCES data_sources(id),
        user_id INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        version TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS pipelines (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        schedule TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'draft',
        config JSONB NOT NULL DEFAULT '{}',
        user_id INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        last_run TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS activities (
        id SERIAL PRIMARY KEY,
        activity TEXT NOT NULL,
        pipeline TEXT,
        status TEXT NOT NULL,
        timestamp TIMESTAMP DEFAULT NOW(),
        user_id INTEGER REFERENCES users(id)
      );

      CREATE TABLE IF NOT EXISTS integrations (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        endpoint TEXT NOT NULL,
        api_key TEXT,
        config JSONB NOT NULL DEFAULT '{}',
        status TEXT NOT NULL DEFAULT 'disconnected',
        user_id INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS features (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT,
        data_type TEXT NOT NULL,
        source TEXT NOT NULL,
        transformation TEXT,
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        metadata JSONB NOT NULL DEFAULT '{}',
        user_id INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS feature_sets (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        tags TEXT[],
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        user_id INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS feature_set_mappings (
        id SERIAL PRIMARY KEY,
        feature_set_id INTEGER NOT NULL REFERENCES feature_sets(id),
        feature_id INTEGER NOT NULL REFERENCES features(id)
      );

      CREATE TABLE IF NOT EXISTS experiments (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        start_date TIMESTAMP,
        end_date TIMESTAMP,
        status TEXT NOT NULL DEFAULT 'draft',
        metrics JSONB NOT NULL DEFAULT '{}',
        variants JSONB NOT NULL DEFAULT '[]',
        user_id INTEGER REFERENCES users(id),
        model_id INTEGER REFERENCES models(id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);

    // Create an admin user for testing
    const hashedPassword = await hashPassword('password'); // Hash the password using our function
    
    console.log('Creating admin user if not exists...');
    await db.execute(/* sql */`
      INSERT INTO users (username, password, email, role)
      VALUES ('admin', '${hashedPassword}', 'admin@aimlplaybook.com', 'admin')
      ON CONFLICT (username) DO NOTHING;
    `);

    console.log('Database migration completed successfully!');
  } catch (error) {
    console.error('Database migration failed:', error);
    process.exit(1);
  }
}

runMigration();