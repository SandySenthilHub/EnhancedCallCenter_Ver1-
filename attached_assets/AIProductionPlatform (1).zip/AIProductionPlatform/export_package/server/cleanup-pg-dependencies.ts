/**
 * This script will remove all PostgreSQL and Drizzle related dependencies
 * as part of the migration to SQL Server.
 */

import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

async function cleanupPostgresDependencies() {
  console.log('Removing PostgreSQL and Drizzle dependencies...');
  
  const dependenciesToRemove = [
    // Postgres related
    '@neondatabase/serverless',
    'pg',
    'connect-pg-simple',
    
    // Drizzle related
    'drizzle-orm',
    'drizzle-kit',
    'drizzle-zod'
  ];
  
  try {
    // Execute npm uninstall command
    const command = `npm uninstall ${dependenciesToRemove.join(' ')}`;
    console.log(`Executing: ${command}`);
    
    const { stdout, stderr } = await execPromise(command);
    console.log('Command output:', stdout);
    
    if (stderr) {
      console.warn('Command warnings/errors:', stderr);
    }
    
    console.log('Successfully removed PostgreSQL and Drizzle dependencies.');
  } catch (error) {
    console.error('Error removing dependencies:', error);
    throw error;
  }
}

// Execute the cleanup script if run directly
if (require.main === module) {
  cleanupPostgresDependencies()
    .then(() => {
      console.log('Dependency cleanup completed successfully');
      process.exit(0);
    })
    .catch(error => {
      console.error('Dependency cleanup failed:', error);
      process.exit(1);
    });
}

export default cleanupPostgresDependencies;