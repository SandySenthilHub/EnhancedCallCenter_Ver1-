import { getPool } from './db.ts.new';
import sql from 'mssql';

// Schema definition for SQL Server
const sqlServerSchema = `
-- Users table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'users')
CREATE TABLE users (
    id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(255) NOT NULL UNIQUE,
    password NVARCHAR(255) NOT NULL,
    email NVARCHAR(255) NOT NULL,
    role NVARCHAR(50) NOT NULL DEFAULT 'data_scientist'
);

-- Data sources table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'data_sources')
CREATE TABLE data_sources (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    type NVARCHAR(50) NOT NULL,
    connection NVARCHAR(255) NOT NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'disconnected',
    config NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Files metadata table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'files')
CREATE TABLE files (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    source NVARCHAR(50) NOT NULL,
    path NVARCHAR(255) NOT NULL,
    size INT NOT NULL,
    format NVARCHAR(50) NOT NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'raw',
    data_source_id INT NULL REFERENCES data_sources(id),
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Algorithm dependencies table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'algorithm_dependencies')
CREATE TABLE algorithm_dependencies (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL UNIQUE,
    version NVARCHAR(50) NULL,
    package_manager NVARCHAR(50) NOT NULL,
    category NVARCHAR(100) NULL,
    description NVARCHAR(MAX) NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Algorithm dependency mappings table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'algorithm_dependency_mappings')
CREATE TABLE algorithm_dependency_mappings (
    id INT IDENTITY(1,1) PRIMARY KEY,
    algorithm_name NVARCHAR(255) NOT NULL,
    dependency_id INT NOT NULL REFERENCES algorithm_dependencies(id),
    required BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Models table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'models')
CREATE TABLE models (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    type NVARCHAR(50) NOT NULL,
    algorithm NVARCHAR(100) NOT NULL,
    parameters NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    metrics NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    status NVARCHAR(50) NOT NULL DEFAULT 'draft',
    data_source_id INT NULL REFERENCES data_sources(id),
    user_id INT NULL REFERENCES users(id),
    version NVARCHAR(50) NOT NULL,
    dependencies_installed BIT NOT NULL DEFAULT 0,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Pipelines table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'pipelines')
CREATE TABLE pipelines (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    type NVARCHAR(50) NOT NULL,
    schedule NVARCHAR(100) NOT NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'draft',
    config NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    last_run DATETIME2 NULL
);

-- Activities table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'activities')
CREATE TABLE activities (
    id INT IDENTITY(1,1) PRIMARY KEY,
    activity NVARCHAR(255) NOT NULL,
    pipeline NVARCHAR(255) NULL,
    status NVARCHAR(50) NOT NULL,
    timestamp DATETIME2 NOT NULL DEFAULT GETDATE(),
    user_id INT NULL REFERENCES users(id)
);

-- Integrations table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'integrations')
CREATE TABLE integrations (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    type NVARCHAR(50) NOT NULL,
    endpoint NVARCHAR(255) NOT NULL,
    api_key NVARCHAR(255) NULL,
    config NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    status NVARCHAR(50) NOT NULL DEFAULT 'disconnected',
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Features table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'features')
CREATE TABLE features (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL UNIQUE,
    description NVARCHAR(MAX) NULL,
    data_type NVARCHAR(50) NOT NULL,
    source NVARCHAR(100) NOT NULL,
    transformation NVARCHAR(MAX) NULL,
    is_active BIT NOT NULL DEFAULT 1,
    metadata NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Feature sets table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'feature_sets')
CREATE TABLE feature_sets (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    tags NVARCHAR(MAX) NULL,
    is_active BIT NOT NULL DEFAULT 1,
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Feature set mappings table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'feature_set_mappings')
CREATE TABLE feature_set_mappings (
    id INT IDENTITY(1,1) PRIMARY KEY,
    feature_set_id INT NOT NULL REFERENCES feature_sets(id),
    feature_id INT NOT NULL REFERENCES features(id)
);

-- Experiments table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'experiments')
CREATE TABLE experiments (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    start_date DATETIME2 NULL,
    end_date DATETIME2 NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'draft',
    metrics NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    variants NVARCHAR(MAX) NOT NULL DEFAULT '[]',
    user_id INT NULL REFERENCES users(id),
    model_id INT NULL REFERENCES models(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- CI/CD Pipelines table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'cicd_pipelines')
CREATE TABLE cicd_pipelines (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    trigger_type NVARCHAR(50) NOT NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'inactive',
    steps NVARCHAR(MAX) NOT NULL,
    model_id INT NULL REFERENCES models(id),
    thresholds NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    notifications NVARCHAR(MAX) NOT NULL DEFAULT '[]',
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Approval Workflows table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'approval_workflows')
CREATE TABLE approval_workflows (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    model_id INT NULL REFERENCES models(id),
    stages NVARCHAR(MAX) NOT NULL,
    current_stage INT NOT NULL DEFAULT 0,
    status NVARCHAR(50) NOT NULL DEFAULT 'pending',
    comments NVARCHAR(MAX) NOT NULL DEFAULT '[]',
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- RL Agents table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'rl_agents')
CREATE TABLE rl_agents (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    algorithm NVARCHAR(100) NOT NULL,
    parameters NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    environment NVARCHAR(255) NOT NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'draft',
    metrics NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- RL Environments table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'rl_environments')
CREATE TABLE rl_environments (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    type NVARCHAR(50) NOT NULL,
    config NVARCHAR(MAX) NOT NULL DEFAULT '{}',
    observation_space NVARCHAR(MAX) NOT NULL,
    action_space NVARCHAR(MAX) NOT NULL,
    reward_function NVARCHAR(MAX) NULL,
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Comments table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'comments')
CREATE TABLE comments (
    id INT IDENTITY(1,1) PRIMARY KEY,
    content NVARCHAR(MAX) NOT NULL,
    entity_type NVARCHAR(50) NOT NULL,
    entity_id INT NOT NULL,
    user_id INT NULL REFERENCES users(id),
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Teams table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'teams')
CREATE TABLE teams (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Team Members table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'team_members')
CREATE TABLE team_members (
    id INT IDENTITY(1,1) PRIMARY KEY,
    team_id INT NOT NULL REFERENCES teams(id),
    user_id INT NOT NULL REFERENCES users(id),
    role NVARCHAR(50) NOT NULL DEFAULT 'member',
    joined_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Workflow Recommendations table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'workflow_recommendations')
CREATE TABLE workflow_recommendations (
    id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL REFERENCES users(id),
    business_case_id INT NOT NULL,
    data_type NVARCHAR(50) NOT NULL,
    objective NVARCHAR(100) NOT NULL,
    recommendation_id INT NOT NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'pending',
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Recommendation Templates table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'recommendation_templates')
CREATE TABLE recommendation_templates (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NOT NULL,
    category NVARCHAR(100) NOT NULL,
    steps NVARCHAR(MAX) NOT NULL,
    tags NVARCHAR(MAX) NOT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- User Workflow Preferences table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'user_workflow_preferences')
CREATE TABLE user_workflow_preferences (
    id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT NOT NULL REFERENCES users(id),
    preferred_data_types NVARCHAR(MAX) NOT NULL,
    preferred_objectives NVARCHAR(MAX) NOT NULL,
    favorite_templates NVARCHAR(MAX) NOT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Business Cases table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'business_cases')
CREATE TABLE business_cases (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NOT NULL,
    industry NVARCHAR(100) NOT NULL,
    category NVARCHAR(100) NOT NULL,
    tags NVARCHAR(MAX) NOT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);

-- Sessions table for authentication
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'sessions')
CREATE TABLE sessions (
    sid VARCHAR(255) PRIMARY KEY NOT NULL,
    session_data NVARCHAR(MAX) NOT NULL,
    expires DATETIME2 NOT NULL
);
`;

async function createSqlServerSchema() {
  try {
    const pool = await getPool();
    console.log('Connected to SQL Server. Creating schema...');
    
    // Split the schema by semicolons to execute each statement separately
    const statements = sqlServerSchema
      .split(';')
      .map(statement => statement.trim())
      .filter(statement => statement.length > 0);
    
    for (const statement of statements) {
      await pool.request().query(statement + ';');
    }
    
    console.log('SQL Server schema created successfully');
  } catch (error) {
    console.error('Error creating SQL Server schema:', error);
    throw error;
  }
}

// Execute the function if this file is run directly
if (require.main === module) {
  createSqlServerSchema()
    .then(() => {
      console.log('Schema creation completed');
      process.exit(0);
    })
    .catch(error => {
      console.error('Schema creation failed:', error);
      process.exit(1);
    });
}

export default createSqlServerSchema;