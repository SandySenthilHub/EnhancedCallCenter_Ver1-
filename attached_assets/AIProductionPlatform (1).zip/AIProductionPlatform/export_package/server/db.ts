import sql from 'mssql';

// Connection configuration
const config: sql.config = {
  user: process.env.AZURE_SQL_USER || 'shahul',
  password: process.env.AZURE_SQL_PASSWORD || 'apple123!@#',
  server: process.env.AZURE_SQL_SERVER || 'callcenter1.database.windows.net',
  database: process.env.AZURE_SQL_DATABASE || 'AImodel',
  options: {
    encrypt: true, // for Azure SQL
    trustServerCertificate: false, // true for local dev / false in production
    enableArithAbort: true
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

// Create and reuse a connection pool
let poolPromise: Promise<sql.ConnectionPool> | null = null;

export async function getPool(): Promise<sql.ConnectionPool> {
  if (!poolPromise) {
    console.log('Creating SQL Server connection pool...');
    poolPromise = new sql.ConnectionPool(config).connect()
      .then(pool => {
        console.log('Connected to SQL Server');
        
        // Handle pool errors
        pool.on('error', err => {
          console.error('SQL Server Pool Error:', err);
          poolPromise = null;
        });
        
        return pool;
      })
      .catch(err => {
        console.error('Error creating SQL Server connection pool:', err);
        poolPromise = null;
        throw err;
      });
  }
  
  return poolPromise;
}

/**
 * Execute a SQL query with no parameters
 * @param sqlQuery The SQL query to execute
 * @returns A Promise with the query results
 */
export async function executeQuery<T>(sqlQuery: string): Promise<T[]> {
  const pool = await getPool();
  const result = await pool.request().query(sqlQuery);
  return result.recordset as T[];
}

/**
 * Execute a SQL query with parameters
 * @param sqlQuery The SQL query to execute
 * @param params Object with parameter names and values
 * @returns A Promise with the query results
 */
export async function executeParameterizedQuery<T>(sqlQuery: string, params: { [key: string]: any } = {}): Promise<T[]> {
  const pool = await getPool();
  const request = pool.request();
  
  // Add all parameters to the request
  for (const [key, value] of Object.entries(params)) {
    // Handle null values explicitly
    if (value === null) {
      request.input(key, sql.VarChar, null);
    } 
    // Handle different data types
    else if (value instanceof Date) {
      request.input(key, sql.DateTime2, value);
    } else if (typeof value === 'number') {
      if (Number.isInteger(value)) {
        request.input(key, sql.Int, value);
      } else {
        request.input(key, sql.Float, value);
      }
    } else if (typeof value === 'boolean') {
      request.input(key, sql.Bit, value);
    } else {
      request.input(key, sql.NVarChar, value);
    }
  }
  
  const result = await request.query(sqlQuery);
  return result.recordset as T[];
}

/**
 * Insert a record into a table
 * @param tableName The name of the table
 * @param data Object with column names and values
 * @returns The inserted record with its ID
 */
export async function executeInsert<T>(tableName: string, data: { [key: string]: any }): Promise<T | null> {
  const pool = await getPool();
  const request = pool.request();
  
  // Build the SQL statement
  const columns = Object.keys(data).filter(key => data[key] !== undefined);
  const values = columns.map(col => `@${col}`);
  
  // Handle the case where no values are provided
  if (columns.length === 0) {
    throw new Error('No valid columns provided for insert');
  }
  
  // Create the SQL query
  const sqlQuery = `
    INSERT INTO ${tableName} (${columns.join(', ')})
    OUTPUT INSERTED.*
    VALUES (${values.join(', ')})
  `;
  
  // Add all parameters to the request
  for (const col of columns) {
    const value = data[col];
    // Handle null values explicitly
    if (value === null) {
      request.input(col, sql.VarChar, null);
    } 
    // Handle different data types
    else if (value instanceof Date) {
      request.input(col, sql.DateTime2, value);
    } else if (typeof value === 'number') {
      if (Number.isInteger(value)) {
        request.input(col, sql.Int, value);
      } else {
        request.input(col, sql.Float, value);
      }
    } else if (typeof value === 'boolean') {
      request.input(col, sql.Bit, value);
    } else {
      request.input(col, sql.NVarChar, value);
    }
  }
  
  // Execute the query
  const result = await request.query(sqlQuery);
  
  if (result.recordset && result.recordset.length > 0) {
    return result.recordset[0] as T;
  }
  
  return null;
}

/**
 * Update records in a table
 * @param tableName The name of the table
 * @param data Object with column names and values to update
 * @param whereClause The WHERE clause for the update
 * @param whereParams Object with parameter names and values for the WHERE clause
 * @returns The first updated record
 */
export async function executeUpdate<T>(
  tableName: string, 
  data: { [key: string]: any },
  whereClause: string,
  whereParams: { [key: string]: any } = {}
): Promise<T | undefined> {
  const pool = await getPool();
  const request = pool.request();
  
  // Build the SET clause
  const columns = Object.keys(data).filter(key => data[key] !== undefined);
  
  // Handle the case where no values are provided
  if (columns.length === 0) {
    throw new Error('No valid columns provided for update');
  }
  
  const setClause = columns.map(col => `${col} = @${col}`).join(', ');
  
  // Create the SQL query with OUTPUT to get the updated record
  const sqlQuery = `
    UPDATE ${tableName}
    SET ${setClause}
    OUTPUT INSERTED.*
    WHERE ${whereClause}
  `;
  
  // Add all parameters to the request
  for (const col of columns) {
    const value = data[col];
    // Handle null values explicitly
    if (value === null) {
      request.input(col, sql.VarChar, null);
    } 
    // Handle different data types
    else if (value instanceof Date) {
      request.input(col, sql.DateTime2, value);
    } else if (typeof value === 'number') {
      if (Number.isInteger(value)) {
        request.input(col, sql.Int, value);
      } else {
        request.input(col, sql.Float, value);
      }
    } else if (typeof value === 'boolean') {
      request.input(col, sql.Bit, value);
    } else {
      request.input(col, sql.NVarChar, value);
    }
  }
  
  // Add WHERE clause parameters
  for (const [key, value] of Object.entries(whereParams)) {
    // Handle null values explicitly
    if (value === null) {
      request.input(key, sql.VarChar, null);
    } 
    // Handle different data types
    else if (value instanceof Date) {
      request.input(key, sql.DateTime2, value);
    } else if (typeof value === 'number') {
      if (Number.isInteger(value)) {
        request.input(key, sql.Int, value);
      } else {
        request.input(key, sql.Float, value);
      }
    } else if (typeof value === 'boolean') {
      request.input(key, sql.Bit, value);
    } else {
      request.input(key, sql.NVarChar, value);
    }
  }
  
  // Execute the query
  const result = await request.query(sqlQuery);
  
  if (result.recordset && result.recordset.length > 0) {
    return result.recordset[0] as T;
  }
  
  return undefined;
}

/**
 * Delete records from a table
 * @param tableName The name of the table
 * @param whereClause The WHERE clause for the delete
 * @param whereParams Object with parameter names and values for the WHERE clause
 * @returns Number of rows affected
 */
export async function executeDelete(
  tableName: string, 
  whereClause: string,
  whereParams: { [key: string]: any } = {}
): Promise<number> {
  const pool = await getPool();
  const request = pool.request();
  
  // Create the SQL query
  const sqlQuery = `
    DELETE FROM ${tableName}
    WHERE ${whereClause}
  `;
  
  // Add WHERE clause parameters
  for (const [key, value] of Object.entries(whereParams)) {
    // Handle null values explicitly
    if (value === null) {
      request.input(key, sql.VarChar, null);
    } 
    // Handle different data types
    else if (value instanceof Date) {
      request.input(key, sql.DateTime2, value);
    } else if (typeof value === 'number') {
      if (Number.isInteger(value)) {
        request.input(key, sql.Int, value);
      } else {
        request.input(key, sql.Float, value);
      }
    } else if (typeof value === 'boolean') {
      request.input(key, sql.Bit, value);
    } else {
      request.input(key, sql.NVarChar, value);
    }
  }
  
  // Execute the query
  const result = await request.query(sqlQuery);
  return result.rowsAffected[0];
}

// Test the connection when this module is imported
getPool().catch(err => {
  console.error('Initial database connection test failed:', err);
});
