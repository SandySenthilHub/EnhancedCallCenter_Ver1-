#!/usr/bin/env tsx
/**
 * Command-line script to run the migration from PostgreSQL to Azure SQL Server
 * Usage: npx tsx server/run-migration.ts
 */

import migrateToAzureSql from './migrate-to-azure';
import readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Display warning and confirmation prompt
console.log('\n' + '!'.repeat(80));
console.log('WARNING: This script will migrate your PostgreSQL database to Azure SQL Server');
console.log('It will also modify your application code to use SQL Server instead of PostgreSQL');
console.log('Make sure you have:');
console.log('  1. A backup of your current PostgreSQL database');
console.log('  2. Valid Azure SQL Server credentials');
console.log('  3. No unsaved changes in your codebase');
console.log('!'.repeat(80) + '\n');

console.log('Azure SQL Server connection parameters:');
console.log('  Server: callcenter1.database.windows.net');
console.log('  Database: AImodel');
console.log('  Username: shahul');
console.log('  Password: apple123!@#\n');

// Prompt for confirmation
rl.question('Are you sure you want to proceed with the migration? (yes/no): ', async (answer) => {
  if (answer.toLowerCase() === 'yes') {
    console.log('\nStarting migration process...\n');
    
    try {
      // Run the migration
      await migrateToAzureSql();
      console.log('\nMigration completed successfully!');
      console.log('You can now restart your application to use the Azure SQL Server database.');
    } catch (error) {
      console.error('\nMigration failed. See above for error details.');
      console.error('You may need to restore your application from backup.');
    }
  } else {
    console.log('\nMigration aborted by user.');
  }
  
  rl.close();
  process.exit(0);
});