import { getPool, executeQuery } from './db.ts.new';

/**
 * Script to test the Azure SQL Server connection
 */
async function testSqlServerConnection() {
  try {
    console.log('Testing connection to Azure SQL Server...');
    
    // Step 1: Get connection pool
    const pool = await getPool();
    console.log('Successfully connected to SQL Server');
    
    // Step 2: Run a simple query
    console.log('Running test query...');
    try {
      const result = await executeQuery('SELECT @@VERSION AS Version');
      console.log('Query result:');
      console.log(result);
      console.log('SQL Server connection test successful!');
    } catch (queryError) {
      console.error('Error executing test query:', queryError);
      throw queryError;
    }
    
  } catch (error) {
    console.error('SQL Server connection test failed:', error);
    throw error;
  }
}

// Execute the test if this file is run directly
if (require.main === module) {
  testSqlServerConnection()
    .then(() => {
      process.exit(0);
    })
    .catch(error => {
      console.error('Test failed:', error);
      process.exit(1);
    });
}

export default testSqlServerConnection;