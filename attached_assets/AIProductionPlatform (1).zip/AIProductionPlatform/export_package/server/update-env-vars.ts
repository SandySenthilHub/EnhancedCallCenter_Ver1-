/**
 * This script updates environment variables for Azure SQL Server connection
 */

import fs from 'fs';
import path from 'path';

function updateEnvVars() {
  console.log('Updating environment variables for Azure SQL Server...');
  
  // Define the Azure SQL Server environment variables
  const envVars = {
    'AZURE_SQL_SERVER': 'callcenter1.database.windows.net',
    'AZURE_SQL_DATABASE': 'AImodel',
    'AZURE_SQL_USER': 'shahul',
    'AZURE_SQL_PASSWORD': 'apple123!@#',
  };
  
  // Find the .env file or create one if it doesn't exist
  const envPath = path.join(process.cwd(), '.env');
  let envContent = '';
  
  if (fs.existsSync(envPath)) {
    // Read existing .env file
    envContent = fs.readFileSync(envPath, 'utf8');
  }
  
  // Add or update each environment variable
  for (const [key, value] of Object.entries(envVars)) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    
    if (regex.test(envContent)) {
      // Update existing variable
      envContent = envContent.replace(regex, `${key}=${value}`);
    } else {
      // Add new variable
      envContent += `\n${key}=${value}`;
    }
  }
  
  // Remove any PostgreSQL related environment variables
  const pgVarsToRemove = [
    'PGPORT',
    'PGPASSWORD',
    'PGUSER',
    'PGDATABASE',
    'PGHOST'
  ];
  
  for (const pgVar of pgVarsToRemove) {
    const regex = new RegExp(`^${pgVar}=.*$\n?`, 'm');
    envContent = envContent.replace(regex, '');
  }
  
  // Keep DATABASE_URL for backward compatibility, but update it to point to SQL Server
  const dbUrlRegex = new RegExp(`^DATABASE_URL=.*$`, 'm');
  const sqlServerUrl = `mssql://${envVars.AZURE_SQL_USER}:${envVars.AZURE_SQL_PASSWORD}@${envVars.AZURE_SQL_SERVER}/${envVars.AZURE_SQL_DATABASE}`;
  
  if (dbUrlRegex.test(envContent)) {
    envContent = envContent.replace(dbUrlRegex, `DATABASE_URL=${sqlServerUrl}`);
  } else {
    envContent += `\nDATABASE_URL=${sqlServerUrl}`;
  }
  
  // Clean up any extra newlines
  envContent = envContent.replace(/\n{3,}/g, '\n\n');
  
  // Write back to the .env file
  fs.writeFileSync(envPath, envContent.trim() + '\n');
  
  console.log('Successfully updated environment variables for Azure SQL Server');
}

// Execute the update script if run directly
if (require.main === module) {
  try {
    updateEnvVars();
    console.log('Environment variable update completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Environment variable update failed:', error);
    process.exit(1);
  }
}

export default updateEnvVars;