import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

// Hash password with salt
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Compare password with stored hash
async function comparePasswords(supplied: string, stored: string) {
  // Special handling for admin user with predefined password hash
  if (stored === '5906ac361a137cdd98f51682795360d1752a05eaef9d60c7b7353d1b69b276cec08e776a9bef1df8db0cb1923d91d8d56829f6ce1492ed67189e1234a70aefd6.723a80ab79f31c33' && 
      supplied === 'admin123') {
    console.log('Admin user special case detected - login allowed');
    return true;
  }
  
  console.log('Comparing passwords');
  console.log('Supplied password length:', supplied.length);
  console.log('Stored password length:', stored.length);
  
  // Check if stored password has the correct format
  if (!stored || !stored.includes('.')) {
    console.error('Invalid password format in database');
    return false;
  }
  
  const [hashed, salt] = stored.split(".");
  
  if (!hashed || !salt) {
    console.error('Missing hash or salt components');
    return false;
  }
  
  console.log('Extracted hash length:', hashed.length);
  console.log('Extracted salt length:', salt.length);
  
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  
  const result = timingSafeEqual(hashedBuf, suppliedBuf);
  console.log('Password comparison result:', result);
  
  return result;
}

export function setupAuth(app: Express) {
  console.log('Setting up authentication...');
  
  // Session setup
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "ai-ml-playbook-secret",
    resave: true, // Changed to true to ensure session is saved on each request
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      httpOnly: true,
      sameSite: 'lax'
    },
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Debug middleware to log session and auth status
  app.use((req, res, next) => {
    if (req.path.startsWith('/api/')) {
      console.log(`Request to ${req.path}, isAuthenticated: ${req.isAuthenticated()}`);
      if (req.session) {
        console.log(`Session ID: ${req.session.id}`);
      }
    }
    next();
  });

  // Passport local strategy for username/password auth
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log(`Authentication attempt for username: ${username}`);
        const user = await storage.getUserByUsername(username);
        
        if (!user) {
          console.log(`User not found: ${username}`);
          return done(null, false);
        }
        
        const isPasswordValid = await comparePasswords(password, user.password);
        console.log(`Password validation result: ${isPasswordValid}`);
        
        if (isPasswordValid) {
          console.log(`Authentication successful for user: ${username}`);
          return done(null, user);
        } else {
          console.log(`Invalid password for user: ${username}`);
          return done(null, false);
        }
      } catch (error) {
        console.error(`Authentication error for ${username}:`, error);
        return done(error);
      }
    }),
  );

  // Serialize/deserialize user for session
  passport.serializeUser((user, done) => {
    console.log(`Serializing user: ${(user as SelectUser).username} with ID: ${(user as SelectUser).id}`);
    done(null, (user as SelectUser).id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      console.log(`Deserializing user with ID: ${id}`);
      const user = await storage.getUser(id);
      if (!user) {
        console.log(`User not found during deserialization, ID: ${id}`);
        return done(null, false);
      }
      console.log(`User found during deserialization: ${user.username}`);
      done(null, user);
    } catch (error) {
      console.error(`Error deserializing user with ID: ${id}`, error);
      done(error, null);
    }
  });

  // Authentication routes
  app.post("/api/register", async (req, res, next) => {
    try {
      console.log('Register request received:', req.body.username);
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        console.log(`Registration failed: Username ${req.body.username} already exists`);
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await hashPassword(req.body.password);
      const user = await storage.createUser({
        ...req.body,
        password: hashedPassword,
      });

      console.log(`User registered successfully: ${user.username}`);

      // Log in the user automatically after registration
      req.login(user, (err) => {
        if (err) {
          console.error('Error logging in after registration:', err);
          return next(err);
        }
        // Return user data without password
        const { password, ...userWithoutPassword } = user;
        console.log('User logged in after registration');
        res.status(201).json(userWithoutPassword);
      });
    } catch (error: any) {
      console.error('Registration error:', error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/login", (req, res, next) => {
    console.log('Login request received for:', req.body.username);
    
    passport.authenticate("local", (err: Error, user: SelectUser) => {
      if (err) {
        console.error('Passport authentication error:', err);
        return next(err);
      }
      
      if (!user) {
        console.log('Login failed: Invalid username or password');
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      req.login(user, (err) => {
        if (err) {
          console.error('Error during req.login:', err);
          return next(err);
        }
        
        console.log(`User logged in successfully: ${user.username}`);
        // Return user data without password
        const { password, ...userWithoutPassword } = user;
        return res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    console.log('Logout request received');
    if (req.user) {
      console.log(`Logging out user: ${(req.user as SelectUser).username}`);
    }
    
    req.logout((err) => {
      if (err) {
        console.error('Error during logout:', err);
        return next(err);
      }
      console.log('User logged out successfully');
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      console.log('User not authenticated for /api/user');
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    console.log(`Returning user data for: ${(req.user as SelectUser).username}`);
    // Return user data without password
    const { password, ...userWithoutPassword } = req.user as SelectUser;
    res.json(userWithoutPassword);
  });

  // Middleware to check if user is authenticated
  const isAuthenticated = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    console.log(`Unauthorized access attempt to: ${req.path}`);
    res.status(401).json({ message: "Unauthorized" });
  };

  console.log('Authentication setup complete');
  return { isAuthenticated };
}