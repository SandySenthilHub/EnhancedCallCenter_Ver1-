import pandas as pd
import numpy as np
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import silhouette_score, mean_squared_error, accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
import os
import joblib
from typing import Dict, List, Any, Union, Optional

class MLEngine:
    def __init__(self):
        self.models = {}
        self.model_factories = {
            'regression': {
                'linear_regression': LinearRegression,
                'ridge': lambda: LinearRegression(alpha=1.0),
                'lasso': lambda: LinearRegression(alpha=1.0)
            },
            'classification': {
                'logistic_regression': LogisticRegression,
                'random_forest': RandomForestClassifier,
                'gradient_boosting': GradientBoostingClassifier
            },
            'clustering': {
                'kmeans': KMeans,
                'dbscan': DBSCAN
            }
        }
    
    def train_model(self, model_type: str, algorithm: str, data: pd.DataFrame, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Train a machine learning model and return metrics."""
        
        if model_type not in self.model_factories or algorithm not in self.model_factories[model_type]:
            raise ValueError(f"Unsupported model type '{model_type}' or algorithm '{algorithm}'")
        
        # Prepare data
        X, y = self._prepare_data(data, model_type)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42) if model_type != 'clustering' else (X, None, None, None)
        
        # Create and train model
        model_factory = self.model_factories[model_type][algorithm]
        model = model_factory(**parameters) if parameters else model_factory()
        
        if model_type == 'clustering':
            model.fit(X)
            labels = model.labels_ if hasattr(model, 'labels_') else model.predict(X)
            
            # Calculate clustering metrics
            metrics = {}
            try:
                metrics['silhouette_score'] = float(silhouette_score(X, labels)) if len(np.unique(labels)) > 1 else 0
            except:
                metrics['silhouette_score'] = 0
            
            if hasattr(model, 'inertia_'):
                metrics['inertia'] = float(model.inertia_)
            
            # Store model
            model_id = f"{algorithm}_{len(self.models) + 1}"
            self.models[model_id] = model
            
            return metrics
        
        elif model_type == 'regression':
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            
            # Calculate regression metrics
            metrics = {
                'rmse': float(np.sqrt(mean_squared_error(y_test, y_pred))),
                'mse': float(mean_squared_error(y_test, y_pred)),
                'r2': float(model.score(X_test, y_test))
            }
            
            # Store model
            model_id = f"{algorithm}_{len(self.models) + 1}"
            self.models[model_id] = model
            
            return metrics
        
        elif model_type == 'classification':
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            
            # Calculate classification metrics
            metrics = {
                'accuracy': float(accuracy_score(y_test, y_pred)),
                'precision': float(precision_score(y_test, y_pred, average='weighted', zero_division=0)),
                'recall': float(recall_score(y_test, y_pred, average='weighted', zero_division=0)),
                'f1': float(f1_score(y_test, y_pred, average='weighted', zero_division=0))
            }
            
            # Store model
            model_id = f"{algorithm}_{len(self.models) + 1}"
            self.models[model_id] = model
            
            return metrics
        
        return {}
    
    def _prepare_data(self, data: pd.DataFrame, model_type: str) -> tuple:
        """Prepare data for model training based on model type."""
        if model_type == 'clustering':
            # For clustering, we don't need a target variable
            return data, None
        
        # For regression and classification, split into features and target
        X = data.drop('target', axis=1) if 'target' in data.columns else data.iloc[:, :-1]
        y = data['target'] if 'target' in data.columns else data.iloc[:, -1]
        
        return X, y
    
    def tune_hyperparameters(self, model_type: str, algorithm: str, data: pd.DataFrame, 
                            param_grid: Dict[str, List[Any]], tuning_strategy: str = 'grid_search', 
                            cv: int = 5, scoring: Optional[str] = None) -> Dict[str, Any]:
        """Tune hyperparameters for a model and return best parameters and metrics."""
        
        if model_type not in self.model_factories or algorithm not in self.model_factories[model_type]:
            raise ValueError(f"Unsupported model type '{model_type}' or algorithm '{algorithm}'")
        
        # Prepare data
        X, y = self._prepare_data(data, model_type)
        
        # Create base model
        model_factory = self.model_factories[model_type][algorithm]
        base_model = model_factory()
        
        # Setup hyperparameter tuning
        if tuning_strategy == 'grid_search':
            search = GridSearchCV(base_model, param_grid, cv=cv, scoring=scoring)
        elif tuning_strategy == 'random_search':
            search = RandomizedSearchCV(base_model, param_grid, cv=cv, scoring=scoring)
        else:
            raise ValueError(f"Unsupported tuning strategy '{tuning_strategy}'")
        
        # Run hyperparameter tuning
        if model_type == 'clustering':
            # For clustering, we might need special handling
            # This is a simplified example
            search.fit(X)
        else:
            search.fit(X, y)
        
        # Get best parameters and metrics
        best_params = search.best_params_
        best_score = search.best_score_
        
        return {
            'best_parameters': best_params,
            'best_score': float(best_score),
            'all_scores': search.cv_results_['mean_test_score'].tolist()
        }
    
    def save_model(self, model_id: str, path: str) -> str:
        """Save trained model to disk."""
        if model_id not in self.models:
            raise ValueError(f"Model '{model_id}' not found")
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Save model
        joblib.dump(self.models[model_id], path)
        
        return path
    
    def load_model(self, path: str) -> str:
        """Load trained model from disk."""
        if not os.path.exists(path):
            raise ValueError(f"Model file '{path}' not found")
        
        # Load model
        model = joblib.load(path)
        
        # Store model
        model_id = f"loaded_{len(self.models) + 1}"
        self.models[model_id] = model
        
        return model_id
