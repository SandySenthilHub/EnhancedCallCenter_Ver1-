// This script will reset the admin password to 'admin123'
// Run with: node server/reset-admin-password.js

import sql from 'mssql';
import { randomBytes, scrypt } from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(scrypt);

// Create connection to database
async function connectToDatabase() {
  try {
    // Create connection pool
    const pool = await sql.connect({
      server: process.env.PGHOST || 'callcenter1.database.windows.net',
      database: process.env.PGDATABASE || 'AImodel',
      user: process.env.PGUSER || 'shahul',
      password: process.env.PGPASSWORD || 'apple123!@#',
      options: {
        encrypt: true,
        trustServerCertificate: false
      }
    });
    
    console.log('Connected to SQL Server');
    return pool;
  } catch (err) {
    console.error('Database connection failed:', err);
    throw err;
  }
}

// Hash password with salt
async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString("hex")}.${salt}`;
}

async function resetAdminPassword() {
  const pool = await connectToDatabase();
  const hashedPassword = await hashPassword('admin123');
  
  try {
    console.log('Resetting admin password...');
    console.log('Hashed password:', hashedPassword);
    
    // Check if admin user exists
    const userCheck = await pool.request()
      .input('username', sql.NVarChar, 'admin')
      .query('SELECT COUNT(*) as count FROM users WHERE username = @username');
    
    const userExists = userCheck.recordset[0].count > 0;
    
    if (userExists) {
      // Update admin password
      await pool.request()
        .input('password', sql.NVarChar, hashedPassword)
        .input('username', sql.NVarChar, 'admin')
        .query('UPDATE users SET password = @password WHERE username = @username');
      
      console.log('Admin password reset successfully');
    } else {
      // Create admin user if not exists
      await pool.request()
        .input('username', sql.NVarChar, 'admin')
        .input('email', sql.NVarChar, 'admin@aimlplaybook.com')
        .input('password', sql.NVarChar, hashedPassword)
        .input('role', sql.NVarChar, 'admin')
        .query(`
          INSERT INTO users (username, email, password, role)
          VALUES (@username, @email, @password, @role)
        `);
      
      console.log('Admin user created successfully');
    }
  } catch (err) {
    console.error('Error resetting admin password:', err);
    throw err;
  } finally {
    await pool.close();
  }
}

resetAdminPassword()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch(err => {
    console.error('Failed:', err);
    process.exit(1);
  });