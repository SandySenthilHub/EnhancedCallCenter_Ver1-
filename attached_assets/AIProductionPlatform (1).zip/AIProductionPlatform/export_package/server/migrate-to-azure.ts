/**
 * Master script to run the complete PostgreSQL to Azure SQL Server migration
 */

import updateEnvVars from './update-env-vars';
import createSqlServerSchema from './create-sqlserver-schema';
import migrateData from './migrate-data';
import cleanupPostgresDependencies from './cleanup-pg-dependencies';
import testSqlServerConnection from './test-sql-connection';
import fs from 'fs';
import path from 'path';

async function migrateToAzureSql() {
  try {
    console.log('='.repeat(80));
    console.log('STARTING MIGRATION FROM POSTGRESQL TO AZURE SQL SERVER');
    console.log('='.repeat(80));
    
    // Step 1: Update environment variables
    console.log('\n--- STEP 1: Updating environment variables ---');
    updateEnvVars();
    
    // Step 2: Test SQL Server connection
    console.log('\n--- STEP 2: Testing Azure SQL Server connection ---');
    try {
      await testSqlServerConnection();
    } catch (connError) {
      console.error('Failed to connect to Azure SQL Server. Please verify your connection settings.');
      console.error('The migration cannot proceed without a valid database connection.');
      throw new Error('SQL Server connection test failed: ' + connError.message);
    }
    
    // Step 3: Create SQL Server schema
    console.log('\n--- STEP 3: Creating Azure SQL Server schema ---');
    await createSqlServerSchema();
    
    // Step 4: Migrate data from PostgreSQL to SQL Server
    console.log('\n--- STEP 4: Migrating data ---');
    await migrateData();
    
    // Step 5: Swap out the files
    console.log('\n--- STEP 5: Swapping files ---');
    await swapFiles();
    
    // Step 6: Clean up PostgreSQL dependencies
    console.log('\n--- STEP 6: Cleaning up PostgreSQL dependencies ---');
    await cleanupPostgresDependencies();
    
    console.log('\n' + '='.repeat(80));
    console.log('MIGRATION COMPLETED SUCCESSFULLY');
    console.log('='.repeat(80));
    console.log('\nRemember to restart the application for changes to take effect.');
    
  } catch (error: any) {
    console.error('\n' + '!'.repeat(80));
    console.error('MIGRATION FAILED');
    console.error('!'.repeat(80));
    console.error(`\nError: ${error.message}`);
    console.error('See above for detailed error logs');
    throw error;
  }
}

// Helper function to swap files
async function swapFiles() {
  const filesToSwap = [
    { old: 'server/db.ts', new: 'server/db.ts.new' },
    { old: 'server/storage.ts', new: 'server/storage.ts.new' },
    { old: 'server/auth.ts', new: 'server/auth.ts.new' },
    { old: 'shared/schema.ts', new: 'shared/schema.ts.new' }
  ];
  
  // Backup original files
  for (const file of filesToSwap) {
    const oldPath = path.join(process.cwd(), file.old);
    const backupPath = path.join(process.cwd(), `${file.old}.bak`);
    
    if (fs.existsSync(oldPath)) {
      fs.copyFileSync(oldPath, backupPath);
      console.log(`Backed up ${file.old} to ${file.old}.bak`);
    } else {
      console.warn(`Warning: Original file ${file.old} not found, no backup created.`);
    }
  }
  
  // Swap new files in place of old ones
  for (const file of filesToSwap) {
    const newPath = path.join(process.cwd(), file.new);
    const oldPath = path.join(process.cwd(), file.old);
    
    if (fs.existsSync(newPath)) {
      fs.copyFileSync(newPath, oldPath);
      console.log(`Swapped ${file.new} to ${file.old}`);
    } else {
      console.warn(`Warning: New file ${file.new} does not exist, skipping.`);
    }
  }
  
  console.log('File swap completed');
}

// Execute the migration if run directly
if (require.main === module) {
  migrateToAzureSql()
    .then(() => {
      process.exit(0);
    })
    .catch(error => {
      console.error('Migration script failed with error:', error);
      process.exit(1);
    });
}

export default migrateToAzureSql;