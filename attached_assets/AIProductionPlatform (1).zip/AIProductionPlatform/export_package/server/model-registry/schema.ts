/**
 * Model Registry Database Schema
 * This file defines the database schema for the Model Registry module.
 */

import { z } from "zod";

// Model stages for lifecycle management
export const MODEL_STAGES = ['Development', 'Staging', 'Production', 'Archived', 'Rejected'] as const;
export type ModelStage = typeof MODEL_STAGES[number];

// Model types to distinguish between native and external integrations
export const MODEL_TYPES = ['Native', 'Azure', 'AWS', 'MLflow'] as const;
export type ModelType = typeof MODEL_TYPES[number];

// Base model schema
export const modelSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string(),
  type: z.enum(MODEL_TYPES),
  created_by: z.number(),  // User ID
  team_id: z.number().nullable(),
  created_at: z.date(),
  updated_at: z.date(),
  is_active: z.boolean().default(true),
  tags: z.array(z.string()).nullable()
});

// Model version schema
export const modelVersionSchema = z.object({
  id: z.number(),
  model_id: z.number(),
  version: z.string(),  // Semantic versioning (e.g., 1.0.0)
  description: z.string(),
  stage: z.enum(MODEL_STAGES).default('Development'),
  created_by: z.number(),  // User ID
  created_at: z.date(),
  updated_at: z.date(),
  metrics: z.record(z.string(), z.any()).nullable(),  // Store performance metrics
  framework: z.string().nullable(),  // e.g., TensorFlow, PyTorch
  algorithm: z.string().nullable(),  // e.g., Random Forest, Neural Network
  input_schema: z.string().nullable(),  // JSON schema of expected inputs
  output_schema: z.string().nullable(),  // JSON schema of outputs
  training_dataset_id: z.number().nullable(),  // Reference to dataset used
  dependencies: z.record(z.string(), z.string()).nullable()  // Library dependencies
});

// Model artifact schema
export const modelArtifactSchema = z.object({
  id: z.number(),
  version_id: z.number(),  // Reference to model version
  name: z.string(),
  type: z.string(),  // e.g., Model, Script, Documentation
  path: z.string(),  // Storage path to the artifact
  size: z.number(),  // Size in bytes
  hash: z.string(),  // For integrity verification
  created_at: z.date(),
  metadata: z.record(z.string(), z.any()).nullable()
});

// External service configuration schema
export const externalServiceConfigSchema = z.object({
  id: z.number(),
  version_id: z.number(),  // Reference to model version
  service_type: z.string(),  // e.g., Azure Text Analytics, AWS Rekognition
  config: z.record(z.string(), z.any()),  // Service-specific configuration
  credential_reference: z.string().nullable(),  // Reference to vault-stored credentials
  region: z.string().nullable(),
  endpoint: z.string().nullable()
});

// Stage transition schema for approval workflows
export const stageTransitionSchema = z.object({
  id: z.number(),
  version_id: z.number(),
  from_stage: z.enum(MODEL_STAGES),
  to_stage: z.enum(MODEL_STAGES),
  requester_id: z.number(),  // User who requested
  approver_id: z.number().nullable(),  // User who approved
  requested_at: z.date(),
  approved_at: z.date().nullable(),
  status: z.enum(['Pending', 'Approved', 'Rejected']),
  comments: z.string().nullable()
});

// Model event schema for audit logging
export const modelEventSchema = z.object({
  id: z.number(),
  model_id: z.number().nullable(),
  version_id: z.number().nullable(),
  user_id: z.number(),
  event_type: z.string(),  // e.g., Created, Updated, StageChanged
  event_details: z.record(z.string(), z.any()),
  timestamp: z.date()
});

// Registry roles for RBAC
export const REGISTRY_ROLES = ['RegistryAdmin', 'ModelContributor', 'ModelApprover', 'ModelViewer'] as const;
export type RegistryRole = typeof REGISTRY_ROLES[number];

// User role schema for access control
export const registryUserRoleSchema = z.object({
  id: z.number(),
  user_id: z.number(),
  role: z.enum(REGISTRY_ROLES),
  model_id: z.number().nullable(),  // If null, applies to all models
  assigned_by: z.number(),
  assigned_at: z.date()
});

// TypeScript Types derived from Zod schemas
export type Model = z.infer<typeof modelSchema>;
export type ModelVersion = z.infer<typeof modelVersionSchema>;
export type ModelArtifact = z.infer<typeof modelArtifactSchema>;
export type ExternalServiceConfig = z.infer<typeof externalServiceConfigSchema>;
export type StageTransition = z.infer<typeof stageTransitionSchema>;
export type ModelEvent = z.infer<typeof modelEventSchema>;
export type RegistryUserRole = z.infer<typeof registryUserRoleSchema>;

// Insert types (omit auto-generated fields)
export type InsertModel = Omit<Model, 'id' | 'created_at' | 'updated_at'>;
export type InsertModelVersion = Omit<ModelVersion, 'id' | 'created_at' | 'updated_at'>;
export type InsertModelArtifact = Omit<ModelArtifact, 'id' | 'created_at'>;
export type InsertExternalServiceConfig = Omit<ExternalServiceConfig, 'id'>;
export type InsertStageTransition = Omit<StageTransition, 'id' | 'requested_at' | 'approved_at'>;
export type InsertModelEvent = Omit<ModelEvent, 'id' | 'timestamp'>;
export type InsertRegistryUserRole = Omit<RegistryUserRole, 'id' | 'assigned_at'>;

// SQL Server table creation script (reference)
export const SQL_MODEL_REGISTRY_SCHEMA = `
-- Models table
CREATE TABLE model_registry_models (
  id INT IDENTITY(1,1) PRIMARY KEY,
  name NVARCHAR(255) NOT NULL,
  description NVARCHAR(MAX) NOT NULL,
  type NVARCHAR(50) NOT NULL,
  created_by INT NOT NULL,
  team_id INT NULL,
  created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
  updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
  is_active BIT NOT NULL DEFAULT 1,
  tags NVARCHAR(MAX) NULL,
  CONSTRAINT UQ_model_name UNIQUE (name)
);

-- Model versions table
CREATE TABLE model_registry_versions (
  id INT IDENTITY(1,1) PRIMARY KEY,
  model_id INT NOT NULL,
  version NVARCHAR(50) NOT NULL,
  description NVARCHAR(MAX) NOT NULL,
  stage NVARCHAR(50) NOT NULL DEFAULT 'Development',
  created_by INT NOT NULL,
  created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
  updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
  metrics NVARCHAR(MAX) NULL,
  framework NVARCHAR(100) NULL,
  algorithm NVARCHAR(100) NULL,
  input_schema NVARCHAR(MAX) NULL,
  output_schema NVARCHAR(MAX) NULL,
  training_dataset_id INT NULL,
  dependencies NVARCHAR(MAX) NULL,
  CONSTRAINT FK_version_model FOREIGN KEY (model_id) REFERENCES model_registry_models(id),
  CONSTRAINT UQ_model_version UNIQUE (model_id, version)
);

-- Model artifacts table
CREATE TABLE model_registry_artifacts (
  id INT IDENTITY(1,1) PRIMARY KEY,
  version_id INT NOT NULL,
  name NVARCHAR(255) NOT NULL,
  type NVARCHAR(50) NOT NULL,
  path NVARCHAR(1000) NOT NULL,
  size BIGINT NOT NULL,
  hash NVARCHAR(255) NOT NULL,
  created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
  metadata NVARCHAR(MAX) NULL,
  CONSTRAINT FK_artifact_version FOREIGN KEY (version_id) REFERENCES model_registry_versions(id)
);

-- External service configuration table
CREATE TABLE model_registry_external_configs (
  id INT IDENTITY(1,1) PRIMARY KEY,
  version_id INT NOT NULL,
  service_type NVARCHAR(100) NOT NULL,
  config NVARCHAR(MAX) NOT NULL,
  credential_reference NVARCHAR(255) NULL,
  region NVARCHAR(100) NULL,
  endpoint NVARCHAR(1000) NULL,
  CONSTRAINT FK_external_version FOREIGN KEY (version_id) REFERENCES model_registry_versions(id)
);

-- Stage transition requests and approvals
CREATE TABLE model_registry_stage_transitions (
  id INT IDENTITY(1,1) PRIMARY KEY,
  version_id INT NOT NULL,
  from_stage NVARCHAR(50) NOT NULL,
  to_stage NVARCHAR(50) NOT NULL,
  requester_id INT NOT NULL,
  approver_id INT NULL,
  requested_at DATETIME2 NOT NULL DEFAULT GETDATE(),
  approved_at DATETIME2 NULL,
  status NVARCHAR(50) NOT NULL,
  comments NVARCHAR(MAX) NULL,
  CONSTRAINT FK_transition_version FOREIGN KEY (version_id) REFERENCES model_registry_versions(id)
);

-- Audit logs for all significant actions
CREATE TABLE model_registry_events (
  id INT IDENTITY(1,1) PRIMARY KEY,
  model_id INT NULL,
  version_id INT NULL,
  user_id INT NOT NULL,
  event_type NVARCHAR(100) NOT NULL,
  event_details NVARCHAR(MAX) NOT NULL,
  timestamp DATETIME2 NOT NULL DEFAULT GETDATE(),
  CONSTRAINT FK_event_model FOREIGN KEY (model_id) REFERENCES model_registry_models(id),
  CONSTRAINT FK_event_version FOREIGN KEY (version_id) REFERENCES model_registry_versions(id)
);

-- User roles specific to the model registry
CREATE TABLE model_registry_user_roles (
  id INT IDENTITY(1,1) PRIMARY KEY,
  user_id INT NOT NULL,
  role NVARCHAR(50) NOT NULL,
  model_id INT NULL,  -- If NULL, applies to all models
  assigned_by INT NOT NULL,
  assigned_at DATETIME2 NOT NULL DEFAULT GETDATE(),
  CONSTRAINT UQ_user_model_role UNIQUE (user_id, role, model_id)
);
`;