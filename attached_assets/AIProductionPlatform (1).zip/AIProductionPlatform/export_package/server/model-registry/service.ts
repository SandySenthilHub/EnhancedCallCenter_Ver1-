/**
 * Model Registry Service
 * This file provides business logic for the Model Registry module.
 */

import { modelRegistryStorage, IModelRegistryStorage } from './storage';
import {
  Model, ModelVersion, ModelArtifact, ExternalServiceConfig, 
  StageTransition, ModelEvent, RegistryUserRole,
  InsertModel, InsertModelVersion, InsertModelArtifact, 
  InsertExternalServiceConfig, InsertStageTransition, 
  InsertModelEvent, InsertRegistryUserRole,
  ModelType, ModelStage, RegistryRole,
  MODEL_TYPES, MODEL_STAGES, REGISTRY_ROLES
} from './schema';
import * as semver from 'semver';
import { storage } from '../storage';

// Error class for Model Registry-specific errors
export class ModelRegistryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ModelRegistryError';
  }
}

// Service interface
export interface IModelRegistryService {
  // Models
  getModels(): Promise<Model[]>;
  getModelById(id: number): Promise<Model>;
  getModelByName(name: string): Promise<Model | null>;
  createModel(model: Omit<InsertModel, 'type'> & { type: ModelType }): Promise<Model>;
  updateModel(id: number, model: Partial<InsertModel>, userId: number): Promise<Model>;
  deleteModel(id: number, userId: number): Promise<boolean>;
  
  // Model Versions
  getModelVersions(modelId: number): Promise<ModelVersion[]>;
  getModelVersionById(id: number): Promise<ModelVersion>;
  createModelVersion(version: Omit<InsertModelVersion, 'stage'> & { stage?: ModelStage }): Promise<ModelVersion>;
  updateModelVersionMetadata(id: number, metadata: Partial<InsertModelVersion>, userId: number): Promise<ModelVersion>;
  
  // Model Version Creation
  createNativeModelVersion(
    modelId: number, 
    version: string, 
    description: string, 
    userId: number,
    framework?: string,
    algorithm?: string,
    inputSchema?: string,
    outputSchema?: string,
    metrics?: Record<string, any>,
    dependencies?: Record<string, string>
  ): Promise<ModelVersion>;
  
  createAzureServiceVersion(
    modelId: number,
    version: string,
    description: string,
    userId: number,
    serviceType: string,
    config: Record<string, any>,
    credentialReference?: string,
    region?: string,
    endpoint?: string
  ): Promise<ModelVersion>;
  
  createAwsServiceVersion(
    modelId: number,
    version: string,
    description: string,
    userId: number,
    serviceType: string,
    config: Record<string, any>,
    credentialReference?: string,
    region?: string,
    endpoint?: string
  ): Promise<ModelVersion>;
  
  createMlflowModelVersion(
    modelId: number,
    version: string,
    description: string,
    userId: number,
    mlflowModelName: string,
    mlflowModelVersion: string,
    mlflowTrackingUri: string,
    config: Record<string, any>
  ): Promise<ModelVersion>;
  
  // Artifacts
  addModelArtifact(
    versionId: number,
    name: string,
    type: string,
    path: string,
    size: number,
    hash: string,
    metadata?: Record<string, any>
  ): Promise<ModelArtifact>;
  
  getModelArtifacts(versionId: number): Promise<ModelArtifact[]>;
  
  // Version suggestions
  suggestNextVersion(modelId: number, versionType: 'major' | 'minor' | 'patch'): Promise<string>;
  
  // Stage transitions
  requestStageTransition(
    versionId: number,
    toStage: ModelStage,
    requesterId: number,
    comments?: string
  ): Promise<StageTransition>;
  
  approveStageTransition(
    transitionId: number,
    approverId: number,
    approved: boolean,
    comments?: string
  ): Promise<StageTransition>;
  
  getPendingApprovals(): Promise<StageTransition[]>;
  
  getStageTransitionHistory(versionId: number): Promise<StageTransition[]>;
  
  // Access control
  hasModelAccess(userId: number, modelId: number, requiredRole: RegistryRole): Promise<boolean>;
  
  assignUserRole(
    userId: number,
    role: RegistryRole,
    assignedById: number,
    modelId?: number
  ): Promise<RegistryUserRole>;
  
  removeUserRole(roleId: number, requestedById: number): Promise<boolean>;
  
  getUserRoles(userId: number): Promise<RegistryUserRole[]>;
  
  // Audit logging
  getModelEvents(modelId?: number, versionId?: number): Promise<ModelEvent[]>;
  
  // Search
  searchModels(query: string, filters?: Record<string, any>): Promise<Model[]>;
  
  // Dashboard data
  getDashboardStats(): Promise<{
    totalModels: number;
    modelsByType: Record<string, number>;
    modelsByStage: Record<string, number>;
    recentModels: Model[];
  }>;
}

export class ModelRegistryService implements IModelRegistryService {
  private storage: IModelRegistryStorage;
  
  constructor(storage: IModelRegistryStorage) {
    this.storage = storage;
  }
  
  // Models
  async getModels(): Promise<Model[]> {
    return this.storage.getModels();
  }
  
  async getModelById(id: number): Promise<Model> {
    const model = await this.storage.getModelById(id);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${id} not found`);
    }
    return model;
  }
  
  async getModelByName(name: string): Promise<Model | null> {
    return await this.storage.getModelByName(name) || null;
  }
  
  async createModel(model: Omit<InsertModel, 'type'> & { type: ModelType }): Promise<Model> {
    // Check if model name is unique
    const existingModel = await this.storage.getModelByName(model.name);
    if (existingModel) {
      throw new ModelRegistryError(`A model with the name "${model.name}" already exists`);
    }
    
    // Validate model type
    if (!MODEL_TYPES.includes(model.type)) {
      throw new ModelRegistryError(`Invalid model type: ${model.type}`);
    }
    
    // Create the model
    const newModel = await this.storage.createModel(model);
    
    // Log the event
    await this.logModelEvent({
      model_id: newModel.id,
      user_id: model.created_by,
      event_type: 'ModelCreated',
      event_details: {
        model_name: newModel.name,
        model_type: newModel.type
      }
    });
    
    return newModel;
  }
  
  async updateModel(id: number, model: Partial<InsertModel>, userId: number): Promise<Model> {
    // Check if model exists
    const existingModel = await this.storage.getModelById(id);
    if (!existingModel) {
      throw new ModelRegistryError(`Model with ID ${id} not found`);
    }
    
    // Check for name uniqueness if name is being updated
    if (model.name && model.name !== existingModel.name) {
      const modelWithSameName = await this.storage.getModelByName(model.name);
      if (modelWithSameName) {
        throw new ModelRegistryError(`A model with the name "${model.name}" already exists`);
      }
    }
    
    // Check access permission
    const hasAccess = await this.hasModelAccess(userId, id, 'ModelContributor');
    if (!hasAccess) {
      throw new ModelRegistryError('Access denied: User does not have permission to update this model');
    }
    
    // Update the model
    const updatedModel = await this.storage.updateModel(id, model);
    if (!updatedModel) {
      throw new ModelRegistryError(`Failed to update model with ID ${id}`);
    }
    
    // Log the event
    await this.logModelEvent({
      model_id: id,
      user_id: userId,
      event_type: 'ModelUpdated',
      event_details: {
        updated_fields: Object.keys(model)
      }
    });
    
    return updatedModel;
  }
  
  async deleteModel(id: number, userId: number): Promise<boolean> {
    // Check if model exists
    const existingModel = await this.storage.getModelById(id);
    if (!existingModel) {
      throw new ModelRegistryError(`Model with ID ${id} not found`);
    }
    
    // Check access permission
    const hasAccess = await this.hasModelAccess(userId, id, 'RegistryAdmin');
    if (!hasAccess) {
      throw new ModelRegistryError('Access denied: User does not have permission to delete this model');
    }
    
    // Delete the model (soft delete)
    const deleted = await this.storage.deleteModel(id);
    
    // Log the event
    if (deleted) {
      await this.logModelEvent({
        model_id: id,
        user_id: userId,
        event_type: 'ModelDeleted',
        event_details: {
          model_name: existingModel.name
        }
      });
    }
    
    return deleted;
  }
  
  // Model Versions
  async getModelVersions(modelId: number): Promise<ModelVersion[]> {
    // Check if model exists
    const model = await this.storage.getModelById(modelId);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${modelId} not found`);
    }
    
    return this.storage.getModelVersions(modelId);
  }
  
  async getModelVersionById(id: number): Promise<ModelVersion> {
    const version = await this.storage.getModelVersionById(id);
    if (!version) {
      throw new ModelRegistryError(`Model version with ID ${id} not found`);
    }
    return version;
  }
  
  async createModelVersion(version: Omit<InsertModelVersion, 'stage'> & { stage?: ModelStage }): Promise<ModelVersion> {
    // Check if model exists
    const model = await this.storage.getModelById(version.model_id);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${version.model_id} not found`);
    }
    
    // Check if version already exists for this model
    const existingVersion = await this.storage.getModelVersionByModelAndVersion(
      version.model_id,
      version.version
    );
    
    if (existingVersion) {
      throw new ModelRegistryError(
        `Version ${version.version} already exists for model "${model.name}"`
      );
    }
    
    // Validate semver formatting
    if (!semver.valid(version.version)) {
      throw new ModelRegistryError(
        `Invalid version format: ${version.version}. Please use semantic versioning (e.g., 1.0.0)`
      );
    }
    
    // Set stage to Development if not provided
    const versionWithStage: InsertModelVersion = {
      ...version,
      stage: version.stage || 'Development'
    };
    
    // Create the version
    const newVersion = await this.storage.createModelVersion(versionWithStage);
    
    // Log the event
    await this.logModelEvent({
      model_id: version.model_id,
      version_id: newVersion.id,
      user_id: version.created_by,
      event_type: 'VersionCreated',
      event_details: {
        model_name: model.name,
        version: newVersion.version,
        stage: newVersion.stage
      }
    });
    
    return newVersion;
  }
  
  async updateModelVersionMetadata(id: number, metadata: Partial<InsertModelVersion>, userId: number): Promise<ModelVersion> {
    // Check if version exists
    const existingVersion = await this.storage.getModelVersionById(id);
    if (!existingVersion) {
      throw new ModelRegistryError(`Model version with ID ${id} not found`);
    }
    
    // Check access permission
    const hasAccess = await this.hasModelAccess(userId, existingVersion.model_id, 'ModelContributor');
    if (!hasAccess) {
      throw new ModelRegistryError('Access denied: User does not have permission to update this model version');
    }
    
    // Disallow changing immutable fields
    const immutableFields = ['model_id', 'version', 'created_by', 'created_at'];
    const hasImmutableField = immutableFields.some(field => field in metadata);
    if (hasImmutableField) {
      throw new ModelRegistryError(
        `Cannot update immutable fields: ${immutableFields.join(', ')}`
      );
    }
    
    // Disallow changing stage directly (must use stage transition requests)
    if ('stage' in metadata) {
      throw new ModelRegistryError(
        'Cannot update stage directly. Use requestStageTransition instead.'
      );
    }
    
    // Update the version metadata
    const updatedVersion = await this.storage.updateModelVersion(id, metadata);
    if (!updatedVersion) {
      throw new ModelRegistryError(`Failed to update version with ID ${id}`);
    }
    
    // Log the event
    await this.logModelEvent({
      model_id: existingVersion.model_id,
      version_id: id,
      user_id: userId,
      event_type: 'VersionUpdated',
      event_details: {
        updated_fields: Object.keys(metadata)
      }
    });
    
    return updatedVersion;
  }
  
  // Model Version Creation with specific types
  async createNativeModelVersion(
    modelId: number, 
    version: string, 
    description: string, 
    userId: number,
    framework?: string,
    algorithm?: string,
    inputSchema?: string,
    outputSchema?: string,
    metrics?: Record<string, any>,
    dependencies?: Record<string, string>
  ): Promise<ModelVersion> {
    // Check if model exists and is Native type
    const model = await this.storage.getModelById(modelId);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${modelId} not found`);
    }
    
    if (model.type !== 'Native') {
      throw new ModelRegistryError(
        `Cannot create a native model version for model with type ${model.type}`
      );
    }
    
    // Create basic version
    const newVersion = await this.createModelVersion({
      model_id: modelId,
      version,
      description,
      created_by: userId,
      framework,
      algorithm,
      input_schema: inputSchema,
      output_schema: outputSchema,
      metrics,
      dependencies
    });
    
    return newVersion;
  }
  
  async createAzureServiceVersion(
    modelId: number,
    version: string,
    description: string,
    userId: number,
    serviceType: string,
    config: Record<string, any>,
    credentialReference?: string,
    region?: string,
    endpoint?: string
  ): Promise<ModelVersion> {
    // Check if model exists and is Azure type
    const model = await this.storage.getModelById(modelId);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${modelId} not found`);
    }
    
    if (model.type !== 'Azure') {
      throw new ModelRegistryError(
        `Cannot create an Azure service version for model with type ${model.type}`
      );
    }
    
    // Create basic version
    const newVersion = await this.createModelVersion({
      model_id: modelId,
      version,
      description,
      created_by: userId
    });
    
    // Create external service configuration
    await this.storage.createExternalServiceConfig({
      version_id: newVersion.id,
      service_type: serviceType,
      config,
      credential_reference: credentialReference || null,
      region,
      endpoint
    });
    
    return newVersion;
  }
  
  async createAwsServiceVersion(
    modelId: number,
    version: string,
    description: string,
    userId: number,
    serviceType: string,
    config: Record<string, any>,
    credentialReference?: string,
    region?: string,
    endpoint?: string
  ): Promise<ModelVersion> {
    // Check if model exists and is AWS type
    const model = await this.storage.getModelById(modelId);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${modelId} not found`);
    }
    
    if (model.type !== 'AWS') {
      throw new ModelRegistryError(
        `Cannot create an AWS service version for model with type ${model.type}`
      );
    }
    
    // Create basic version
    const newVersion = await this.createModelVersion({
      model_id: modelId,
      version,
      description,
      created_by: userId
    });
    
    // Create external service configuration
    await this.storage.createExternalServiceConfig({
      version_id: newVersion.id,
      service_type: serviceType,
      config,
      credential_reference: credentialReference || null,
      region,
      endpoint
    });
    
    return newVersion;
  }
  
  async createMlflowModelVersion(
    modelId: number,
    version: string,
    description: string,
    userId: number,
    mlflowModelName: string,
    mlflowModelVersion: string,
    mlflowTrackingUri: string,
    config: Record<string, any>
  ): Promise<ModelVersion> {
    // Check if model exists and is MLflow type
    const model = await this.storage.getModelById(modelId);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${modelId} not found`);
    }
    
    if (model.type !== 'MLflow') {
      throw new ModelRegistryError(
        `Cannot create an MLflow model version for model with type ${model.type}`
      );
    }
    
    // Create basic version
    const newVersion = await this.createModelVersion({
      model_id: modelId,
      version,
      description,
      created_by: userId
    });
    
    // Create external service configuration with MLflow specific details
    await this.storage.createExternalServiceConfig({
      version_id: newVersion.id,
      service_type: 'MLflow',
      config: {
        ...config,
        mlflow_model_name: mlflowModelName,
        mlflow_model_version: mlflowModelVersion,
        mlflow_tracking_uri: mlflowTrackingUri
      },
      credential_reference: null
    });
    
    return newVersion;
  }
  
  // Artifacts
  async addModelArtifact(
    versionId: number,
    name: string,
    type: string,
    path: string,
    size: number,
    hash: string,
    metadata?: Record<string, any>
  ): Promise<ModelArtifact> {
    // Check if version exists
    const version = await this.storage.getModelVersionById(versionId);
    if (!version) {
      throw new ModelRegistryError(`Model version with ID ${versionId} not found`);
    }
    
    // Create the artifact
    const artifact = await this.storage.createModelArtifact({
      version_id: versionId,
      name,
      type,
      path,
      size,
      hash,
      created_at: new Date(),
      metadata
    });
    
    // Log the event
    await this.logModelEvent({
      model_id: version.model_id,
      version_id: versionId,
      user_id: version.created_by,
      event_type: 'ArtifactAdded',
      event_details: {
        artifact_name: name,
        artifact_type: type,
        artifact_size: size
      }
    });
    
    return artifact;
  }
  
  async getModelArtifacts(versionId: number): Promise<ModelArtifact[]> {
    // Check if version exists
    const version = await this.storage.getModelVersionById(versionId);
    if (!version) {
      throw new ModelRegistryError(`Model version with ID ${versionId} not found`);
    }
    
    return this.storage.getModelArtifacts(versionId);
  }
  
  // Version suggestions
  async suggestNextVersion(modelId: number, versionType: 'major' | 'minor' | 'patch'): Promise<string> {
    // Check if model exists
    const model = await this.storage.getModelById(modelId);
    if (!model) {
      throw new ModelRegistryError(`Model with ID ${modelId} not found`);
    }
    
    // Get all versions for the model
    const versions = await this.storage.getModelVersions(modelId);
    
    if (versions.length === 0) {
      // No versions yet, start with 1.0.0
      return '1.0.0';
    }
    
    // Find latest version by parsing semver
    let latestVersion = '0.0.0';
    for (const version of versions) {
      if (semver.valid(version.version) && semver.gt(version.version, latestVersion)) {
        latestVersion = version.version;
      }
    }
    
    // Increment based on version type
    if (versionType === 'major') {
      return semver.inc(latestVersion, 'major') || '1.0.0';
    } else if (versionType === 'minor') {
      return semver.inc(latestVersion, 'minor') || '0.1.0';
    } else {
      return semver.inc(latestVersion, 'patch') || '0.0.1';
    }
  }
  
  // Stage transitions
  async requestStageTransition(
    versionId: number,
    toStage: ModelStage,
    requesterId: number,
    comments?: string
  ): Promise<StageTransition> {
    // Check if version exists
    const version = await this.storage.getModelVersionById(versionId);
    if (!version) {
      throw new ModelRegistryError(`Model version with ID ${versionId} not found`);
    }
    
    // Check access permission
    const hasAccess = await this.hasModelAccess(requesterId, version.model_id, 'ModelContributor');
    if (!hasAccess) {
      throw new ModelRegistryError('Access denied: User does not have permission to request stage transitions');
    }
    
    // Validate stage transition
    if (version.stage === toStage) {
      throw new ModelRegistryError(`Version is already in the "${toStage}" stage`);
    }
    
    // Check if there's already a pending transition for this version
    const existingTransitions = await this.storage.getStageTransitions(versionId);
    const pendingTransition = existingTransitions.find(t => t.status === 'Pending');
    if (pendingTransition) {
      throw new ModelRegistryError(
        `There is already a pending transition request for this version from "${pendingTransition.from_stage}" to "${pendingTransition.to_stage}"`
      );
    }
    
    // Check if moving to Production
    if (toStage === 'Production') {
      // Check if there's already a Production version for this model
      const model = await this.storage.getModelById(version.model_id);
      const productionVersion = await this.storage.getProductionModelVersion(version.model_id);
      
      if (productionVersion && productionVersion.id !== versionId) {
        // Add a warning to comments that this will replace an existing production version
        const warningComment = `Note: This will replace version ${productionVersion.version} which is currently in Production.`;
        if (comments) {
          comments = `${comments}\n\n${warningComment}`;
        } else {
          comments = warningComment;
        }
      }
    }
    
    // Create transition request
    const transition = await this.storage.createStageTransition({
      version_id: versionId,
      from_stage: version.stage,
      to_stage: toStage,
      requester_id: requesterId,
      status: toStage === 'Production' ? 'Pending' : 'Approved', // Only Production needs approval
      approver_id: toStage === 'Production' ? null : requesterId, // Self-approve non-Production transitions
      comments: comments || null
    });
    
    // If not moving to Production, automatically apply the transition
    if (toStage !== 'Production') {
      await this.storage.updateModelVersion(versionId, { stage: toStage });
      
      // Log the event
      await this.logModelEvent({
        model_id: version.model_id,
        version_id: versionId,
        user_id: requesterId,
        event_type: 'StageChanged',
        event_details: {
          from_stage: version.stage,
          to_stage: toStage,
          auto_approved: true
        }
      });
    } else {
      // Log the event for requesting Production promotion
      await this.logModelEvent({
        model_id: version.model_id,
        version_id: versionId,
        user_id: requesterId,
        event_type: 'ProductionPromotionRequested',
        event_details: {
          from_stage: version.stage,
          requested_by: requesterId
        }
      });
    }
    
    return transition;
  }
  
  async approveStageTransition(
    transitionId: number,
    approverId: number,
    approved: boolean,
    comments?: string
  ): Promise<StageTransition> {
    // Get the transition
    const transition = await this.storage.getStageTransitionById(transitionId);
    if (!transition) {
      throw new ModelRegistryError(`Stage transition with ID ${transitionId} not found`);
    }
    
    // Check if it's already been processed
    if (transition.status !== 'Pending') {
      throw new ModelRegistryError(`This transition has already been ${transition.status.toLowerCase()}`);
    }
    
    // Check if the user has approval permissions
    const version = await this.storage.getModelVersionById(transition.version_id);
    if (!version) {
      throw new ModelRegistryError(`Model version with ID ${transition.version_id} not found`);
    }
    
    const hasAccess = await this.hasModelAccess(approverId, version.model_id, 'ModelApprover');
    if (!hasAccess) {
      throw new ModelRegistryError('Access denied: User does not have permission to approve stage transitions');
    }
    
    // Update the transition
    const status = approved ? 'Approved' : 'Rejected';
    const updatedTransition = await this.storage.updateStageTransition(transitionId, {
      status,
      approver_id: approverId,
      approved_at: new Date(),
      comments: comments || transition.comments
    });
    
    if (!updatedTransition) {
      throw new ModelRegistryError(`Failed to update transition with ID ${transitionId}`);
    }
    
    // If approved, update the version's stage
    if (approved) {
      await this.storage.updateModelVersion(version.id, { stage: transition.to_stage });
      
      // If moving to Production, check if there's another version already in Production
      if (transition.to_stage === 'Production') {
        const productionVersions = await this.storage.getModelsByStage('Production');
        const existingProduction = productionVersions.find(
          item => item.model.id === version.model_id && item.version.id !== version.id
        );
        
        if (existingProduction) {
          // Move the existing Production version to Archived
          await this.storage.updateModelVersion(existingProduction.version.id, { stage: 'Archived' });
          
          // Log the archiving
          await this.logModelEvent({
            model_id: existingProduction.model.id,
            version_id: existingProduction.version.id,
            user_id: approverId,
            event_type: 'ArchivedFromProduction',
            event_details: {
              replaced_by_version: version.version,
              archived_by: approverId
            }
          });
        }
      }
    }
    
    // Log the event
    await this.logModelEvent({
      model_id: version.model_id,
      version_id: version.id,
      user_id: approverId,
      event_type: approved ? 'StageTransitionApproved' : 'StageTransitionRejected',
      event_details: {
        from_stage: transition.from_stage,
        to_stage: transition.to_stage,
        requester_id: transition.requester_id,
        approver_id: approverId,
        comments: comments
      }
    });
    
    return updatedTransition;
  }
  
  async getPendingApprovals(): Promise<StageTransition[]> {
    return this.storage.getPendingStageTransitions();
  }
  
  async getStageTransitionHistory(versionId: number): Promise<StageTransition[]> {
    // Check if version exists
    const version = await this.storage.getModelVersionById(versionId);
    if (!version) {
      throw new ModelRegistryError(`Model version with ID ${versionId} not found`);
    }
    
    return this.storage.getStageTransitions(versionId);
  }
  
  // Access control
  async hasModelAccess(userId: number, modelId: number, requiredRole: RegistryRole): Promise<boolean> {
    // If the user doesn't exist, they don't have access
    try {
      await storage.getUser(userId);
    } catch (error) {
      return false;
    }
    
    // Check if the user has a global registry admin role
    const userRoles = await this.storage.getUserRoles(userId);
    
    // Registry admins have access to everything
    if (userRoles.some(role => role.role === 'RegistryAdmin' && role.model_id === null)) {
      return true;
    }
    
    // Check specific roles
    switch (requiredRole) {
      case 'RegistryAdmin':
        // Only global or model-specific registry admins have this permission
        return userRoles.some(
          role => role.role === 'RegistryAdmin' && 
                 (role.model_id === null || role.model_id === modelId)
        );
        
      case 'ModelApprover':
        // Registry admins and model approvers have this permission
        return userRoles.some(
          role => (role.role === 'RegistryAdmin' || role.role === 'ModelApprover') && 
                 (role.model_id === null || role.model_id === modelId)
        );
        
      case 'ModelContributor':
        // Registry admins, model approvers, and model contributors have this permission
        return userRoles.some(
          role => (role.role === 'RegistryAdmin' || 
                   role.role === 'ModelApprover' || 
                   role.role === 'ModelContributor') && 
                 (role.model_id === null || role.model_id === modelId)
        );
        
      case 'ModelViewer':
        // All roles have view permission
        return userRoles.some(
          role => (role.model_id === null || role.model_id === modelId)
        );
        
      default:
        return false;
    }
  }
  
  async assignUserRole(
    userId: number,
    role: RegistryRole,
    assignedById: number,
    modelId?: number
  ): Promise<RegistryUserRole> {
    // Validate role
    if (!REGISTRY_ROLES.includes(role)) {
      throw new ModelRegistryError(`Invalid role: ${role}`);
    }
    
    // Check if the assigner has permission
    const hasPermission = await this.hasModelAccess(
      assignedById,
      modelId || 0, // Use 0 as a placeholder for global roles
      'RegistryAdmin'
    );
    
    if (!hasPermission) {
      throw new ModelRegistryError('Access denied: User does not have permission to assign roles');
    }
    
    // If modelId is provided, check if the model exists
    if (modelId !== undefined) {
      const model = await this.storage.getModelById(modelId);
      if (!model) {
        throw new ModelRegistryError(`Model with ID ${modelId} not found`);
      }
    }
    
    // Check if the user exists
    try {
      await storage.getUser(userId);
    } catch (error) {
      throw new ModelRegistryError(`User with ID ${userId} not found`);
    }
    
    // Check if the role assignment already exists
    const userRoles = await this.storage.getUserRoles(userId);
    const existingRole = userRoles.find(
      r => r.role === role && r.model_id === (modelId || null)
    );
    
    if (existingRole) {
      throw new ModelRegistryError(
        `User already has the ${role} role${modelId ? ` for model ID ${modelId}` : ' globally'}`
      );
    }
    
    // Create the role assignment
    const userRole = await this.storage.createUserRole({
      user_id: userId,
      role,
      model_id: modelId || null,
      assigned_by: assignedById
    });
    
    // Log the event
    await this.logModelEvent({
      model_id: modelId || null,
      user_id: assignedById,
      event_type: 'UserRoleAssigned',
      event_details: {
        assigned_user_id: userId,
        role,
        model_id: modelId || null
      }
    });
    
    return userRole;
  }
  
  async removeUserRole(roleId: number, requestedById: number): Promise<boolean> {
    // Get the role
    const role = await this.storage.getUserRoleById(roleId);
    if (!role) {
      throw new ModelRegistryError(`User role with ID ${roleId} not found`);
    }
    
    // Check if the requester has permission
    const hasPermission = await this.hasModelAccess(
      requestedById,
      role.model_id || 0, // Use 0 as a placeholder for global roles
      'RegistryAdmin'
    );
    
    if (!hasPermission) {
      throw new ModelRegistryError('Access denied: User does not have permission to remove roles');
    }
    
    // Delete the role
    const deleted = await this.storage.deleteUserRole(roleId);
    
    // Log the event
    if (deleted) {
      await this.logModelEvent({
        model_id: role.model_id,
        user_id: requestedById,
        event_type: 'UserRoleRemoved',
        event_details: {
          user_id: role.user_id,
          role: role.role,
          model_id: role.model_id
        }
      });
    }
    
    return deleted;
  }
  
  async getUserRoles(userId: number): Promise<RegistryUserRole[]> {
    // Check if the user exists
    try {
      await storage.getUser(userId);
    } catch (error) {
      throw new ModelRegistryError(`User with ID ${userId} not found`);
    }
    
    return this.storage.getUserRoles(userId);
  }
  
  // Audit logging
  private async logModelEvent(event: InsertModelEvent): Promise<ModelEvent> {
    return this.storage.createModelEvent({
      ...event,
      timestamp: new Date()
    });
  }
  
  async getModelEvents(modelId?: number, versionId?: number): Promise<ModelEvent[]> {
    return this.storage.getModelEvents(modelId, versionId);
  }
  
  // Search
  async searchModels(query: string, filters?: Record<string, any>): Promise<Model[]> {
    return this.storage.searchModels(query, filters);
  }
  
  // Dashboard data
  async getDashboardStats(): Promise<{
    totalModels: number;
    modelsByType: Record<string, number>;
    modelsByStage: Record<string, number>;
    recentModels: Model[];
  }> {
    const totalModels = await this.storage.getModelCount();
    const recentModels = await this.storage.getRecentlyUpdatedModels(5);
    
    // Count models by type
    const modelsByType: Record<string, number> = {};
    for (const type of MODEL_TYPES) {
      const models = await this.storage.getModelsByType(type);
      modelsByType[type] = models.length;
    }
    
    // Count models by stage
    const modelsByStage: Record<string, number> = {};
    for (const stage of MODEL_STAGES) {
      const models = await this.storage.getModelsByStage(stage);
      modelsByStage[stage] = models.length;
    }
    
    return {
      totalModels,
      modelsByType,
      modelsByStage,
      recentModels
    };
  }
}

// Create and export an instance of the service
export const modelRegistryService = new ModelRegistryService(modelRegistryStorage);