/**
 * Model Registry Routes
 * This file defines the API routes for the Model Registry module.
 */

import { Express, Request, Response } from 'express';
import { modelRegistryService, ModelRegistryError } from './service';
import { z } from 'zod';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { MODEL_TYPES, MODEL_STAGES, REGISTRY_ROLES } from './schema';

// Configure storage for model artifacts
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/model-artifacts';
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Generate a unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + extension);
  }
});

const upload = multer({ 
  storage,
  limits: {
    fileSize: 100 * 1024 * 1024, // Limit to 100MB
  }
});

// Validation schemas
const createModelSchema = z.object({
  name: z.string().min(1, "Model name is required"),
  description: z.string().min(1, "Description is required"),
  type: z.enum(MODEL_TYPES as [string, ...string[]]),
  team_id: z.number().optional().nullable(),
  tags: z.array(z.string()).optional()
});

const updateModelSchema = z.object({
  name: z.string().optional(),
  description: z.string().optional(),
  team_id: z.number().optional().nullable(),
  tags: z.array(z.string()).optional()
});

const createNativeVersionSchema = z.object({
  version: z.string().min(1, "Version is required"),
  description: z.string().min(1, "Description is required"),
  framework: z.string().optional(),
  algorithm: z.string().optional(),
  input_schema: z.string().optional(),
  output_schema: z.string().optional(),
  metrics: z.record(z.string(), z.any()).optional(),
  dependencies: z.record(z.string(), z.string()).optional()
});

const createExternalVersionSchema = z.object({
  version: z.string().min(1, "Version is required"),
  description: z.string().min(1, "Description is required"),
  service_type: z.string().min(1, "Service type is required"),
  config: z.record(z.string(), z.any()),
  credential_reference: z.string().optional(),
  region: z.string().optional(),
  endpoint: z.string().optional()
});

const createMlflowVersionSchema = z.object({
  version: z.string().min(1, "Version is required"),
  description: z.string().min(1, "Description is required"),
  mlflow_model_name: z.string().min(1, "MLflow model name is required"),
  mlflow_model_version: z.string().min(1, "MLflow model version is required"),
  mlflow_tracking_uri: z.string().min(1, "MLflow tracking URI is required"),
  config: z.record(z.string(), z.any()).optional()
});

const updateVersionMetadataSchema = z.object({
  description: z.string().optional(),
  framework: z.string().optional(),
  algorithm: z.string().optional(),
  input_schema: z.string().optional(),
  output_schema: z.string().optional(),
  metrics: z.record(z.string(), z.any()).optional(),
  dependencies: z.record(z.string(), z.string()).optional()
});

const stageTransitionSchema = z.object({
  to_stage: z.enum(MODEL_STAGES as [string, ...string[]]),
  comments: z.string().optional()
});

const approveTransitionSchema = z.object({
  approved: z.boolean(),
  comments: z.string().optional()
});

const assignRoleSchema = z.object({
  user_id: z.number(),
  role: z.enum(REGISTRY_ROLES as [string, ...string[]]),
  model_id: z.number().optional()
});

const searchSchema = z.object({
  query: z.string(),
  type: z.enum(MODEL_TYPES as [string, ...string[]]).optional(),
  stage: z.enum(MODEL_STAGES as [string, ...string[]]).optional(),
  created_by: z.number().optional(),
  team_id: z.number().optional()
});

// Define routes
export function registerModelRegistryRoutes(app: Express, isAuthenticated: any) {
  const apiPrefix = '/api/model-registry';
  
  // Middleware to get the current user ID from the request
  const getCurrentUserId = (req: Request): number => {
    if (!req.user) {
      throw new ModelRegistryError('User not authenticated');
    }
    return (req.user as any).id;
  };
  
  // Error handler
  const handleError = (res: Response, error: any) => {
    console.error('Model Registry Error:', error);
    
    if (error instanceof ModelRegistryError) {
      res.status(400).json({ error: error.message });
    } else {
      res.status(500).json({ error: 'Internal server error' });
    }
  };
  
  // Calculate file hash for integrity verification
  const calculateFileHash = (filePath: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      const hash = crypto.createHash('sha256');
      const stream = fs.createReadStream(filePath);
      
      stream.on('data', data => hash.update(data));
      stream.on('end', () => resolve(hash.digest('hex')));
      stream.on('error', error => reject(error));
    });
  };
  
  // Models API
  
  // Get all models
  app.get(`${apiPrefix}/models`, isAuthenticated, async (req, res) => {
    try {
      const models = await modelRegistryService.getModels();
      res.json(models);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get a model by ID
  app.get(`${apiPrefix}/models/:id`, isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const model = await modelRegistryService.getModelById(id);
      res.json(model);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create a model
  app.post(`${apiPrefix}/models`, isAuthenticated, async (req, res) => {
    try {
      const userId = getCurrentUserId(req);
      const validatedData = createModelSchema.parse(req.body);
      
      const model = await modelRegistryService.createModel({
        ...validatedData,
        created_by: userId
      });
      
      res.status(201).json(model);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Update a model
  app.patch(`${apiPrefix}/models/:id`, isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = updateModelSchema.parse(req.body);
      
      const model = await modelRegistryService.updateModel(id, validatedData, userId);
      res.json(model);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Delete a model
  app.delete(`${apiPrefix}/models/:id`, isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      
      const deleted = await modelRegistryService.deleteModel(id, userId);
      res.status(deleted ? 200 : 404).json({ success: deleted });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Model Versions API
  
  // Get versions for a model
  app.get(`${apiPrefix}/models/:id/versions`, isAuthenticated, async (req, res) => {
    try {
      const modelId = parseInt(req.params.id);
      const versions = await modelRegistryService.getModelVersions(modelId);
      res.json(versions);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get a specific version
  app.get(`${apiPrefix}/versions/:id`, isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const version = await modelRegistryService.getModelVersionById(id);
      res.json(version);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Create a native model version
  app.post(`${apiPrefix}/models/:id/versions/native`, isAuthenticated, async (req, res) => {
    try {
      const modelId = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = createNativeVersionSchema.parse(req.body);
      
      const version = await modelRegistryService.createNativeModelVersion(
        modelId,
        validatedData.version,
        validatedData.description,
        userId,
        validatedData.framework,
        validatedData.algorithm,
        validatedData.input_schema,
        validatedData.output_schema,
        validatedData.metrics,
        validatedData.dependencies
      );
      
      res.status(201).json(version);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Create an Azure service version
  app.post(`${apiPrefix}/models/:id/versions/azure`, isAuthenticated, async (req, res) => {
    try {
      const modelId = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = createExternalVersionSchema.parse(req.body);
      
      const version = await modelRegistryService.createAzureServiceVersion(
        modelId,
        validatedData.version,
        validatedData.description,
        userId,
        validatedData.service_type,
        validatedData.config,
        validatedData.credential_reference,
        validatedData.region,
        validatedData.endpoint
      );
      
      res.status(201).json(version);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Create an AWS service version
  app.post(`${apiPrefix}/models/:id/versions/aws`, isAuthenticated, async (req, res) => {
    try {
      const modelId = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = createExternalVersionSchema.parse(req.body);
      
      const version = await modelRegistryService.createAwsServiceVersion(
        modelId,
        validatedData.version,
        validatedData.description,
        userId,
        validatedData.service_type,
        validatedData.config,
        validatedData.credential_reference,
        validatedData.region,
        validatedData.endpoint
      );
      
      res.status(201).json(version);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Create an MLflow model version
  app.post(`${apiPrefix}/models/:id/versions/mlflow`, isAuthenticated, async (req, res) => {
    try {
      const modelId = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = createMlflowVersionSchema.parse(req.body);
      
      const version = await modelRegistryService.createMlflowModelVersion(
        modelId,
        validatedData.version,
        validatedData.description,
        userId,
        validatedData.mlflow_model_name,
        validatedData.mlflow_model_version,
        validatedData.mlflow_tracking_uri,
        validatedData.config || {}
      );
      
      res.status(201).json(version);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Update version metadata
  app.patch(`${apiPrefix}/versions/:id`, isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = updateVersionMetadataSchema.parse(req.body);
      
      const version = await modelRegistryService.updateModelVersionMetadata(id, validatedData, userId);
      res.json(version);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Suggest next version number
  app.get(`${apiPrefix}/models/:id/suggest-version`, isAuthenticated, async (req, res) => {
    try {
      const modelId = parseInt(req.params.id);
      const versionType = (req.query.type as string) || 'minor';
      
      if (!['major', 'minor', 'patch'].includes(versionType)) {
        return res.status(400).json({ error: 'Invalid version type. Must be one of: major, minor, patch' });
      }
      
      const nextVersion = await modelRegistryService.suggestNextVersion(modelId, versionType as 'major' | 'minor' | 'patch');
      res.json({ version: nextVersion });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Model Artifacts API
  
  // Get artifacts for a version
  app.get(`${apiPrefix}/versions/:id/artifacts`, isAuthenticated, async (req, res) => {
    try {
      const versionId = parseInt(req.params.id);
      const artifacts = await modelRegistryService.getModelArtifacts(versionId);
      res.json(artifacts);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Upload an artifact
  app.post(
    `${apiPrefix}/versions/:id/artifacts`,
    isAuthenticated,
    upload.single('artifact'),
    async (req, res) => {
      try {
        if (!req.file) {
          return res.status(400).json({ error: 'No file uploaded' });
        }
        
        const versionId = parseInt(req.params.id);
        const version = await modelRegistryService.getModelVersionById(versionId);
        
        const filePath = req.file.path;
        const fileHash = await calculateFileHash(filePath);
        const metadata = req.body.metadata ? JSON.parse(req.body.metadata) : undefined;
        
        const artifact = await modelRegistryService.addModelArtifact(
          versionId,
          req.file.originalname,
          req.body.type || 'Model',
          filePath,
          req.file.size,
          fileHash,
          metadata
        );
        
        res.status(201).json(artifact);
      } catch (error) {
        handleError(res, error);
      }
    }
  );
  
  // Stage Transitions API
  
  // Request a stage transition
  app.post(`${apiPrefix}/versions/:id/stage-transitions`, isAuthenticated, async (req, res) => {
    try {
      const versionId = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = stageTransitionSchema.parse(req.body);
      
      const transition = await modelRegistryService.requestStageTransition(
        versionId,
        validatedData.to_stage,
        userId,
        validatedData.comments
      );
      
      res.status(201).json(transition);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Get stage transition history for a version
  app.get(`${apiPrefix}/versions/:id/stage-transitions`, isAuthenticated, async (req, res) => {
    try {
      const versionId = parseInt(req.params.id);
      const transitions = await modelRegistryService.getStageTransitionHistory(versionId);
      res.json(transitions);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Get pending approvals
  app.get(`${apiPrefix}/pending-approvals`, isAuthenticated, async (req, res) => {
    try {
      const transitions = await modelRegistryService.getPendingApprovals();
      res.json(transitions);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Approve or reject a stage transition
  app.post(`${apiPrefix}/stage-transitions/:id/approve`, isAuthenticated, async (req, res) => {
    try {
      const transitionId = parseInt(req.params.id);
      const userId = getCurrentUserId(req);
      const validatedData = approveTransitionSchema.parse(req.body);
      
      const transition = await modelRegistryService.approveStageTransition(
        transitionId,
        userId,
        validatedData.approved,
        validatedData.comments
      );
      
      res.json(transition);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Access Control API
  
  // Assign a role to a user
  app.post(`${apiPrefix}/user-roles`, isAuthenticated, async (req, res) => {
    try {
      const assignerId = getCurrentUserId(req);
      const validatedData = assignRoleSchema.parse(req.body);
      
      const role = await modelRegistryService.assignUserRole(
        validatedData.user_id,
        validatedData.role,
        assignerId,
        validatedData.model_id
      );
      
      res.status(201).json(role);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Get user roles
  app.get(`${apiPrefix}/user-roles`, isAuthenticated, async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : getCurrentUserId(req);
      const roles = await modelRegistryService.getUserRoles(userId);
      res.json(roles);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Remove a user role
  app.delete(`${apiPrefix}/user-roles/:id`, isAuthenticated, async (req, res) => {
    try {
      const roleId = parseInt(req.params.id);
      const requesterId = getCurrentUserId(req);
      
      const deleted = await modelRegistryService.removeUserRole(roleId, requesterId);
      res.status(deleted ? 200 : 404).json({ success: deleted });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Audit Log API
  
  // Get events for a model or version
  app.get(`${apiPrefix}/events`, isAuthenticated, async (req, res) => {
    try {
      const modelId = req.query.modelId ? parseInt(req.query.modelId as string) : undefined;
      const versionId = req.query.versionId ? parseInt(req.query.versionId as string) : undefined;
      
      const events = await modelRegistryService.getModelEvents(modelId, versionId);
      res.json(events);
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Search API
  
  // Search for models
  app.post(`${apiPrefix}/search`, isAuthenticated, async (req, res) => {
    try {
      const validatedData = searchSchema.parse(req.body);
      
      const filters: Record<string, any> = {};
      if (validatedData.type) filters.type = validatedData.type;
      if (validatedData.stage) filters.stage = validatedData.stage;
      if (validatedData.created_by) filters.createdBy = validatedData.created_by;
      if (validatedData.team_id) filters.teamId = validatedData.team_id;
      
      const models = await modelRegistryService.searchModels(validatedData.query, filters);
      res.json(models);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        handleError(res, error);
      }
    }
  });
  
  // Dashboard API
  
  // Get dashboard statistics
  app.get(`${apiPrefix}/dashboard`, isAuthenticated, async (req, res) => {
    try {
      const stats = await modelRegistryService.getDashboardStats();
      res.json(stats);
    } catch (error) {
      handleError(res, error);
    }
  });

  // Import external service routes
  
  // Import Azure service
  app.post(`${apiPrefix}/import/azure`, isAuthenticated, async (req, res) => {
    try {
      const userId = getCurrentUserId(req);
      const { name, description, service_type, endpoint, region, credential_reference } = req.body;
      
      // Create a new model with type 'Azure'
      const model = await modelRegistryService.createModel({
        name,
        description,
        type: 'Azure',
        created_by: userId,
        team_id: null,
        tags: [],
        is_active: true
      });
      
      // Create an initial version with external service configuration
      const version = await modelRegistryService.createAzureServiceVersion(
        model.id,
        '1.0.0', // Default initial version
        description,
        userId,
        service_type,
        { endpoint },
        credential_reference,
        region,
        endpoint
      );
      
      res.status(201).json({ model, version });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Import AWS service
  app.post(`${apiPrefix}/import/aws`, isAuthenticated, async (req, res) => {
    try {
      const userId = getCurrentUserId(req);
      const { name, description, service_type, region, credential_reference } = req.body;
      
      // Create a new model with type 'AWS'
      const model = await modelRegistryService.createModel({
        name,
        description,
        type: 'AWS',
        created_by: userId,
        team_id: null,
        tags: [],
        is_active: true
      });
      
      // Create an initial version with external service configuration
      const version = await modelRegistryService.createAwsServiceVersion(
        model.id,
        '1.0.0', // Default initial version
        description,
        userId,
        service_type,
        { region },
        credential_reference,
        region
      );
      
      res.status(201).json({ model, version });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  // Import MLflow model
  app.post(`${apiPrefix}/import/mlflow`, isAuthenticated, async (req, res) => {
    try {
      const userId = getCurrentUserId(req);
      const { name, description, tracking_uri } = req.body;
      
      // Create a new model with type 'MLflow'
      const model = await modelRegistryService.createModel({
        name,
        description,
        type: 'MLflow',
        created_by: userId,
        team_id: null,
        tags: [],
        is_active: true
      });
      
      // Create an initial version with MLflow configuration
      const version = await modelRegistryService.createMlflowModelVersion(
        model.id,
        '1.0.0', // Default initial version
        description,
        userId,
        name, // Use the model name as the MLflow model name
        '1', // Default MLflow version
        tracking_uri,
        { tracking_uri }
      );
      
      res.status(201).json({ model, version });
    } catch (error) {
      handleError(res, error);
    }
  });
  
  console.log('Model Registry routes registered');
};