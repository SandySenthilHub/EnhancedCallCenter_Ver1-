/**
 * Model Registry Storage
 * This file provides CRUD operations for the Model Registry module.
 */

import * as db from "../db";
import { sql } from "drizzle-orm";

// SQL Server utility functions for Model Registry
async function executeQuery<T>(sqlQuery: string): Promise<T[]> {
  return await db.executeQuery<T>(sqlQuery);
}

async function executeParameterizedQuery<T>(sqlQuery: string, params: { [key: string]: any } = {}): Promise<T[]> {
  return await db.executeParameterizedQuery<T>(sqlQuery, params);
}

async function executeInsert<T>(tableName: string, data: { [key: string]: any }): Promise<T | null> {
  return await db.executeInsert<T>(tableName, data);
}

async function executeUpdate<T>(
  tableName: string, 
  data: { [key: string]: any },
  whereClause: string,
  whereParams: { [key: string]: any } = {}
): Promise<T | undefined> {
  return await db.executeUpdate<T>(tableName, data, whereClause, whereParams);
}

async function executeDelete(
  tableName: string, 
  whereClause: string,
  whereParams: { [key: string]: any } = {}
): Promise<number> {
  return await db.executeDelete(tableName, whereClause, whereParams);
}
import {
  Model, ModelVersion, ModelArtifact, ExternalServiceConfig, StageTransition, ModelEvent, RegistryUserRole,
  InsertModel, InsertModelVersion, InsertModelArtifact, InsertExternalServiceConfig, 
  InsertStageTransition, InsertModelEvent, InsertRegistryUserRole,
  MODEL_STAGES, REGISTRY_ROLES
} from './schema';

// Utilities
const parseJsonField = <T>(field: string | null): T | null => {
  if (!field) return null;
  try {
    return JSON.parse(field) as T;
  } catch (error) {
    console.error(`Error parsing JSON field:`, error);
    return null;
  }
};

// Storage interface for Model Registry
export interface IModelRegistryStorage {
  // Models
  getModels(): Promise<Model[]>;
  getModelById(id: number): Promise<Model | undefined>;
  getModelByName(name: string): Promise<Model | undefined>;
  createModel(model: InsertModel): Promise<Model>;
  updateModel(id: number, model: Partial<InsertModel>): Promise<Model | undefined>;
  deleteModel(id: number): Promise<boolean>; // Soft delete by setting is_active = false
  
  // Model Versions
  getModelVersions(modelId: number): Promise<ModelVersion[]>;
  getModelVersionById(id: number): Promise<ModelVersion | undefined>;
  getModelVersionByModelAndVersion(modelId: number, version: string): Promise<ModelVersion | undefined>;
  getProductionModelVersion(modelId: number): Promise<ModelVersion | undefined>;
  createModelVersion(version: InsertModelVersion): Promise<ModelVersion>;
  updateModelVersion(id: number, version: Partial<InsertModelVersion>): Promise<ModelVersion | undefined>;
  
  // Model Artifacts
  getModelArtifacts(versionId: number): Promise<ModelArtifact[]>;
  getModelArtifactById(id: number): Promise<ModelArtifact | undefined>;
  createModelArtifact(artifact: InsertModelArtifact): Promise<ModelArtifact>;
  deleteModelArtifact(id: number): Promise<boolean>;
  
  // External Service Configurations
  getExternalServiceConfigs(versionId: number): Promise<ExternalServiceConfig[]>;
  getExternalServiceConfigById(id: number): Promise<ExternalServiceConfig | undefined>;
  createExternalServiceConfig(config: InsertExternalServiceConfig): Promise<ExternalServiceConfig>;
  updateExternalServiceConfig(id: number, config: Partial<InsertExternalServiceConfig>): Promise<ExternalServiceConfig | undefined>;
  deleteExternalServiceConfig(id: number): Promise<boolean>;
  
  // Stage Transitions
  getStageTransitions(versionId: number): Promise<StageTransition[]>;
  getPendingStageTransitions(): Promise<StageTransition[]>;
  getStageTransitionById(id: number): Promise<StageTransition | undefined>;
  createStageTransition(transition: InsertStageTransition): Promise<StageTransition>;
  updateStageTransition(id: number, transition: Partial<InsertStageTransition>): Promise<StageTransition | undefined>;
  
  // Events (Audit Log)
  getModelEvents(modelId?: number, versionId?: number): Promise<ModelEvent[]>;
  createModelEvent(event: InsertModelEvent): Promise<ModelEvent>;
  
  // User Roles
  getUserRoles(userId: number): Promise<RegistryUserRole[]>;
  getModelUserRoles(modelId: number): Promise<RegistryUserRole[]>;
  getUserRoleById(id: number): Promise<RegistryUserRole | undefined>;
  createUserRole(role: InsertRegistryUserRole): Promise<RegistryUserRole>;
  deleteUserRole(id: number): Promise<boolean>;
  
  // Advanced queries
  searchModels(query: string, filters?: Record<string, any>): Promise<Model[]>;
  getModelCount(): Promise<number>;
  getRecentlyUpdatedModels(limit?: number): Promise<Model[]>;
  getModelsByType(type: string): Promise<Model[]>;
  getModelsByStage(stage: string): Promise<{ model: Model, version: ModelVersion }[]>;
}

// SQL Server implementation of Model Registry Storage
export class SqlServerModelRegistryStorage implements IModelRegistryStorage {
  // Models
  async getModels(): Promise<Model[]> {
    const models = await executeQuery<Model>(`
      SELECT * FROM model_registry_models 
      WHERE is_active = 1 
      ORDER BY updated_at DESC
    `);
    
    // Parse JSON fields
    return models.map(model => ({
      ...model,
      tags: parseJsonField<string[]>(model.tags as unknown as string)
    }));
  }
  
  async getModelById(id: number): Promise<Model | undefined> {
    const models = await executeParameterizedQuery<Model>(
      `SELECT * FROM model_registry_models WHERE id = @id AND is_active = 1`,
      { id }
    );
    
    if (models.length === 0) return undefined;
    
    // Parse JSON fields
    const model = models[0];
    return {
      ...model,
      tags: parseJsonField<string[]>(model.tags as unknown as string)
    };
  }
  
  async getModelByName(name: string): Promise<Model | undefined> {
    const models = await executeParameterizedQuery<Model>(
      `SELECT * FROM model_registry_models WHERE name = @name AND is_active = 1`,
      { name }
    );
    
    if (models.length === 0) return undefined;
    
    // Parse JSON fields
    const model = models[0];
    return {
      ...model,
      tags: parseJsonField<string[]>(model.tags as unknown as string)
    };
  }
  
  async createModel(model: InsertModel): Promise<Model> {
    // Convert arrays to JSON strings for storage
    const processedModel = {
      ...model,
      tags: model.tags ? JSON.stringify(model.tags) : null
    };
    
    const newModel = await executeInsert<Model>('model_registry_models', processedModel);
    if (!newModel) throw new Error('Failed to create model');
    
    // Parse JSON fields in the response
    return {
      ...newModel,
      tags: parseJsonField<string[]>(newModel.tags as unknown as string)
    };
  }
  
  async updateModel(id: number, model: Partial<InsertModel>): Promise<Model | undefined> {
    // Convert arrays to JSON strings for storage
    const processedModel: any = { ...model };
    if (model.tags) {
      processedModel.tags = JSON.stringify(model.tags);
    }
    
    // Always update the updated_at timestamp
    processedModel.updated_at = new Date();
    
    const updatedModel = await executeUpdate<Model>(
      'model_registry_models',
      processedModel,
      'id = @id',
      { id }
    );
    
    if (!updatedModel) return undefined;
    
    // Parse JSON fields in the response
    return {
      ...updatedModel,
      tags: parseJsonField<string[]>(updatedModel.tags as unknown as string)
    };
  }
  
  async deleteModel(id: number): Promise<boolean> {
    // Soft delete by setting is_active = false
    const result = await executeUpdate<Model>(
      'model_registry_models',
      { is_active: false, updated_at: new Date() },
      'id = @id',
      { id }
    );
    
    return !!result;
  }
  
  // Model Versions
  async getModelVersions(modelId: number): Promise<ModelVersion[]> {
    const versions = await executeParameterizedQuery<ModelVersion>(
      `SELECT * FROM model_registry_versions WHERE model_id = @modelId ORDER BY created_at DESC`,
      { modelId }
    );
    
    // Parse JSON fields
    return versions.map(version => ({
      ...version,
      metrics: parseJsonField<Record<string, any>>(version.metrics as unknown as string),
      dependencies: parseJsonField<Record<string, string>>(version.dependencies as unknown as string)
    }));
  }
  
  async getModelVersionById(id: number): Promise<ModelVersion | undefined> {
    const versions = await executeParameterizedQuery<ModelVersion>(
      `SELECT * FROM model_registry_versions WHERE id = @id`,
      { id }
    );
    
    if (versions.length === 0) return undefined;
    
    // Parse JSON fields
    const version = versions[0];
    return {
      ...version,
      metrics: parseJsonField<Record<string, any>>(version.metrics as unknown as string),
      dependencies: parseJsonField<Record<string, string>>(version.dependencies as unknown as string)
    };
  }
  
  async getModelVersionByModelAndVersion(modelId: number, version: string): Promise<ModelVersion | undefined> {
    const versions = await executeParameterizedQuery<ModelVersion>(
      `SELECT * FROM model_registry_versions WHERE model_id = @modelId AND version = @version`,
      { modelId, version }
    );
    
    if (versions.length === 0) return undefined;
    
    // Parse JSON fields
    const modelVersion = versions[0];
    return {
      ...modelVersion,
      metrics: parseJsonField<Record<string, any>>(modelVersion.metrics as unknown as string),
      dependencies: parseJsonField<Record<string, string>>(modelVersion.dependencies as unknown as string)
    };
  }
  
  async getProductionModelVersion(modelId: number): Promise<ModelVersion | undefined> {
    const versions = await executeParameterizedQuery<ModelVersion>(
      `SELECT * FROM model_registry_versions WHERE model_id = @modelId AND stage = 'Production'`,
      { modelId }
    );
    
    if (versions.length === 0) return undefined;
    
    // Parse JSON fields
    const version = versions[0];
    return {
      ...version,
      metrics: parseJsonField<Record<string, any>>(version.metrics as unknown as string),
      dependencies: parseJsonField<Record<string, string>>(version.dependencies as unknown as string)
    };
  }
  
  async createModelVersion(version: InsertModelVersion): Promise<ModelVersion> {
    // Convert objects to JSON strings for storage
    const processedVersion = {
      ...version,
      metrics: version.metrics ? JSON.stringify(version.metrics) : null,
      dependencies: version.dependencies ? JSON.stringify(version.dependencies) : null,
      input_schema: version.input_schema ? JSON.stringify(version.input_schema) : null,
      output_schema: version.output_schema ? JSON.stringify(version.output_schema) : null
    };
    
    const newVersion = await executeInsert<ModelVersion>('model_registry_versions', processedVersion);
    if (!newVersion) throw new Error('Failed to create model version');
    
    // Parse JSON fields in the response
    return {
      ...newVersion,
      metrics: parseJsonField<Record<string, any>>(newVersion.metrics as unknown as string),
      dependencies: parseJsonField<Record<string, string>>(newVersion.dependencies as unknown as string)
    };
  }
  
  async updateModelVersion(id: number, version: Partial<InsertModelVersion>): Promise<ModelVersion | undefined> {
    // Convert objects to JSON strings for storage
    const processedVersion: any = { ...version };
    
    if (version.metrics) {
      processedVersion.metrics = JSON.stringify(version.metrics);
    }
    
    if (version.dependencies) {
      processedVersion.dependencies = JSON.stringify(version.dependencies);
    }
    
    if (version.input_schema) {
      processedVersion.input_schema = JSON.stringify(version.input_schema);
    }
    
    if (version.output_schema) {
      processedVersion.output_schema = JSON.stringify(version.output_schema);
    }
    
    // Always update the updated_at timestamp
    processedVersion.updated_at = new Date();
    
    const updatedVersion = await executeUpdate<ModelVersion>(
      'model_registry_versions',
      processedVersion,
      'id = @id',
      { id }
    );
    
    if (!updatedVersion) return undefined;
    
    // Parse JSON fields in the response
    return {
      ...updatedVersion,
      metrics: parseJsonField<Record<string, any>>(updatedVersion.metrics as unknown as string),
      dependencies: parseJsonField<Record<string, string>>(updatedVersion.dependencies as unknown as string)
    };
  }
  
  // Model Artifacts
  async getModelArtifacts(versionId: number): Promise<ModelArtifact[]> {
    const artifacts = await executeParameterizedQuery<ModelArtifact>(
      `SELECT * FROM model_registry_artifacts WHERE version_id = @versionId`,
      { versionId }
    );
    
    // Parse JSON fields
    return artifacts.map(artifact => ({
      ...artifact,
      metadata: parseJsonField<Record<string, any>>(artifact.metadata as unknown as string)
    }));
  }
  
  async getModelArtifactById(id: number): Promise<ModelArtifact | undefined> {
    const artifacts = await executeParameterizedQuery<ModelArtifact>(
      `SELECT * FROM model_registry_artifacts WHERE id = @id`,
      { id }
    );
    
    if (artifacts.length === 0) return undefined;
    
    // Parse JSON fields
    const artifact = artifacts[0];
    return {
      ...artifact,
      metadata: parseJsonField<Record<string, any>>(artifact.metadata as unknown as string)
    };
  }
  
  async createModelArtifact(artifact: InsertModelArtifact): Promise<ModelArtifact> {
    // Convert objects to JSON strings for storage
    const processedArtifact = {
      ...artifact,
      metadata: artifact.metadata ? JSON.stringify(artifact.metadata) : null
    };
    
    const newArtifact = await executeInsert<ModelArtifact>('model_registry_artifacts', processedArtifact);
    if (!newArtifact) throw new Error('Failed to create model artifact');
    
    // Parse JSON fields in the response
    return {
      ...newArtifact,
      metadata: parseJsonField<Record<string, any>>(newArtifact.metadata as unknown as string)
    };
  }
  
  async deleteModelArtifact(id: number): Promise<boolean> {
    const result = await executeDelete('model_registry_artifacts', 'id = @id', { id });
    return result > 0;
  }
  
  // External Service Configurations
  async getExternalServiceConfigs(versionId: number): Promise<ExternalServiceConfig[]> {
    const configs = await executeParameterizedQuery<ExternalServiceConfig>(
      `SELECT * FROM model_registry_external_configs WHERE version_id = @versionId`,
      { versionId }
    );
    
    // Parse JSON fields
    return configs.map(config => ({
      ...config,
      config: parseJsonField<Record<string, any>>(config.config as unknown as string)
    }));
  }
  
  async getExternalServiceConfigById(id: number): Promise<ExternalServiceConfig | undefined> {
    const configs = await executeParameterizedQuery<ExternalServiceConfig>(
      `SELECT * FROM model_registry_external_configs WHERE id = @id`,
      { id }
    );
    
    if (configs.length === 0) return undefined;
    
    // Parse JSON fields
    const config = configs[0];
    return {
      ...config,
      config: parseJsonField<Record<string, any>>(config.config as unknown as string)
    };
  }
  
  async createExternalServiceConfig(config: InsertExternalServiceConfig): Promise<ExternalServiceConfig> {
    // Convert objects to JSON strings for storage
    const processedConfig = {
      ...config,
      config: JSON.stringify(config.config)
    };
    
    const newConfig = await executeInsert<ExternalServiceConfig>('model_registry_external_configs', processedConfig);
    if (!newConfig) throw new Error('Failed to create external service configuration');
    
    // Parse JSON fields in the response
    return {
      ...newConfig,
      config: parseJsonField<Record<string, any>>(newConfig.config as unknown as string)
    };
  }
  
  async updateExternalServiceConfig(id: number, config: Partial<InsertExternalServiceConfig>): Promise<ExternalServiceConfig | undefined> {
    // Convert objects to JSON strings for storage
    const processedConfig: any = { ...config };
    
    if (config.config) {
      processedConfig.config = JSON.stringify(config.config);
    }
    
    const updatedConfig = await executeUpdate<ExternalServiceConfig>(
      'model_registry_external_configs',
      processedConfig,
      'id = @id',
      { id }
    );
    
    if (!updatedConfig) return undefined;
    
    // Parse JSON fields in the response
    return {
      ...updatedConfig,
      config: parseJsonField<Record<string, any>>(updatedConfig.config as unknown as string)
    };
  }
  
  async deleteExternalServiceConfig(id: number): Promise<boolean> {
    const result = await executeDelete('model_registry_external_configs', 'id = @id', { id });
    return result > 0;
  }
  
  // Stage Transitions
  async getStageTransitions(versionId: number): Promise<StageTransition[]> {
    return await executeParameterizedQuery<StageTransition>(
      `SELECT * FROM model_registry_stage_transitions 
       WHERE version_id = @versionId 
       ORDER BY requested_at DESC`,
      { versionId }
    );
  }
  
  async getPendingStageTransitions(): Promise<StageTransition[]> {
    return await executeQuery<StageTransition>(
      `SELECT * FROM model_registry_stage_transitions 
       WHERE status = 'Pending' 
       ORDER BY requested_at`
    );
  }
  
  async getStageTransitionById(id: number): Promise<StageTransition | undefined> {
    const transitions = await executeParameterizedQuery<StageTransition>(
      `SELECT * FROM model_registry_stage_transitions WHERE id = @id`,
      { id }
    );
    
    return transitions.length > 0 ? transitions[0] : undefined;
  }
  
  async createStageTransition(transition: InsertStageTransition): Promise<StageTransition> {
    const newTransition = await executeInsert<StageTransition>('model_registry_stage_transitions', transition);
    if (!newTransition) throw new Error('Failed to create stage transition');
    return newTransition;
  }
  
  async updateStageTransition(id: number, transition: Partial<InsertStageTransition>): Promise<StageTransition | undefined> {
    return await executeUpdate<StageTransition>(
      'model_registry_stage_transitions',
      transition,
      'id = @id',
      { id }
    );
  }
  
  // Events (Audit Log)
  async getModelEvents(modelId?: number, versionId?: number): Promise<ModelEvent[]> {
    let query = 'SELECT * FROM model_registry_events';
    const params: Record<string, any> = {};
    
    // Add filters if provided
    if (modelId !== undefined && versionId !== undefined) {
      query += ' WHERE model_id = @modelId AND version_id = @versionId';
      params.modelId = modelId;
      params.versionId = versionId;
    } else if (modelId !== undefined) {
      query += ' WHERE model_id = @modelId';
      params.modelId = modelId;
    } else if (versionId !== undefined) {
      query += ' WHERE version_id = @versionId';
      params.versionId = versionId;
    }
    
    query += ' ORDER BY timestamp DESC';
    
    const events = await executeParameterizedQuery<ModelEvent>(query, params);
    
    // Parse JSON fields
    return events.map(event => ({
      ...event,
      event_details: parseJsonField<Record<string, any>>(event.event_details as unknown as string)
    }));
  }
  
  async createModelEvent(event: InsertModelEvent): Promise<ModelEvent> {
    // Convert objects to JSON strings for storage
    const processedEvent = {
      ...event,
      event_details: JSON.stringify(event.event_details)
    };
    
    const newEvent = await executeInsert<ModelEvent>('model_registry_events', processedEvent);
    if (!newEvent) throw new Error('Failed to create model event');
    
    // Parse JSON fields in the response
    return {
      ...newEvent,
      event_details: parseJsonField<Record<string, any>>(newEvent.event_details as unknown as string)
    };
  }
  
  // User Roles
  async getUserRoles(userId: number): Promise<RegistryUserRole[]> {
    return await executeParameterizedQuery<RegistryUserRole>(
      `SELECT * FROM model_registry_user_roles 
       WHERE user_id = @userId`,
      { userId }
    );
  }
  
  async getModelUserRoles(modelId: number): Promise<RegistryUserRole[]> {
    return await executeParameterizedQuery<RegistryUserRole>(
      `SELECT * FROM model_registry_user_roles 
       WHERE model_id = @modelId OR model_id IS NULL`,
      { modelId }
    );
  }
  
  async getUserRoleById(id: number): Promise<RegistryUserRole | undefined> {
    const roles = await executeParameterizedQuery<RegistryUserRole>(
      `SELECT * FROM model_registry_user_roles WHERE id = @id`,
      { id }
    );
    
    return roles.length > 0 ? roles[0] : undefined;
  }
  
  async createUserRole(role: InsertRegistryUserRole): Promise<RegistryUserRole> {
    const newRole = await executeInsert<RegistryUserRole>('model_registry_user_roles', role);
    if (!newRole) throw new Error('Failed to create user role');
    return newRole;
  }
  
  async deleteUserRole(id: number): Promise<boolean> {
    const result = await executeDelete('model_registry_user_roles', 'id = @id', { id });
    return result > 0;
  }
  
  // Advanced queries
  async searchModels(query: string, filters?: Record<string, any>): Promise<Model[]> {
    let sqlQuery = `
      SELECT * FROM model_registry_models
      WHERE is_active = 1 AND (
        name LIKE @search OR 
        description LIKE @search OR
        tags LIKE @search
      )
    `;
    
    const params: Record<string, any> = {
      search: `%${query}%`
    };
    
    // Add filters if provided
    if (filters) {
      if (filters.type) {
        sqlQuery += ' AND type = @type';
        params.type = filters.type;
      }
      
      if (filters.stage) {
        sqlQuery += `
          AND id IN (
            SELECT DISTINCT model_id 
            FROM model_registry_versions 
            WHERE stage = @stage
          )
        `;
        params.stage = filters.stage;
      }
      
      if (filters.createdBy) {
        sqlQuery += ' AND created_by = @createdBy';
        params.createdBy = filters.createdBy;
      }
      
      if (filters.teamId) {
        sqlQuery += ' AND team_id = @teamId';
        params.teamId = filters.teamId;
      }
    }
    
    sqlQuery += ' ORDER BY updated_at DESC';
    
    const models = await executeParameterizedQuery<Model>(sqlQuery, params);
    
    // Parse JSON fields
    return models.map(model => ({
      ...model,
      tags: parseJsonField<string[]>(model.tags as unknown as string)
    }));
  }
  
  async getModelCount(): Promise<number> {
    const result = await executeQuery<{ count: number }>(`
      SELECT COUNT(*) as count FROM model_registry_models WHERE is_active = 1
    `);
    
    return result[0]?.count || 0;
  }
  
  async getRecentlyUpdatedModels(limit: number = 10): Promise<Model[]> {
    const models = await executeParameterizedQuery<Model>(
      `SELECT TOP (@limit) * FROM model_registry_models 
       WHERE is_active = 1 
       ORDER BY updated_at DESC`,
      { limit }
    );
    
    // Parse JSON fields
    return models.map(model => ({
      ...model,
      tags: parseJsonField<string[]>(model.tags as unknown as string)
    }));
  }
  
  async getModelsByType(type: string): Promise<Model[]> {
    const models = await executeParameterizedQuery<Model>(
      `SELECT * FROM model_registry_models 
       WHERE type = @type AND is_active = 1 
       ORDER BY updated_at DESC`,
      { type }
    );
    
    // Parse JSON fields
    return models.map(model => ({
      ...model,
      tags: parseJsonField<string[]>(model.tags as unknown as string)
    }));
  }
  
  async getModelsByStage(stage: string): Promise<{ model: Model, version: ModelVersion }[]> {
    const result = await executeParameterizedQuery<any>(
      `SELECT m.*, v.* 
       FROM model_registry_models m
       JOIN model_registry_versions v ON m.id = v.model_id
       WHERE v.stage = @stage AND m.is_active = 1
       ORDER BY m.updated_at DESC`,
      { stage }
    );
    
    return result.map((row: any) => {
      // Split the row into model and version properties
      const model: Model = {
        id: row.id,
        name: row.name,
        description: row.description,
        type: row.type,
        created_by: row.created_by,
        team_id: row.team_id,
        created_at: row.created_at,
        updated_at: row.updated_at,
        is_active: row.is_active,
        tags: parseJsonField<string[]>(row.tags)
      };
      
      const version: ModelVersion = {
        id: row.id_1, // Assuming SQL Server returns id_1 for the second id column
        model_id: row.model_id,
        version: row.version,
        description: row.description_1, // Assuming SQL Server returns description_1 for the second description column
        stage: row.stage,
        created_by: row.created_by_1,
        created_at: row.created_at_1,
        updated_at: row.updated_at_1,
        metrics: parseJsonField<Record<string, any>>(row.metrics),
        framework: row.framework,
        algorithm: row.algorithm,
        input_schema: row.input_schema,
        output_schema: row.output_schema,
        training_dataset_id: row.training_dataset_id,
        dependencies: parseJsonField<Record<string, string>>(row.dependencies)
      };
      
      return { model, version };
    });
  }
}

// Create and export an instance of the storage
export const modelRegistryStorage = new SqlServerModelRegistryStorage();