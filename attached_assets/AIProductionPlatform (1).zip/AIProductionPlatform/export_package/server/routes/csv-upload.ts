import express from 'express';
import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';
import { storage } from '../storage';
import { insertAlgorithmDependencySchema } from '@shared/schema';
import { z } from 'zod';

const router = express.Router();

// Define the route for CSV upload - algorithm dependencies
router.post('/api/algorithm-dependencies/upload', express.text({ type: 'text/csv' }), async (req, res) => {
  try {
    // Parse the CSV content
    const records = parse(req.body, {
      columns: true,
      skip_empty_lines: true,
      trim: true
    });

    const results = {
      successful: 0,
      failed: 0,
      errors: [] as string[]
    };

    // Process each record
    for (const record of records) {
      try {
        // Validate the record
        const validatedData = insertAlgorithmDependencySchema.parse({
          name: record.name,
          version: record.version || null,
          packageManager: record.packageManager || 'pip', // Default to pip if not specified
          category: record.category || null,
          description: record.description || null
        });

        // Check if dependency already exists
        const existingDeps = await storage.getAlgorithmDependencies();
        const existingDep = existingDeps.find(dep => dep.name === validatedData.name);

        if (existingDep) {
          // Update existing dependency
          await storage.updateAlgorithmDependency(existingDep.id, validatedData);
        } else {
          // Create new dependency
          await storage.createAlgorithmDependency(validatedData);
        }
        
        results.successful++;
      } catch (error) {
        results.failed++;
        if (error instanceof z.ZodError) {
          results.errors.push(`Error in row for ${record.name || 'unknown'}: ${error.errors.map(e => e.message).join(', ')}`);
        } else {
          results.errors.push(`Error processing ${record.name || 'unknown'}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
    }

    res.json({
      message: `Processed ${records.length} dependencies`,
      results
    });
  } catch (error) {
    console.error('Error processing CSV upload:', error);
    res.status(500).json({ error: 'Failed to process CSV upload', message: error instanceof Error ? error.message : String(error) });
  }
});

export function registerCsvUploadRoutes(app: express.Express) {
  app.use(router);
}