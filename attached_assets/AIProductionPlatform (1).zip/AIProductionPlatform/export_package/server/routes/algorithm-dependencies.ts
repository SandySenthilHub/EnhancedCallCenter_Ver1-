import express from 'express';
import { z } from 'zod';
import { storage } from '../storage';
import { insertAlgorithmDependencySchema, insertAlgorithmDependencyMappingSchema } from '@shared/schema';
import { spawn } from 'child_process';
import multer from 'multer';
import { parse } from 'csv-parse';

// Set up multer for file uploads
const upload = multer({ storage: multer.memoryStorage() });

const router = express.Router();

// Helper function to install packages
async function installPackage(packageName: string, version: string | undefined, packageManager: string): Promise<boolean> {
  return new Promise((resolve, reject) => {
    let command: string;
    let args: string[] = [];
    
    // Build command based on package manager
    switch (packageManager) {
      case 'pip':
        command = 'pip';
        args = ['install'];
        if (version) {
          args.push(`${packageName}==${version}`);
        } else {
          args.push(packageName);
        }
        break;
      case 'npm':
        command = 'npm';
        args = ['install', version ? `${packageName}@${version}` : packageName];
        break;
      case 'conda':
        command = 'conda';
        args = ['install', '-y', version ? `${packageName}=${version}` : packageName];
        break;
      default:
        reject(new Error(`Unsupported package manager: ${packageManager}`));
        return;
    }
    
    // Execute the command
    const process = spawn(command, args);
    let output = '';
    let errorOutput = '';
    
    process.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    process.stderr.on('data', (data) => {
      errorOutput += data.toString();
    });
    
    process.on('close', (code) => {
      if (code === 0) {
        resolve(true);
      } else {
        reject(new Error(`Installation failed with code ${code}: ${errorOutput}`));
      }
    });
  });
}

// Get all algorithm dependencies
router.get('/algorithm-dependencies', async (req, res) => {
  try {
    const dependencies = await storage.getAlgorithmDependencies();
    res.json(dependencies);
  } catch (error) {
    console.error('Error fetching algorithm dependencies:', error);
    res.status(500).json({ error: 'Failed to fetch algorithm dependencies' });
  }
});

// Get a specific algorithm dependency by ID
router.get('/algorithm-dependencies/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const dependency = await storage.getAlgorithmDependency(id);
    
    if (!dependency) {
      return res.status(404).json({ error: 'Algorithm dependency not found' });
    }
    
    res.json(dependency);
  } catch (error) {
    console.error('Error fetching algorithm dependency:', error);
    res.status(500).json({ error: 'Failed to fetch algorithm dependency' });
  }
});

// Create a new algorithm dependency
router.post('/algorithm-dependencies', async (req, res) => {
  try {
    const validatedData = insertAlgorithmDependencySchema.parse(req.body);
    const dependency = await storage.createAlgorithmDependency(validatedData);
    res.status(201).json(dependency);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating algorithm dependency:', error);
    res.status(500).json({ error: 'Failed to create algorithm dependency' });
  }
});

// Update an algorithm dependency
router.put('/algorithm-dependencies/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const validatedData = insertAlgorithmDependencySchema.parse(req.body);
    
    const updatedDependency = await storage.updateAlgorithmDependency(id, validatedData);
    
    if (!updatedDependency) {
      return res.status(404).json({ error: 'Algorithm dependency not found' });
    }
    
    res.json(updatedDependency);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error updating algorithm dependency:', error);
    res.status(500).json({ error: 'Failed to update algorithm dependency' });
  }
});

// Delete an algorithm dependency
router.delete('/algorithm-dependencies/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await storage.deleteAlgorithmDependency(id);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting algorithm dependency:', error);
    res.status(500).json({ error: 'Failed to delete algorithm dependency' });
  }
});

// Get all mappings for a specific algorithm
router.get('/algorithm-mappings/:algorithmName', async (req, res) => {
  try {
    const { algorithmName } = req.params;
    const mappings = await storage.getAlgorithmDependencyMappingsByAlgorithm(algorithmName);
    res.json(mappings);
  } catch (error) {
    console.error('Error fetching algorithm dependency mappings:', error);
    res.status(500).json({ error: 'Failed to fetch algorithm dependency mappings' });
  }
});

// Create a new algorithm dependency mapping
router.post('/algorithm-mappings', async (req, res) => {
  try {
    const validatedData = insertAlgorithmDependencyMappingSchema.parse(req.body);
    const mapping = await storage.createAlgorithmDependencyMapping(validatedData);
    res.status(201).json(mapping);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error creating algorithm dependency mapping:', error);
    res.status(500).json({ error: 'Failed to create algorithm dependency mapping' });
  }
});

// Delete an algorithm dependency mapping
router.delete('/algorithm-mappings/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await storage.deleteAlgorithmDependencyMapping(id);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting algorithm dependency mapping:', error);
    res.status(500).json({ error: 'Failed to delete algorithm dependency mapping' });
  }
});

// Install dependencies for a specific algorithm
router.post('/algorithm-dependencies/install/:algorithmName', async (req, res) => {
  try {
    const { algorithmName } = req.params;
    
    // Get all dependencies for this algorithm
    const mappings = await storage.getAlgorithmDependencyMappingsByAlgorithm(algorithmName);
    
    if (!mappings || mappings.length === 0) {
      return res.status(404).json({ error: 'No dependencies found for this algorithm' });
    }
    
    // Fetch full dependency details for each mapping
    const dependencies = await Promise.all(
      mappings.map(mapping => storage.getAlgorithmDependency(mapping.dependencyId))
    );
    
    // Filter out any null values (dependencies that may have been deleted)
    const validDependencies = dependencies.filter(dep => dep !== null);
    
    if (validDependencies.length === 0) {
      return res.status(404).json({ error: 'No valid dependencies found for this algorithm' });
    }
    
    // Install each dependency
    const installResults = await Promise.all(
      validDependencies.map(async dep => {
        try {
          await installPackage(dep.name, dep.version, dep.packageManager);
          return { name: dep.name, success: true };
        } catch (error) {
          return { name: dep.name, success: false, error: error.message };
        }
      })
    );
    
    // Update model if specified
    if (req.body.modelId) {
      try {
        const modelId = parseInt(req.body.modelId);
        // Get the current model
        const model = await storage.getModel(modelId);
        if (!model) {
          console.error(`Model with ID ${modelId} not found`);
        } else {
          // Update the model with dependencies installed flag
          await storage.updateModel(modelId, { 
            dependenciesInstalled: true 
          });
          console.log(`Updated model ${modelId} with dependenciesInstalled=true`);
        }
      } catch (error) {
        console.error('Error updating model:', error);
      }
    }
    
    // Check if all installations were successful
    const allSuccessful = installResults.every(result => result.success);
    
    if (allSuccessful) {
      res.status(200).json({ 
        success: true, 
        message: 'All dependencies installed successfully',
        details: installResults
      });
    } else {
      res.status(207).json({
        success: false,
        message: 'Some dependencies failed to install',
        details: installResults
      });
    }
  } catch (error) {
    console.error('Error installing dependencies:', error);
    res.status(500).json({ error: 'Failed to install dependencies' });
  }
});

// Export a requirements.txt file for a specific algorithm
router.get('/algorithm-dependencies/export/:algorithmName', async (req, res) => {
  try {
    const { algorithmName } = req.params;
    
    // Get all dependencies for this algorithm
    const mappings = await storage.getAlgorithmDependencyMappingsByAlgorithm(algorithmName);
    
    if (!mappings || mappings.length === 0) {
      return res.status(404).json({ error: 'No dependencies found for this algorithm' });
    }
    
    // Fetch full dependency details for each mapping
    const dependencies = await Promise.all(
      mappings.map(mapping => storage.getAlgorithmDependency(mapping.dependencyId))
    );
    
    // Filter out any null values and generate requirements text
    const requirementsText = dependencies
      .filter(dep => dep !== null)
      .map(dep => {
        if (dep.version) {
          return `${dep.name}==${dep.version}`;
        }
        return dep.name;
      })
      .join('\n');
    
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Content-Disposition', `attachment; filename="${algorithmName}-requirements.txt"`);
    res.send(requirementsText);
  } catch (error) {
    console.error('Error exporting dependencies:', error);
    res.status(500).json({ error: 'Failed to export dependencies' });
  }
});

// Batch import dependencies from CSV
router.post('/api/algorithm-dependencies/batch-import', async (req, res) => {
  try {
    const { dependencies } = req.body;
    
    if (!dependencies || !Array.isArray(dependencies)) {
      return res.status(400).json({ 
        error: 'Invalid dependencies data. Expected an array of dependencies.' 
      });
    }
    
    console.log(`Processing batch import of ${dependencies.length} dependencies`);
    
    // Process each dependency
    const results = [];
    const errors = [];
    
    for (let i = 0; i < dependencies.length; i++) {
      const dep = dependencies[i];
      
      try {
        if (!dep || !dep.name) {
          errors.push({ name: 'unknown', error: 'Missing package name', index: i });
          continue;
        }
        
        // Create standardized dependency object
        const dependency = {
          name: dep.name,
          version: dep.version || '',
          packageManager: dep.packageManager || 'pip',
          category: dep.category || '',
          description: dep.description || `${dep.name} library for Python/ML applications`
        };
        
        console.log(`Processing dependency ${i+1}/${dependencies.length}: ${dependency.name}`);
        
        // Check if dependency already exists
        const existingDep = await storage.getDependencyByName(dependency.name);
        
        if (existingDep) {
          // Update the existing dependency
          const updated = await storage.updateDependency(existingDep.id, dependency);
          results.push(updated);
        } else {
          // Create a new dependency
          const created = await storage.createAlgorithmDependency(dependency);
          results.push(created);
        }
      } catch (error: any) {
        const errorName = dep?.name || `Dependency at index ${i}`;
        console.error(`Error processing dependency ${errorName}:`, error);
        errors.push({ name: errorName, error: error?.message || 'Unknown error', index: i });
      }
    }
    
    return res.status(201).json({ 
      message: 'Dependencies processed successfully', 
      count: results.length,
      errors: errors.length > 0 ? errors : undefined,
      dependencies: results.slice(0, 10) // Only send back the first 10 for performance
    });
  } catch (error: any) {
    console.error('Error importing dependencies:', error);
    return res.status(500).json({ error: `Failed to import dependencies: ${error?.message || 'Unknown error'}` });
  }
});

// Direct CSV file upload endpoint
router.post('/api/algorithm-dependencies/upload-csv', upload.single('csvFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No CSV file provided' });
    }
    
    console.log(`Received CSV file: ${req.file.originalname}, size: ${req.file.size} bytes`);
    
    // Parse CSV content
    const csvContent = req.file.buffer.toString('utf8');
    
    // Process CSV using csv-parse
    parse(csvContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true
    }, async (err, records) => {
      if (err) {
        console.error('CSV parsing error:', err);
        return res.status(400).json({ error: `Failed to parse CSV: ${err.message}` });
      }
      
      console.log(`Parsed ${records.length} records from CSV`);
      
      // Transform records into dependency objects
      const dependencies = records.map((record: Record<string, string>) => ({
        name: record.name || '',
        version: record.version || '',
        packageManager: record.packageManager || 'pip',
        category: record.category || '',
        description: record.description || `${record.name} - ${record.category || ''} library`
      })).filter((dep: {name: string}) => dep.name); // Filter out records without name
      
      // Process each dependency
      const results = [];
      const errors = [];
      
      for (let i = 0; i < dependencies.length; i++) {
        const dependency = dependencies[i];
        
        try {
          // Check if dependency already exists
          const existingDep = await storage.getDependencyByName(dependency.name);
          
          if (existingDep) {
            // Update the existing dependency
            const updated = await storage.updateDependency(existingDep.id, dependency);
            results.push(updated);
          } else {
            // Create a new dependency
            const created = await storage.createAlgorithmDependency(dependency);
            results.push(created);
          }
        } catch (err) {
          const error = err as Error;
          console.error(`Error processing dependency ${dependency.name}:`, error);
          errors.push({ name: dependency.name, error: error.message || 'Unknown error' });
        }
      }
      
      return res.status(201).json({
        message: 'CSV file processed successfully',
        count: results.length,
        errors: errors.length > 0 ? errors : undefined
      });
    });
  } catch (error) {
    console.error('Error processing CSV upload:', error);
    return res.status(500).json({ error: 'Failed to process CSV upload' });
  }
});

export default router;