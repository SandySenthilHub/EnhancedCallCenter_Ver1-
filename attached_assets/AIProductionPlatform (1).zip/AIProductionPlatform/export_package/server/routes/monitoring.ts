import type { Express } from "express";

export function registerMonitoringRoutes(app: Express, isAuthenticated: any) {
  // Test endpoints for generating monitoring events
  app.post('/api/test/model-event', isAuthenticated, (req, res) => {
    try {
      const { name, status, details } = req.body;
      
      // Validate required fields
      if (!name || !status) {
        return res.status(400).json({ message: 'Name and status are required' });
      }
      
      // Send status update through WebSocket
      global.sendStatusUpdate({
        entityType: 'model',
        id: Math.floor(Math.random() * 100), // Generate random ID for test
        name,
        status,
        details
      });
      
      res.status(200).json({ success: true, message: 'Model event generated' });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.post('/api/test/pipeline-event', isAuthenticated, (req, res) => {
    try {
      const { name, status, details } = req.body;
      
      // Validate required fields
      if (!name || !status) {
        return res.status(400).json({ message: 'Name and status are required' });
      }
      
      // Send status update through WebSocket
      global.sendStatusUpdate({
        entityType: 'pipeline',
        id: Math.floor(Math.random() * 100), // Generate random ID for test
        name,
        status,
        details
      });
      
      res.status(200).json({ success: true, message: 'Pipeline event generated' });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
  
  app.post('/api/test/alert', isAuthenticated, (req, res) => {
    try {
      const { severity, source, message, details } = req.body;
      
      // Validate required fields
      if (!severity || !source || !message) {
        return res.status(400).json({ message: 'Severity, source, and message are required' });
      }
      
      // Send alert through WebSocket
      global.sendMonitoringAlert({
        severity,
        source,
        message,
        details
      });
      
      res.status(200).json({ success: true, message: 'Alert generated' });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}