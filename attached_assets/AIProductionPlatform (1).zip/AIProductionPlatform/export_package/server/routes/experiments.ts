import { Express } from "express";
import { storage } from "../storage";
import { insertExperimentSchema } from "@shared/schema";
import { z } from "zod";

export function registerExperimentRoutes(app: Express, isAuthenticated: any) {
  // Get all experiments
  app.get("/api/experiments", isAuthenticated, async (req, res) => {
    try {
      const experiments = await storage.getExperiments();
      res.json(experiments);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get a single experiment by ID
  app.get("/api/experiments/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const experiment = await storage.getExperiment(id);
      if (!experiment) {
        return res.status(404).json({ message: "Experiment not found" });
      }

      res.json(experiment);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new experiment
  app.post("/api/experiments", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertExperimentSchema.parse(req.body);
      
      // Add user ID from authenticated user
      const experimentData = {
        ...validatedData,
        userId: req.user!.id
      };
      
      const newExperiment = await storage.createExperiment(experimentData);
      res.status(201).json(newExperiment);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: error.message });
    }
  });

  // Update an experiment
  app.patch("/api/experiments/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      // Get existing experiment to check ownership
      const existingExperiment = await storage.getExperiment(id);
      if (!existingExperiment) {
        return res.status(404).json({ message: "Experiment not found" });
      }

      // Optional: Check if user owns the experiment or is admin
      // if (existingExperiment.userId !== req.user!.id && req.user!.role !== 'admin') {
      //   return res.status(403).json({ message: "Not authorized to modify this experiment" });
      // }

      const updatedExperiment = await storage.updateExperiment(id, req.body);
      res.json(updatedExperiment);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: error.message });
    }
  });
}