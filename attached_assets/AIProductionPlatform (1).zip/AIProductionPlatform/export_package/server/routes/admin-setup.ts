import type { Express } from "express";
import { storage } from "../storage";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

// Hash password function (same as in auth.ts)
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export function registerAdminSetupRoutes(app: Express) {
  // Route to create or reset admin account
  app.post("/api/admin/setup", async (req, res) => {
    try {
      // Get admin user or create new one
      let admin = await storage.getUserByUsername("admin");
      const defaultAdminPassword = "password";

      if (!admin) {
        // Create new admin account
        admin = await storage.createUser({
          username: "admin",
          password: await hashPassword(defaultAdminPassword),
          email: "admin@aimlplaybook.com",
          role: "admin"
        });
        
        console.log("Admin account created successfully");
        return res.status(201).json({ 
          message: "Admin account created successfully", 
          username: "admin", 
          password: defaultAdminPassword 
        });
      } else {
        // Reset admin password
        const updatedAdmin = await storage.updateUserPassword(
          admin.id,
          await hashPassword(defaultAdminPassword)
        );
        
        console.log("Admin password reset successfully");
        return res.status(200).json({ 
          message: "Admin password reset successfully", 
          username: "admin", 
          password: defaultAdminPassword 
        });
      }
    } catch (error: any) {
      console.error("Error setting up admin account:", error);
      res.status(500).json({ message: error.message });
    }
  });
}