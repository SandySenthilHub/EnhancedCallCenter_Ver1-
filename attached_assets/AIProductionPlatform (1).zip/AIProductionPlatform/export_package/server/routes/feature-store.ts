import { Express } from 'express';
import { storage } from '../storage';

export function registerFeatureStoreRoutes(app: Express, isAuthenticated: any) {
  // Features API endpoints
  app.get('/api/features', isAuthenticated, async (req, res) => {
    try {
      const features = await storage.getFeatures();
      res.json(features);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get('/api/features/:id', isAuthenticated, async (req, res) => {
    try {
      const feature = await storage.getFeature(parseInt(req.params.id));
      if (!feature) {
        return res.status(404).json({ message: 'Feature not found' });
      }
      res.json(feature);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/features', isAuthenticated, async (req, res) => {
    try {
      const newFeature = await storage.createFeature({
        ...req.body,
        userId: (req.user as any).id
      });

      // Log activity
      await storage.createActivity({
        activity: `Feature "${newFeature.name}" created`,
        pipeline: null,
        status: 'success',
        userId: (req.user as any).id
      });

      res.status(201).json(newFeature);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch('/api/features/:id', isAuthenticated, async (req, res) => {
    try {
      const updatedFeature = await storage.updateFeature(
        parseInt(req.params.id),
        req.body
      );

      if (!updatedFeature) {
        return res.status(404).json({ message: 'Feature not found' });
      }

      res.json(updatedFeature);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Feature Sets API endpoints
  app.get('/api/feature-sets', isAuthenticated, async (req, res) => {
    try {
      const featureSets = await storage.getFeatureSets();
      res.json(featureSets);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get('/api/feature-sets/:id', isAuthenticated, async (req, res) => {
    try {
      const featureSet = await storage.getFeatureSet(parseInt(req.params.id));
      if (!featureSet) {
        return res.status(404).json({ message: 'Feature set not found' });
      }
      res.json(featureSet);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post('/api/feature-sets', isAuthenticated, async (req, res) => {
    try {
      const newFeatureSet = await storage.createFeatureSet({
        ...req.body,
        userId: (req.user as any).id
      });

      // Log activity
      await storage.createActivity({
        activity: `Feature set "${newFeatureSet.name}" created`,
        pipeline: null,
        status: 'success',
        userId: (req.user as any).id
      });

      res.status(201).json(newFeatureSet);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get features in a feature set
  app.get('/api/feature-sets/:id/features', isAuthenticated, async (req, res) => {
    try {
      const featureSetId = parseInt(req.params.id);
      const featureSet = await storage.getFeatureSet(featureSetId);
      
      if (!featureSet) {
        return res.status(404).json({ message: 'Feature set not found' });
      }
      
      const features = await storage.getFeaturesInSet(featureSetId);
      res.json(features);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Add a feature to a feature set
  app.post('/api/feature-sets/:setId/features/:featureId', isAuthenticated, async (req, res) => {
    try {
      const featureSetId = parseInt(req.params.setId);
      const featureId = parseInt(req.params.featureId);
      
      // Verify both feature set and feature exist
      const featureSet = await storage.getFeatureSet(featureSetId);
      const feature = await storage.getFeature(featureId);
      
      if (!featureSet) {
        return res.status(404).json({ message: 'Feature set not found' });
      }
      
      if (!feature) {
        return res.status(404).json({ message: 'Feature not found' });
      }
      
      const mapping = await storage.addFeatureToSet({
        featureSetId,
        featureId
      });
      
      res.status(201).json(mapping);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Remove a feature from a feature set
  app.delete('/api/feature-sets/:setId/features/:featureId', isAuthenticated, async (req, res) => {
    try {
      const featureSetId = parseInt(req.params.setId);
      const featureId = parseInt(req.params.featureId);
      
      await storage.removeFeatureFromSet(featureSetId, featureId);
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}