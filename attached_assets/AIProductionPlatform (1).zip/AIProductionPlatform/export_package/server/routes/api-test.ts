import express from 'express';
import { storage } from '../storage';

// Create a router for testing API endpoints without authentication
const router = express.Router();

// Get all algorithm dependencies (public version for testing)
router.get('/public/algorithm-dependencies', async (req, res) => {
  try {
    const dependencies = await storage.getAlgorithmDependencies();
    res.json(dependencies);
  } catch (error) {
    console.error('Error fetching algorithm dependencies:', error);
    res.status(500).json({ error: 'Failed to fetch algorithm dependencies' });
  }
});

export default router;