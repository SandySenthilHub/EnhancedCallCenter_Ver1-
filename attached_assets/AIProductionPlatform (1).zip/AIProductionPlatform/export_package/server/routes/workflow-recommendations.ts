import { Router } from "express";
import { storage } from "../storage";
import {
  insertWorkflowRecommendationSchema,
  insertRecommendationTemplateSchema,
  insertUserWorkflowPreferenceSchema
} from "@shared/schema";
import { isAuthenticated } from "../middleware/auth";
import { zodParse } from "../middleware/validation";

const router = Router();

// Middleware to ensure user is authenticated
router.use(isAuthenticated);

// Get all workflow recommendations
router.get("/workflow-recommendations", async (req, res) => {
  try {
    const recommendations = await storage.getWorkflowRecommendations();
    res.json(recommendations);
  } catch (error) {
    console.error("Error fetching workflow recommendations:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get a specific workflow recommendation
router.get("/workflow-recommendations/:id", async (req, res) => {
  try {
    const recommendation = await storage.getWorkflowRecommendation(parseInt(req.params.id));
    if (!recommendation) {
      return res.status(404).json({ message: "Workflow recommendation not found" });
    }
    res.json(recommendation);
  } catch (error) {
    console.error("Error fetching workflow recommendation:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Create a new workflow recommendation
router.post(
  "/workflow-recommendations",
  zodParse(insertWorkflowRecommendationSchema),
  async (req, res) => {
    try {
      const newRecommendation = await storage.createWorkflowRecommendation({
        ...req.body,
        userId: req.user.id
      });
      res.status(201).json(newRecommendation);
    } catch (error) {
      console.error("Error creating workflow recommendation:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

// Update a workflow recommendation
router.patch(
  "/workflow-recommendations/:id",
  async (req, res) => {
    try {
      const recommendation = await storage.getWorkflowRecommendation(parseInt(req.params.id));
      if (!recommendation) {
        return res.status(404).json({ message: "Workflow recommendation not found" });
      }
      
      if (recommendation.userId !== req.user.id) {
        return res.status(403).json({ message: "You can only edit your own recommendations" });
      }
      
      const updatedRecommendation = await storage.updateWorkflowRecommendation(
        parseInt(req.params.id),
        req.body
      );
      res.json(updatedRecommendation);
    } catch (error) {
      console.error("Error updating workflow recommendation:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

// Delete a workflow recommendation
router.delete("/workflow-recommendations/:id", async (req, res) => {
  try {
    const recommendation = await storage.getWorkflowRecommendation(parseInt(req.params.id));
    if (!recommendation) {
      return res.status(404).json({ message: "Workflow recommendation not found" });
    }
    
    if (recommendation.userId !== req.user.id) {
      return res.status(403).json({ message: "You can only delete your own recommendations" });
    }
    
    await storage.deleteWorkflowRecommendation(parseInt(req.params.id));
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting workflow recommendation:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get all recommendation templates
router.get("/recommendation-templates", async (req, res) => {
  try {
    const templates = await storage.getRecommendationTemplates();
    res.json(templates);
  } catch (error) {
    console.error("Error fetching recommendation templates:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get recommendation templates by category
router.get("/recommendation-templates/category/:category", async (req, res) => {
  try {
    const templates = await storage.getRecommendationTemplatesByCategory(req.params.category);
    res.json(templates);
  } catch (error) {
    console.error("Error fetching recommendation templates by category:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get a specific recommendation template
router.get("/recommendation-templates/:id", async (req, res) => {
  try {
    const template = await storage.getRecommendationTemplate(parseInt(req.params.id));
    if (!template) {
      return res.status(404).json({ message: "Recommendation template not found" });
    }
    res.json(template);
  } catch (error) {
    console.error("Error fetching recommendation template:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Create a new recommendation template (admin only)
router.post(
  "/recommendation-templates",
  zodParse(insertRecommendationTemplateSchema),
  async (req, res) => {
    try {
      // Check if user is admin
      if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Only admins can create recommendation templates" });
      }
      
      const newTemplate = await storage.createRecommendationTemplate(req.body);
      res.status(201).json(newTemplate);
    } catch (error) {
      console.error("Error creating recommendation template:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

// Update a recommendation template (admin only)
router.patch(
  "/recommendation-templates/:id",
  async (req, res) => {
    try {
      // Check if user is admin
      if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Only admins can update recommendation templates" });
      }
      
      const template = await storage.getRecommendationTemplate(parseInt(req.params.id));
      if (!template) {
        return res.status(404).json({ message: "Recommendation template not found" });
      }
      
      const updatedTemplate = await storage.updateRecommendationTemplate(
        parseInt(req.params.id),
        req.body
      );
      res.json(updatedTemplate);
    } catch (error) {
      console.error("Error updating recommendation template:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

// Delete a recommendation template (admin only)
router.delete("/recommendation-templates/:id", async (req, res) => {
  try {
    // Check if user is admin
    if (req.user.role !== "admin") {
      return res.status(403).json({ message: "Only admins can delete recommendation templates" });
    }
    
    const template = await storage.getRecommendationTemplate(parseInt(req.params.id));
    if (!template) {
      return res.status(404).json({ message: "Recommendation template not found" });
    }
    
    await storage.deleteRecommendationTemplate(parseInt(req.params.id));
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting recommendation template:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get user workflow preferences
router.get("/user-workflow-preferences", async (req, res) => {
  try {
    const preferences = await storage.getUserWorkflowPreference(req.user.id);
    if (!preferences) {
      return res.status(404).json({ message: "User workflow preferences not found" });
    }
    res.json(preferences);
  } catch (error) {
    console.error("Error fetching user workflow preferences:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Create or update user workflow preferences
router.post(
  "/user-workflow-preferences",
  zodParse(insertUserWorkflowPreferenceSchema),
  async (req, res) => {
    try {
      const existingPreferences = await storage.getUserWorkflowPreference(req.user.id);
      
      if (existingPreferences) {
        // Update existing preferences
        const updatedPreferences = await storage.updateUserWorkflowPreference(
          req.user.id,
          { ...req.body, userId: req.user.id }
        );
        return res.json(updatedPreferences);
      } else {
        // Create new preferences
        const newPreferences = await storage.createUserWorkflowPreference({
          ...req.body,
          userId: req.user.id
        });
        return res.status(201).json(newPreferences);
      }
    } catch (error) {
      console.error("Error creating/updating user workflow preferences:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

export default router;