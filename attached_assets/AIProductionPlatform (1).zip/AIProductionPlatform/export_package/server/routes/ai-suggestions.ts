import { Express, Request, Response } from "express";
import OpenAI from "openai";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export function registerAISuggestionsRoutes(app: Express, isAuthenticated: any) {
  // API endpoint for generating feature name suggestions
  app.post("/api/ai/feature-name-suggestions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { 
        columnData, 
        datasetDescription, 
        currentName, 
        dataType, 
        statistics,
        domain
      } = req.body;

      if (!columnData && !statistics) {
        return res.status(400).json({ 
          message: "Either column data or statistics are required" 
        });
      }

      // Create a prompt for OpenAI
      const prompt = createFeatureNamePrompt(
        columnData,
        datasetDescription,
        currentName,
        dataType,
        statistics,
        domain
      );

      // Call OpenAI API for suggestions
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an AI assistant specialized in data science and machine learning feature engineering. Your task is to suggest descriptive, accurate, and standardized names for data features based on sample data or statistics provided."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 500,
      });

      // Parse the response
      const content = response.choices[0].message.content;
      const suggestions = content ? JSON.parse(content) : null;

      res.json(suggestions);
    } catch (error: any) {
      console.error("Error generating feature name suggestions:", error);
      res.status(500).json({ 
        message: "Failed to generate feature name suggestions", 
        error: error.message 
      });
    }
  });

  // API endpoint for batch generating feature name suggestions
  app.post("/api/ai/batch-feature-name-suggestions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { 
        features,
        datasetDescription,
        domain
      } = req.body;

      if (!features || !Array.isArray(features) || features.length === 0) {
        return res.status(400).json({ 
          message: "Valid features array is required" 
        });
      }

      // Create a prompt for OpenAI
      const prompt = createBatchFeatureNamePrompt(
        features,
        datasetDescription,
        domain
      );

      // Call OpenAI API for suggestions
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an AI assistant specialized in data science and machine learning feature engineering. Your task is to suggest descriptive, accurate, and standardized names for multiple data features based on their current names, data types, and descriptions or statistics."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 800,
      });

      // Parse the response
      const content = response.choices[0].message.content;
      const suggestions = content ? JSON.parse(content) : null;

      res.json(suggestions);
    } catch (error: any) {
      console.error("Error generating batch feature name suggestions:", error);
      res.status(500).json({ 
        message: "Failed to generate batch feature name suggestions", 
        error: error.message 
      });
    }
  });

  // API endpoint for generating feature description suggestions
  app.post("/api/ai/feature-description-suggestions", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { 
        featureName,
        dataType,
        sampleValues,
        statistics,
        domain,
        currentDescription
      } = req.body;

      if (!featureName) {
        return res.status(400).json({ 
          message: "Feature name is required" 
        });
      }

      // Create a prompt for OpenAI
      const prompt = createFeatureDescriptionPrompt(
        featureName,
        dataType,
        sampleValues,
        statistics,
        domain,
        currentDescription
      );

      // Call OpenAI API for suggestions
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an AI assistant specialized in data science documentation. Your task is to generate clear, concise, and accurate descriptions for data features based on their names, data types, and sample values or statistics."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 500,
      });

      // Parse the response
      const content = response.choices[0].message.content;
      const suggestions = content ? JSON.parse(content) : null;

      res.json(suggestions);
    } catch (error: any) {
      console.error("Error generating feature description suggestions:", error);
      res.status(500).json({ 
        message: "Failed to generate feature description suggestions", 
        error: error.message 
      });
    }
  });
}

// Helper function to create a prompt for feature name suggestion
function createFeatureNamePrompt(
  columnData: any[] | null,
  datasetDescription: string | null,
  currentName: string | null,
  dataType: string | null,
  statistics: any | null,
  domain: string | null
): string {
  let prompt = "Based on the following information, suggest 3-5 appropriate, descriptive names for this data feature.";
  
  if (currentName) {
    prompt += `\n\nCurrent feature name: "${currentName}"`;
  }
  
  if (dataType) {
    prompt += `\n\nData type: ${dataType}`;
  }
  
  if (datasetDescription) {
    prompt += `\n\nDataset description: ${datasetDescription}`;
  }
  
  if (domain) {
    prompt += `\n\nDomain: ${domain}`;
  }
  
  if (columnData && columnData.length > 0) {
    prompt += `\n\nSample data (first ${Math.min(10, columnData.length)} values): ${JSON.stringify(columnData.slice(0, 10))}`;
  }
  
  if (statistics) {
    prompt += `\n\nStatistics: ${JSON.stringify(statistics)}`;
  }
  
  prompt += "\n\nPlease respond with a JSON object in the following format:";
  prompt += `
{
  "suggestions": [
    {
      "name": "suggested_feature_name_1",
      "reason": "Explanation for why this name is appropriate",
      "confidence": 0.9
    },
    {
      "name": "suggested_feature_name_2",
      "reason": "Explanation for why this name is appropriate",
      "confidence": 0.8
    }
    // additional suggestions...
  ]
}
`;

  return prompt;
}

// Helper function to create a prompt for batch feature name suggestions
function createBatchFeatureNamePrompt(
  features: any[],
  datasetDescription: string | null,
  domain: string | null
): string {
  let prompt = "Based on the following information, suggest appropriate, descriptive names for multiple data features.";
  
  if (datasetDescription) {
    prompt += `\n\nDataset description: ${datasetDescription}`;
  }
  
  if (domain) {
    prompt += `\n\nDomain: ${domain}`;
  }
  
  prompt += "\n\nFeatures to rename:";
  
  features.forEach((feature, index) => {
    prompt += `\n\nFeature ${index + 1}:`;
    if (feature.name) {
      prompt += `\n- Current name: "${feature.name}"`;
    }
    if (feature.dataType) {
      prompt += `\n- Data type: ${feature.dataType}`;
    }
    if (feature.description) {
      prompt += `\n- Description: ${feature.description}`;
    }
    if (feature.statistics) {
      prompt += `\n- Statistics: ${JSON.stringify(feature.statistics)}`;
    }
    if (feature.sampleValues && feature.sampleValues.length > 0) {
      prompt += `\n- Sample values: ${JSON.stringify(feature.sampleValues.slice(0, 5))}`;
    }
  });
  
  prompt += "\n\nPlease respond with a JSON object in the following format:";
  prompt += `
{
  "suggestions": [
    {
      "originalName": "feature_1_original_name",
      "suggestedName": "feature_1_suggested_name",
      "reason": "Explanation for why this name is appropriate",
      "confidence": 0.9
    },
    {
      "originalName": "feature_2_original_name",
      "suggestedName": "feature_2_suggested_name",
      "reason": "Explanation for why this name is appropriate",
      "confidence": 0.8
    }
    // additional suggestions...
  ]
}
`;

  return prompt;
}

// Helper function to create a prompt for feature description generation
function createFeatureDescriptionPrompt(
  featureName: string,
  dataType: string | null,
  sampleValues: any[] | null,
  statistics: any | null,
  domain: string | null,
  currentDescription: string | null
): string {
  let prompt = `Generate a clear, concise description for the feature named "${featureName}".`;
  
  if (currentDescription) {
    prompt += `\n\nCurrent description: "${currentDescription}"`;
  }
  
  if (dataType) {
    prompt += `\n\nData type: ${dataType}`;
  }
  
  if (domain) {
    prompt += `\n\nDomain: ${domain}`;
  }
  
  if (sampleValues && sampleValues.length > 0) {
    prompt += `\n\nSample values: ${JSON.stringify(sampleValues.slice(0, 10))}`;
  }
  
  if (statistics) {
    prompt += `\n\nStatistics: ${JSON.stringify(statistics)}`;
  }
  
  prompt += "\n\nPlease respond with a JSON object in the following format:";
  prompt += `
{
  "description": "A clear and concise description of the feature",
  "shortDescription": "A brief one-line description",
  "possibleUses": ["Potential use case 1", "Potential use case 2"],
  "cautions": ["Potential issue or caution 1", "Potential issue or caution 2"]
}
`;

  return prompt;
}