import { Express } from 'express';
import { Pool } from '@neondatabase/serverless';
import { pool as pgPool } from '../db';

export function registerDatabaseStatusRoutes(app: Express) {
  // Check database connection status
  app.get('/api/database/status', async (req, res) => {
    try {
      const status = {
        postgres: { connected: false },
        sqlServer: { connected: false }
      };

      // Check PostgreSQL connection
      try {
        if (process.env.DATABASE_URL) {
          const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
          const pgClient = await pgPool.connect();
          
          try {
            await pgClient.query('SELECT 1');
            status.postgres.connected = true;
          } finally {
            pgClient.release();
          }
        }
      } catch (pgError) {
        console.error('PostgreSQL connection error:', pgError);
      }

      // Check SQL Server connection
      try {
        const sqlPool = await getSqlServerPool();
        await sqlPool.request().query('SELECT 1');
        status.sqlServer.connected = true;
      } catch (sqlError) {
        console.error('SQL Server connection error:', sqlError);
      }

      res.json(status);
    } catch (error) {
      console.error('Error checking database status:', error);
      res.status(500).json({ message: 'Error checking database status' });
    }
  });
  
  console.log('Database status routes registered');
}