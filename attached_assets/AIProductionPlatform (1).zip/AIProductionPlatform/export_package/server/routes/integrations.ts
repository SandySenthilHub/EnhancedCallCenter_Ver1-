import { Express } from 'express';
import { storage } from '../storage';
import { INTEGRATION_TYPES } from '@shared/schema';
import { WebSocket } from 'ws';

export function registerIntegrationRoutes(app: Express, isAuthenticated: any) {
  // Get all integrations
  app.get('/api/integrations', isAuthenticated, async (req, res) => {
    try {
      const integrations = await storage.getIntegrations();
      res.json(integrations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get integrations by type (nifi, spark, flink)
  app.get('/api/integrations/type/:type', isAuthenticated, async (req, res) => {
    try {
      const type = req.params.type;
      // Validate integration type
      if (!Object.values(INTEGRATION_TYPES).includes(type as any)) {
        return res.status(400).json({ 
          message: `Invalid integration type. Must be one of: ${Object.values(INTEGRATION_TYPES).join(', ')}` 
        });
      }
      
      const integrations = await storage.getIntegrationsByType(type);
      res.json(integrations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get a specific integration by ID
  app.get('/api/integrations/:id', isAuthenticated, async (req, res) => {
    try {
      const integration = await storage.getIntegration(parseInt(req.params.id));
      if (!integration) {
        return res.status(404).json({ message: 'Integration not found' });
      }
      res.json(integration);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new integration
  app.post('/api/integrations', isAuthenticated, async (req, res) => {
    try {
      // Include user ID from authenticated session
      const newIntegration = await storage.createIntegration({
        ...req.body,
        userId: (req.user as any).id
      });

      // Log activity for this new integration
      await storage.createActivity({
        activity: `Integration "${newIntegration.name}" created`,
        pipeline: null,
        status: 'success',
        userId: (req.user as any).id
      });

      // Send real-time notification
      global.sendMonitoringAlert({
        severity: 'info',
        source: 'Integrations',
        message: `New ${newIntegration.type} integration "${newIntegration.name}" created`
      });

      res.status(201).json(newIntegration);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Update an integration
  app.patch('/api/integrations/:id', isAuthenticated, async (req, res) => {
    try {
      const updatedIntegration = await storage.updateIntegration(
        parseInt(req.params.id),
        req.body
      );

      if (!updatedIntegration) {
        return res.status(404).json({ message: 'Integration not found' });
      }

      // Log activity for this update
      await storage.createActivity({
        activity: `Integration "${updatedIntegration.name}" updated`,
        pipeline: null,
        status: 'success',
        userId: (req.user as any).id
      });

      res.json(updatedIntegration);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Delete an integration
  app.delete('/api/integrations/:id', isAuthenticated, async (req, res) => {
    try {
      const integration = await storage.getIntegration(parseInt(req.params.id));
      
      if (!integration) {
        return res.status(404).json({ message: 'Integration not found' });
      }
      
      await storage.deleteIntegration(parseInt(req.params.id));

      // Log activity for this deletion
      await storage.createActivity({
        activity: `Integration "${integration.name}" deleted`,
        pipeline: null,
        status: 'success',
        userId: (req.user as any).id
      });

      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Test integration connection
  app.post('/api/integrations/:id/test', isAuthenticated, async (req, res) => {
    try {
      const integration = await storage.getIntegration(parseInt(req.params.id));
      
      if (!integration) {
        return res.status(404).json({ message: 'Integration not found' });
      }

      // Simulated test for now - would make actual API calls in production
      let testResult;
      let success = Math.random() > 0.2; // 80% success rate for the demo

      if (success) {
        testResult = { 
          status: 'connected', 
          message: `Successfully connected to ${integration.type} at ${integration.endpoint}` 
        };
        
        // Update the integration status
        await storage.updateIntegration(integration.id, { status: 'connected' });

        // Send monitoring alert
        global.sendMonitoringAlert({
          severity: 'info',
          source: 'Integrations',
          message: `Connection to "${integration.name}" successful`,
          details: { type: integration.type, endpoint: integration.endpoint }
        });
      } else {
        testResult = { 
          status: 'failed', 
          message: `Failed to connect to ${integration.type} at ${integration.endpoint}` 
        };
        
        // Update the integration status
        await storage.updateIntegration(integration.id, { status: 'disconnected' });

        // Send monitoring alert
        global.sendMonitoringAlert({
          severity: 'warning',
          source: 'Integrations',
          message: `Connection to "${integration.name}" failed`,
          details: { type: integration.type, endpoint: integration.endpoint }
        });
      }

      res.json(testResult);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}