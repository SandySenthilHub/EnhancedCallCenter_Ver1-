import express from 'express';
import fs from 'fs';
import path from 'path';
import { spawn, exec } from 'child_process';
import { storage } from '../storage';
import { insertAlgorithmDependencySchema } from '@shared/schema';
import { z } from 'zod';

const router = express.Router();

// Directory for storing dependency lock files and Docker files
const DEPENDENCY_DIR = path.join(process.cwd(), 'dependencies');

// Ensure the directory exists
if (!fs.existsSync(DEPENDENCY_DIR)) {
  fs.mkdirSync(DEPENDENCY_DIR, { recursive: true });
}

// Define validation schema for dependency locking
const lockDependencySchema = z.object({
  algorithmName: z.string(),
  environment: z.enum(['development', 'testing', 'production']).default('development')
});

// Helper function to execute command and capture output
function executeCommand(command: string): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    exec(command, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }
      resolve({ stdout, stderr });
    });
  });
}

// Check for dependency conflicts
async function checkDependencyConflicts(packages: string[]): Promise<{ hasConflicts: boolean; details: string }> {
  try {
    // Simulated conflict detection - in production you would use a more sophisticated method
    const result = await executeCommand(`pip check`);
    const hasConflicts = result.stdout.includes('conflict') || result.stderr.includes('conflict');
    
    return {
      hasConflicts,
      details: hasConflicts ? result.stdout || result.stderr : 'No conflicts detected'
    };
  } catch (error: any) {
    return {
      hasConflicts: true,
      details: `Error checking conflicts: ${error.message}`
    };
  }
}

// Scan dependencies for security vulnerabilities
async function scanForVulnerabilities(packages: string[]): Promise<{ hasVulnerabilities: boolean; details: string[] }> {
  try {
    // In a real implementation, you would use a tool like safety for Python packages
    // This is a simulated version
    const vulnerabilities: string[] = [];
    
    // Simulate checking each package
    for (const pkg of packages) {
      // This would be replaced with actual vulnerability scanning like:
      // const result = await executeCommand(`safety check --name ${pkg}`);
      
      // For demo purposes, randomly find "vulnerabilities" in 10% of packages
      if (Math.random() < 0.1) {
        vulnerabilities.push(`${pkg}: Simulated vulnerability detected`);
      }
    }
    
    return {
      hasVulnerabilities: vulnerabilities.length > 0,
      details: vulnerabilities
    };
  } catch (error: any) {
    return {
      hasVulnerabilities: true,
      details: [`Error scanning for vulnerabilities: ${error.message}`]
    };
  }
}

// Generate a Dockerfile for the given algorithm and its dependencies
function generateDockerfile(algorithmName: string, dependencies: any[]): string {
  const pythonDeps = dependencies.filter(dep => dep && dep.packageManager === 'pip')
    .map(dep => dep && dep.version ? `${dep.name}==${dep.version}` : dep.name);
  
  const nodeDeps = dependencies.filter(dep => dep && dep.packageManager === 'npm')
    .map(dep => dep && dep.version ? `${dep.name}@${dep.version}` : dep.name);
  
  const condaDeps = dependencies.filter(dep => dep && dep.packageManager === 'conda')
    .map(dep => dep && dep.version ? `${dep.name}=${dep.version}` : dep.name);
  
  let dockerfile = `FROM python:3.9-slim\n\n`;
  dockerfile += `WORKDIR /app\n\n`;
  
  // Install system dependencies
  dockerfile += `RUN apt-get update && apt-get install -y --no-install-recommends \\\n`;
  dockerfile += `    build-essential \\\n`;
  dockerfile += `    curl \\\n`;
  
  // Add Node.js if needed
  if (nodeDeps.length > 0) {
    dockerfile += `    && curl -fsSL https://deb.nodesource.com/setup_16.x | bash - \\\n`;
    dockerfile += `    && apt-get install -y nodejs \\\n`;
  }
  
  dockerfile += `    && apt-get clean \\\n`;
  dockerfile += `    && rm -rf /var/lib/apt/lists/*\n\n`;
  
  // Install Python dependencies
  if (pythonDeps.length > 0) {
    dockerfile += `# Install Python dependencies\n`;
    dockerfile += `COPY requirements.txt .\n`;
    dockerfile += `RUN pip install --no-cache-dir -r requirements.txt\n\n`;
  }
  
  // Install Node.js dependencies if needed
  if (nodeDeps.length > 0) {
    dockerfile += `# Install Node.js dependencies\n`;
    dockerfile += `COPY package.json .\n`;
    dockerfile += `RUN npm install\n\n`;
  }
  
  // Install Conda dependencies if needed
  if (condaDeps.length > 0) {
    dockerfile += `# Install Miniconda and Conda dependencies\n`;
    dockerfile += `RUN curl -LO https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh \\\n`;
    dockerfile += `    && bash Miniconda3-latest-Linux-x86_64.sh -p /miniconda -b \\\n`;
    dockerfile += `    && rm Miniconda3-latest-Linux-x86_64.sh\n`;
    dockerfile += `ENV PATH=/miniconda/bin:$PATH\n`;
    dockerfile += `COPY environment.yml .\n`;
    dockerfile += `RUN conda env update -f environment.yml\n\n`;
  }
  
  dockerfile += `# Copy application files\n`;
  dockerfile += `COPY . .\n\n`;
  
  dockerfile += `# Command to run the application\n`;
  dockerfile += `CMD ["python", "app.py"]\n`;
  
  return dockerfile;
}

// Create requirements.txt, package.json, and environment.yml as needed
function generateDependencyFiles(algorithmName: string, dependencies: any[]): {
  requirementsText: string;
  packageJson: string;
  environmentYml: string;
} {
  const pythonDeps = dependencies.filter(dep => dep && dep.packageManager === 'pip')
    .map(dep => dep && dep.version ? `${dep.name}==${dep.version}` : dep.name);
  
  const nodeDeps = dependencies.filter(dep => dep && dep.packageManager === 'npm')
    .reduce((acc: Record<string, string>, dep) => {
      if (dep) {
        acc[dep.name] = dep.version || 'latest';
      }
      return acc;
    }, {});
  
  const condaDeps = dependencies.filter(dep => dep && dep.packageManager === 'conda')
    .map(dep => dep && dep.version ? `${dep.name}=${dep.version}` : dep.name);
  
  const requirementsText = pythonDeps.join('\n');
  
  const packageJson = JSON.stringify({
    name: `${algorithmName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-dependencies`,
    version: '1.0.0',
    private: true,
    dependencies: nodeDeps
  }, null, 2);
  
  const environmentYml = `name: ${algorithmName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-env
channels:
  - defaults
  - conda-forge
dependencies:
${condaDeps.map(dep => `  - ${dep}`).join('\n')}
`;
  
  return {
    requirementsText,
    packageJson,
    environmentYml
  };
}

// Lock dependencies for an algorithm to ensure reproducibility
router.post('/algorithm-dependencies/lock/:algorithmName', async (req, res) => {
  try {
    const { algorithmName, environment } = lockDependencySchema.parse({
      algorithmName: req.params.algorithmName,
      ...req.body
    });
    
    // Get all dependencies for this algorithm
    const mappings = await storage.getAlgorithmDependencyMappingsByAlgorithm(algorithmName);
    
    if (!mappings || mappings.length === 0) {
      return res.status(404).json({ error: 'No dependencies found for this algorithm' });
    }
    
    // Fetch full dependency details for each mapping
    const dependencies = await Promise.all(
      mappings.map(mapping => storage.getAlgorithmDependency(mapping.dependencyId))
    );
    
    // Filter out any null values
    const validDependencies = dependencies.filter(dep => dep !== null);
    
    if (validDependencies.length === 0) {
      return res.status(404).json({ error: 'No valid dependencies found for this algorithm' });
    }
    
    // Group dependencies by package manager
    const packageManagers = new Set(validDependencies.map(dep => dep && dep.packageManager));
    
    // Create the algorithm directory if it doesn't exist
    const algorithmDir = path.join(DEPENDENCY_DIR, algorithmName, environment);
    if (!fs.existsSync(algorithmDir)) {
      fs.mkdirSync(algorithmDir, { recursive: true });
    }
    
    // Create dependency files
    const { requirementsText, packageJson, environmentYml } = generateDependencyFiles(
      algorithmName,
      validDependencies
    );
    
    // Write files based on which package managers are used
    const createdFiles = [];
    
    if (packageManagers.has('pip') && requirementsText) {
      const requirementsFile = path.join(algorithmDir, 'requirements.txt');
      fs.writeFileSync(requirementsFile, requirementsText);
      createdFiles.push('requirements.txt');
      
      // Create pip-freeze for exact locking if in production
      if (environment === 'production') {
        try {
          const { stdout } = await executeCommand('pip freeze > ' + path.join(algorithmDir, 'requirements.lock'));
          createdFiles.push('requirements.lock');
        } catch (error: any) {
          console.error('Error generating pip freeze:', error);
        }
      }
    }
    
    if (packageManagers.has('npm') && packageJson) {
      const packageJsonFile = path.join(algorithmDir, 'package.json');
      fs.writeFileSync(packageJsonFile, packageJson);
      createdFiles.push('package.json');
      
      // Create package-lock.json for exact locking if in production
      if (environment === 'production') {
        try {
          // This would be run in the context of that directory in a real implementation
          fs.writeFileSync(path.join(algorithmDir, 'package-lock.json'), '{}');
          createdFiles.push('package-lock.json');
        } catch (error: any) {
          console.error('Error generating package-lock.json:', error);
        }
      }
    }
    
    if (packageManagers.has('conda') && environmentYml) {
      const environmentFile = path.join(algorithmDir, 'environment.yml');
      fs.writeFileSync(environmentFile, environmentYml);
      createdFiles.push('environment.yml');
      
      // Create exact conda environment export if in production
      if (environment === 'production') {
        try {
          // This would be a real conda export in a real implementation
          fs.writeFileSync(path.join(algorithmDir, 'environment.lock.yml'), environmentYml);
          createdFiles.push('environment.lock.yml');
        } catch (error: any) {
          console.error('Error generating conda environment lock:', error);
        }
      }
    }
    
    // Generate Dockerfile for containerized environment
    const dockerfile = generateDockerfile(algorithmName, validDependencies);
    fs.writeFileSync(path.join(algorithmDir, 'Dockerfile'), dockerfile);
    createdFiles.push('Dockerfile');
    
    // Check for dependency conflicts
    const conflictCheck = await checkDependencyConflicts(
      validDependencies.map(dep => dep && dep.version ? `${dep.name}==${dep.version}` : dep.name)
    );
    
    // Scan for vulnerabilities
    const vulnerabilityCheck = await scanForVulnerabilities(
      validDependencies.map(dep => dep && dep.name)
    );
    
    // Create dependency metadata
    const metadata = {
      algorithmName,
      environment,
      dependencies: validDependencies.map(dep => dep && ({
        name: dep.name,
        version: dep.version || 'latest',
        packageManager: dep.packageManager
      })),
      createdAt: new Date().toISOString(),
      locks: createdFiles,
      conflicts: conflictCheck,
      vulnerabilities: vulnerabilityCheck,
    };
    
    fs.writeFileSync(
      path.join(algorithmDir, 'dependency-metadata.json'),
      JSON.stringify(metadata, null, 2)
    );
    
    res.status(200).json({
      success: true,
      message: `Dependencies locked for algorithm ${algorithmName} in ${environment} environment`,
      lockedFiles: createdFiles,
      directory: algorithmDir,
      conflicts: conflictCheck,
      vulnerabilities: vulnerabilityCheck,
    });
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: error.errors });
    }
    console.error('Error locking dependencies:', error);
    res.status(500).json({ error: 'Failed to lock dependencies', details: error.message });
  }
});

// Get locked dependencies for an algorithm
router.get('/algorithm-dependencies/lock/:algorithmName/:environment?', async (req, res) => {
  try {
    const algorithmName = req.params.algorithmName;
    const environment = req.params.environment || 'development';
    
    const algorithmDir = path.join(DEPENDENCY_DIR, algorithmName, environment);
    
    if (!fs.existsSync(algorithmDir)) {
      return res.status(404).json({
        error: `No locked dependencies found for ${algorithmName} in ${environment} environment`
      });
    }
    
    const metadataFile = path.join(algorithmDir, 'dependency-metadata.json');
    
    if (!fs.existsSync(metadataFile)) {
      return res.status(404).json({
        error: `No dependency metadata found for ${algorithmName} in ${environment} environment`
      });
    }
    
    const metadata = JSON.parse(fs.readFileSync(metadataFile, 'utf8'));
    
    res.status(200).json(metadata);
  } catch (error: any) {
    console.error('Error retrieving locked dependencies:', error);
    res.status(500).json({ error: 'Failed to retrieve locked dependencies', details: error.message });
  }
});

// Generate CI/CD configuration for dependencies
router.get('/algorithm-dependencies/cicd/:algorithmName/:type', async (req, res) => {
  try {
    const { algorithmName, type } = req.params;
    
    // Get all dependencies for this algorithm
    const mappings = await storage.getAlgorithmDependencyMappingsByAlgorithm(algorithmName);
    
    if (!mappings || mappings.length === 0) {
      return res.status(404).json({ error: 'No dependencies found for this algorithm' });
    }
    
    // Fetch full dependency details for each mapping
    const dependencies = await Promise.all(
      mappings.map(mapping => storage.getAlgorithmDependency(mapping.dependencyId))
    );
    
    // Filter out any null values
    const validDependencies = dependencies.filter(dep => dep !== null);
    
    if (validDependencies.length === 0) {
      return res.status(404).json({ error: 'No valid dependencies found for this algorithm' });
    }
    
    let cicdConfig = '';
    
    if (type === 'github') {
      // Generate GitHub Actions workflow
      cicdConfig = `name: Test Dependencies
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.9'
`;

      const hasPythonDeps = validDependencies.some(dep => dep && dep.packageManager === 'pip');
      const hasNodeDeps = validDependencies.some(dep => dep && dep.packageManager === 'npm');
      
      if (hasPythonDeps) {
        cicdConfig += `    - name: Install Python dependencies
      run: |
        python -m pip install --upgrade pip
        pip install pytest safety
        pip install -r requirements.txt
    - name: Check for vulnerabilities
      run: safety check
    - name: Run tests
      run: pytest
`;
      }
      
      if (hasNodeDeps) {
        cicdConfig += `    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '16'
    - name: Install Node.js dependencies
      run: npm install
    - name: Run Node.js tests
      run: npm test
`;
      }
    } else if (type === 'gitlab') {
      // Generate GitLab CI config
      cicdConfig = `image: python:3.9

stages:
  - test

test:
  stage: test
  script:
`;

      const hasPythonDeps = validDependencies.some(dep => dep && dep.packageManager === 'pip');
      const hasNodeDeps = validDependencies.some(dep => dep && dep.packageManager === 'npm');
      
      if (hasPythonDeps) {
        cicdConfig += `    - pip install pytest safety
    - pip install -r requirements.txt
    - safety check
    - pytest
`;
      }
      
      if (hasNodeDeps) {
        cicdConfig += `    - curl -sL https://deb.nodesource.com/setup_16.x | bash -
    - apt-get install -y nodejs
    - npm install
    - npm test
`;
      }
    } else if (type === 'jenkins') {
      // Generate Jenkinsfile
      cicdConfig = `pipeline {
    agent {
        docker {
            image 'python:3.9'
        }
    }
    stages {
        stage('Setup') {
            steps {
                sh 'pip install pytest safety'
`;

      const hasPythonDeps = validDependencies.some(dep => dep && dep.packageManager === 'pip');
      const hasNodeDeps = validDependencies.some(dep => dep && dep.packageManager === 'npm');
      
      if (hasPythonDeps) {
        cicdConfig += `                sh 'pip install -r requirements.txt'
`;
      }
      
      if (hasNodeDeps) {
        cicdConfig += `                sh 'curl -sL https://deb.nodesource.com/setup_16.x | bash -'
                sh 'apt-get install -y nodejs'
                sh 'npm install'
`;
      }

      cicdConfig += `            }
        }
        stage('Security Check') {
            steps {
                sh 'safety check'
            }
        }
        stage('Test') {
            steps {
`;

      if (hasPythonDeps) {
        cicdConfig += `                sh 'pytest'
`;
      }
      
      if (hasNodeDeps) {
        cicdConfig += `                sh 'npm test'
`;
      }

      cicdConfig += `            }
        }
    }
}
`;
    } else {
      return res.status(400).json({ error: `Unsupported CI/CD system: ${type}` });
    }
    
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Content-Disposition', `attachment; filename="${algorithmName}-${type}-config.yml"`);
    res.send(cicdConfig);
  } catch (error: any) {
    console.error('Error generating CI/CD configuration:', error);
    res.status(500).json({ error: 'Failed to generate CI/CD configuration', details: error.message });
  }
});

// Document algorithm dependencies
router.get('/algorithm-dependencies/doc/:algorithmName', async (req, res) => {
  try {
    const { algorithmName } = req.params;
    
    // Get all dependencies for this algorithm
    const mappings = await storage.getAlgorithmDependencyMappingsByAlgorithm(algorithmName);
    
    if (!mappings || mappings.length === 0) {
      return res.status(404).json({ error: 'No dependencies found for this algorithm' });
    }
    
    // Fetch full dependency details for each mapping
    const dependencies = await Promise.all(
      mappings.map(mapping => storage.getAlgorithmDependency(mapping.dependencyId))
    );
    
    // Filter out any null values
    const validDependencies = dependencies.filter(dep => dep !== null);
    
    if (validDependencies.length === 0) {
      return res.status(404).json({ error: 'No valid dependencies found for this algorithm' });
    }
    
    // Generate markdown documentation
    let markdown = `# Dependencies for ${algorithmName}\n\n`;
    
    // Group by package manager
    const packageManagerGroups: Record<string, any[]> = {};
    validDependencies.forEach(dep => {
      if (dep) {
        const pm = dep.packageManager;
        if (!packageManagerGroups[pm]) {
          packageManagerGroups[pm] = [];
        }
        packageManagerGroups[pm].push(dep);
      }
    });
    
    Object.entries(packageManagerGroups).forEach(([packageManager, deps]) => {
      markdown += `## ${packageManager.charAt(0).toUpperCase() + packageManager.slice(1)} Dependencies\n\n`;
      markdown += `| Package | Version | Description |\n`;
      markdown += `| ------- | ------- | ----------- |\n`;
      
      deps.forEach(dep => {
        markdown += `| ${dep.name} | ${dep.version || 'latest'} | ${dep.description || 'No description available'} |\n`;
      });
      
      markdown += `\n`;
    });
    
    // Add installation instructions
    markdown += `## Installation Instructions\n\n`;
    
    if (packageManagerGroups['pip']) {
      markdown += `### Python (pip)\n\n`;
      markdown += `\`\`\`bash\npip install -r requirements.txt\n\`\`\`\n\n`;
    }
    
    if (packageManagerGroups['npm']) {
      markdown += `### Node.js (npm)\n\n`;
      markdown += `\`\`\`bash\nnpm install\n\`\`\`\n\n`;
    }
    
    if (packageManagerGroups['conda']) {
      markdown += `### Conda\n\n`;
      markdown += `\`\`\`bash\nconda env update -f environment.yml\n\`\`\`\n\n`;
    }
    
    // Add Docker instructions
    markdown += `## Docker\n\n`;
    markdown += `A Dockerfile is provided for containerized usage of ${algorithmName}.\n\n`;
    markdown += `\`\`\`bash\n`;
    markdown += `# Build the Docker image\ndocker build -t ${algorithmName.toLowerCase().replace(/[^a-z0-9]/g, '-')}:latest .\n\n`;
    markdown += `# Run the Docker container\ndocker run -it --rm ${algorithmName.toLowerCase().replace(/[^a-z0-9]/g, '-')}:latest\n`;
    markdown += `\`\`\`\n\n`;
    
    // Add CI/CD instructions
    markdown += `## CI/CD Configuration\n\n`;
    markdown += `CI/CD configurations for GitHub Actions, GitLab CI, and Jenkins are available:\n\n`;
    markdown += `- [GitHub Actions configuration](${algorithmName}-github-config.yml)\n`;
    markdown += `- [GitLab CI configuration](${algorithmName}-gitlab-config.yml)\n`;
    markdown += `- [Jenkins configuration](${algorithmName}-jenkins-config.yml)\n\n`;
    
    // Add maintenance information
    markdown += `## Dependency Maintenance\n\n`;
    markdown += `Dependencies should be regularly updated and checked for security vulnerabilities.\n`;
    markdown += `Use the following commands to check for outdated packages:\n\n`;
    
    if (packageManagerGroups['pip']) {
      markdown += `### Python\n`;
      markdown += `\`\`\`bash\npip list --outdated\n\`\`\`\n\n`;
    }
    
    if (packageManagerGroups['npm']) {
      markdown += `### Node.js\n`;
      markdown += `\`\`\`bash\nnpm outdated\n\`\`\`\n\n`;
    }
    
    if (packageManagerGroups['conda']) {
      markdown += `### Conda\n`;
      markdown += `\`\`\`bash\nconda update --all\n\`\`\`\n\n`;
    }
    
    res.setHeader('Content-Type', 'text/markdown');
    res.setHeader('Content-Disposition', `attachment; filename="${algorithmName}-dependencies.md"`);
    res.send(markdown);
  } catch (error: any) {
    console.error('Error generating dependency documentation:', error);
    res.status(500).json({ error: 'Failed to generate dependency documentation', details: error.message });
  }
});

export default router;