import express from 'express';
import algorithmDependenciesRouter from './algorithm-dependencies';

export function registerAlgorithmDependenciesRoutes(app: express.Express): void {
  app.use('/api', algorithmDependenciesRouter);
  console.log('Algorithm dependencies routes registered');
}