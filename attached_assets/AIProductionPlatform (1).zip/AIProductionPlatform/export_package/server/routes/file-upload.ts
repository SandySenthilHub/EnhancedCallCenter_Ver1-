import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { z } from 'zod';
import { storage } from '../storage';

// Use these schemas directly with Zod instead of using drizzle-zod schemas
const fileSchema = z.object({
  name: z.string(),
  source: z.string(),
  path: z.string(),
  size: z.number(),
  format: z.string(),
  status: z.string().default('raw'),
  dataSourceId: z.number().nullable().optional(),
  userId: z.number().nullable().optional()
});

const dataSourceSchema = z.object({
  name: z.string(),
  type: z.string(),
  connection: z.string(),
  status: z.string().default('disconnected'),
  userId: z.number().nullable().optional(),
  fileId: z.number().nullable().optional()
});

// Configure multer for file uploads
const storage_dir = path.join(process.cwd(), "uploads");
// Create the uploads directory if it doesn't exist
if (!fs.existsSync(storage_dir)) {
  fs.mkdirSync(storage_dir, { recursive: true });
}

const storage_engine = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, storage_dir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage_engine,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB
  },
  fileFilter: (req, file, cb) => {
    const allowedExtensions = [".csv", ".json", ".parquet", ".txt"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedExtensions.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error("Unsupported file format"));
    }
  }
});

export function registerFileUploadRoutes(app: express.Express, isAuthenticated: any) {
  // Upload files
  app.post("/api/upload", isAuthenticated, upload.array("files"), async (req: express.Request, res: express.Response) => {
    try {
      const files = req.files as Express.Multer.File[];
      // Get user ID from the authenticated user session
      const userId = req.user?.id;
      const source = req.body.source || "upload";
      const dataSourceName = req.body.dataSourceName;
      
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "No files were uploaded" });
      }
      
      const filePromises = files.map(async (file) => {
        const format = path.extname(file.originalname).replace(".", "").toLowerCase();
        
        const fileData = {
          name: file.originalname,
          source,
          path: file.path,
          size: file.size,
          format,
          userId,
          status: "raw"
        };
        
        // Validate file metadata
        const validatedData = fileSchema.parse(fileData);
        
        // Create file metadata in database
        return await storage.createFile(validatedData);
      });
      
      const savedFiles = await Promise.all(filePromises);
      
      // If there is a dataSourceName, create a data source for the file
      if (dataSourceName && savedFiles.length > 0) {
        const fileId = savedFiles[0].id;
        const dataSourceData = {
          name: dataSourceName,
          type: 'file',
          connection: `file://${savedFiles[0].path}`,
          status: 'connected',
          userId,
          fileId
        };
        
        try {
          // Validate and create data source
          const validatedDataSource = dataSourceSchema.parse(dataSourceData);
          const dataSource = await storage.createDataSource(validatedDataSource);
          
          // Return only the data source since that's what the client expects
          return res.status(201).json(dataSource);
        } catch (error) {
          console.error('Error creating data source:', error);
          // Still return the saved files even if data source creation fails
        }
      }
      
      res.status(201).json(savedFiles);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error uploading files:", error);
      res.status(500).json({ error: "Failed to upload files", message: error instanceof Error ? error.message : String(error) });
    }
  });
}