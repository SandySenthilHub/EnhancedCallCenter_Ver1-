import { Express } from 'express';
import { storage } from '../storage';
import { z } from 'zod';
import { insertDataEncodingConfigSchema, insertDataEncodingHistorySchema } from '../../shared/schema';

export function registerDataEncodingRoutes(app: Express, isAuthenticated: any) {
  // Get all data encoding configurations
  app.get('/api/data-encodings', isAuthenticated, async (req, res) => {
    try {
      const configs = await storage.getDataEncodingConfigs();
      res.json(configs);
    } catch (error: any) {
      console.error('Error fetching data encoding configurations:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get a specific data encoding configuration
  app.get('/api/data-encodings/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const config = await storage.getDataEncodingConfig(id);
      
      if (!config) {
        return res.status(404).json({ message: 'Data encoding configuration not found' });
      }
      
      res.json(config);
    } catch (error: any) {
      console.error('Error fetching data encoding configuration:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Create a new data encoding configuration
  app.post('/api/data-encodings', isAuthenticated, async (req, res) => {
    try {
      // Validate request body
      const validatedData = insertDataEncodingConfigSchema.parse({
        ...req.body,
        userId: (req.user as any).id
      });
      
      const newConfig = await storage.createDataEncodingConfig(validatedData);
      
      // Log creation in activity log
      await storage.createActivity({
        activity: `Data encoding configuration "${newConfig.name}" created`,
        pipeline: null,
        status: 'success',
        userId: (req.user as any).id
      });
      
      res.status(201).json(newConfig);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      
      console.error('Error creating data encoding configuration:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Update a data encoding configuration
  app.patch('/api/data-encodings/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updatedConfig = await storage.updateDataEncodingConfig(id, req.body);
      
      if (!updatedConfig) {
        return res.status(404).json({ message: 'Data encoding configuration not found' });
      }
      
      res.json(updatedConfig);
    } catch (error: any) {
      console.error('Error updating data encoding configuration:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Delete a data encoding configuration
  app.delete('/api/data-encodings/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteDataEncodingConfig(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Data encoding configuration not found' });
      }
      
      res.status(204).end();
    } catch (error: any) {
      console.error('Error deleting data encoding configuration:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Get encoding history for a specific configuration
  app.get('/api/data-encodings/:id/history', isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const history = await storage.getDataEncodingHistory(configId);
      
      res.json(history);
    } catch (error: any) {
      console.error('Error fetching data encoding history:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Apply encoding to data and record history
  app.post('/api/data-encodings/:id/apply', isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const config = await storage.getDataEncodingConfig(configId);
      
      if (!config) {
        return res.status(404).json({ message: 'Data encoding configuration not found' });
      }
      
      // TODO: In a real implementation, this would call the data processing service
      // to apply the encoding transformation
      
      // Record the application in history
      const historyEntry = await storage.createDataEncodingHistory({
        configId,
        status: 'completed',
        results: { transformedRows: 1000, outputColumns: ['category_electronics', 'category_clothing'] },
        metrics: { 
          cardinalityBefore: 25, 
          cardinalityAfter: 2,
          memoryUsageBefore: '2MB',
          memoryUsageAfter: '3MB'
        },
        userId: (req.user as any).id
      });
      
      res.status(200).json({
        message: 'Encoding applied successfully',
        history: historyEntry
      });
    } catch (error: any) {
      console.error('Error applying data encoding:', error);
      res.status(500).json({ message: error.message });
    }
  });

  // Preview encoding on sample data
  app.post('/api/data-encodings/:id/preview', isAuthenticated, async (req, res) => {
    try {
      const configId = parseInt(req.params.id);
      const config = await storage.getDataEncodingConfig(configId);
      
      if (!config) {
        return res.status(404).json({ message: 'Data encoding configuration not found' });
      }
      
      // This would typically call a data service to apply the encoding
      // to a small sample of data and return the results
      
      // For demonstration, return a mock response
      res.json({
        originalData: [
          { id: 1, category: 'Electronics', sales: 5000 },
          { id: 2, category: 'Clothing', sales: 3000 },
          { id: 3, category: 'Electronics', sales: 4500 }
        ],
        encodedData: [
          { id: 1, category_Electronics: 1, category_Clothing: 0, sales: 5000 },
          { id: 2, category_Electronics: 0, category_Clothing: 1, sales: 3000 },
          { id: 3, category_Electronics: 1, category_Clothing: 0, sales: 4500 }
        ],
        encodingType: config.encodingType,
        metrics: {
          originalColumns: ['id', 'category', 'sales'],
          newColumns: ['id', 'category_Electronics', 'category_Clothing', 'sales'],
          uniqueValuesBefore: 2,
          columnsCreated: 2
        }
      });
    } catch (error: any) {
      console.error('Error previewing data encoding:', error);
      res.status(500).json({ message: error.message });
    }
  });
}