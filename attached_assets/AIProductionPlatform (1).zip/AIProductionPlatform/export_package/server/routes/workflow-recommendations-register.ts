import { Express } from "express";
import workflowRecommendationsRouter from "./workflow-recommendations";

export function registerWorkflowRecommendationsRoutes(app: Express) {
  app.use('/api', workflowRecommendationsRouter);
}