import { Express, Request, Response } from "express";
import { storage } from "../storage";
import { insertDataSourceSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";

// Configure multer for file uploads
const storage_dir = path.join(process.cwd(), "uploads");
// Create the uploads directory if it doesn't exist
if (!fs.existsSync(storage_dir)) {
  fs.mkdirSync(storage_dir, { recursive: true });
}

const storage_engine = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, storage_dir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage_engine,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB
  },
  fileFilter: (req, file, cb) => {
    const allowedExtensions = [".csv", ".json", ".wav", ".mp3", ".parquet", ".txt"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedExtensions.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error("Unsupported file format"));
    }
  }
});

// File metadata schema for validation
const fileMetadataSchema = z.object({
  name: z.string(),
  source: z.string(),
  path: z.string(),
  size: z.number(),
  format: z.string(),
  userId: z.number(),
  status: z.string().default("raw")
});

// Spark job schema for validation
const sparkJobSchema = z.object({
  jobType: z.string(),
  sourceFileId: z.string(),
  outputFormat: z.string().optional(),
  outputPath: z.string().optional(),
  sqlQuery: z.string().optional(),
  sparkConfig: z.record(z.any()).optional(),
  userId: z.number()
});

export function registerDataSourceRoutes(app: Express, isAuthenticated: any) {
  // Get all data sources
  app.get("/api/data-sources", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const dataSources = await storage.getDataSources();
      res.json(dataSources);
    } catch (error) {
      console.error("Error fetching data sources:", error);
      res.status(500).json({ error: "Failed to fetch data sources" });
    }
  });

  // Get a single data source by ID
  app.get("/api/data-sources/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const dataSource = await storage.getDataSource(id);
      
      if (!dataSource) {
        return res.status(404).json({ error: "Data source not found" });
      }
      
      res.json(dataSource);
    } catch (error) {
      console.error("Error fetching data source:", error);
      res.status(500).json({ error: "Failed to fetch data source" });
    }
  });
  
  // Get columns for a data source
  app.get("/api/data-sources/:id/columns", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const dataSource = await storage.getDataSource(id);
      
      if (!dataSource) {
        return res.status(404).json({ error: "Data source not found" });
      }
      
      // If this is a file-based data source, get the file and return its columns
      if (dataSource.type === 'upload' || dataSource.type === 'file') {
        // Get associated file
        const files = await storage.getFilesByDataSourceId(id);
        
        if (!files || files.length === 0) {
          return res.status(404).json({ error: "No files found for this data source" });
        }
        
        // For simplicity, use the first file
        const file = files[0];
        
        // For CSV files, return sample columns based on file format
        if (file.format === 'csv') {
          // In a real implementation, we would read the file and extract headers
          // For now, return a list of sample columns from the storage or a predefined list
          const columns = await storage.getDataSourceColumns(id);
          return res.json(columns || [
            { name: "id", type: "integer" },
            { name: "name", type: "string" },
            { name: "category", type: "string" },
            { name: "value", type: "float" },
            { name: "timestamp", type: "datetime" }
          ]);
        } else if (file.format === 'json' || file.format === 'parquet') {
          // For these formats, we would normally read schema information
          // Return sample columns for now
          const columns = await storage.getDataSourceColumns(id);
          return res.json(columns || [
            { name: "id", type: "integer" },
            { name: "properties", type: "object" },
            { name: "tags", type: "array" },
            { name: "metadata", type: "object" }
          ]);
        } else {
          return res.status(400).json({ error: "Unsupported file format for column extraction" });
        }
      } else if (dataSource.type === 'database' || dataSource.type === 'sql') {
        // For database sources, we would typically query the schema
        // Here we'll use a helper function that would do this in a real implementation
        const columns = await storage.getDataSourceColumns(id);
        return res.json(columns || [
          { name: "id", type: "integer" },
          { name: "user_id", type: "integer" },
          { name: "product_name", type: "string" },
          { name: "price", type: "decimal" },
          { name: "created_at", type: "timestamp" }
        ]);
      } else {
        // For other sources like APIs, return an empty array or mock schema
        return res.json([]);
      }
    } catch (error) {
      console.error("Error fetching data source columns:", error);
      res.status(500).json({ error: "Failed to fetch data source columns" });
    }
  });

  // Create a new data source
  app.post("/api/data-sources", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const validatedData = insertDataSourceSchema.parse(req.body);
      const dataSource = await storage.createDataSource(validatedData);
      res.status(201).json(dataSource);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating data source:", error);
      res.status(500).json({ error: "Failed to create data source" });
    }
  });

  // Update a data source
  app.patch("/api/data-sources/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const dataSource = await storage.getDataSource(id);
      
      if (!dataSource) {
        return res.status(404).json({ error: "Data source not found" });
      }
      
      // Validate partial data
      const validatedData = insertDataSourceSchema.partial().parse(req.body);
      
      // Update the data source
      const updatedDataSource = await storage.updateDataSource(id, validatedData);
      res.json(updatedDataSource);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error updating data source:", error);
      res.status(500).json({ error: "Failed to update data source" });
    }
  });

  // Delete a data source
  app.delete("/api/data-sources/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const dataSource = await storage.getDataSource(id);
      
      if (!dataSource) {
        return res.status(404).json({ error: "Data source not found" });
      }
      
      await storage.deleteDataSource(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting data source:", error);
      res.status(500).json({ error: "Failed to delete data source" });
    }
  });

  // File Routes
  // Get all files
  app.get("/api/files", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const files = await storage.getFiles();
      res.json(files);
    } catch (error) {
      console.error("Error fetching files:", error);
      res.status(500).json({ error: "Failed to fetch files" });
    }
  });

  // Get a single file by ID
  app.get("/api/files/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const file = await storage.getFile(id);
      
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      
      res.json(file);
    } catch (error) {
      console.error("Error fetching file:", error);
      res.status(500).json({ error: "Failed to fetch file" });
    }
  });

  // Upload files
  app.post("/api/upload", isAuthenticated, upload.array("files"), async (req: Request, res: Response) => {
    try {
      const files = req.files as Express.Multer.File[];
      const userId = parseInt(req.body.userId);
      const source = req.body.source || "upload";
      
      if (!files || files.length === 0) {
        return res.status(400).json({ error: "No files were uploaded" });
      }
      
      const filePromises = files.map(async (file) => {
        const format = path.extname(file.originalname).replace(".", "").toLowerCase();
        
        const fileData = {
          name: file.originalname,
          source,
          path: file.path,
          size: file.size,
          format,
          userId,
          status: "raw"
        };
        
        // Validate file metadata
        const validatedData = fileMetadataSchema.parse(fileData);
        
        // Create file metadata in database
        return await storage.createFile(validatedData);
      });
      
      const savedFiles = await Promise.all(filePromises);
      res.status(201).json(savedFiles);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error uploading files:", error);
      res.status(500).json({ error: "Failed to upload files" });
    }
  });

  // Delete a file
  app.delete("/api/files/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const file = await storage.getFile(id);
      
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      
      // Delete the file from disk if it's a local file
      if (file.source === "upload" && fs.existsSync(file.path)) {
        fs.unlinkSync(file.path);
      }
      
      await storage.deleteFile(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting file:", error);
      res.status(500).json({ error: "Failed to delete file" });
    }
  });

  // Spark job routes
  app.post("/api/spark/job", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const validatedData = sparkJobSchema.parse(req.body);
      
      // In a real implementation, we would submit the job to a Spark cluster
      // Here, we'll just simulate it by creating a job entry
      const jobId = uuidv4();
      
      // Simulate processing
      setTimeout(async () => {
        try {
          // Update the original file status to indicate it's being processed
          const fileId = parseInt(validatedData.sourceFileId);
          await storage.updateFile(fileId, { status: "processing" });
          
          // Simulate completion after some time
          setTimeout(async () => {
            try {
              // Create a new file entry for the processed output
              const originalFile = await storage.getFile(fileId);
              if (originalFile) {
                let outputFormat = validatedData.outputFormat || "parquet";
                let outputName = `${path.basename(originalFile.name, path.extname(originalFile.name))}_processed.${outputFormat}`;
                let outputPath = validatedData.outputPath || path.join(storage_dir, outputName);
                
                // In a real implementation, the Spark job would have created this file
                // Here we'll just simulate it
                const outputFileData = {
                  name: outputName,
                  source: "spark",
                  path: outputPath,
                  size: originalFile.size, // In reality, the size would be different
                  format: outputFormat,
                  userId: validatedData.userId,
                  status: "processed"
                };
                
                await storage.createFile(outputFileData);
                
                // Update the original file status to indicate processing is complete
                await storage.updateFile(fileId, { status: "processed" });
              }
            } catch (error) {
              console.error("Error simulating Spark job completion:", error);
            }
          }, 10000); // Simulate job taking 10 seconds
        } catch (error) {
          console.error("Error simulating Spark job:", error);
        }
      }, 2000); // Start processing after 2 seconds
      
      res.status(202).json({
        jobId,
        message: "Spark job submitted successfully",
        status: "pending"
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error submitting Spark job:", error);
      res.status(500).json({ error: "Failed to submit Spark job" });
    }
  });

  // Get Spark job status
  app.get("/api/spark/job/:id", isAuthenticated, (req: Request, res: Response) => {
    // In a real implementation, we would check the status of the job with the Spark cluster
    // Here, we'll just return a simulated status
    const jobId = req.params.id;
    
    // Simulate a random status for demonstration
    const statuses = ["pending", "running", "completed", "failed"];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
    
    res.json({
      jobId,
      status: randomStatus,
      progress: randomStatus === "completed" ? 100 : Math.floor(Math.random() * 100)
    });
  });
}