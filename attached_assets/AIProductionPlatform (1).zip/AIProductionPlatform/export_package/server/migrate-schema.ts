import { db } from './db';
import { sql } from 'drizzle-orm';

async function migrateSchema() {
  try {
    console.log('Adding category column to algorithm_dependencies table...');
    
    // Check if category column exists
    const result = await db.execute(sql`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'algorithm_dependencies' AND column_name = 'category'
    `);
    
    // If category column doesn't exist, add it
    if (result.rows.length === 0) {
      await db.execute(sql`
        ALTER TABLE algorithm_dependencies
        ADD COLUMN category TEXT
      `);
      console.log('Category column added successfully.');
    } else {
      console.log('Category column already exists.');
    }
    
    console.log('Migration completed successfully.');
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    process.exit(0);
  }
}

migrateSchema();