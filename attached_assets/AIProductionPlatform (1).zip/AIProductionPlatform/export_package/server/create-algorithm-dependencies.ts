import { executeQuery } from './db';

async function createAlgorithmDependenciesTable() {
  try {
    console.log('Checking algorithm_dependencies table...');
    
    // Check if category column exists
    const columnCheckQuery = `
      SELECT COUNT(*) as count 
      FROM INFORMATION_SCHEMA.COLUMNS 
      WHERE TABLE_NAME = 'algorithm_dependencies' AND COLUMN_NAME = 'category'
    `;
    
    const columnResult = await executeQuery(columnCheckQuery);
    const categoryExists = columnResult[0]?.count > 0;

    if (!categoryExists) {
      console.log('Adding category column to algorithm_dependencies table...');
      
      // Add category column
      const alterTableQuery = `
        ALTER TABLE algorithm_dependencies 
        ADD category NVARCHAR(100)
      `;
      
      await executeQuery(alterTableQuery);
      console.log('Category column added successfully.');
    } else {
      console.log('Category column already exists.');
    }
    
    console.log('Algorithm dependencies table check completed.');
    return true;
  } catch (error) {
    console.error('Error with algorithm_dependencies table:', error);
    return false;
  }
}

export default createAlgorithmDependenciesTable;