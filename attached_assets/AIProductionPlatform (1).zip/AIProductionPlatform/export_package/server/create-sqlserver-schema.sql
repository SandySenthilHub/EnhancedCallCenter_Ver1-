-- SQL Server Schema for AI/ML Playbook Platform
-- Use this script to create the database schema in Azure SQL Server

-- Sessions table for authentication persistence
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'sessions')
BEGIN
    CREATE TABLE sessions (
        sid NVARCHAR(255) PRIMARY KEY,
        session_data NVARCHAR(MAX) NOT NULL,
        expires DATETIME NOT NULL
    );
    CREATE INDEX idx_sessions_expires ON sessions (expires);
END;

-- Users table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'users')
BEGIN
    CREATE TABLE users (
        id INT IDENTITY(1,1) PRIMARY KEY,
        username NVARCHAR(100) NOT NULL UNIQUE,
        email NVARCHAR(255) NOT NULL,
        password NVARCHAR(255) NOT NULL,
        role NVARCHAR(50) NOT NULL DEFAULT 'data_scientist',
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE()
    );
END;

-- Data sources table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'data_sources')
BEGIN
    CREATE TABLE data_sources (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        type NVARCHAR(50) NOT NULL,
        connection NVARCHAR(MAX) NOT NULL,
        status NVARCHAR(50) DEFAULT 'disconnected',
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- Models table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'models')
BEGIN
    CREATE TABLE models (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        type NVARCHAR(50) NOT NULL,
        algorithm NVARCHAR(100) NOT NULL,
        parameters NVARCHAR(MAX), -- JSON string
        metrics NVARCHAR(MAX), -- JSON string
        status NVARCHAR(50) DEFAULT 'draft',
        data_source_id INT,
        user_id INT,
        version NVARCHAR(20) DEFAULT '1.0.0',
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (data_source_id) REFERENCES data_sources(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- Pipelines table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'pipelines')
BEGIN
    CREATE TABLE pipelines (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        type NVARCHAR(50) NOT NULL,
        schedule NVARCHAR(100) NOT NULL,
        status NVARCHAR(50) DEFAULT 'draft',
        config NVARCHAR(MAX), -- JSON string
        user_id INT,
        last_run DATETIME,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- Activities table for logging
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'activities')
BEGIN
    CREATE TABLE activities (
        id INT IDENTITY(1,1) PRIMARY KEY,
        activity NVARCHAR(255) NOT NULL,
        pipeline NVARCHAR(100),
        status NVARCHAR(50) NOT NULL,
        user_id INT,
        timestamp DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- Integrations table for NiFi, Spark, Flink
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'integrations')
BEGIN
    CREATE TABLE integrations (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        type NVARCHAR(50) NOT NULL, -- 'nifi', 'spark', 'flink', etc.
        url NVARCHAR(255) NOT NULL,
        status NVARCHAR(50) DEFAULT 'disconnected',
        config NVARCHAR(MAX), -- JSON string with credentials and settings
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- Feature Store tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'features')
BEGIN
    CREATE TABLE features (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        description NVARCHAR(MAX),
        type NVARCHAR(50) NOT NULL, -- 'numerical', 'categorical', etc.
        source NVARCHAR(100) NOT NULL,
        validation_rules NVARCHAR(MAX),
        metadata NVARCHAR(MAX), -- JSON string with additional metadata
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'feature_sets')
BEGIN
    CREATE TABLE feature_sets (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        description NVARCHAR(MAX),
        version NVARCHAR(20) DEFAULT '1.0.0',
        status NVARCHAR(50) DEFAULT 'draft',
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'feature_set_mappings')
BEGIN
    CREATE TABLE feature_set_mappings (
        id INT IDENTITY(1,1) PRIMARY KEY,
        feature_set_id INT NOT NULL,
        feature_id INT NOT NULL,
        created_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (feature_set_id) REFERENCES feature_sets(id),
        FOREIGN KEY (feature_id) REFERENCES features(id),
        CONSTRAINT UQ_feature_set_mapping UNIQUE (feature_set_id, feature_id)
    );
END;

-- A/B Testing Experiments
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'experiments')
BEGIN
    CREATE TABLE experiments (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        description NVARCHAR(MAX),
        type NVARCHAR(50) NOT NULL, -- 'ab_test', 'canary', etc.
        status NVARCHAR(50) DEFAULT 'draft',
        config NVARCHAR(MAX), -- JSON string with experiment configuration
        results NVARCHAR(MAX), -- JSON string with experiment results
        start_date DATETIME,
        end_date DATETIME,
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- MLOps Automation tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'cicd_pipelines')
BEGIN
    CREATE TABLE cicd_pipelines (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        provider NVARCHAR(50) NOT NULL, -- 'github', 'gitlab', 'azure_devops', etc.
        repository_url NVARCHAR(255) NOT NULL,
        branch NVARCHAR(100) NOT NULL,
        config NVARCHAR(MAX), -- JSON string with CI/CD configuration
        status NVARCHAR(50) DEFAULT 'inactive',
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'approval_workflows')
BEGIN
    CREATE TABLE approval_workflows (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        description NVARCHAR(MAX),
        steps NVARCHAR(MAX), -- JSON string with approval steps
        status NVARCHAR(50) DEFAULT 'draft',
        model_id INT,
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (model_id) REFERENCES models(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- Reinforcement Learning tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'rl_agents')
BEGIN
    CREATE TABLE rl_agents (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        algorithm NVARCHAR(100) NOT NULL, -- 'dqn', 'ppo', 'a2c', etc.
        config NVARCHAR(MAX), -- JSON string with agent configuration
        metrics NVARCHAR(MAX), -- JSON string with performance metrics
        status NVARCHAR(50) DEFAULT 'draft',
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'rl_environments')
BEGIN
    CREATE TABLE rl_environments (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        type NVARCHAR(50) NOT NULL, -- 'custom', 'gym', 'unity', etc.
        config NVARCHAR(MAX), -- JSON string with environment configuration
        reward_function NVARCHAR(MAX), -- JSON string or code for reward function
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

-- Collaborative Features tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'comments')
BEGIN
    CREATE TABLE comments (
        id INT IDENTITY(1,1) PRIMARY KEY,
        entity_type NVARCHAR(50) NOT NULL, -- 'model', 'pipeline', 'experiment', etc.
        entity_id INT NOT NULL,
        content NVARCHAR(MAX) NOT NULL,
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'teams')
BEGIN
    CREATE TABLE teams (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        description NVARCHAR(MAX),
        created_by INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (created_by) REFERENCES users(id)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'team_members')
BEGIN
    CREATE TABLE team_members (
        id INT IDENTITY(1,1) PRIMARY KEY,
        team_id INT NOT NULL,
        user_id INT NOT NULL,
        role NVARCHAR(50) NOT NULL DEFAULT 'member', -- 'admin', 'member', etc.
        joined_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (team_id) REFERENCES teams(id),
        FOREIGN KEY (user_id) REFERENCES users(id),
        CONSTRAINT UQ_team_member UNIQUE (team_id, user_id)
    );
END;

-- Workflow Recommendation Wizard tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'workflow_recommendations')
BEGIN
    CREATE TABLE workflow_recommendations (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        description NVARCHAR(MAX),
        use_case NVARCHAR(100) NOT NULL,
        configuration NVARCHAR(MAX), -- JSON string with workflow configuration
        user_id INT,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'recommendation_templates')
BEGIN
    CREATE TABLE recommendation_templates (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        description NVARCHAR(MAX),
        category NVARCHAR(50) NOT NULL, -- 'classification', 'regression', 'clustering', etc.
        template NVARCHAR(MAX) NOT NULL, -- JSON string with template configuration
        is_active BIT DEFAULT 1,
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE()
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'user_workflow_preferences')
BEGIN
    CREATE TABLE user_workflow_preferences (
        id INT IDENTITY(1,1) PRIMARY KEY,
        user_id INT NOT NULL,
        preferences NVARCHAR(MAX) NOT NULL, -- JSON string with user preferences
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (user_id) REFERENCES users(id),
        CONSTRAINT UQ_user_preferences UNIQUE (user_id)
    );
END;

-- Algorithm Dependencies tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'algorithm_dependencies')
BEGIN
    CREATE TABLE algorithm_dependencies (
        id INT IDENTITY(1,1) PRIMARY KEY,
        name NVARCHAR(100) NOT NULL,
        version NVARCHAR(20) NOT NULL,
        package_manager NVARCHAR(20) NOT NULL, -- 'pip', 'npm', 'conda', etc.
        description NVARCHAR(MAX),
        documentation_url NVARCHAR(255),
        homepage_url NVARCHAR(255),
        source_url NVARCHAR(255),
        license NVARCHAR(100),
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        CONSTRAINT UQ_dependency_name_version UNIQUE (name, version)
    );
END;

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'algorithm_dependency_mappings')
BEGIN
    CREATE TABLE algorithm_dependency_mappings (
        id INT IDENTITY(1,1) PRIMARY KEY,
        algorithm_name NVARCHAR(100) NOT NULL,
        dependency_id INT NOT NULL,
        required_version NVARCHAR(50),
        created_at DATETIME DEFAULT GETDATE(),
        updated_at DATETIME DEFAULT GETDATE(),
        FOREIGN KEY (dependency_id) REFERENCES algorithm_dependencies(id),
        CONSTRAINT UQ_algorithm_dependency UNIQUE (algorithm_name, dependency_id)
    );

    -- Data Encoding Configuration Table
    IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'data_encoding_configs')
    BEGIN
        CREATE TABLE data_encoding_configs (
            id INT IDENTITY(1,1) PRIMARY KEY,
            name NVARCHAR(100) NOT NULL,
            description NVARCHAR(500) NULL,
            encoding_type NVARCHAR(50) NOT NULL, -- one-hot, label, target, binary, frequency, etc.
            source_column NVARCHAR(100) NOT NULL, -- column to encode
            config NVARCHAR(MAX) NOT NULL DEFAULT '{}', -- specific configuration options as JSON
            output_columns NVARCHAR(MAX) NULL, -- generated column names as JSON array
            data_source_id INT NULL,
            file_id INT NULL,
            user_id INT NULL,
            created_at DATETIME DEFAULT GETDATE(),
            updated_at DATETIME DEFAULT GETDATE(),
            status NVARCHAR(50) NOT NULL DEFAULT 'draft',
            FOREIGN KEY (data_source_id) REFERENCES data_sources(id),
            FOREIGN KEY (file_id) REFERENCES files(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    END;

    -- Data Encoding History Table
    IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'data_encoding_history')
    BEGIN
        CREATE TABLE data_encoding_history (
            id INT IDENTITY(1,1) PRIMARY KEY,
            config_id INT NOT NULL,
            applied_at DATETIME DEFAULT GETDATE(),
            status NVARCHAR(50) NOT NULL,
            results NVARCHAR(MAX) NOT NULL DEFAULT '{}', -- JSON results
            metrics NVARCHAR(MAX) NOT NULL DEFAULT '{}', -- JSON metrics
            user_id INT NULL,
            FOREIGN KEY (config_id) REFERENCES data_encoding_configs(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    END;
END;

-- Create admin user if not exists
IF NOT EXISTS (SELECT * FROM users WHERE username = 'admin')
BEGIN
    -- Password is 'admin123' hashed
    INSERT INTO users (username, email, password, role)
    VALUES ('admin', 'admin@aimlplaybook.com', '5906ac361a137cdd98f51682795360d1752a05eaef9d60c7b7353d1b69b276cec08e776a9bef1df8db0cb1923d91d8d56829f6ce1492ed67189e1234a70aefd6.723a80ab79f31c33', 'admin');
END;