import fs from 'fs';
import path from 'path';
import createSqlServerSchema from './create-sqlserver-schema';
import migrateData from './migrate-data';

/**
 * Script to perform complete migration from PostgreSQL to SQL Server
 * This will:
 * 1. Create SQL Server schema
 * 2. Migrate existing data
 * 3. Swap out the old files with new ones
 */
async function migrateToSqlServer() {
  try {
    console.log('Starting full migration to SQL Server...');
    
    // 1. Create SQL Server schema
    console.log('Creating SQL Server schema...');
    await createSqlServerSchema();
    
    // 2. Migrate data
    console.log('Migrating data from PostgreSQL to SQL Server...');
    await migrateData();
    
    // 3. Swap files
    console.log('Swapping PostgreSQL files with SQL Server files...');
    const filesToSwap = [
      { old: 'server/db.ts', new: 'server/db.ts.new' },
      { old: 'server/storage.ts', new: 'server/storage.ts.new' },
      { old: 'server/auth.ts', new: 'server/auth.ts.new' },
      { old: 'shared/schema.ts', new: 'shared/schema.ts.new' }
    ];
    
    // Backup original files
    for (const file of filesToSwap) {
      const backupPath = `${file.old}.bak`;
      if (fs.existsSync(file.old)) {
        fs.copyFileSync(file.old, backupPath);
        console.log(`Backed up ${file.old} to ${backupPath}`);
      }
    }
    
    // Swap new files in place of old ones
    for (const file of filesToSwap) {
      if (fs.existsSync(file.new)) {
        fs.copyFileSync(file.new, file.old);
        console.log(`Swapped ${file.new} to ${file.old}`);
      } else {
        console.warn(`Warning: New file ${file.new} does not exist`);
      }
    }
    
    console.log('Migration to SQL Server completed successfully!');
    console.log('Remember to restart the application for changes to take effect.');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
}

// Execute the migration script if run directly
if (require.main === module) {
  migrateToSqlServer()
    .then(() => {
      console.log('Full migration from PostgreSQL to SQL Server completed successfully');
      process.exit(0);
    })
    .catch(error => {
      console.error('Migration failed:', error);
      process.exit(1);
    });
}

export default migrateToSqlServer;