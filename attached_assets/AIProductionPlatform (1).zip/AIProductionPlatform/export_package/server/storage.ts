import { 
  type User, type InsertUser,
  type DataSource, type InsertDataSource,
  type Model, type InsertModel,
  type Pipeline, type InsertPipeline,
  type Activity, type InsertActivity,
  type Integration, type InsertIntegration,
  type Feature, type InsertFeature,
  type FeatureSet, type InsertFeatureSet,
  type FeatureSetMapping, type InsertFeatureSetMapping,
  type Experiment, type InsertExperiment,
  type File, type InsertFile,
  
  // MLOps Automation
  type CicdPipeline, type InsertCicdPipeline,
  type ApprovalWorkflow, type InsertApprovalWorkflow,
  
  // Reinforcement Learning
  type RlAgent, type InsertRlAgent,
  type RlEnvironment, type InsertRlEnvironment,
  
  // Collaborative Features
  type Comment, type InsertComment,
  type Team, type InsertTeam,
  type TeamMember, type InsertTeamMember,
  
  // Workflow Recommendation Wizard
  type WorkflowRecommendation, type InsertWorkflowRecommendation,
  type RecommendationTemplate, type InsertRecommendationTemplate,
  type UserWorkflowPreference, type InsertUserWorkflowPreference,
  
  // Algorithm Dependencies
  type AlgorithmDependency, type InsertAlgorithmDependency,
  type AlgorithmDependencyMapping, type InsertAlgorithmDependencyMapping,
  
  // Data Encoding
  type DataEncodingConfig, type InsertDataEncodingConfig,
  type DataEncodingHistory, type InsertDataEncodingHistory
} from "@shared/schema";
import { executeQuery, executeParameterizedQuery, executeInsert, executeUpdate, executeDelete } from "./db";
import session from "express-session";
import sql from 'mssql';
import createSessionsTable from './create-sessions-table.js';

// We'll use the SqlServerSessionStore class defined below

// Expand the interface with CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPassword(id: number, hashedPassword: string): Promise<User | undefined>;
  
  // Data source methods
  getDataSources(): Promise<DataSource[]>;
  getDataSource(id: number): Promise<DataSource | undefined>;
  createDataSource(dataSource: InsertDataSource): Promise<DataSource>;
  updateDataSource(id: number, dataSource: Partial<InsertDataSource>): Promise<DataSource | undefined>;
  deleteDataSource(id: number): Promise<boolean>;
  getDataSourceColumns(id: number): Promise<Array<{name: string, type: string}> | null>;
  getFilesByDataSourceId(dataSourceId: number): Promise<any[]>;
  
  // File methods
  getFiles(): Promise<File[]>;
  getFile(id: number): Promise<File | undefined>;
  createFile(file: InsertFile): Promise<File>;
  updateFile(id: number, file: Partial<InsertFile>): Promise<File | undefined>;
  deleteFile(id: number): Promise<boolean>;
  
  // Model methods
  getModels(): Promise<Model[]>;
  getModel(id: number): Promise<Model | undefined>;
  createModel(model: InsertModel): Promise<Model>;
  updateModel(id: number, model: Partial<InsertModel>): Promise<Model | undefined>;
  
  // Pipeline methods
  getPipelines(): Promise<Pipeline[]>;
  getPipeline(id: number): Promise<Pipeline | undefined>;
  createPipeline(pipeline: InsertPipeline): Promise<Pipeline>;
  updatePipeline(id: number, pipeline: Partial<InsertPipeline>): Promise<Pipeline | undefined>;
  
  // Activity methods
  getActivities(): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  
  // Integration methods
  getIntegrations(): Promise<Integration[]>;
  getIntegration(id: number): Promise<Integration | undefined>;
  getIntegrationsByType(type: string): Promise<Integration[]>;
  createIntegration(integration: InsertIntegration): Promise<Integration>;
  updateIntegration(id: number, integration: Partial<InsertIntegration>): Promise<Integration | undefined>;
  deleteIntegration(id: number): Promise<void>;
  
  // Feature store methods
  getFeatures(): Promise<Feature[]>;
  getFeature(id: number): Promise<Feature | undefined>;
  createFeature(feature: InsertFeature): Promise<Feature>;
  updateFeature(id: number, feature: Partial<InsertFeature>): Promise<Feature | undefined>;
  
  // Feature set methods
  getFeatureSets(): Promise<FeatureSet[]>;
  getFeatureSet(id: number): Promise<FeatureSet | undefined>;
  createFeatureSet(featureSet: InsertFeatureSet): Promise<FeatureSet>;
  addFeatureToSet(mapping: InsertFeatureSetMapping): Promise<FeatureSetMapping>;
  removeFeatureFromSet(featureSetId: number, featureId: number): Promise<void>;
  getFeaturesInSet(featureSetId: number): Promise<Feature[]>;
  
  // Experiment methods
  getExperiments(): Promise<Experiment[]>;
  getExperiment(id: number): Promise<Experiment | undefined>;
  createExperiment(experiment: InsertExperiment): Promise<Experiment>;
  updateExperiment(id: number, experiment: Partial<InsertExperiment>): Promise<Experiment | undefined>;
  
  // MLOps Automation - CI/CD Pipeline methods
  getCicdPipelines(): Promise<CicdPipeline[]>;
  getCicdPipeline(id: number): Promise<CicdPipeline | undefined>;
  createCicdPipeline(pipeline: InsertCicdPipeline): Promise<CicdPipeline>;
  updateCicdPipeline(id: number, pipeline: Partial<InsertCicdPipeline>): Promise<CicdPipeline | undefined>;
  deleteCicdPipeline(id: number): Promise<void>;
  
  // MLOps Automation - Approval Workflow methods
  getApprovalWorkflows(): Promise<ApprovalWorkflow[]>;
  getApprovalWorkflow(id: number): Promise<ApprovalWorkflow | undefined>;
  createApprovalWorkflow(workflow: InsertApprovalWorkflow): Promise<ApprovalWorkflow>;
  updateApprovalWorkflow(id: number, workflow: Partial<InsertApprovalWorkflow>): Promise<ApprovalWorkflow | undefined>;
  deleteApprovalWorkflow(id: number): Promise<void>;
  
  // Reinforcement Learning - Agent methods
  getRlAgents(): Promise<RlAgent[]>;
  getRlAgent(id: number): Promise<RlAgent | undefined>;
  createRlAgent(agent: InsertRlAgent): Promise<RlAgent>;
  updateRlAgent(id: number, agent: Partial<InsertRlAgent>): Promise<RlAgent | undefined>;
  deleteRlAgent(id: number): Promise<void>;
  
  // Reinforcement Learning - Environment methods
  getRlEnvironments(): Promise<RlEnvironment[]>;
  getRlEnvironment(id: number): Promise<RlEnvironment | undefined>;
  createRlEnvironment(environment: InsertRlEnvironment): Promise<RlEnvironment>;
  updateRlEnvironment(id: number, environment: Partial<InsertRlEnvironment>): Promise<RlEnvironment | undefined>;
  deleteRlEnvironment(id: number): Promise<void>;
  
  // Collaborative Features - Comment methods
  getComments(entityType: string, entityId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  updateComment(id: number, content: string): Promise<Comment | undefined>;
  deleteComment(id: number): Promise<void>;
  
  // Collaborative Features - Team methods
  getTeams(): Promise<Team[]>;
  getTeam(id: number): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: number, team: Partial<InsertTeam>): Promise<Team | undefined>;
  deleteTeam(id: number): Promise<void>;
  
  // Collaborative Features - Team Member methods
  getTeamMembers(teamId: number): Promise<TeamMember[]>;
  addTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  updateTeamMemberRole(teamId: number, userId: number, role: string): Promise<TeamMember | undefined>;
  removeTeamMember(teamId: number, userId: number): Promise<void>;
  
  // Workflow Recommendation Wizard methods
  getWorkflowRecommendations(): Promise<WorkflowRecommendation[]>;
  getWorkflowRecommendation(id: number): Promise<WorkflowRecommendation | undefined>;
  createWorkflowRecommendation(recommendation: InsertWorkflowRecommendation): Promise<WorkflowRecommendation>;
  updateWorkflowRecommendation(id: number, recommendation: Partial<InsertWorkflowRecommendation>): Promise<WorkflowRecommendation | undefined>;
  deleteWorkflowRecommendation(id: number): Promise<void>;
  
  // Recommendation Template methods
  getRecommendationTemplates(): Promise<RecommendationTemplate[]>;
  getRecommendationTemplate(id: number): Promise<RecommendationTemplate | undefined>;
  getRecommendationTemplatesByCategory(category: string): Promise<RecommendationTemplate[]>;
  createRecommendationTemplate(template: InsertRecommendationTemplate): Promise<RecommendationTemplate>;
  updateRecommendationTemplate(id: number, template: Partial<InsertRecommendationTemplate>): Promise<RecommendationTemplate | undefined>;
  deleteRecommendationTemplate(id: number): Promise<void>;
  
  // User Workflow Preferences methods
  getUserWorkflowPreference(userId: number): Promise<UserWorkflowPreference | undefined>;
  createUserWorkflowPreference(preference: InsertUserWorkflowPreference): Promise<UserWorkflowPreference>;
  updateUserWorkflowPreference(userId: number, preference: Partial<InsertUserWorkflowPreference>): Promise<UserWorkflowPreference | undefined>;
  
  // Algorithm Dependencies methods
  getAlgorithmDependencies(): Promise<AlgorithmDependency[]>;
  getAlgorithmDependency(id: number): Promise<AlgorithmDependency | undefined>;
  getDependencyByName(name: string): Promise<AlgorithmDependency | undefined>;
  createAlgorithmDependency(dependency: InsertAlgorithmDependency): Promise<AlgorithmDependency>;
  updateDependency(id: number, dependency: Partial<InsertAlgorithmDependency>): Promise<AlgorithmDependency | undefined>;
  deleteAlgorithmDependency(id: number): Promise<void>;
  
  // Algorithm Dependency Mappings methods
  getAlgorithmDependencyMappingsByAlgorithm(algorithmName: string): Promise<AlgorithmDependencyMapping[]>;
  createAlgorithmDependencyMapping(mapping: InsertAlgorithmDependencyMapping): Promise<AlgorithmDependencyMapping>;
  
  // Data Encoding methods
  getDataEncodingConfigs(): Promise<DataEncodingConfig[]>;
  getDataEncodingConfig(id: number): Promise<DataEncodingConfig | undefined>;
  createDataEncodingConfig(config: InsertDataEncodingConfig): Promise<DataEncodingConfig>;
  updateDataEncodingConfig(id: number, config: Partial<InsertDataEncodingConfig>): Promise<DataEncodingConfig | undefined>;
  deleteDataEncodingConfig(id: number): Promise<boolean>;
  getDataEncodingHistory(configId: number): Promise<DataEncodingHistory[]>;
  createDataEncodingHistory(history: InsertDataEncodingHistory): Promise<DataEncodingHistory>;
  deleteAlgorithmDependencyMapping(id: number): Promise<void>;
  
  // Session store for authentication
  sessionStore: session.Store;
}

// SQL Server session store with better error handling
class SqlServerSessionStore extends session.Store {
  constructor() {
    super();
    // Create the sessions table if it doesn't exist
    createSessionsTable().catch(err => {
      console.error('Failed to create sessions table:', err);
    });
  }

  async get(sid: string, callback: (err: any, session?: session.SessionData | null) => void) {
    try {
      console.log(`Getting session for sid: ${sid}`);
      const sessionData = await executeParameterizedQuery<{ session_data: string, expires: Date }>(
        `SELECT session_data, expires FROM sessions WHERE sid = @sid`,
        { sid }
      );

      if (!sessionData.length) {
        console.log(`No session found for sid: ${sid}`);
        return callback(null, null);
      }

      if (new Date() > new Date(sessionData[0].expires)) {
        console.log(`Session expired for sid: ${sid}`);
        // Delete expired session
        await executeParameterizedQuery(`DELETE FROM sessions WHERE sid = @sid`, { sid });
        return callback(null, null);
      }

      let sessionParsed;
      try {
        sessionParsed = JSON.parse(sessionData[0].session_data);
        console.log(`Successfully parsed session data for sid: ${sid}`);
      } catch (parseErr) {
        console.error(`Error parsing session data for sid: ${sid}`, parseErr);
        return callback(parseErr);
      }

      callback(null, sessionParsed);
    } catch (err) {
      console.error(`Error retrieving session for sid: ${sid}`, err);
      callback(err);
    }
  }

  async set(sid: string, session: session.SessionData, callback?: (err?: any) => void) {
    try {
      console.log(`Setting session for sid: ${sid}`);
      const expires = new Date(Date.now() + (session.cookie?.originalMaxAge || 86400000));
      const sessionData = JSON.stringify(session);

      // Try simpler approach with separate insert/update to avoid MERGE issues
      const existingSession = await executeParameterizedQuery(
        `SELECT sid FROM sessions WHERE sid = @sid`,
        { sid }
      );

      if (existingSession.length) {
        await executeParameterizedQuery(
          `UPDATE sessions SET session_data = @sessionData, expires = @expires WHERE sid = @sid`,
          { sid, sessionData, expires }
        );
        console.log(`Session updated for sid: ${sid}`);
      } else {
        await executeParameterizedQuery(
          `INSERT INTO sessions (sid, session_data, expires) VALUES (@sid, @sessionData, @expires)`,
          { sid, sessionData, expires }
        );
        console.log(`Session created for sid: ${sid}`);
      }

      if (callback) callback();
    } catch (err) {
      console.error(`Error setting session for sid: ${sid}`, err);
      if (callback) callback(err);
    }
  }

  async destroy(sid: string, callback?: (err?: any) => void) {
    try {
      console.log(`Destroying session for sid: ${sid}`);
      await executeParameterizedQuery(
        `DELETE FROM sessions WHERE sid = @sid`,
        { sid }
      );
      console.log(`Session destroyed for sid: ${sid}`);
      if (callback) callback();
    } catch (err) {
      console.error(`Error destroying session for sid: ${sid}`, err);
      if (callback) callback(err);
    }
  }

  async touch(sid: string, session: session.SessionData, callback?: (err?: any) => void) {
    try {
      console.log(`Touching session for sid: ${sid}`);
      const expires = new Date(Date.now() + (session.cookie?.originalMaxAge || 86400000));
      
      await executeParameterizedQuery(
        `UPDATE sessions SET expires = @expires WHERE sid = @sid`,
        { sid, expires }
      );
      console.log(`Session touched for sid: ${sid}`);
      if (callback) callback();
    } catch (err) {
      console.error(`Error touching session for sid: ${sid}`, err);
      if (callback) callback(err);
    }
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    // Initialize database connection and session store
    this.sessionStore = new SqlServerSessionStore();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const users = await executeParameterizedQuery<User>(
      `SELECT * FROM users WHERE id = @id`,
      { id }
    );
    return users[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await executeParameterizedQuery<User>(
      `SELECT * FROM users WHERE username = @username`,
      { username }
    );
    return users[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user = await executeInsert<User>('users', insertUser);
    if (!user) throw new Error('Failed to create user');
    return user;
  }
  
  async updateUserPassword(id: number, hashedPassword: string): Promise<User | undefined> {
    return await executeUpdate<User>(
      'users',
      { password: hashedPassword },
      'id = @id',
      { id }
    );
  }
  
  // Data source methods
  async getDataSources(): Promise<DataSource[]> {
    return await executeQuery<DataSource>(`SELECT * FROM data_sources`);
  }
  
  async getDataSource(id: number): Promise<DataSource | undefined> {
    const dataSources = await executeParameterizedQuery<DataSource>(
      `SELECT * FROM data_sources WHERE id = @id`,
      { id }
    );
    return dataSources[0];
  }
  
  async createDataSource(dataSource: InsertDataSource): Promise<DataSource> {
    const newDataSource = await executeInsert<DataSource>('data_sources', dataSource);
    if (!newDataSource) throw new Error('Failed to create data source');
    return newDataSource;
  }
  
  async updateDataSource(id: number, dataSource: Partial<InsertDataSource>): Promise<DataSource | undefined> {
    const updatedDataSource = await executeUpdate<DataSource>(
      'data_sources',
      dataSource,
      'id = @id',
      { id }
    );
    return updatedDataSource;
  }
  
  async deleteDataSource(id: number): Promise<boolean> {
    const result = await executeDelete('data_sources', 'id = @id', { id });
    return result > 0;
  }
  
  async getDataSourceColumns(id: number): Promise<Array<{name: string, type: string}> | null> {
    // Check data source type
    const dataSource = await this.getDataSource(id);
    if (!dataSource) return null;
    
    if (dataSource.type === 'database' || dataSource.type === 'sql') {
      // For database sources, query from the system catalog/schema
      // Here we're returning a realistic set of sample columns for SQL database sources
      // In a real implementation, we'd query the database schema
      try {
        // For SQL Server, we could query information_schema.columns
        // This is a simplified example
        return [
          { name: "id", type: "int" },
          { name: "name", type: "varchar" },
          { name: "description", type: "text" },
          { name: "created_at", type: "datetime" },
          { name: "status", type: "varchar" },
          { name: "price", type: "decimal" },
          { name: "quantity", type: "int" },
          { name: "category", type: "varchar" }
        ];
      } catch (error) {
        console.error('Error fetching columns from database source:', error);
        return null;
      }
    } else {
      // For file-based sources, try to get from the associated file
      const files = await this.getFilesByDataSourceId(id);
      if (!files || files.length === 0) return null;
      
      const file = files[0]; // Just use the first file
      
      // In reality, we would parse the file and extract schema information
      // For now, return sample columns based on format
      if (file.format === 'csv') {
        return [
          { name: "id", type: "integer" },
          { name: "name", type: "string" },
          { name: "email", type: "string" },
          { name: "age", type: "integer" },
          { name: "category", type: "string" },
          { name: "score", type: "float" }
        ];
      } else if (file.format === 'json' || file.format === 'parquet') {
        return [
          { name: "id", type: "integer" },
          { name: "name", type: "string" },
          { name: "properties", type: "object" },
          { name: "metadata", type: "object" },
          { name: "tags", type: "array" }
        ];
      }
    }
    
    return null;
  }
  
  async getFilesByDataSourceId(dataSourceId: number): Promise<any[]> {
    // In real implementation, we'd query the files table for entries linked to this data source
    try {
      return await executeParameterizedQuery(
        'SELECT * FROM files WHERE data_source_id = @dataSourceId',
        { dataSourceId }
      );
    } catch (error) {
      console.error('Error fetching files for data source:', error);
      return [];
    }
  }
  
  // File methods
  async getFiles(): Promise<File[]> {
    return await executeQuery<File>('SELECT * FROM files');
  }
  
  async getFile(id: number): Promise<File | undefined> {
    const files = await executeParameterizedQuery<File>(
      'SELECT * FROM files WHERE id = @id',
      { id }
    );
    return files[0];
  }
  
  async createFile(file: InsertFile): Promise<File> {
    const newFile = await executeInsert<File>('files', file);
    if (!newFile) throw new Error('Failed to create file');
    return newFile;
  }
  
  async updateFile(id: number, file: Partial<InsertFile>): Promise<File | undefined> {
    const updatedFile = await executeUpdate<File>(
      'files',
      file,
      'id = @id',
      { id }
    );
    return updatedFile;
  }
  
  async deleteFile(id: number): Promise<boolean> {
    const result = await executeDelete('files', 'id = @id', { id });
    return result > 0;
  }
  
  // Model methods
  async getModels(): Promise<Model[]> {
    return await executeQuery<Model>(`SELECT * FROM models`);
  }
  
  async getModel(id: number): Promise<Model | undefined> {
    const models = await executeParameterizedQuery<Model>(
      `SELECT * FROM models WHERE id = @id`,
      { id }
    );
    return models[0];
  }
  
  async createModel(model: InsertModel): Promise<Model> {
    // Convert JSON objects to strings for SQL Server
    const processedModel = {
      ...model,
      parameters: typeof model.parameters === 'object' ? JSON.stringify(model.parameters) : model.parameters,
      metrics: typeof model.metrics === 'object' ? JSON.stringify(model.metrics) : model.metrics
    };
    
    const newModel = await executeInsert<Model>('models', processedModel);
    if (!newModel) throw new Error('Failed to create model');
    return newModel;
  }
  
  async updateModel(id: number, model: Partial<InsertModel>): Promise<Model | undefined> {
    // Convert JSON objects to strings for SQL Server
    const processedModel = { ...model };
    if (model.parameters && typeof model.parameters === 'object') {
      processedModel.parameters = JSON.stringify(model.parameters);
    }
    if (model.metrics && typeof model.metrics === 'object') {
      processedModel.metrics = JSON.stringify(model.metrics);
    }
    
    return await executeUpdate<Model>(
      'models',
      processedModel,
      'id = @id',
      { id }
    );
  }
  
  // Pipeline methods
  async getPipelines(): Promise<Pipeline[]> {
    return await executeQuery<Pipeline>(`SELECT * FROM pipelines`);
  }
  
  async getPipeline(id: number): Promise<Pipeline | undefined> {
    const pipelines = await executeParameterizedQuery<Pipeline>(
      `SELECT * FROM pipelines WHERE id = @id`,
      { id }
    );
    return pipelines[0];
  }
  
  async createPipeline(pipeline: InsertPipeline): Promise<Pipeline> {
    // Convert JSON objects to strings for SQL Server
    const processedPipeline = {
      ...pipeline,
      config: typeof pipeline.config === 'object' ? JSON.stringify(pipeline.config) : pipeline.config
    };
    
    const newPipeline = await executeInsert<Pipeline>('pipelines', processedPipeline);
    if (!newPipeline) throw new Error('Failed to create pipeline');
    return newPipeline;
  }
  
  async updatePipeline(id: number, pipeline: Partial<InsertPipeline>): Promise<Pipeline | undefined> {
    // Convert JSON objects to strings for SQL Server
    const processedPipeline = { ...pipeline };
    if (pipeline.config && typeof pipeline.config === 'object') {
      processedPipeline.config = JSON.stringify(pipeline.config);
    }
    
    return await executeUpdate<Pipeline>(
      'pipelines',
      processedPipeline,
      'id = @id',
      { id }
    );
  }
  
  // Activity methods
  async getActivities(): Promise<Activity[]> {
    return await executeQuery<Activity>(`SELECT * FROM activities ORDER BY timestamp DESC`);
  }
  
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const newActivity = await executeInsert<Activity>('activities', activity);
    if (!newActivity) throw new Error('Failed to create activity');
    return newActivity;
  }
  
  // Integration methods for NiFi, Spark, Flink
  async getIntegrations(): Promise<Integration[]> {
    return await executeQuery<Integration>(`SELECT * FROM integrations`);
  }
  
  async getIntegration(id: number): Promise<Integration | undefined> {
    const integrations = await executeParameterizedQuery<Integration>(
      `SELECT * FROM integrations WHERE id = @id`,
      { id }
    );
    return integrations[0];
  }
  
  async getIntegrationsByType(type: string): Promise<Integration[]> {
    return await executeParameterizedQuery<Integration>(
      `SELECT * FROM integrations WHERE type = @type`,
      { type }
    );
  }
  
  async createIntegration(integration: InsertIntegration): Promise<Integration> {
    // Convert JSON objects to strings for SQL Server if needed
    const processedIntegration = {
      ...integration,
      config: typeof integration.config === 'object' ? JSON.stringify(integration.config) : integration.config
    };
    
    const newIntegration = await executeInsert<Integration>('integrations', processedIntegration);
    if (!newIntegration) throw new Error('Failed to create integration');
    return newIntegration;
  }
  
  async updateIntegration(id: number, integration: Partial<InsertIntegration>): Promise<Integration | undefined> {
    // Convert JSON objects to strings for SQL Server if needed
    const processedIntegration = { ...integration };
    if (integration.config && typeof integration.config === 'object') {
      processedIntegration.config = JSON.stringify(integration.config);
    }
    
    return await executeUpdate<Integration>(
      'integrations',
      processedIntegration,
      'id = @id',
      { id }
    );
  }
  
  async deleteIntegration(id: number): Promise<void> {
    await executeDelete('integrations', 'id = @id', { id });
  }
  
  // Feature store methods
  async getFeatures(): Promise<Feature[]> {
    return await executeQuery<Feature>(`SELECT * FROM features`);
  }
  
  async getFeature(id: number): Promise<Feature | undefined> {
    const features = await executeParameterizedQuery<Feature>(
      `SELECT * FROM features WHERE id = @id`,
      { id }
    );
    return features[0];
  }
  
  async createFeature(feature: InsertFeature): Promise<Feature> {
    // Convert JSON objects to strings for SQL Server if needed
    const processedFeature = {
      ...feature,
      metadata: typeof feature.metadata === 'object' ? JSON.stringify(feature.metadata) : feature.metadata
    };
    
    const newFeature = await executeInsert<Feature>('features', processedFeature);
    if (!newFeature) throw new Error('Failed to create feature');
    return newFeature;
  }
  
  async updateFeature(id: number, feature: Partial<InsertFeature>): Promise<Feature | undefined> {
    // Convert JSON objects to strings for SQL Server if needed
    const processedFeature = { ...feature };
    if (feature.metadata && typeof feature.metadata === 'object') {
      processedFeature.metadata = JSON.stringify(feature.metadata);
    }
    
    return await executeUpdate<Feature>(
      'features',
      processedFeature,
      'id = @id',
      { id }
    );
  }
  
  // Feature set methods
  async getFeatureSets(): Promise<FeatureSet[]> {
    return await executeQuery<FeatureSet>(`SELECT * FROM feature_sets`);
  }
  
  async getFeatureSet(id: number): Promise<FeatureSet | undefined> {
    const featureSets = await executeParameterizedQuery<FeatureSet>(
      `SELECT * FROM feature_sets WHERE id = @id`,
      { id }
    );
    return featureSets[0];
  }
  
  async createFeatureSet(featureSet: InsertFeatureSet): Promise<FeatureSet> {
    const newFeatureSet = await executeInsert<FeatureSet>('feature_sets', featureSet);
    if (!newFeatureSet) throw new Error('Failed to create feature set');
    return newFeatureSet;
  }
  
  async addFeatureToSet(mapping: InsertFeatureSetMapping): Promise<FeatureSetMapping> {
    const newMapping = await executeInsert<FeatureSetMapping>('feature_set_mappings', mapping);
    if (!newMapping) throw new Error('Failed to add feature to set');
    return newMapping;
  }
  
  async removeFeatureFromSet(featureSetId: number, featureId: number): Promise<void> {
    await executeDelete(
      'feature_set_mappings', 
      'feature_set_id = @featureSetId AND feature_id = @featureId',
      { featureSetId, featureId }
    );
  }
  
  async getFeaturesInSet(featureSetId: number): Promise<Feature[]> {
    const features = await executeParameterizedQuery<Feature>(
      `SELECT f.* FROM features f 
       JOIN feature_set_mappings m ON f.id = m.feature_id 
       WHERE m.feature_set_id = @featureSetId`,
      { featureSetId }
    );
    
    return features;
  }
  
  // Experiment methods for A/B testing
  async getExperiments(): Promise<Experiment[]> {
    return await executeQuery<Experiment>(`SELECT * FROM experiments`);
  }
  
  async getExperiment(id: number): Promise<Experiment | undefined> {
    const experiments = await executeParameterizedQuery<Experiment>(
      `SELECT * FROM experiments WHERE id = @id`,
      { id }
    );
    return experiments[0];
  }
  
  async createExperiment(experiment: InsertExperiment): Promise<Experiment> {
    // Convert JSON objects to strings for SQL Server if needed
    const processedExperiment = {
      ...experiment,
      config: typeof experiment.config === 'object' ? JSON.stringify(experiment.config) : experiment.config,
      results: typeof experiment.results === 'object' ? JSON.stringify(experiment.results) : experiment.results
    };
    
    const newExperiment = await executeInsert<Experiment>('experiments', processedExperiment);
    if (!newExperiment) throw new Error('Failed to create experiment');
    return newExperiment;
  }
  
  async updateExperiment(id: number, experiment: Partial<InsertExperiment>): Promise<Experiment | undefined> {
    // Convert JSON objects to strings for SQL Server if needed
    const processedExperiment = { ...experiment };
    if (experiment.config && typeof experiment.config === 'object') {
      processedExperiment.config = JSON.stringify(experiment.config);
    }
    if (experiment.results && typeof experiment.results === 'object') {
      processedExperiment.results = JSON.stringify(experiment.results);
    }
    
    return await executeUpdate<Experiment>(
      'experiments',
      processedExperiment,
      'id = @id',
      { id }
    );
  }

  // Workflow Recommendation Wizard methods
  async getWorkflowRecommendations(): Promise<WorkflowRecommendation[]> {
    return await db.select().from(workflowRecommendations).orderBy(desc(workflowRecommendations.createdAt));
  }

  async getWorkflowRecommendation(id: number): Promise<WorkflowRecommendation | undefined> {
    const [recommendation] = await db.select().from(workflowRecommendations).where(eq(workflowRecommendations.id, id));
    return recommendation;
  }

  async createWorkflowRecommendation(recommendation: InsertWorkflowRecommendation): Promise<WorkflowRecommendation> {
    const [newRecommendation] = await db.insert(workflowRecommendations).values(recommendation).returning();
    return newRecommendation;
  }

  async updateWorkflowRecommendation(id: number, recommendation: Partial<InsertWorkflowRecommendation>): Promise<WorkflowRecommendation | undefined> {
    const [updatedRecommendation] = await db
      .update(workflowRecommendations)
      .set({ ...recommendation, updatedAt: new Date() })
      .where(eq(workflowRecommendations.id, id))
      .returning();
    return updatedRecommendation;
  }

  async deleteWorkflowRecommendation(id: number): Promise<void> {
    await db.delete(workflowRecommendations).where(eq(workflowRecommendations.id, id));
  }

  // Recommendation Template methods
  async getRecommendationTemplates(): Promise<RecommendationTemplate[]> {
    return await db.select().from(recommendationTemplates).where(eq(recommendationTemplates.isActive, true));
  }

  async getRecommendationTemplate(id: number): Promise<RecommendationTemplate | undefined> {
    const [template] = await db.select().from(recommendationTemplates).where(eq(recommendationTemplates.id, id));
    return template;
  }

  async getRecommendationTemplatesByCategory(category: string): Promise<RecommendationTemplate[]> {
    return await db
      .select()
      .from(recommendationTemplates)
      .where(and(
        eq(recommendationTemplates.category, category),
        eq(recommendationTemplates.isActive, true)
      ));
  }

  async createRecommendationTemplate(template: InsertRecommendationTemplate): Promise<RecommendationTemplate> {
    const [newTemplate] = await db.insert(recommendationTemplates).values(template).returning();
    return newTemplate;
  }

  async updateRecommendationTemplate(id: number, template: Partial<InsertRecommendationTemplate>): Promise<RecommendationTemplate | undefined> {
    const [updatedTemplate] = await db
      .update(recommendationTemplates)
      .set({ ...template, updatedAt: new Date() })
      .where(eq(recommendationTemplates.id, id))
      .returning();
    return updatedTemplate;
  }

  async deleteRecommendationTemplate(id: number): Promise<void> {
    await db.delete(recommendationTemplates).where(eq(recommendationTemplates.id, id));
  }

  // User Workflow Preferences methods
  async getUserWorkflowPreference(userId: number): Promise<UserWorkflowPreference | undefined> {
    const [preference] = await db
      .select()
      .from(userWorkflowPreferences)
      .where(eq(userWorkflowPreferences.userId, userId));
    return preference;
  }

  async createUserWorkflowPreference(preference: InsertUserWorkflowPreference): Promise<UserWorkflowPreference> {
    const [newPreference] = await db.insert(userWorkflowPreferences).values(preference).returning();
    return newPreference;
  }

  async updateUserWorkflowPreference(userId: number, preference: Partial<InsertUserWorkflowPreference>): Promise<UserWorkflowPreference | undefined> {
    const [updatedPreference] = await db
      .update(userWorkflowPreferences)
      .set({ ...preference, updatedAt: new Date() })
      .where(eq(userWorkflowPreferences.userId, userId))
      .returning();
    return updatedPreference;
  }

  // Algorithm Dependencies methods
  async getAlgorithmDependencies(): Promise<AlgorithmDependency[]> {
    return await executeQuery<AlgorithmDependency>('SELECT * FROM algorithm_dependencies');
  }
  
  async getAlgorithmDependency(id: number): Promise<AlgorithmDependency | undefined> {
    const dependencies = await executeParameterizedQuery<AlgorithmDependency>(
      'SELECT * FROM algorithm_dependencies WHERE id = @id',
      { id }
    );
    return dependencies.length > 0 ? dependencies[0] : undefined;
  }
  
  async getDependencyByName(name: string): Promise<AlgorithmDependency | undefined> {
    const dependencies = await executeParameterizedQuery<AlgorithmDependency>(
      'SELECT * FROM algorithm_dependencies WHERE name = @name',
      { name }
    );
    return dependencies.length > 0 ? dependencies[0] : undefined;
  }
  
  async createAlgorithmDependency(dependency: InsertAlgorithmDependency): Promise<AlgorithmDependency> {
    // Convert camelCase to snake_case for SQL Server
    const data = {
      name: dependency.name,
      version: dependency.version,
      package_manager: dependency.packageManager,
      category: dependency.category,
      description: dependency.description,
      created_at: new Date(),
      updated_at: new Date()
    };
    
    const newDependency = await executeInsert<AlgorithmDependency>('algorithm_dependencies', data);
    if (!newDependency) throw new Error('Failed to create algorithm dependency');
    return newDependency;
  }
  
  async updateDependency(id: number, dependency: Partial<InsertAlgorithmDependency>): Promise<AlgorithmDependency | undefined> {
    // Convert camelCase to snake_case for SQL Server
    const data: any = { updated_at: new Date() };
    if (dependency.name) data.name = dependency.name;
    if (dependency.version) data.version = dependency.version;
    if (dependency.packageManager) data.package_manager = dependency.packageManager;
    if (dependency.category) data.category = dependency.category;
    if (dependency.description) data.description = dependency.description;
    
    const updatedDependency = await executeUpdate<AlgorithmDependency>(
      'algorithm_dependencies',
      data,
      'id = @id',
      { id }
    );
    return updatedDependency;
  }
  
  async updateAlgorithmDependency(id: number, dependency: Partial<InsertAlgorithmDependency>): Promise<AlgorithmDependency | undefined> {
    return this.updateDependency(id, dependency);
  }
  
  async deleteAlgorithmDependency(id: number): Promise<void> {
    await executeDelete('algorithm_dependencies', 'id = @id', { id });
  }
  
  // Algorithm Dependency Mappings methods
  async getAlgorithmDependencyMappingsByAlgorithm(algorithmName: string): Promise<AlgorithmDependencyMapping[]> {
    return await executeParameterizedQuery<AlgorithmDependencyMapping>(
      'SELECT * FROM algorithm_dependency_mappings WHERE algorithm_name = @algorithmName',
      { algorithmName }
    );
  }
  
  async createAlgorithmDependencyMapping(mapping: InsertAlgorithmDependencyMapping): Promise<AlgorithmDependencyMapping> {
    // Convert camelCase to snake_case for SQL Server
    const data = {
      algorithm_name: mapping.algorithmName,
      dependency_id: mapping.dependencyId,
      required: mapping.required !== undefined ? mapping.required : true,
      created_at: new Date(),
      updated_at: new Date()
    };
    
    const newMapping = await executeInsert<AlgorithmDependencyMapping>('algorithm_dependency_mappings', data);
    if (!newMapping) throw new Error('Failed to create algorithm dependency mapping');
    return newMapping;
  }
  
  async deleteAlgorithmDependencyMapping(id: number): Promise<void> {
    await executeDelete('algorithm_dependency_mappings', 'id = @id', { id });
  }
  
  // Data Encoding methods
  async getDataEncodingConfigs(): Promise<DataEncodingConfig[]> {
    return await executeQuery<DataEncodingConfig>('SELECT * FROM data_encoding_configs ORDER BY created_at DESC');
  }

  async getDataEncodingConfig(id: number): Promise<DataEncodingConfig | undefined> {
    const results = await executeParameterizedQuery<DataEncodingConfig>(
      'SELECT * FROM data_encoding_configs WHERE id = @id',
      { id }
    );
    return results.length > 0 ? results[0] : undefined;
  }

  async createDataEncodingConfig(config: InsertDataEncodingConfig): Promise<DataEncodingConfig> {
    return await executeInsert<DataEncodingConfig>('data_encoding_configs', {
      ...config,
      createdAt: new Date(),
      updatedAt: new Date()
    });
  }

  async updateDataEncodingConfig(
    id: number, 
    config: Partial<InsertDataEncodingConfig>
  ): Promise<DataEncodingConfig | undefined> {
    return await executeUpdate<DataEncodingConfig>(
      'data_encoding_configs',
      { ...config, updatedAt: new Date() },
      'id = @id',
      { id }
    );
  }

  async deleteDataEncodingConfig(id: number): Promise<boolean> {
    try {
      // First delete any history records associated with this config
      await executeDelete('data_encoding_history', 'config_id = @id', { id });
      
      // Then delete the config itself
      await executeDelete('data_encoding_configs', 'id = @id', { id });
      return true;
    } catch (error) {
      console.error('Error deleting data encoding config:', error);
      return false;
    }
  }

  async getDataEncodingHistory(configId: number): Promise<DataEncodingHistory[]> {
    return await executeParameterizedQuery<DataEncodingHistory>(
      'SELECT * FROM data_encoding_history WHERE config_id = @configId ORDER BY applied_at DESC',
      { configId }
    );
  }

  async createDataEncodingHistory(history: InsertDataEncodingHistory): Promise<DataEncodingHistory> {
    return await executeInsert<DataEncodingHistory>('data_encoding_history', {
      ...history,
      appliedAt: new Date()
    });
  }
}

// Export database storage implementation
export const storage = new DatabaseStorage();
