import { getPool } from './db';

async function createSessionsTable() {
  try {
    console.log('Creating sessions table if not exists...');
    const pool = await getPool();
    
    // NVARCHAR(MAX) is SQL Server specific, not PostgreSQL
    const createTableQuery = `
      IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'sessions')
      BEGIN
        CREATE TABLE sessions (
          sid NVARCHAR(255) PRIMARY KEY,
          session_data NVARCHAR(MAX) NOT NULL,
          expires DATETIME NOT NULL
        )
        CREATE INDEX idx_sessions_expires ON sessions (expires)
        PRINT 'Sessions table created successfully'
      END
      ELSE
      BEGIN
        PRINT 'Sessions table already exists'
      END
    `;
    
    await pool.request().query(createTableQuery);
    console.log('Sessions table check/creation completed');
  } catch (error) {
    console.error('Error creating sessions table:', error);
    throw error;
  }
}

// For ES modules, we can't use require.main === module
// If you want to run this file directly with tsx, use:
// import { fileURLToPath } from 'url';
// const isMainModule = process.argv[1] === fileURLToPath(import.meta.url);

// For now, we'll just export the function

export default createSessionsTable;