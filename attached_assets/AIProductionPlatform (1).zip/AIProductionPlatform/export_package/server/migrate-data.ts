import { db as pgDb } from './db';
import { executeQuery, executeInsert, getPool } from './db.ts.new';
import createSqlServerSchema from './create-sqlserver-schema';
import sql from 'mssql';

/**
 * Migrate data from PostgreSQL to SQL Server
 * This script will:
 * 1. Create the SQL Server schema
 * 2. Read data from PostgreSQL
 * 3. Insert data into SQL Server
 */
async function migrateData() {
  try {
    console.log('Starting migration from PostgreSQL to SQL Server...');
    
    // 1. Create SQL Server schema
    console.log('Setting up SQL Server schema...');
    await createSqlServerSchema();
    
    // 2. Get connection to SQL Server
    const sqlPool = await getPool();
    
    // 3. Migrate each table
    await migrateUsers();
    await migrateDataSources();
    await migrateAlgorithmDependencies();
    await migrateAlgorithmDependencyMappings();
    await migrateModels();
    await migratePipelines();
    await migrateActivities();
    
    console.log('Migration completed successfully!');
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
}

// Helper function to process JSON data
function processJsonData(data: any): any {
  if (!data) return null;
  if (typeof data === 'object') {
    return JSON.stringify(data);
  }
  return data;
}

// Migrate users
async function migrateUsers() {
  try {
    console.log('Migrating users...');
    const users = await pgDb.query.users.findMany();
    
    for (const user of users) {
      await executeInsert('users', {
        id: user.id,  // Keep the same IDs
        username: user.username,
        password: user.password,
        email: user.email,
        role: user.role
      });
    }
    
    console.log(`Migrated ${users.length} users`);
  } catch (error) {
    console.error('Error migrating users:', error);
    throw error;
  }
}

// Migrate data sources
async function migrateDataSources() {
  try {
    console.log('Migrating data sources...');
    const dataSources = await pgDb.query.dataSources.findMany();
    
    for (const dataSource of dataSources) {
      await executeInsert('data_sources', {
        id: dataSource.id,  // Keep the same IDs
        name: dataSource.name,
        type: dataSource.type,
        connection: dataSource.connection,
        status: dataSource.status,
        config: processJsonData(dataSource.config),
        user_id: dataSource.userId,
        created_at: dataSource.createdAt,
        updated_at: dataSource.updatedAt
      });
    }
    
    console.log(`Migrated ${dataSources.length} data sources`);
  } catch (error) {
    console.error('Error migrating data sources:', error);
    throw error;
  }
}

// Migrate algorithm dependencies
async function migrateAlgorithmDependencies() {
  try {
    console.log('Migrating algorithm dependencies...');
    const dependencies = await pgDb.query.algorithmDependencies.findMany();
    
    for (const dependency of dependencies) {
      await executeInsert('algorithm_dependencies', {
        id: dependency.id,  // Keep the same IDs
        name: dependency.name,
        version: dependency.version,
        package_manager: dependency.packageManager,
        category: dependency.category,
        description: dependency.description,
        created_at: dependency.createdAt,
        updated_at: dependency.updatedAt
      });
    }
    
    console.log(`Migrated ${dependencies.length} algorithm dependencies`);
  } catch (error) {
    console.error('Error migrating algorithm dependencies:', error);
    throw error;
  }
}

// Migrate algorithm dependency mappings
async function migrateAlgorithmDependencyMappings() {
  try {
    console.log('Migrating algorithm dependency mappings...');
    const mappings = await pgDb.query.algorithmDependencyMappings.findMany();
    
    for (const mapping of mappings) {
      await executeInsert('algorithm_dependency_mappings', {
        id: mapping.id,  // Keep the same IDs
        algorithm_name: mapping.algorithmName,
        dependency_id: mapping.dependencyId,
        required: mapping.required,
        created_at: mapping.createdAt,
        updated_at: mapping.updatedAt
      });
    }
    
    console.log(`Migrated ${mappings.length} algorithm dependency mappings`);
  } catch (error) {
    console.error('Error migrating algorithm dependency mappings:', error);
    throw error;
  }
}

// Migrate models
async function migrateModels() {
  try {
    console.log('Migrating models...');
    const models = await pgDb.query.models.findMany();
    
    for (const model of models) {
      await executeInsert('models', {
        id: model.id,  // Keep the same IDs
        name: model.name,
        type: model.type,
        algorithm: model.algorithm,
        parameters: processJsonData(model.parameters),
        metrics: processJsonData(model.metrics),
        status: model.status,
        data_source_id: model.dataSourceId,
        user_id: model.userId,
        version: model.version,
        dependencies_installed: model.dependenciesInstalled,
        created_at: model.createdAt,
        updated_at: model.updatedAt
      });
    }
    
    console.log(`Migrated ${models.length} models`);
  } catch (error) {
    console.error('Error migrating models:', error);
    throw error;
  }
}

// Migrate pipelines
async function migratePipelines() {
  try {
    console.log('Migrating pipelines...');
    const pipelines = await pgDb.query.pipelines.findMany();
    
    for (const pipeline of pipelines) {
      await executeInsert('pipelines', {
        id: pipeline.id,  // Keep the same IDs
        name: pipeline.name,
        type: pipeline.type,
        schedule: pipeline.schedule,
        status: pipeline.status,
        config: processJsonData(pipeline.config),
        user_id: pipeline.userId,
        created_at: pipeline.createdAt,
        last_run: pipeline.lastRun
      });
    }
    
    console.log(`Migrated ${pipelines.length} pipelines`);
  } catch (error) {
    console.error('Error migrating pipelines:', error);
    throw error;
  }
}

// Migrate activities
async function migrateActivities() {
  try {
    console.log('Migrating activities...');
    const activities = await pgDb.query.activities.findMany();
    
    for (const activity of activities) {
      await executeInsert('activities', {
        id: activity.id,  // Keep the same IDs
        activity: activity.activity,
        pipeline: activity.pipeline,
        status: activity.status,
        timestamp: activity.timestamp,
        user_id: activity.userId
      });
    }
    
    console.log(`Migrated ${activities.length} activities`);
  } catch (error) {
    console.error('Error migrating activities:', error);
    throw error;
  }
}

// Execute the migration script if run directly
if (require.main === module) {
  migrateData()
    .then(() => {
      console.log('Migration from PostgreSQL to SQL Server completed successfully');
      process.exit(0);
    })
    .catch(error => {
      console.error('Migration failed:', error);
      process.exit(1);
    });
}

export default migrateData;